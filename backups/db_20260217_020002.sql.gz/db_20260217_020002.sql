--
-- PostgreSQL database dump
--

\restrict NGDxBedIbUxKG3wrbENdTAiDl7klrOhpKKeDw6HwPT8fgbTR5uhUjDbT3BJ2jGV

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "users_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.timeline_events DROP CONSTRAINT IF EXISTS "timeline_events_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.timeline_events DROP CONSTRAINT IF EXISTS "timeline_events_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.tenant_settings DROP CONSTRAINT IF EXISTS "tenant_settings_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.templates DROP CONSTRAINT IF EXISTS "templates_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.template_categories DROP CONSTRAINT IF EXISTS "template_categories_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.signatures DROP CONSTRAINT IF EXISTS "signatures_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.signature_requests DROP CONSTRAINT IF EXISTS "signature_requests_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.signature_requests DROP CONSTRAINT IF EXISTS "signature_requests_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.signature_reminders DROP CONSTRAINT IF EXISTS "signature_reminders_signatureId_fkey";
ALTER TABLE IF EXISTS ONLY public.reminder_logs DROP CONSTRAINT IF EXISTS "reminder_logs_trackingId_fkey";
ALTER TABLE IF EXISTS ONLY public.registered_mails DROP CONSTRAINT IF EXISTS "registered_mails_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS "push_subscriptions_accessId_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS "notification_preferences_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS "messages_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_clientId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_templates DROP CONSTRAINT IF EXISTS "folder_templates_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS "folder_persons_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS "folder_persons_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS "folder_persons_clientId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS "folder_persons_avocatAdverseId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_doc_categories DROP CONSTRAINT IF EXISTS "folder_doc_categories_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_categories DROP CONSTRAINT IF EXISTS "folder_categories_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_categories DROP CONSTRAINT IF EXISTS "folder_categories_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_templateId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_folderCategoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_docCategoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_clientId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_tracking DROP CONSTRAINT IF EXISTS "document_tracking_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_responseDocumentId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS "deadlines_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS "deadlines_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS "deadlines_assignedToId_fkey";
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS "conversation_participants_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS "clients_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.client_consents DROP CONSTRAINT IF EXISTS "client_consents_clientId_fkey";
ALTER TABLE IF EXISTS ONLY public.client_accesses DROP CONSTRAINT IF EXISTS "client_accesses_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.client_access_logs DROP CONSTRAINT IF EXISTS "client_access_logs_accessId_fkey";
ALTER TABLE IF EXISTS ONLY public.builder_templates DROP CONSTRAINT IF EXISTS "builder_templates_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.builder_templates DROP CONSTRAINT IF EXISTS "builder_templates_templateCategoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.builder_blocks DROP CONSTRAINT IF EXISTS "builder_blocks_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.backup_logs DROP CONSTRAINT IF EXISTS "backup_logs_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.avocat_legal_info DROP CONSTRAINT IF EXISTS "avocat_legal_info_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_tenantId_fkey";
DROP INDEX IF EXISTS public."users_tenantId_role_idx";
DROP INDEX IF EXISTS public."users_tenantId_idx";
DROP INDEX IF EXISTS public."users_resetToken_key";
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.users_email_idx;
DROP INDEX IF EXISTS public.timeline_events_type_idx;
DROP INDEX IF EXISTS public."timeline_events_folderId_idx";
DROP INDEX IF EXISTS public."timeline_events_createdAt_idx";
DROP INDEX IF EXISTS public.tenants_siret_key;
DROP INDEX IF EXISTS public.tenants_siret_idx;
DROP INDEX IF EXISTS public.tenants_email_key;
DROP INDEX IF EXISTS public.tenants_email_idx;
DROP INDEX IF EXISTS public."tenant_settings_tenantId_key";
DROP INDEX IF EXISTS public."templates_tenantId_idx";
DROP INDEX IF EXISTS public.templates_category_idx;
DROP INDEX IF EXISTS public."template_categories_tenantId_idx";
DROP INDEX IF EXISTS public."signatures_transactionId_key";
DROP INDEX IF EXISTS public."signatures_transactionId_idx";
DROP INDEX IF EXISTS public.signatures_status_idx;
DROP INDEX IF EXISTS public."signatures_signerEmail_idx";
DROP INDEX IF EXISTS public."signatures_documentId_idx";
DROP INDEX IF EXISTS public."signature_requests_folderId_idx";
DROP INDEX IF EXISTS public."signature_requests_docusignEnvelopeId_idx";
DROP INDEX IF EXISTS public."signature_requests_documentId_idx";
DROP INDEX IF EXISTS public."signature_reminders_signatureId_idx";
DROP INDEX IF EXISTS public."reminder_logs_trackingId_idx";
DROP INDEX IF EXISTS public."reminder_logs_sentAt_idx";
DROP INDEX IF EXISTS public."registered_mails_trackingNumber_key";
DROP INDEX IF EXISTS public."registered_mails_trackingNumber_idx";
DROP INDEX IF EXISTS public.registered_mails_status_idx;
DROP INDEX IF EXISTS public."registered_mails_sendingBoxId_key";
DROP INDEX IF EXISTS public."registered_mails_documentId_idx";
DROP INDEX IF EXISTS public.push_subscriptions_endpoint_key;
DROP INDEX IF EXISTS public."push_subscriptions_accessId_idx";
DROP INDEX IF EXISTS public."notifications_userId_isRead_idx";
DROP INDEX IF EXISTS public."notifications_tenantId_idx";
DROP INDEX IF EXISTS public."notifications_createdAt_idx";
DROP INDEX IF EXISTS public."notification_preferences_userId_key";
DROP INDEX IF EXISTS public."messages_senderId_idx";
DROP INDEX IF EXISTS public."messages_createdAt_idx";
DROP INDEX IF EXISTS public."messages_conversationId_idx";
DROP INDEX IF EXISTS public."folders_tenantId_reference_key";
DROP INDEX IF EXISTS public."folders_tenantId_idx";
DROP INDEX IF EXISTS public.folders_status_idx;
DROP INDEX IF EXISTS public."folders_parentId_idx";
DROP INDEX IF EXISTS public."folders_clientId_idx";
DROP INDEX IF EXISTS public."folder_tree_templates_tenantId_name_key";
DROP INDEX IF EXISTS public."folder_tree_templates_tenantId_idx";
DROP INDEX IF EXISTS public."folder_templates_tenantId_idx";
DROP INDEX IF EXISTS public."folder_persons_tenantId_idx";
DROP INDEX IF EXISTS public.folder_persons_role_idx;
DROP INDEX IF EXISTS public."folder_persons_folderId_idx";
DROP INDEX IF EXISTS public."folder_persons_clientId_idx";
DROP INDEX IF EXISTS public."folder_doc_categories_folderId_name_key";
DROP INDEX IF EXISTS public."folder_doc_categories_folderId_idx";
DROP INDEX IF EXISTS public."folder_categories_tenantId_idx";
DROP INDEX IF EXISTS public."folder_categories_parentId_idx";
DROP INDEX IF EXISTS public."email_logs_tenantId_idx";
DROP INDEX IF EXISTS public."email_logs_createdAt_idx";
DROP INDEX IF EXISTS public."documents_tenantId_idx";
DROP INDEX IF EXISTS public.documents_status_idx;
DROP INDEX IF EXISTS public."documents_requiresSignature_idx";
DROP INDEX IF EXISTS public."documents_folderId_idx";
DROP INDEX IF EXISTS public."documents_folderCategoryId_idx";
DROP INDEX IF EXISTS public."documents_docCategoryId_idx";
DROP INDEX IF EXISTS public."documents_clientId_idx";
DROP INDEX IF EXISTS public.documents_checksum_idx;
DROP INDEX IF EXISTS public.document_tracking_status_idx;
DROP INDEX IF EXISTS public."document_tracking_signatureRequestId_key";
DROP INDEX IF EXISTS public."document_tracking_nextReminderAt_idx";
DROP INDEX IF EXISTS public."document_tracking_lrarTrackingNumber_key";
DROP INDEX IF EXISTS public."document_tracking_documentId_key";
DROP INDEX IF EXISTS public."document_requests_tenantId_idx";
DROP INDEX IF EXISTS public.document_requests_status_idx;
DROP INDEX IF EXISTS public."document_requests_folderId_idx";
DROP INDEX IF EXISTS public."deadlines_tenantId_idx";
DROP INDEX IF EXISTS public.deadlines_status_idx;
DROP INDEX IF EXISTS public."deadlines_folderId_idx";
DROP INDEX IF EXISTS public."deadlines_dueDate_idx";
DROP INDEX IF EXISTS public."deadlines_assignedToId_idx";
DROP INDEX IF EXISTS public."conversations_tenantId_idx";
DROP INDEX IF EXISTS public."conversations_lastMessageAt_idx";
DROP INDEX IF EXISTS public."conversations_folderId_idx";
DROP INDEX IF EXISTS public."conversation_participants_userId_idx";
DROP INDEX IF EXISTS public."conversation_participants_conversationId_userId_key";
DROP INDEX IF EXISTS public."clients_tenantId_idx";
DROP INDEX IF EXISTS public."clients_tenantId_email_idx";
DROP INDEX IF EXISTS public."clients_lastName_firstName_idx";
DROP INDEX IF EXISTS public."clients_invitationToken_key";
DROP INDEX IF EXISTS public."clients_invitationToken_idx";
DROP INDEX IF EXISTS public.clients_email_idx;
DROP INDEX IF EXISTS public."client_reminders_tenantId_idx";
DROP INDEX IF EXISTS public.client_reminders_status_idx;
DROP INDEX IF EXISTS public."client_reminders_scheduledAt_idx";
DROP INDEX IF EXISTS public."client_reminders_clientId_idx";
DROP INDEX IF EXISTS public."client_consents_clientId_idx";
DROP INDEX IF EXISTS public."client_accesses_folderId_email_key";
DROP INDEX IF EXISTS public.client_accesses_email_idx;
DROP INDEX IF EXISTS public."client_accesses_activationToken_key";
DROP INDEX IF EXISTS public."client_accesses_activationToken_idx";
DROP INDEX IF EXISTS public."client_access_logs_createdAt_idx";
DROP INDEX IF EXISTS public."client_access_logs_accessId_idx";
DROP INDEX IF EXISTS public."builder_templates_tenantId_idx";
DROP INDEX IF EXISTS public."builder_templates_templateCategoryId_idx";
DROP INDEX IF EXISTS public."builder_templates_isSystem_idx";
DROP INDEX IF EXISTS public."builder_templates_documentType_idx";
DROP INDEX IF EXISTS public.builder_templates_category_idx;
DROP INDEX IF EXISTS public."builder_blocks_tenantId_idx";
DROP INDEX IF EXISTS public."builder_blocks_isSystem_idx";
DROP INDEX IF EXISTS public.builder_blocks_category_idx;
DROP INDEX IF EXISTS public."backup_logs_tenantId_idx";
DROP INDEX IF EXISTS public."backup_logs_startedAt_idx";
DROP INDEX IF EXISTS public."avocat_legal_info_tenantId_key";
DROP INDEX IF EXISTS public."audit_logs_userId_idx";
DROP INDEX IF EXISTS public."audit_logs_tenantId_idx";
DROP INDEX IF EXISTS public."audit_logs_entityType_entityId_idx";
DROP INDEX IF EXISTS public."audit_logs_createdAt_idx";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.timeline_events DROP CONSTRAINT IF EXISTS timeline_events_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.tenant_settings DROP CONSTRAINT IF EXISTS tenant_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.templates DROP CONSTRAINT IF EXISTS templates_pkey;
ALTER TABLE IF EXISTS ONLY public.template_categories DROP CONSTRAINT IF EXISTS template_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.signatures DROP CONSTRAINT IF EXISTS signatures_pkey;
ALTER TABLE IF EXISTS ONLY public.signature_requests DROP CONSTRAINT IF EXISTS signature_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.signature_reminders DROP CONSTRAINT IF EXISTS signature_reminders_pkey;
ALTER TABLE IF EXISTS ONLY public.reminder_logs DROP CONSTRAINT IF EXISTS reminder_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.registered_mails DROP CONSTRAINT IF EXISTS registered_mails_pkey;
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS push_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS folders_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_tree_templates DROP CONSTRAINT IF EXISTS folder_tree_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_templates DROP CONSTRAINT IF EXISTS folder_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS folder_persons_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_doc_categories DROP CONSTRAINT IF EXISTS folder_doc_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_categories DROP CONSTRAINT IF EXISTS folder_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.email_logs DROP CONSTRAINT IF EXISTS email_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_tracking DROP CONSTRAINT IF EXISTS document_tracking_pkey;
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS document_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS deadlines_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS conversation_participants_pkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_pkey;
ALTER TABLE IF EXISTS ONLY public.client_reminders DROP CONSTRAINT IF EXISTS client_reminders_pkey;
ALTER TABLE IF EXISTS ONLY public.client_consents DROP CONSTRAINT IF EXISTS client_consents_pkey;
ALTER TABLE IF EXISTS ONLY public.client_accesses DROP CONSTRAINT IF EXISTS client_accesses_pkey;
ALTER TABLE IF EXISTS ONLY public.client_access_logs DROP CONSTRAINT IF EXISTS client_access_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.builder_templates DROP CONSTRAINT IF EXISTS builder_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.builder_blocks DROP CONSTRAINT IF EXISTS builder_blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_logs DROP CONSTRAINT IF EXISTS backup_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.avocat_legal_info DROP CONSTRAINT IF EXISTS avocat_legal_info_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.timeline_events;
DROP TABLE IF EXISTS public.tenants;
DROP TABLE IF EXISTS public.tenant_settings;
DROP TABLE IF EXISTS public.templates;
DROP TABLE IF EXISTS public.template_categories;
DROP TABLE IF EXISTS public.signatures;
DROP TABLE IF EXISTS public.signature_requests;
DROP TABLE IF EXISTS public.signature_reminders;
DROP TABLE IF EXISTS public.reminder_logs;
DROP TABLE IF EXISTS public.registered_mails;
DROP TABLE IF EXISTS public.push_subscriptions;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.folders;
DROP TABLE IF EXISTS public.folder_tree_templates;
DROP TABLE IF EXISTS public.folder_templates;
DROP TABLE IF EXISTS public.folder_persons;
DROP TABLE IF EXISTS public.folder_doc_categories;
DROP TABLE IF EXISTS public.folder_categories;
DROP TABLE IF EXISTS public.email_logs;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_tracking;
DROP TABLE IF EXISTS public.document_requests;
DROP TABLE IF EXISTS public.deadlines;
DROP TABLE IF EXISTS public.conversations;
DROP TABLE IF EXISTS public.conversation_participants;
DROP TABLE IF EXISTS public.clients;
DROP TABLE IF EXISTS public.client_reminders;
DROP TABLE IF EXISTS public.client_consents;
DROP TABLE IF EXISTS public.client_accesses;
DROP TABLE IF EXISTS public.client_access_logs;
DROP TABLE IF EXISTS public.builder_templates;
DROP TABLE IF EXISTS public.builder_blocks;
DROP TABLE IF EXISTS public.backup_logs;
DROP TABLE IF EXISTS public.avocat_legal_info;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."TrackingStatus";
DROP TYPE IF EXISTS public."SignerType";
DROP TYPE IF EXISTS public."SignatureStatus";
DROP TYPE IF EXISTS public."ReminderType";
DROP TYPE IF EXISTS public."ReminderStatus";
DROP TYPE IF EXISTS public."RegisteredMailStatus";
DROP TYPE IF EXISTS public."PersonType";
DROP TYPE IF EXISTS public."PersonRole";
DROP TYPE IF EXISTS public."OutputFormat";
DROP TYPE IF EXISTS public."NotificationType";
DROP TYPE IF EXISTS public."FolderType";
DROP TYPE IF EXISTS public."FolderStatus";
DROP TYPE IF EXISTS public."EmailStatus";
DROP TYPE IF EXISTS public."DocumentType";
DROP TYPE IF EXISTS public."DocumentStatus";
DROP TYPE IF EXISTS public."DocumentRequestStatus";
DROP TYPE IF EXISTS public."DocumentRequestPriority";
DROP TYPE IF EXISTS public."DeliveryMethod";
DROP TYPE IF EXISTS public."DeadlineType";
DROP TYPE IF EXISTS public."DeadlineStatus";
DROP TYPE IF EXISTS public."DeadlinePriority";
DROP TYPE IF EXISTS public."ConsentType";
DROP TYPE IF EXISTS public."ClientType";
DROP TYPE IF EXISTS public."BlockCategory";
DROP TYPE IF EXISTS public."BackupType";
DROP TYPE IF EXISTS public."BackupStatus";
--
-- Name: BackupStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."BackupStatus" AS ENUM (
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."BackupStatus" OWNER TO lexdoc_user;

--
-- Name: BackupType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."BackupType" AS ENUM (
    'DATABASE',
    'MINIO',
    'FULL'
);


ALTER TYPE public."BackupType" OWNER TO lexdoc_user;

--
-- Name: BlockCategory; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."BlockCategory" AS ENUM (
    'INTRO',
    'FAITS',
    'MOYENS',
    'DISPOSITIF',
    'SIGNATURE',
    'CLAUSE',
    'CUSTOM'
);


ALTER TYPE public."BlockCategory" OWNER TO lexdoc_user;

--
-- Name: ClientType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ClientType" AS ENUM (
    'INDIVIDUAL',
    'COMPANY',
    'ASSOCIATION'
);


ALTER TYPE public."ClientType" OWNER TO lexdoc_user;

--
-- Name: ConsentType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ConsentType" AS ENUM (
    'DATA_PROCESSING',
    'EMAIL_NOTIFICATIONS',
    'SMS_NOTIFICATIONS',
    'DOCUMENT_STORAGE',
    'DATA_RETENTION'
);


ALTER TYPE public."ConsentType" OWNER TO lexdoc_user;

--
-- Name: DeadlinePriority; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeadlinePriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."DeadlinePriority" OWNER TO lexdoc_user;

--
-- Name: DeadlineStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeadlineStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'OVERDUE'
);


ALTER TYPE public."DeadlineStatus" OWNER TO lexdoc_user;

--
-- Name: DeadlineType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeadlineType" AS ENUM (
    'DEADLINE',
    'HEARING',
    'MEETING',
    'REMINDER',
    'TASK',
    'OTHER'
);


ALTER TYPE public."DeadlineType" OWNER TO lexdoc_user;

--
-- Name: DeliveryMethod; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeliveryMethod" AS ENUM (
    'SIGNATURE_ELECTRONIQUE',
    'LRAR',
    'EMAIL'
);


ALTER TYPE public."DeliveryMethod" OWNER TO lexdoc_user;

--
-- Name: DocumentRequestPriority; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentRequestPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."DocumentRequestPriority" OWNER TO lexdoc_user;

--
-- Name: DocumentRequestStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentRequestStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'CANCELLED',
    'EXPIRED'
);


ALTER TYPE public."DocumentRequestStatus" OWNER TO lexdoc_user;

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'DRAFT',
    'PENDING_REVIEW',
    'PENDING_SIGNATURE',
    'SIGNED',
    'SENT',
    'ARCHIVED',
    'CANCELLED'
);


ALTER TYPE public."DocumentStatus" OWNER TO lexdoc_user;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentType" AS ENUM (
    'CONTRACT',
    'DEED',
    'LETTER',
    'INVOICE',
    'RECEIPT',
    'CERTIFICATE',
    'REPORT',
    'MINUTES',
    'AMENDMENT',
    'MEMORANDUM',
    'POWER_OF_ATTORNEY',
    'OTHER'
);


ALTER TYPE public."DocumentType" OWNER TO lexdoc_user;

--
-- Name: EmailStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."EmailStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."EmailStatus" OWNER TO lexdoc_user;

--
-- Name: FolderStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."FolderStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'PENDING',
    'CLOSED',
    'ARCHIVED'
);


ALTER TYPE public."FolderStatus" OWNER TO lexdoc_user;

--
-- Name: FolderType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."FolderType" AS ENUM (
    'LITIGATION',
    'CONTRACT',
    'BUSINESS',
    'FAMILY',
    'REAL_ESTATE',
    'LABOR',
    'INTELLECTUAL',
    'ADMINISTRATIVE',
    'CRIMINAL',
    'OTHER'
);


ALTER TYPE public."FolderType" OWNER TO lexdoc_user;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."NotificationType" AS ENUM (
    'SIGNATURE_PENDING',
    'SIGNATURE_COMPLETED',
    'SIGNATURE_REMINDER',
    'DOCUMENT_UPLOADED',
    'DOCUMENT_SHARED',
    'DOCUMENT_REQUEST',
    'DOCUMENT_REQUEST_FULFILLED',
    'FOLDER_CREATED',
    'FOLDER_STATUS_CHANGED',
    'CLIENT_ACCESS_CREATED',
    'DEADLINE_APPROACHING',
    'DEADLINE_PASSED',
    'MESSAGE_RECEIVED',
    'SYSTEM',
    'CLIENT_STEP_COMPLETED',
    'CLIENT_PROFILE_COMPLETE'
);


ALTER TYPE public."NotificationType" OWNER TO lexdoc_user;

--
-- Name: OutputFormat; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."OutputFormat" AS ENUM (
    'DOCX',
    'PDF'
);


ALTER TYPE public."OutputFormat" OWNER TO lexdoc_user;

--
-- Name: PersonRole; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."PersonRole" AS ENUM (
    'PARTIE_ADVERSE',
    'AVOCAT_ADVERSE',
    'TEMOIN',
    'EXPERT',
    'NOTAIRE',
    'HUISSIER',
    'MEDIATEUR',
    'AUTRE',
    'CLIENT',
    'POSTULANT'
);


ALTER TYPE public."PersonRole" OWNER TO lexdoc_user;

--
-- Name: PersonType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."PersonType" AS ENUM (
    'PHYSIQUE',
    'MORALE'
);


ALTER TYPE public."PersonType" OWNER TO lexdoc_user;

--
-- Name: RegisteredMailStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."RegisteredMailStatus" AS ENUM (
    'PREPARING',
    'SENT',
    'IN_TRANSIT',
    'DELIVERED',
    'RETURNED',
    'ERROR'
);


ALTER TYPE public."RegisteredMailStatus" OWNER TO lexdoc_user;

--
-- Name: ReminderStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ReminderStatus" AS ENUM (
    'SENT',
    'FAILED',
    'OPENED',
    'CLICKED'
);


ALTER TYPE public."ReminderStatus" OWNER TO lexdoc_user;

--
-- Name: ReminderType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ReminderType" AS ENUM (
    'FIRST_REMINDER',
    'SECOND_REMINDER',
    'THIRD_REMINDER',
    'FINAL_NOTICE'
);


ALTER TYPE public."ReminderType" OWNER TO lexdoc_user;

--
-- Name: SignatureStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."SignatureStatus" AS ENUM (
    'PENDING',
    'SIGNED',
    'REFUSED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."SignatureStatus" OWNER TO lexdoc_user;

--
-- Name: SignerType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."SignerType" AS ENUM (
    'CLIENT',
    'LAWYER',
    'THIRD_PARTY'
);


ALTER TYPE public."SignerType" OWNER TO lexdoc_user;

--
-- Name: TrackingStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."TrackingStatus" AS ENUM (
    'DRAFT',
    'PENDING_SIGNATURE',
    'SIGNED',
    'PENDING_DELIVERY',
    'DELIVERED',
    'EXPIRED'
);


ALTER TYPE public."TrackingStatus" OWNER TO lexdoc_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'LAWYER',
    'ASSISTANT',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO lexdoc_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO lexdoc_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    changes jsonb,
    metadata jsonb,
    "userId" text,
    "ipAddress" text,
    "userAgent" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO lexdoc_user;

--
-- Name: avocat_legal_info; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.avocat_legal_info (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    "numeroToque" text,
    barreau text,
    specialites text[] DEFAULT ARRAY[]::text[],
    rcs text,
    "tvaIntra" text,
    "assuranceRC" text,
    "numeroPolice" text,
    "signaturePath" text,
    "cachetPath" text,
    "mentionsLegales" jsonb
);


ALTER TABLE public.avocat_legal_info OWNER TO lexdoc_user;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.backup_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text,
    type public."BackupType" NOT NULL,
    status public."BackupStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "fileSize" bigint,
    "googleDriveId" text,
    "errorMessage" text
);


ALTER TABLE public.backup_logs OWNER TO lexdoc_user;

--
-- Name: builder_blocks; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.builder_blocks (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    category public."BlockCategory" NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    variables jsonb,
    tags text[] DEFAULT ARRAY[]::text[],
    "isMandatory" boolean DEFAULT false NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "displayOrder" integer,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdById" text,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.builder_blocks OWNER TO lexdoc_user;

--
-- Name: builder_templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.builder_templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    description text,
    "documentType" text NOT NULL,
    juridiction text,
    category text,
    "blocksStructure" jsonb NOT NULL,
    "requiredVariables" jsonb,
    "outputFormat" public."OutputFormat" DEFAULT 'DOCX'::public."OutputFormat" NOT NULL,
    "workflowConfig" jsonb,
    "legalMentions" jsonb,
    "isSystem" boolean DEFAULT false NOT NULL,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdById" text,
    "templateCategoryId" text,
    "deletedAt" timestamp(3) without time zone,
    "folderNature" text,
    "folderType" text,
    "isPersonalise" boolean DEFAULT false NOT NULL,
    "sourceFileUrl" text
);


ALTER TABLE public.builder_templates OWNER TO lexdoc_user;

--
-- Name: client_access_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_access_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accessId" text NOT NULL,
    action text NOT NULL,
    "ipAddress" text NOT NULL,
    "userAgent" text
);


ALTER TABLE public.client_access_logs OWNER TO lexdoc_user;

--
-- Name: client_accesses; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_accesses (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    email text NOT NULL,
    "passwordHash" text,
    "activationToken" text,
    "tokenExpiresAt" timestamp(3) without time zone,
    "isActivated" boolean DEFAULT false NOT NULL,
    "lastLoginAt" timestamp(3) without time zone
);


ALTER TABLE public.client_accesses OWNER TO lexdoc_user;

--
-- Name: client_consents; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_consents (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "clientId" text NOT NULL,
    type public."ConsentType" NOT NULL,
    granted boolean NOT NULL,
    "grantedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "userAgent" text
);


ALTER TABLE public.client_consents OWNER TO lexdoc_user;

--
-- Name: client_reminders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_reminders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text NOT NULL,
    "clientId" text NOT NULL,
    type text NOT NULL,
    "referenceId" text,
    "scheduledAt" timestamp(3) without time zone NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "reminderNumber" integer DEFAULT 1 NOT NULL,
    channel text DEFAULT 'email'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL
);


ALTER TABLE public.client_reminders OWNER TO lexdoc_user;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.clients (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    type public."ClientType" DEFAULT 'INDIVIDUAL'::public."ClientType" NOT NULL,
    "firstName" text,
    "lastName" text,
    "birthDate" timestamp(3) without time zone,
    "companyName" text,
    siret text,
    "vatNumber" text,
    email text NOT NULL,
    phone text,
    mobile text,
    address text,
    "addressLine2" text,
    "postalCode" text,
    city text,
    country text DEFAULT 'FR'::text NOT NULL,
    "hasExternet" boolean DEFAULT false NOT NULL,
    "extranetPassword" text,
    "extranetActivatedAt" timestamp(3) without time zone,
    "extranetLastLoginAt" timestamp(3) without time zone,
    "invitationToken" text,
    "invitationSentAt" timestamp(3) without time zone,
    "invitationExpiresAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    notes text,
    "tenantId" text NOT NULL,
    "adressePro" text,
    capital text,
    civilite text,
    "complementAdressePerso" text,
    "complementAdressePro" text,
    "conjointDateNaissance" timestamp(3) without time zone,
    "conjointNationalite" text,
    "conjointNom" text,
    "conjointPrenom" text,
    "conjointProfession" text,
    "cpPro" text,
    "dateContratMariage" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    "departementNaissance" text,
    "emailSecondaire" text,
    fax text,
    "formeSociale" text,
    "lieuNaissance" text,
    "mereNomJeuneFille" text,
    "merePrenom" text,
    nationalite text DEFAULT 'Française'::text,
    "nbEnfantsMajeurs" integer DEFAULT 0,
    "nbEnfantsMineurs" integer DEFAULT 0,
    "nomUsage" text,
    "notaireMariage" text,
    "objetSocial" text,
    "paysNaissance" text,
    "paysPro" text,
    "pereNom" text,
    "perePrenom" text,
    profession text,
    "profileCompletionPercent" integer DEFAULT 0 NOT NULL,
    "profileLastStep" integer DEFAULT 0 NOT NULL,
    "profileSubmittedAt" timestamp(3) without time zone,
    "profileSubmittedVersion" integer DEFAULT 0 NOT NULL,
    rcs text,
    "regimeMatrimonial" text,
    secu text,
    siege text,
    "situationFamiliale" text,
    "telPro" text,
    "villePro" text
);


ALTER TABLE public.clients OWNER TO lexdoc_user;

--
-- Name: conversation_participants; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.conversation_participants (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "conversationId" text NOT NULL,
    "userId" text NOT NULL,
    "lastReadAt" timestamp(3) without time zone,
    "unreadCount" integer DEFAULT 0 NOT NULL,
    "notificationsEnabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.conversation_participants OWNER TO lexdoc_user;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    subject text,
    "folderId" text,
    "lastMessageAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL
);


ALTER TABLE public.conversations OWNER TO lexdoc_user;

--
-- Name: deadlines; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.deadlines (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    title text NOT NULL,
    description text,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "dueTime" text,
    type public."DeadlineType" DEFAULT 'DEADLINE'::public."DeadlineType" NOT NULL,
    priority public."DeadlinePriority" DEFAULT 'NORMAL'::public."DeadlinePriority" NOT NULL,
    status public."DeadlineStatus" DEFAULT 'PENDING'::public."DeadlineStatus" NOT NULL,
    reminders jsonb,
    "lastReminderSentAt" timestamp(3) without time zone,
    "folderId" text,
    "documentId" text,
    "assignedToId" text,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL,
    "isRecurring" boolean DEFAULT false NOT NULL,
    "recurrenceRule" text,
    "completedAt" timestamp(3) without time zone,
    "completedById" text
);


ALTER TABLE public.deadlines OWNER TO lexdoc_user;

--
-- Name: document_requests; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.document_requests (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."DocumentRequestStatus" DEFAULT 'PENDING'::public."DocumentRequestStatus" NOT NULL,
    priority public."DocumentRequestPriority" DEFAULT 'NORMAL'::public."DocumentRequestPriority" NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "responseDocumentId" text,
    "responseDate" timestamp(3) without time zone,
    "responseNotes" text,
    "reminderCount" integer DEFAULT 0 NOT NULL,
    "lastReminderAt" timestamp(3) without time zone,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.document_requests OWNER TO lexdoc_user;

--
-- Name: document_tracking; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.document_tracking (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    status public."TrackingStatus" DEFAULT 'DRAFT'::public."TrackingStatus" NOT NULL,
    "deliveryMethod" public."DeliveryMethod",
    "signatureRequestId" text,
    "signatureStatus" public."SignatureStatus",
    "signedAt" timestamp(3) without time zone,
    "signedBy" text[] DEFAULT ARRAY[]::text[],
    "lrarTrackingNumber" text,
    "lrarStatus" public."RegisteredMailStatus",
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "reminderCount" integer DEFAULT 0 NOT NULL,
    "lastReminderAt" timestamp(3) without time zone,
    "nextReminderAt" timestamp(3) without time zone,
    "autoRemindersEnabled" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.document_tracking OWNER TO lexdoc_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    type public."DocumentType" NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    size bigint NOT NULL,
    checksum text NOT NULL,
    "bucketName" text NOT NULL,
    "objectKey" text NOT NULL,
    "isEncrypted" boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "parentId" text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    "requiresSignature" boolean DEFAULT false NOT NULL,
    "signatureDeadline" timestamp(3) without time zone,
    "validFrom" timestamp(3) without time zone,
    "validUntil" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    "folderId" text NOT NULL,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL,
    "folderCategoryId" text,
    "clientId" text,
    "docCategoryId" text,
    "docusignEnvelopeId" text,
    "docusignSentAt" timestamp(3) without time zone,
    "docusignSignedAt" timestamp(3) without time zone,
    "docusignStatus" text,
    "sendingboxDeliveredAt" timestamp(3) without time zone,
    "sendingboxSentAt" timestamp(3) without time zone,
    "sendingboxStatus" text,
    "sendingboxTrackingId" text,
    "templateId" text,
    "visibleExtranet" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.documents OWNER TO lexdoc_user;

--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.email_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "to" text NOT NULL,
    subject text NOT NULL,
    template text NOT NULL,
    status public."EmailStatus" DEFAULT 'SENT'::public."EmailStatus" NOT NULL,
    "errorMessage" text,
    "notificationId" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.email_logs OWNER TO lexdoc_user;

--
-- Name: folder_categories; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_categories (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    color text,
    icon text,
    "parentId" text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.folder_categories OWNER TO lexdoc_user;

--
-- Name: folder_doc_categories; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_doc_categories (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "folderId" text NOT NULL,
    name text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    icon text
);


ALTER TABLE public.folder_doc_categories OWNER TO lexdoc_user;

--
-- Name: folder_persons; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_persons (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    "tenantId" text NOT NULL,
    type public."PersonType" DEFAULT 'PHYSIQUE'::public."PersonType" NOT NULL,
    role public."PersonRole" NOT NULL,
    "firstName" text,
    "lastName" text NOT NULL,
    company text,
    email text,
    phone text,
    address text,
    notes text,
    "avocatAdverseId" text,
    barreau text,
    cabinet text,
    "clientId" text,
    ordre integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.folder_persons OWNER TO lexdoc_user;

--
-- Name: folder_templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    "folderType" public."FolderType" NOT NULL,
    structure jsonb NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.folder_templates OWNER TO lexdoc_user;

--
-- Name: folder_tree_templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_tree_templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    "folderType" text NOT NULL,
    categories jsonb NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.folder_tree_templates OWNER TO lexdoc_user;

--
-- Name: folders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    reference text NOT NULL,
    title text NOT NULL,
    description text,
    type public."FolderType" NOT NULL,
    status public."FolderStatus" DEFAULT 'OPEN'::public."FolderStatus" NOT NULL,
    "openedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "clientId" text NOT NULL,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL,
    color text DEFAULT '#3B82F6'::text,
    "metadataCession" jsonb,
    "parentId" text,
    chambre text,
    "dateAudience" timestamp(3) without time zone,
    "dateEcheance" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    juridiction text,
    nature text,
    "numeroRG" text
);


ALTER TABLE public.folders OWNER TO lexdoc_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.messages (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "conversationId" text NOT NULL,
    content text NOT NULL,
    attachments jsonb,
    "senderId" text NOT NULL,
    "isEdited" boolean DEFAULT false NOT NULL,
    "editedAt" timestamp(3) without time zone,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL
);


ALTER TABLE public.messages OWNER TO lexdoc_user;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.notification_preferences (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    "emailSignatures" boolean DEFAULT true NOT NULL,
    "emailDocuments" boolean DEFAULT true NOT NULL,
    "emailDeadlines" boolean DEFAULT true NOT NULL,
    "emailMessages" boolean DEFAULT true NOT NULL,
    "emailDigest" boolean DEFAULT false NOT NULL,
    "digestFrequency" text DEFAULT 'DAILY'::text NOT NULL,
    "pushEnabled" boolean DEFAULT true NOT NULL,
    "pushSignatures" boolean DEFAULT true NOT NULL,
    "pushDocuments" boolean DEFAULT true NOT NULL,
    "pushDeadlines" boolean DEFAULT true NOT NULL,
    "pushMessages" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO lexdoc_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "entityType" text,
    "entityId" text,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    "emailSent" boolean DEFAULT false NOT NULL,
    "emailSentAt" timestamp(3) without time zone,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.notifications OWNER TO lexdoc_user;

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.push_subscriptions (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accessId" text NOT NULL,
    endpoint text NOT NULL,
    keys jsonb NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO lexdoc_user;

--
-- Name: registered_mails; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.registered_mails (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    "recipientName" text NOT NULL,
    "recipientAddress" text NOT NULL,
    "recipientCity" text NOT NULL,
    "recipientPostalCode" text NOT NULL,
    "recipientCountry" text DEFAULT 'FR'::text NOT NULL,
    "sendingBoxId" text,
    "trackingNumber" text,
    status public."RegisteredMailStatus" DEFAULT 'PREPARING'::public."RegisteredMailStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "returnedAt" timestamp(3) without time zone,
    "proofUrl" text,
    cost numeric(10,2)
);


ALTER TABLE public.registered_mails OWNER TO lexdoc_user;

--
-- Name: reminder_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.reminder_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "trackingId" text NOT NULL,
    type public."ReminderType" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "sentTo" text NOT NULL,
    "emailSubject" text,
    "emailBody" text,
    status public."ReminderStatus" DEFAULT 'SENT'::public."ReminderStatus" NOT NULL,
    "errorMessage" text
);


ALTER TABLE public.reminder_logs OWNER TO lexdoc_user;

--
-- Name: signature_reminders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signature_reminders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "signatureId" text NOT NULL,
    "reminderNumber" integer NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "emailSent" boolean DEFAULT true NOT NULL,
    "smsSent" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.signature_reminders OWNER TO lexdoc_user;

--
-- Name: signature_requests; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signature_requests (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    "documentId" text NOT NULL,
    "docusignEnvelopeId" text,
    signataires jsonb NOT NULL,
    "ordreSignature" text DEFAULT 'parallele'::text NOT NULL,
    "dateExpiration" timestamp(3) without time zone,
    "messagePersonnalise" text,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.signature_requests OWNER TO lexdoc_user;

--
-- Name: signatures; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signatures (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    "signerEmail" text NOT NULL,
    "signerName" text NOT NULL,
    "signerType" public."SignerType" DEFAULT 'CLIENT'::public."SignerType" NOT NULL,
    "transactionId" text,
    "signatureUrl" text,
    status public."SignatureStatus" DEFAULT 'PENDING'::public."SignatureStatus" NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "signedAt" timestamp(3) without time zone,
    "refusedAt" timestamp(3) without time zone,
    "expiredAt" timestamp(3) without time zone,
    "certificateUrl" text
);


ALTER TABLE public.signatures OWNER TO lexdoc_user;

--
-- Name: template_categories; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.template_categories (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    color text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.template_categories OWNER TO lexdoc_user;

--
-- Name: templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    "sourceFileUrl" text,
    variables jsonb,
    blocks jsonb,
    "folderType" text,
    "folderNature" text,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isPersonalise" boolean DEFAULT false NOT NULL,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.templates OWNER TO lexdoc_user;

--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.tenant_settings (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "enableReminders" boolean DEFAULT true NOT NULL,
    "reminderSchedule" text DEFAULT '1,3,5'::text NOT NULL,
    "maxReminders" integer DEFAULT 3 NOT NULL,
    "defaultSignatureDeadlineDays" integer DEFAULT 7 NOT NULL,
    "emailFromName" text,
    "emailReplyTo" text,
    "emailSignature" text,
    "lrarSenderName" text,
    "lrarSenderAddress" text,
    "documentRetentionYears" integer DEFAULT 10 NOT NULL,
    "autoArchiveClosedFolders" boolean DEFAULT false NOT NULL,
    "autoArchiveAfterDays" integer DEFAULT 365 NOT NULL,
    "enforceStrongPasswords" boolean DEFAULT true NOT NULL,
    "sessionTimeoutMinutes" integer DEFAULT 480 NOT NULL,
    "require2FA" boolean DEFAULT false NOT NULL,
    "allowClientUpload" boolean DEFAULT false NOT NULL,
    "clientUploadMaxSizeMB" integer DEFAULT 10 NOT NULL,
    "tenantId" text NOT NULL,
    "docusignAccessToken" text,
    "docusignAccountId" text,
    "docusignAccountName" text,
    "docusignConnectedAt" timestamp(3) without time zone,
    "docusignRefreshToken" text,
    "sendingboxApiKey" text,
    "sendingboxConnectedAt" timestamp(3) without time zone,
    "reminderDelay1" integer DEFAULT 3 NOT NULL,
    "reminderDelay2" integer DEFAULT 7 NOT NULL,
    "reminderDelay3" integer DEFAULT 14 NOT NULL,
    "reminderNotify" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tenant_settings OWNER TO lexdoc_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "legalName" text,
    siret text,
    address text,
    "postalCode" text,
    city text,
    country text DEFAULT 'FR'::text NOT NULL,
    phone text,
    email text NOT NULL,
    website text,
    logo text,
    "primaryColor" text DEFAULT '#0066ff'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "subscriptionTier" text DEFAULT 'TRIAL'::text NOT NULL,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    "maxClients" integer DEFAULT 100 NOT NULL,
    "maxStorage" bigint DEFAULT '5368709120'::bigint NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "subscribedAt" timestamp(3) without time zone,
    barreau text,
    "deletedAt" timestamp(3) without time zone,
    toque text
);


ALTER TABLE public.tenants OWNER TO lexdoc_user;

--
-- Name: timeline_events; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.timeline_events (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "folderId" text NOT NULL,
    "documentId" text,
    type text NOT NULL,
    description text NOT NULL,
    metadata jsonb,
    "userId" text
);


ALTER TABLE public.timeline_events OWNER TO lexdoc_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    avatar text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    permissions jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "resetToken" text,
    "resetTokenExpiresAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "refreshTokens" text[] DEFAULT ARRAY[]::text[],
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "onboardingCompleted" boolean DEFAULT false NOT NULL,
    "onboardingStep" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.users OWNER TO lexdoc_user;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
df614b84-63b5-4bb7-acb3-705677064d8c	c3975f490877fbbe544867ca743a67c9e6ee63f8c45786aab9149392fbc41cab	2026-02-03 17:36:28.361432+00	20260203173628_init	\N	\N	2026-02-03 17:36:28.169949+00	1
b53b932e-f567-43d5-9c46-769f20004240	7befaa95cbd2df3dc0b69296e0c81b9f33821247ab2e5b8a85c8d00a37733473	2026-02-04 09:03:32.753787+00	20260204090332_add_master_models	\N	\N	2026-02-04 09:03:32.608161+00	1
9224efd1-6eb4-4b35-8ff4-40d603b275f5	1bfa825f044421de547fb7894bea3757e55cc68bfb2076c920612bbddc819573	2026-02-05 11:08:37.496505+00	20260205110837_add_folder_persons	\N	\N	2026-02-05 11:08:37.466876+00	1
9f39542c-5bc6-4192-b2a6-3e8a3c6ec2ae	027a9a0dfca8757a2510ca81b5f2909f060cb4f3ffc7b9195d58273f39665fcd	2026-02-05 12:18:53.822141+00	20260205121846_add_categories_and_document_requests	\N	\N	2026-02-05 12:18:53.756947+00	1
57b95031-c718-4cf4-a8c9-3da482e50ee5	76e97876e0249e9f13b4593e35f5e30de2df7cf067e9ed204333f938ab9c60f8	2026-02-05 15:56:54.976369+00	20260205155654_add_notifications	\N	\N	2026-02-05 15:56:54.925674+00	1
45c6821e-9d78-4e40-be5d-c5937404a327	eae02a367e0a0fe05f26f30011d3eeca99215d7356139119b53925883631b21f	2026-02-05 16:05:43.698416+00	20260205160543_add_deadlines	\N	\N	2026-02-05 16:05:43.667612+00	1
0da97ed0-5060-4b0f-91ba-180168a3867b	3d72c771232e2d51625c0ffb809798730649b040fc2386f6398f9652a01f8b59	2026-02-05 16:17:51.515635+00	20260205161751_add_chat_messaging	\N	\N	2026-02-05 16:17:51.476935+00	1
5553f0a3-aeae-4296-b513-e4377966ac41	0d342c615764fe6787a29200411f317d0458b343a0b9cad63a7bf002994bee42	2026-02-06 14:23:39.215489+00	20260206142333_spec_ux_unifiee_enrichissement	\N	\N	2026-02-06 14:23:39.086418+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.audit_logs (id, "createdAt", action, "entityType", "entityId", changes, metadata, "userId", "ipAddress", "userAgent", "tenantId") FROM stdin;
cml9d6re0000310v131hgdvno	2026-02-05 11:19:45.193	FOLDER_PERSON_CREATED	FolderPerson	cml9d6rdu000110v1tusjcjkg	\N	{"role": "PARTIE_ADVERSE", "type": "PHYSIQUE", "folderId": "fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9d6yyd000710v1s2ytx2ou	2026-02-05 11:19:54.998	FOLDER_PERSON_CREATED	FolderPerson	cml9d6yya000510v135c0rzqq	\N	{"role": "AVOCAT_ADVERSE", "type": "MORALE", "folderId": "fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9dchns000910v1wak9ry48	2026-02-05 11:24:12.52	FOLDER_PERSON_UPDATED	FolderPerson	cml9d6rdu000110v1tusjcjkg	{"phone": "06 12 34 56 78"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9ded1o000b10v1j93e9zw7	2026-02-05 11:25:39.853	FOLDER_PERSON_DELETED	FolderPerson	cml9d6yya000510v135c0rzqq	\N	{"folderId": "fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6", "deletedPerson": {"role": "AVOCAT_ADVERSE", "type": "MORALE", "lastName": "Durand", "firstName": "Marie"}}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9kmiuy000111bil489a50p	2026-02-05 14:47:57.946	FOLDER_VIEWED	Folder	cml8feb1z000510pf9trmhfa2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9kmiwr000311bif9vuzeh2	2026-02-05 14:47:58.012	FOLDER_VIEWED	Folder	cml8feb1z000510pf9trmhfa2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9kseay000l11bizy0ekhjm	2026-02-05 14:52:31.978	DOCUMENT_REQUEST_CREATED	DocumentRequest	cml9kseai000j11bi8qvvdh5f	\N	{"title": "Justificatif de domicile", "folderId": "fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9ksedt000p11biz4h33zcr	2026-02-05 14:52:32.081	DOCUMENT_REQUEST_CREATED	DocumentRequest	cml9ksedi000n11bicid4rupz	\N	{"title": "Pièce d'identité", "folderId": "fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9m0r5a000114jc1n3cvdzx	2026-02-05 15:27:01.483	FOLDER_VIEWED	Folder	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9m1cse000314jc2sx4xjma	2026-02-05 15:27:29.534	FOLDER_VIEWED	Folder	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9mcqwi00017q3ncwjf1i93	2026-02-05 15:36:21.043	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mcqy300037q3nzwis0mn8	2026-02-05 15:36:21.1	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9md6l500057q3nmvyes1ro	2026-02-05 15:36:41.369	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9md6mv00077q3n29rc8uzk	2026-02-05 15:36:41.431	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mj7vl00097q3nw8gsexwy	2026-02-05 15:41:22.978	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mj7x5000b7q3ns4w8isw7	2026-02-05 15:41:23.033	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mn7i40001iauvrf1bq1eb	2026-02-05 15:44:29.116	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9moch20003iauv35nd41ud	2026-02-05 15:45:22.214	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mocqc0005iauvhvfvpfn8	2026-02-05 15:45:22.549	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nqoeu000111z64186hkb9	2026-02-05 16:15:10.614	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nqohs000311z6iug2xrh2	2026-02-05 16:15:10.72	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nskok000511z6fpfbsuf1	2026-02-05 16:16:39.092	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nskqh000711z6kbn6ylrj	2026-02-05 16:16:39.161	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaq9q2n0005yf6no3p9xbg0	2026-02-06 10:13:44.638	FOLDER_VIEWED	Folder	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaq9q4s0007yf6nkq0lyzol	2026-02-06 10:13:44.717	FOLDER_VIEWED	Folder	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqkl750009yf6ngxvxrxlj	2026-02-06 10:22:11.537	FOLDER_VIEWED	Folder	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqkl8u000byf6nra5tkirg	2026-02-06 10:22:11.598	FOLDER_VIEWED	Folder	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqmlor000dyf6nm4ll42fq	2026-02-06 10:23:45.483	FOLDER_VIEWED	Folder	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqmlqd000fyf6nu6j51vmg	2026-02-06 10:23:45.541	FOLDER_VIEWED	Folder	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqnv9r000jyf6nwcbuuswt	2026-02-06 10:24:44.56	FOLDER_CREATED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	{"type": "CRIMINAL", "title": "essai", "clientId": "cml8feb1q000310pfqjw2w14v"}	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqnxei000nyf6ni9e40ble	2026-02-06 10:24:47.323	FOLDER_VIEWED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqy7kz000pyf6nso8ei6jm	2026-02-06 10:32:47.075	FOLDER_VIEWED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqnxcl000lyf6nqzr0aoic	2026-02-06 10:24:47.254	FOLDER_VIEWED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaqy7mv000ryf6nbi4ypdbn	2026-02-06 10:32:47.144	FOLDER_VIEWED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	80.215.180.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaxp7xj0001mimr8ebkmafp	2026-02-06 13:41:44.935	FOLDER_VIEWED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlaxp7yu0003mimrf32qcy1i	2026-02-06 13:41:44.982	FOLDER_VIEWED	Folder	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlay1lo90005mimr9qehgvbx	2026-02-06 13:51:22.617	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	node	cml6vykdd0000jms2wwxl9s27
cmlay39cf0007mimr26xza0uc	2026-02-06 13:52:39.951	FOLDER_VIEWED	Folder	cml8feb2l000d10pfe8y2gtge	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlay39dq0009mimr1nt6r7kd	2026-02-06 13:52:39.998	FOLDER_VIEWED	Folder	cml8feb2l000d10pfe8y2gtge	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlay3b0g000bmimrzw2z3zua	2026-02-06 13:52:42.112	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	node	cml6vykdd0000jms2wwxl9s27
cmlay3b1d000dmimrhn2rukpq	2026-02-06 13:52:42.145	DOCUMENT_UPDATED	Document	cml6vyl1d000rjms21ti62wqk	{"folderId": "cml6vyl0z000fjms24ukfhi3k"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	node	cml6vykdd0000jms2wwxl9s27
cmlay3b1p000fmimr43bhmth1	2026-02-06 13:52:42.157	DOCUMENT_UPDATED	Document	cml6vyl1d000rjms21ti62wqk	{"folderId": "cml6vyl0z000fjms24ukfhi3k"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	node	cml6vykdd0000jms2wwxl9s27
cmlayee4t000hmimrkld0kjeq	2026-02-06 14:01:19.374	FOLDER_VIEWED	Folder	cml8feb2l000d10pfe8y2gtge	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlayee8q000jmimrh5xt3fyd	2026-02-06 14:01:19.514	FOLDER_VIEWED	Folder	cml8feb2l000d10pfe8y2gtge	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlb17inq000g111vpwzazc4q	2026-02-06 15:19:57.494	FOLDER_CREATED_WIZARD	Folder	cmlb17ims0002111v6gbo2rh6	\N	{"type": "juridique", "title": "Test Wizard Cession 2026", "nature": "cession", "clientId": "seed-client-techcorp-pm"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
cmlb185ia0017111vj3jhvoz5	2026-02-06 15:20:27.106	FOLDER_CREATED_WIZARD	Folder	cmlb185h4000j111vmhnvpqz9	\N	{"type": "judiciaire", "title": "TechCorp c/ Durand 2026", "nature": null, "clientId": "seed-client-techcorp-pm"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
cmlb18yr1000if4hahfk0glyz	2026-02-06 15:21:05.005	FOLDER_CREATED_WIZARD	Folder	cmlb18ypu0004f4ha1yi87is2	\N	{"type": "juridique", "title": "AGOA WizardTest2 2026", "nature": "agoa", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
cmlb19c09000kf4hamf5481q8	2026-02-06 15:21:22.186	FOLDER_STATUS_CHANGED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	{"newStatus": "IN_PROGRESS", "oldStatus": "OPEN"}	cml6vykja0002jms2hhr4hfr3	\N	\N	cml6vykdd0000jms2wwxl9s27
cmlb19c0q000mf4ha6gtk9tk3	2026-02-06 15:21:22.203	FOLDER_STATUS_CHANGED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	{"newStatus": "OPEN", "oldStatus": "IN_PROGRESS"}	cml6vykja0002jms2hhr4hfr3	\N	\N	cml6vykdd0000jms2wwxl9s27
cmlb1t5re0003110l2a325l7n	2026-02-06 15:36:47.21	FOLDER_VIEWED	Folder	cmlb185h4000j111vmhnvpqz9	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	python-requests/2.31.0	cml6vykdd0000jms2wwxl9s27
cmlb1tntt0001h48w03icl370	2026-02-06 15:37:10.625	DOCUMENT_UPDATED	Document	cmlb185hs0013111vlzb0r4hm	\N	{"visibleExtranet": true}	cml6vykja0002jms2hhr4hfr3	\N	\N	cml6vykdd0000jms2wwxl9s27
cmlb1tnu60003h48wb7v09x0s	2026-02-06 15:37:10.638	DOCUMENT_UPDATED	Document	cmlb185hs0013111vlzb0r4hm	\N	{"visibleExtranet": false}	cml6vykja0002jms2hhr4hfr3	\N	\N	cml6vykdd0000jms2wwxl9s27
cmlb2dluq000551o7ob0q6uqt	2026-02-06 15:52:41.187	DOCUMENT_GENERATED	Document	cmlb2dluc000151o73j4fvzem	\N	{"forced": true, "folderId": "cmlb18ypu0004f4ha1yi87is2", "templateId": "cmlb298cx0001ffaircjtnyy8", "templateName": "Convention d'honoraires"}	cml6vykja0002jms2hhr4hfr3	\N	\N	cml6vykdd0000jms2wwxl9s27
cmlb2hyo800051256tgl0a4a5	2026-02-06 15:56:04.425	DOCUMENT_GENERATED	Document	cmlb2hynx000112569i3eq2pg	\N	{"forced": true, "folderId": "cmlb18ypu0004f4ha1yi87is2", "templateId": "cmlb298d70003ffaiktmypbci", "templateName": "Lettre de mission"}	cml6vykja0002jms2hhr4hfr3	\N	\N	cml6vykdd0000jms2wwxl9s27
cmlb2hypw000b1256byc1g5dz	2026-02-06 15:56:04.484	DOCUMENT_GENERATED	Document	cmlb2hypl00071256add7xul3	\N	{"folderId": "cmlb18ypu0004f4ha1yi87is2", "templateId": "cmlb298dh0007ffais6upwlwu", "templateName": "Assignation TJ"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	python-requests/2.31.0	cml6vykdd0000jms2wwxl9s27
cmlb5mrgb00041021u5e25y00	2026-02-06 17:23:47.195	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20, "reminderNotify": true}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cmlb5mrh200081021pamwz6l2	2026-02-06 17:23:47.222	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cmlb628pm000f10217004pfjm	2026-02-06 17:35:49.402	USER_CREATED	User	cmlb628pf000d102131uurnum	{"role": "ASSISTANT", "email": "test-e2e-user-1770399349180@test.fr"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb628vr000h1021ignp71vk	2026-02-06 17:35:49.623	USER_PASSWORD_RESET	User	cmlb628pf000d102131uurnum	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb628w3000j1021myvmswnu	2026-02-06 17:35:49.635	USER_DEACTIVATED	User	cmlb628pf000d102131uurnum	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb628x2000n1021p8ffsitf	2026-02-06 17:35:49.67	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb628xe000r1021kub0j58f	2026-02-06 17:35:49.682	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63n5l0011102126sgyluw	2026-02-06 17:36:54.777	FOLDER_CREATED	Folder	cmlb63n5c000z1021i9u7034k	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb63n48000x1021lafmd6nw"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63n6400131021f12ormi4	2026-02-06 17:36:54.797	FOLDER_VIEWED	Folder	cmlb63n5c000z1021i9u7034k	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63n6o00151021vb7x9gcx	2026-02-06 17:36:54.817	FOLDER_DELETED	Folder	cmlb63n5c000z1021i9u7034k	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63ny9001a1021lduq3xko	2026-02-06 17:36:55.809	USER_CREATED	User	cmlb63ny500181021bx6gngd0	{"role": "ASSISTANT", "email": "test-e2e-user-1770399415583@test.fr"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63o4s001c10213u7kkvmm	2026-02-06 17:36:56.044	USER_PASSWORD_RESET	User	cmlb63ny500181021bx6gngd0	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63o53001e1021o4ybp7zx	2026-02-06 17:36:56.055	USER_DEACTIVATED	User	cmlb63ny500181021bx6gngd0	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63o5x001i1021a30j5jmy	2026-02-06 17:36:56.085	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63o66001m1021vd2ge1nq	2026-02-06 17:36:56.095	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63vku001q1021onsd2sc2	2026-02-06 17:37:05.694	FOLDER_CREATED	Folder	cmlb63vkr001o1021qujizh0y	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63vl9001s1021hp4xqqgj	2026-02-06 17:37:05.709	FOLDER_VIEWED	Folder	cmlb63vkr001o1021qujizh0y	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb63vlx001u10214gplmzla	2026-02-06 17:37:05.733	FOLDER_DELETED	Folder	cmlb63vkr001o1021qujizh0y	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6amsu0006bx8t9muec26s	2026-02-06 17:42:20.911	USER_CREATED	User	cmlb6amsr0004bx8tmpk8eyt1	{"role": "ASSISTANT", "email": "test-e2e-user-1770399740692@test.fr"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6amz20008bx8t3dqxurtx	2026-02-06 17:42:21.134	USER_PASSWORD_RESET	User	cmlb6amsr0004bx8tmpk8eyt1	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6amzf000abx8txsd9sc6p	2026-02-06 17:42:21.147	USER_DEACTIVATED	User	cmlb6amsr0004bx8tmpk8eyt1	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6an0f000ebx8tw911rny0	2026-02-06 17:42:21.184	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6an0r000ibx8tv1b67fob	2026-02-06 17:42:21.195	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6ana9000mbx8twlksc4ke	2026-02-06 17:42:21.538	FOLDER_CREATED	Folder	cmlb6ana4000kbx8tqd0o5jwg	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6anap000obx8tqn49py2k	2026-02-06 17:42:21.553	FOLDER_VIEWED	Folder	cmlb6ana4000kbx8tqd0o5jwg	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6anb6000qbx8tui2ho895	2026-02-06 17:42:21.57	FOLDER_DELETED	Folder	cmlb6ana4000kbx8tqd0o5jwg	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6szvw000sbx8t0yd32mnx	2026-02-06 17:56:37.676	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlb6szx1000ubx8t9ccy4upw	2026-02-06 17:56:37.717	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlb6wnmk0004twwig0du665b	2026-02-06 17:59:28.412	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wnmv0008twwikofjv2pe	2026-02-06 17:59:28.424	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wnv1000etwwimupbtwny	2026-02-06 17:59:28.717	FOLDER_CREATED	Folder	cmlb6wnuw000ctwwiudd5cz6f	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wnvf000gtwwikz2xjfwn	2026-02-06 17:59:28.731	FOLDER_VIEWED	Folder	cmlb6wnuw000ctwwiudd5cz6f	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wnvv000itwwi6gbix41b	2026-02-06 17:59:28.748	FOLDER_DELETED	Folder	cmlb6wnuw000ctwwiudd5cz6f	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wsnz000ntwwiucarc0ex	2026-02-06 17:59:34.944	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wsoa000rtwwi59g3l5br	2026-02-06 17:59:34.954	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wsv9000xtwwi4v6bh500	2026-02-06 17:59:35.206	FOLDER_CREATED	Folder	cmlb6wsv5000vtwwizh4qmnh1	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wsvn000ztwwixijvtqqi	2026-02-06 17:59:35.22	FOLDER_VIEWED	Folder	cmlb6wsv5000vtwwizh4qmnh1	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6wsw50011twwirakmjbo1	2026-02-06 17:59:35.237	FOLDER_DELETED	Folder	cmlb6wsv5000vtwwizh4qmnh1	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6xbob0013twwiwunr5crv	2026-02-06 17:59:59.579	USER_DEACTIVATED	User	cmlb63ny500181021bx6gngd0	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
cmlb6xbol0015twwii0ls2x21	2026-02-06 17:59:59.589	USER_DEACTIVATED	User	cmlb6amsr0004bx8tmpk8eyt1	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
cmlb6xbos0017twwi6l02ns3v	2026-02-06 17:59:59.597	USER_DEACTIVATED	User	cmlb628pf000d102131uurnum	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
cmlb6y3fu001ctwwivb6untxn	2026-02-06 18:00:35.562	USER_CREATED	User	cmlb6y3fq001atwwi0f1emmnk	{"role": "ASSISTANT", "email": "test-e2e-user-1770400835343@test.fr"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3m0001etwwiioqyb7dt	2026-02-06 18:00:35.784	USER_PASSWORD_RESET	User	cmlb6y3fq001atwwi0f1emmnk	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3mc001gtwwiwu8g0ffm	2026-02-06 18:00:35.796	USER_DEACTIVATED	User	cmlb6y3fq001atwwi0f1emmnk	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3nb001ktwwiox1ow8tb	2026-02-06 18:00:35.832	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3nn001otwwi5rke205l	2026-02-06 18:00:35.843	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3uz001utwwi6dp7enmx	2026-02-06 18:00:36.107	FOLDER_CREATED	Folder	cmlb6y3uu001stwwi1osy77k4	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3vf001wtwwiugp0qioh	2026-02-06 18:00:36.123	FOLDER_VIEWED	Folder	cmlb6y3uu001stwwi1osy77k4	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb6y3vy001ytwwiyiv137fa	2026-02-06 18:00:36.143	FOLDER_DELETED	Folder	cmlb6y3uu001stwwi1osy77k4	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb7f0rj0001y5jgjfhi9vds	2026-02-06 18:13:45.247	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlb7f0sp0003y5jgydsg58xb	2026-02-06 18:13:45.289	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlb9luo300b4xjn8ml7yplte	2026-02-01 11:45:03.171	DOCUMENT_DOWNLOAD	Template	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.92	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luo900b6xjn84st84i6f	2026-01-10 08:26:03.176	FOLDER_CREATE	Folder	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.94	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luob00b8xjn8lwwkjgdm	2026-01-17 11:43:03.179	TEMPLATE_GENERATE	Template	cmlb9ltzc000fxjn8pe5zbquq	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.191	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luoe00baxjn8suo4ggai	2026-01-25 16:02:03.182	DOCUMENT_VIEW	User	cml8feb2t000h10pfy2cvm3la	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.200	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luoh00bcxjn8yukxhi63	2026-01-26 10:51:03.184	SETTINGS_UPDATE	Client	cml8feb2t000h10pfy2cvm3la	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.19	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luoj00bexjn8av68xvdu	2026-01-17 14:08:03.187	DOCUMENT_VIEW	Document	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.142	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luom00bgxjn8asdcxkwt	2026-01-27 16:54:03.189	SETTINGS_UPDATE	User	cmlb9ldz2000po0taqlkknhzy	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.163	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luoo00bixjn8pr7lo03p	2026-01-09 10:55:03.192	DOCUMENT_DOWNLOAD	Document	cmlb9ltyx0009xjn8ev7qvq1y	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.134	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luoq00bkxjn8plu3063y	2026-01-08 10:04:03.194	LOGIN	Document	cmlb9ltz6000dxjn8q3ikm5q2	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.174	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luot00bmxjn8z4582aeg	2026-02-03 15:41:03.196	SIGNATURE_SEND	Client	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.224	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luow00boxjn8yovh8i1r	2026-02-03 17:09:03.2	DEADLINE_CREATE	Signature	cmlb9ltyg0003xjn8p26kbkxt	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.177	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luoz00bqxjn8f8vhi4mz	2026-01-09 12:38:03.203	CLIENT_CREATE	Document	cmlb9ltyg0003xjn8p26kbkxt	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.80	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lup100bsxjn82slslrus	2026-02-04 13:19:03.205	SETTINGS_UPDATE	User	cmlb9ltyg0003xjn8p26kbkxt	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.38	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lup300buxjn8f8ff30v0	2026-01-29 13:08:03.207	DOCUMENT_VIEW	User	cmlb9ldyz000no0tavpxqe5f8	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.153	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lup600bwxjn8vu63ka4h	2026-02-02 17:19:03.209	SETTINGS_UPDATE	Document	cml8feb2i000b10pfg17hbnxm	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.90	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lup800byxjn8j9zlnkfi	2026-01-20 13:15:03.212	SETTINGS_UPDATE	Template	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.232	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupb00c0xjn8l63y4el1	2026-01-23 10:00:03.214	SETTINGS_UPDATE	User	cmlb9ldyv000lo0tagud0d5cn	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.228	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupc00c2xjn8swqawyla	2026-02-05 14:13:03.216	DOCUMENT_UPLOAD	Folder	cmlaz9ydk0001i4b0mf637jrl	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.9	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupf00c4xjn8zlu0vihf	2026-02-02 12:08:03.218	NOTIFICATION_READ	Template	cmlaqnv9e000hyf6npv6echvh	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.231	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luph00c6xjn82ss1igpo	2026-01-19 15:21:03.221	LOGIN	User	cmlb9ldyq000ho0tab273yhyu	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.154	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupk00c8xjn82os2e839	2026-02-06 16:00:03.223	NOTIFICATION_READ	Client	cmlb17ims0002111v6gbo2rh6	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.45	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupm00caxjn8fw6z9urp	2026-01-24 12:07:03.226	DOCUMENT_UPLOAD	User	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.44	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupq00ccxjn81uadtpz1	2026-01-19 13:19:03.229	SIGNATURE_SEND	Folder	cml8feb2i000b10pfg17hbnxm	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.203	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lupu00cexjn8gchwexgm	2026-01-21 09:27:03.233	SIGNATURE_SEND	Signature	cml6vyl11000hjms2krxzvmzx	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.168	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luq000cgxjn8ky53l4kc	2026-01-28 09:34:03.24	CLIENT_CREATE	User	cmlaz9ydq0003i4b0dggysja4	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.72	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luq500cixjn8kmmd6icj	2026-02-04 14:10:03.244	NOTIFICATION_READ	Signature	cml6vyl0z000fjms24ukfhi3k	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.124	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luq800ckxjn89y4lbcml	2026-01-17 15:08:03.248	SIGNATURE_SEND	Template	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.246	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luqa00cmxjn8qi1ferr0	2026-02-05 11:05:03.25	DOCUMENT_VIEW	Signature	cmlb9ltyx0009xjn8ev7qvq1y	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.127	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luqg00coxjn88zlwrhiz	2026-01-18 08:38:03.256	DOCUMENT_VIEW	User	cmlb9ldyz000no0tavpxqe5f8	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.57	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luqn00cqxjn8kpa3xqit	2026-01-25 13:29:03.262	SETTINGS_UPDATE	User	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.249	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luqr00csxjn8rjas7dvk	2026-01-12 08:56:03.266	TEMPLATE_GENERATE	Template	cmlb9ldyl000fo0ta56i3m5t7	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.131	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luqu00cuxjn8egqmp0ph	2026-01-13 14:07:03.27	TEMPLATE_GENERATE	Client	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.21	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lur000cwxjn843xwhe9b	2026-01-13 09:55:03.275	FOLDER_CREATE	Client	cml6vyl11000hjms2krxzvmzx	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.77	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lur600cyxjn8z2pxa2yp	2026-01-26 11:47:03.281	LOGIN	Document	cmlb9ltyx0009xjn8ev7qvq1y	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.244	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lura00d0xjn8ydmfw5mg	2026-01-27 13:29:03.286	DOCUMENT_DOWNLOAD	User	cmlb9ltz6000dxjn8q3ikm5q2	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.179	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lurd00d2xjn82jphn8ta	2026-01-10 16:33:03.289	CLIENT_CREATE	Signature	cmlb9ltyx0009xjn8ev7qvq1y	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.116	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lurh00d4xjn8oatpfshb	2026-01-20 12:04:03.293	NOTIFICATION_READ	Folder	cmlb185h4000j111vmhnvpqz9	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.101	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lurk00d6xjn8guww7j3j	2026-01-27 15:25:03.296	TEMPLATE_GENERATE	Client	cmlb9ldyt000jo0taxfxaxno0	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.167	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luro00d8xjn8n4worob7	2026-02-03 08:27:03.299	LOGIN	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.187	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lurr00daxjn8sgbnhl1g	2026-02-01 11:16:03.302	FOLDER_CREATE	User	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.3	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lurt00dcxjn83yr6oyxy	2026-01-26 14:21:03.305	CLIENT_CREATE	User	cmlb9ldyv000lo0tagud0d5cn	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.159	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lurw00dexjn8jio736ur	2026-01-17 16:21:03.308	DOCUMENT_VIEW	Folder	cml8feb2i000b10pfg17hbnxm	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.51	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lury00dgxjn8skobw64q	2026-02-05 12:25:03.31	NOTIFICATION_READ	Signature	cml8feb2l000d10pfe8y2gtge	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.233	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lus100dixjn8zwb736s8	2026-01-09 13:54:03.312	SIGNATURE_SEND	Client	cmlb9ltz2000bxjn8n1ih7loj	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.5	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lus400dkxjn8t9qr4ucs	2026-01-23 14:43:03.315	SETTINGS_UPDATE	Template	cmlb9ltys0007xjn8hiblj6iz	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.132	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lus700dmxjn8plmbrrbj	2026-01-16 16:02:03.319	DOCUMENT_DOWNLOAD	Client	cml8feb2l000d10pfe8y2gtge	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.128	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lusa00doxjn8g0s2bzgb	2026-01-17 09:48:03.321	DOCUMENT_VIEW	Document	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.40	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lusc00dqxjn8a6nx6e0r	2026-02-02 13:28:03.324	SETTINGS_UPDATE	Client	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.28	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luse00dsxjn8uyrd8spw	2026-01-17 08:04:03.326	DOCUMENT_VIEW	Folder	cmlb185h4000j111vmhnvpqz9	\N	\N	cml6vykp40004jms2d2rnfrpm	192.168.1.43	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lush00duxjn891b7eeqs	2026-01-25 15:43:03.329	CLIENT_CREATE	Signature	cmlaz9ydq0003i4b0dggysja4	\N	\N	cml6vykja0002jms2hhr4hfr3	192.168.1.170	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mwhu0005yhmmb87fqv9x	2026-02-06 19:15:52.195	FOLDER_CREATED	Folder	cmlb9mwho0003yhmmg6uza7r4	\N	{"type": "LITIGATION", "title": "Test E2E Folder 2026", "clientId": "cmlb9ldyc000do0tayw7fbac9"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mwig0007yhmml2fsp2tb	2026-02-06 19:15:52.216	FOLDER_VIEWED	Folder	cmlb9mwho0003yhmmg6uza7r4	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mwjc0009yhmmpm7lutq4	2026-02-06 19:15:52.248	FOLDER_DELETED	Folder	cmlb9mwho0003yhmmg6uza7r4	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mwtj000eyhmmf0nyk9md	2026-02-06 19:15:52.615	USER_CREATED	User	cmlb9mwtd000cyhmmpczr3qtz	{"role": "ASSISTANT", "email": "test-e2e-user-1770405352377@test.fr"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mwzn000gyhmm8z0bsmgr	2026-02-06 19:15:52.835	USER_PASSWORD_RESET	User	cmlb9mwtd000cyhmmpczr3qtz	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mx00000iyhmmika2r2hw	2026-02-06 19:15:52.848	USER_DEACTIVATED	User	cmlb9mwtd000cyhmmpczr3qtz	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mx0x000myhmmqt87jaqh	2026-02-06 19:15:52.882	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 5, "reminderDelay2": 10, "reminderDelay3": 20}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlb9mx1e000qyhmmmtbg843h	2026-02-06 19:15:52.898	SETTINGS_UPDATED	TenantSettings	cml6vyl1t0016jms240uih3kh	{"reminderDelay1": 3, "reminderDelay2": 7, "reminderDelay3": 14}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	\N	cml6vykdd0000jms2wwxl9s27
cmlbe488n000syhmmaq82pav2	2026-02-06 21:21:19.03	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlbe48bo000uyhmmvw2t6i7b	2026-02-06 21:21:19.14	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlc6iweo0012yhmmt5f6yudi	2026-02-07 10:36:32.784	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlc6iwgj0014yhmmc0ph6t13	2026-02-07 10:36:32.851	FOLDER_VIEWED	Folder	cmlb18ypu0004f4ha1yi87is2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cmlc7t86z0005g2oubxlg8ptr	2026-02-07 11:12:34.235	FOLDER_CREATED	Folder	cmlc7t86l0003g2ouf76d74yj	\N	{"type": "LITIGATION", "title": "Test Email Brevo", "clientId": "cmlc6ju1k0016yhmm97qv58zj"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	Python-urllib/3.12	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: avocat_legal_info; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.avocat_legal_info (id, "createdAt", "updatedAt", "tenantId", "numeroToque", barreau, specialites, rcs, "tvaIntra", "assuranceRC", "numeroPolice", "signaturePath", "cachetPath", "mentionsLegales") FROM stdin;
cml7z1r4400018nc2oq2y4dwa	2026-02-04 11:56:10.754	2026-02-04 11:58:08.016	cml6vykdd0000jms2wwxl9s27	P0245	Angers	{"Droit des affaires","Droit des sociétés",Fusions-Acquisitions}	Angers B 123 456 789	FR12345678901	AXA Assurances	RC-2026-00123456	\N	\N	{"rcs": "Angers B 123 456 789", "ordre": "Ordre des Avocats du Barreau d'Angers", "siege": "123 Rue de la Paix, 49000 Angers", "capital": 10000, "denomination": "Cabinet Pragmavox", "forme_juridique": "SELARL"}
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.backup_logs (id, "createdAt", "tenantId", type, status, "startedAt", "completedAt", "fileSize", "googleDriveId", "errorMessage") FROM stdin;
cml8vc3840003nk90y6t6vu6u	2026-02-05 03:00:00.724	\N	DATABASE	FAILED	2026-02-05 03:00:00.724	2026-02-05 03:00:00.883	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-05T03-00-00-718Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cml8vc3510001nk90jsvc1ntg	2026-02-05 03:00:00.442	\N	FULL	FAILED	2026-02-05 03:00:00.442	2026-02-05 03:00:00.909	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-05T03-00-00-718Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlaary3l0003yf6nlgvpsitm	2026-02-06 03:00:00.993	\N	DATABASE	FAILED	2026-02-06 03:00:00.993	2026-02-06 03:00:01.427	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-06T03-00-00-990Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlaary0e0001yf6niign42xt	2026-02-06 03:00:00.663	\N	FULL	FAILED	2026-02-06 03:00:00.663	2026-02-06 03:00:01.493	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-06T03-00-00-990Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlbq7ss3000yyhmm7ay8artz	2026-02-07 03:00:01.011	\N	DATABASE	FAILED	2026-02-07 03:00:01.011	2026-02-07 03:00:01.321	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-07T03-00-01-005Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlbq7sp1000wyhmm5xs7dqd1	2026-02-07 03:00:00.684	\N	FULL	FAILED	2026-02-07 03:00:00.684	2026-02-07 03:00:01.425	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-07T03-00-01-005Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmld5nn8b0003oyefap5v84bp	2026-02-08 03:00:00.731	\N	DATABASE	FAILED	2026-02-08 03:00:00.731	2026-02-08 03:00:00.959	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-08T03-00-00-726Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmld5nn5v0001oyef12gyjs7o	2026-02-08 03:00:00.45	\N	FULL	FAILED	2026-02-08 03:00:00.45	2026-02-08 03:00:01.011	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-08T03-00-00-726Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlel3i7h0007oyef6cp14vcg	2026-02-09 03:00:01.133	\N	DATABASE	FAILED	2026-02-09 03:00:01.133	2026-02-09 03:00:01.446	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-09T03-00-01-128Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlel3i3z0005oyefv6f1qh4l	2026-02-09 03:00:00.817	\N	FULL	FAILED	2026-02-09 03:00:00.817	2026-02-09 03:00:01.522	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-09T03-00-01-128Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlg0jccc00034gzz2d9twcg7	2026-02-10 03:00:00.444	\N	DATABASE	FAILED	2026-02-10 03:00:00.444	2026-02-10 03:00:00.676	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-10T03-00-00-442Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlg0jc9m00014gzz4jh3p499	2026-02-10 03:00:00.212	\N	FULL	FAILED	2026-02-10 03:00:00.212	2026-02-10 03:00:00.729	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-10T03-00-00-442Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlhfz7gc00074gzzu9a94rxc	2026-02-11 03:00:01.021	\N	DATABASE	FAILED	2026-02-11 03:00:01.021	2026-02-11 03:00:01.409	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-11T03-00-01-016Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlhfz7dk00054gzziphqfl63	2026-02-11 03:00:00.752	\N	FULL	FAILED	2026-02-11 03:00:00.752	2026-02-11 03:00:01.464	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-11T03-00-01-016Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlivf21o000b4gzzusxm62o3	2026-02-12 03:00:00.924	\N	DATABASE	FAILED	2026-02-12 03:00:00.924	2026-02-12 03:00:01.109	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-12T03-00-00-921Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlivf1zi00094gzzvivk9mgx	2026-02-12 03:00:00.706	\N	FULL	FAILED	2026-02-12 03:00:00.706	2026-02-12 03:00:01.165	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-12T03-00-00-921Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlkauway000f4gzz5olv997k	2026-02-13 03:00:00.395	\N	DATABASE	FAILED	2026-02-13 03:00:00.395	2026-02-13 03:00:00.695	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-13T03-00-00-392Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlkauw8k000d4gzzxb1we45j	2026-02-13 03:00:00.152	\N	FULL	FAILED	2026-02-13 03:00:00.152	2026-02-13 03:00:00.739	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-13T03-00-00-392Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmllqarfp000j4gzz3vgbjk2v	2026-02-14 03:00:00.997	\N	DATABASE	FAILED	2026-02-14 03:00:00.997	2026-02-14 03:00:01.259	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-14T03-00-00-994Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmllqardf000h4gzzk9cssx9j	2026-02-14 03:00:00.742	\N	FULL	FAILED	2026-02-14 03:00:00.742	2026-02-14 03:00:01.325	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-14T03-00-00-994Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmln5qm1z000n4gzzdj07kuvp	2026-02-15 03:00:00.935	\N	DATABASE	FAILED	2026-02-15 03:00:00.935	2026-02-15 03:00:01.329	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-15T03-00-00-931Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmln5qlze000l4gzz38geddmm	2026-02-15 03:00:00.684	\N	FULL	FAILED	2026-02-15 03:00:00.684	2026-02-15 03:00:01.384	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-15T03-00-00-931Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlol6gxf000r4gzzqznxhmk2	2026-02-16 03:00:01.203	\N	DATABASE	FAILED	2026-02-16 03:00:01.203	2026-02-16 03:00:01.513	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-16T03-00-01-200Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cmlol6gu1000p4gzzdmnuk542	2026-02-16 03:00:00.851	\N	FULL	FAILED	2026-02-16 03:00:00.851	2026-02-16 03:00:01.543	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-16T03-00-01-200Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
\.


--
-- Data for Name: builder_blocks; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.builder_blocks (id, "createdAt", "updatedAt", "tenantId", category, title, content, variables, tags, "isMandatory", "isSystem", "displayOrder", "usageCount", "createdById", "deletedAt") FROM stdin;
cml7z49iq0001b6vehzovx84s	2026-02-04 11:58:07.922	2026-02-04 11:58:07.922	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête assignation TJ	ASSIGNATION\n\nDevant le Tribunal Judiciaire de {{juridiction}}\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}, {{demandeur.qualite}}, demeurant {{demandeur.adresse}},\n\nAyant pour avocat constitué : Maître {{avocat.nom}}, avocat au barreau de {{avocat.barreau}}, Toque n°{{avocat.toque}}	\N	{assignation,TJ,"tribunal judiciaire"}	t	t	\N	0	\N	\N
cml7z49iz0003b6vepujrnmuc	2026-02-04 11:58:07.931	2026-02-04 11:58:07.931	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête assignation TC	ASSIGNATION\n\nDevant le Tribunal de Commerce de {{juridiction}}\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}, {{demandeur.forme_juridique}}, au capital de {{demandeur.capital}} euros, immatriculée au RCS de {{demandeur.rcs}} sous le numéro {{demandeur.siret}}, dont le siège social est situé {{demandeur.siege}}	\N	{assignation,TC,"tribunal commerce"}	t	t	\N	0	\N	\N
cml7z49j20005b6ve03t88bbo	2026-02-04 11:58:07.934	2026-02-04 11:58:07.934	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête conclusions	CONCLUSIONS\n\nPOUR :\n{{partie.nom}}, {{partie.qualite}}\nDemeurant {{partie.adresse}}\n\nAyant pour avocat constitué : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n{{avocat.adresse}}\nTél : {{avocat.telephone}} - Fax : {{avocat.fax}}\nToque n°{{avocat.toque}}	\N	{conclusions,en-tête}	f	t	\N	0	\N	\N
cml7z49ji0007b6vetr147duw	2026-02-04 11:58:07.951	2026-02-04 11:58:07.951	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête mise en demeure	{{cabinet.nom}}\n{{cabinet.adresse}}\n{{cabinet.cp}} {{cabinet.ville}}\n\nLettre recommandée avec AR n°{{lrar.numero}}\n\n{{lieu}}, le {{date}}\n\nObjet : Mise en demeure\nRéf : {{reference_dossier}}\n\nMadame, Monsieur,	\N	{"mise en demeure",LRAR,courrier}	f	t	\N	0	\N	\N
cml7z49jl0009b6veju45kles	2026-02-04 11:58:07.953	2026-02-04 11:58:07.953	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête convocation audience	CONVOCATION À L'AUDIENCE\n\nVeuillez vous présenter ou vous faire représenter le :\n\n{{date_audience}} à {{heure_audience}}\n\nDevant le {{juridiction}}\nSitué : {{adresse_juridiction}}\nSalle : {{salle_audience}}\n\nPour l'affaire :\n{{demandeur.nom}} c/ {{defendeur.nom}}\nRG n°{{numero_rg}}	\N	{convocation,audience}	f	t	\N	0	\N	\N
cml7z49jo000bb6veyo49j1i5	2026-02-04 11:58:07.957	2026-02-04 11:58:07.957	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Cession entreprise	I. EXPOSÉ DES FAITS\n\nLa société {{cedant.nom}}, {{cedant.forme}}, a été constituée le {{cedant.date_constitution}}.\n\nSon capital social s'élève à {{cedant.capital}} euros, divisé en {{cedant.nombre_parts}} parts sociales de {{cedant.valeur_nominale}} euros chacune.\n\nPar acte sous seing privé en date du {{date_promesse}}, {{cedant.dirigeant}} a consenti à {{cessionnaire.nom}} une promesse de cession portant sur {{nombre_parts_cedees}} parts sociales, représentant {{pourcentage_cession}}% du capital social.	\N	{faits,cession,entreprise,"parts sociales"}	f	t	\N	0	\N	\N
cml7z49jr000db6ve23qmqhl9	2026-02-04 11:58:07.959	2026-02-04 11:58:07.959	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Inexécution contrat	I. EXPOSÉ DES FAITS\n\nPar contrat en date du {{date_contrat}}, {{demandeur.nom}} et {{defendeur.nom}} ont conclu un accord portant sur {{objet_contrat}}.\n\nAux termes de ce contrat, {{defendeur.nom}} s'engageait à :\n{{#each obligations}}\n- {{this}}\n{{/each}}\n\nOr, force est de constater que {{defendeur.nom}} n'a pas respecté ses engagements contractuels.	\N	{faits,inexécution,contrat}	f	t	\N	0	\N	\N
cml7z49jt000fb6vewht7g66x	2026-02-04 11:58:07.962	2026-02-04 11:58:07.962	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Litige commercial	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} exerce une activité de {{demandeur.activite}} depuis {{demandeur.date_creation}}.\n\nDans le cadre de son activité, {{demandeur.nom}} a passé commande auprès de {{defendeur.nom}} le {{date_commande}} pour un montant de {{montant_commande}} euros HT.\n\nMalgré le paiement intégral de la commande le {{date_paiement}}, {{defendeur.nom}} n'a toujours pas procédé à la livraison des marchandises commandées.	\N	{faits,litige,commercial}	f	t	\N	0	\N	\N
cml7z49jv000hb6vecm701xa8	2026-02-04 11:58:07.964	2026-02-04 11:58:07.964	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1103 Code Civil	II. DISCUSSION EN DROIT\n\nA. Sur la force obligatoire du contrat\n\nAux termes de l'article 1103 du Code civil :\n« Les contrats légalement formés tiennent lieu de loi à ceux qui les ont faits. »\n\nEn l'espèce, le contrat conclu entre les parties est parfaitement valable et doit donc recevoir pleine et entière application.\n\n{{defendeur.nom}} ne saurait s'exonérer de ses obligations contractuelles sans engager sa responsabilité.	\N	{moyens,droit,contrat,1103}	f	t	\N	0	\N	\N
cml7z49jx000jb6vevp0sqzbo	2026-02-04 11:58:07.966	2026-02-04 11:58:07.966	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1217 Code Civil	B. Sur les remèdes à l'inexécution\n\nL'article 1217 du Code civil dispose :\n« La partie envers laquelle l'engagement n'a pas été exécuté, ou l'a été imparfaitement, peut :\n- refuser d'exécuter ou suspendre l'exécution de sa propre obligation ;\n- poursuivre l'exécution forcée en nature de l'obligation ;\n- obtenir une réduction du prix ;\n- provoquer la résolution du contrat ;\n- demander réparation des conséquences de l'inexécution. »\n\nEn l'espèce, {{demandeur.nom}} est fondé à solliciter {{remede_choisi}}.	\N	{moyens,droit,inexécution,1217}	f	t	\N	0	\N	\N
cml7z49jz000lb6vea2qby8gt	2026-02-04 11:58:07.968	2026-02-04 11:58:07.968	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Responsabilité contractuelle	C. Sur la responsabilité contractuelle\n\nLa responsabilité contractuelle de {{defendeur.nom}} est engagée dès lors que :\n\n1. Un contrat valable a été conclu entre les parties ;\n2. {{defendeur.nom}} n'a pas exécuté ses obligations contractuelles ;\n3. Cette inexécution a causé un préjudice à {{demandeur.nom}}.\n\nCes trois conditions sont réunies en l'espèce :\n- Le contrat du {{date_contrat}} est parfaitement valable ;\n- L'inexécution est caractérisée par {{description_inexecution}} ;\n- Le préjudice s'élève à la somme de {{montant_prejudice}} euros.	\N	{moyens,responsabilité,contractuelle}	f	t	\N	0	\N	\N
cml7z49k1000nb6vem119olib	2026-02-04 11:58:07.969	2026-02-04 11:58:07.969	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Condamnation pécuniaire	PAR CES MOTIFS\n\nPlaise au Tribunal de :\n\n- DÉCLARER {{demandeur.nom}} recevable et bien fondé en ses demandes ;\n\n- CONDAMNER {{defendeur.nom}} à payer à {{demandeur.nom}} la somme de {{montant_principal}} euros à titre de dommages et intérêts ;\n\n- CONDAMNER {{defendeur.nom}} à payer à {{demandeur.nom}} la somme de {{montant_article_700}} euros au titre de l'article 700 du Code de procédure civile ;\n\n- CONDAMNER {{defendeur.nom}} aux entiers dépens ;	\N	{dispositif,condamnation,dommages-intérêts}	t	t	\N	0	\N	\N
cml85wbxr0005m3wj01sxwyyw	2026-02-04 15:07:55.119	2026-02-04 15:07:55.119	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête déclaration de créance	DÉCLARATION DE CRÉANCE\n\nProcédure collective n°{{numero_procedure}}\nOuverte à l'encontre de : {{debiteur.nom}}\nJugement d'ouverture du {{date_jugement}}\n\nCRÉANCIER DÉCLARANT :\n{{creancier.nom}}\n{{creancier.adresse}}\nSIRET : {{creancier.siret}}\n\nÀ l'attention de :\nMaître {{mandataire.nom}}, {{mandataire.qualite}}\n{{mandataire.adresse}}	\N	{déclaration,créance,"procédure collective",redressement}	f	t	\N	0	\N	\N
cml7z49k3000pb6vep28zt8bp	2026-02-04 11:58:07.972	2026-02-04 11:58:07.972	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Exécution forcée	PAR CES MOTIFS\n\nPlaise au Tribunal de :\n\n- ORDONNER l'exécution forcée du contrat conclu le {{date_contrat}} ;\n\n- CONDAMNER {{defendeur.nom}} à exécuter son obligation de {{obligation}} sous astreinte de {{montant_astreinte}} euros par jour de retard à compter de la signification du présent jugement ;\n\n- CONDAMNER {{defendeur.nom}} aux dépens ainsi qu'à payer à {{demandeur.nom}} la somme de {{montant_article_700}} euros sur le fondement de l'article 700 du CPC ;	\N	{dispositif,"exécution forcée",astreinte}	f	t	\N	0	\N	\N
cml7z49k6000rb6vesj4lazij	2026-02-04 11:58:07.974	2026-02-04 11:58:07.974	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Résolution contrat	PAR CES MOTIFS\n\nPlaise au Tribunal de :\n\n- PRONONCER la résolution du contrat conclu le {{date_contrat}} aux torts exclusifs de {{defendeur.nom}} ;\n\n- CONDAMNER {{defendeur.nom}} à restituer à {{demandeur.nom}} la somme de {{montant_restitution}} euros versée en exécution du contrat ;\n\n- CONDAMNER {{defendeur.nom}} à payer à {{demandeur.nom}} la somme de {{montant_prejudice}} euros à titre de dommages et intérêts ;	\N	{dispositif,résolution,contrat}	f	t	\N	0	\N	\N
cml7z49k8000tb6vez4ps44yj	2026-02-04 11:58:07.976	2026-02-04 11:58:07.976	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Formule signature avocat	Sous toutes réserves et ce ne sera que justice.\n\nFait à {{lieu}}, le {{date}}\n\nMaître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}	\N	{signature,avocat}	t	t	\N	0	\N	\N
cml7z49ka000vb6ve9qef0mu2	2026-02-04 11:58:07.978	2026-02-04 11:58:07.978	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Bordereau de pièces	BORDEREAU DE COMMUNICATION DE PIÈCES\n\n{{#each pieces}}\nPièce n°{{@index}} : {{this.titre}}\n{{/each}}	\N	{bordereau,pièces}	f	t	\N	0	\N	\N
cml7z49kc000xb6vezg7hxujk	2026-02-04 11:58:07.98	2026-02-04 11:58:07.98	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de non-concurrence	ARTICLE {{numero}} - NON-CONCURRENCE\n\nLe Cédant s'engage à ne pas exercer, directement ou indirectement, une activité concurrente de celle de la Société pendant une durée de {{duree}} ans à compter de la Date de Réalisation, sur le territoire de {{territoire}}.\n\nEn cas de violation de cette obligation, le Cédant sera redevable envers le Cessionnaire d'une indemnité forfaitaire de {{montant_penalite}} euros, sans préjudice du droit du Cessionnaire de demander l'indemnisation de son préjudice réel.	\N	{clause,non-concurrence,cession}	f	t	\N	0	\N	\N
cml7z49ke000zb6ve9lefic9i	2026-02-04 11:58:07.982	2026-02-04 11:58:07.982	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de garantie d'actif et passif	ARTICLE {{numero}} - GARANTIE D'ACTIF ET DE PASSIF\n\n{{numero}}.1 - Le Cédant garantit le Cessionnaire contre toute diminution d'actif ou augmentation de passif de la Société qui résulterait :\n- d'événements, faits ou circonstances antérieurs à la Date de Réalisation ;\n- de la non-conformité des déclarations figurant à l'Annexe {{annexe_declarations}}.\n\n{{numero}}.2 - Cette garantie est consentie pour une durée de {{duree_garantie}} mois à compter de la Date de Réalisation.\n\n{{numero}}.3 - La garantie ne pourra être mise en œuvre que si le montant unitaire d'une Réclamation excède {{seuil_declenchement}} euros et si le montant cumulé des Réclamations excède {{franchise}} euros.	\N	{clause,GAP,garantie,cession}	f	t	\N	0	\N	\N
cml7z49kg0011b6verddbio78	2026-02-04 11:58:07.985	2026-02-04 11:58:07.985	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'earn-out	ARTICLE {{numero}} - COMPLÉMENT DE PRIX (EARN-OUT)\n\n{{numero}}.1 - En sus du Prix de Cession, le Cessionnaire versera au Cédant un complément de prix calculé comme suit :\n\n- Si l'EBITDA de l'exercice {{exercice_reference}} est supérieur à {{seuil_ebitda}} euros, le Cessionnaire versera au Cédant {{pourcentage_earnout}}% de l'excédent.\n\n{{numero}}.2 - Le complément de prix sera plafonné à {{plafond_earnout}} euros.\n\n{{numero}}.3 - Le paiement interviendra dans les {{delai_paiement}} jours suivant l'approbation des comptes de l'exercice {{exercice_reference}}.	\N	{clause,earn-out,"complément prix",cession}	f	t	\N	0	\N	\N
cml7z49ki0013b6veiobgn2vk	2026-02-04 11:58:07.987	2026-02-04 11:58:07.987	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de confidentialité	ARTICLE {{numero}} - CONFIDENTIALITÉ\n\nLes Parties s'engagent à considérer comme strictement confidentielles et à ne pas divulguer les informations échangées dans le cadre de la présente opération.\n\nCette obligation de confidentialité restera en vigueur pendant une durée de {{duree}} ans à compter de la signature des présentes.\n\nLa violation de cette obligation pourra donner lieu à l'allocation de dommages et intérêts.	\N	{clause,confidentialité}	f	t	\N	0	\N	\N
cml7z49kk0015b6ve43fsawdl	2026-02-04 11:58:07.989	2026-02-04 11:58:07.989	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de sortie conjointe (tag-along)	ARTICLE {{numero}} - DROIT DE SORTIE CONJOINTE (TAG-ALONG)\n\nEn cas de projet de cession par un Associé Majoritaire de tout ou partie de ses parts sociales à un tiers, les Associés Minoritaires bénéficieront d'un droit de sortie conjointe leur permettant de céder leurs parts au même prix et aux mêmes conditions.\n\nL'Associé Majoritaire devra notifier son projet de cession aux Associés Minoritaires par lettre recommandée avec accusé de réception {{delai_notification}} jours avant la date envisagée de cession.	\N	{clause,tag-along,"sortie conjointe","pacte associés"}	f	t	\N	0	\N	\N
cml7z49km0017b6vepg1sr0ia	2026-02-04 11:58:07.99	2026-02-04 11:58:07.99	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'entraînement (drag-along)	ARTICLE {{numero}} - OBLIGATION DE SORTIE CONJOINTE (DRAG-ALONG)\n\nEn cas de projet de cession par les Associés Majoritaires représentant au moins {{seuil_majoritaires}}% du capital social à un tiers acquéreur offrant d'acquérir 100% du capital, les Associés Minoritaires seront tenus de céder leurs parts au même prix et aux mêmes conditions.\n\nLe droit d'entraînement ne pourra être exercé que si le prix de cession est au moins égal à {{prix_minimum}} euros par part sociale.	\N	{clause,drag-along,entraînement,"pacte associés"}	f	t	\N	0	\N	\N
cml82hb9y0001hqsdzc8ou44s	2026-02-04 13:32:15.573	2026-02-04 13:32:15.573	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête lettre simple	{{cabinet.nom}}\n{{cabinet.adresse}}\n{{cabinet.cp}} {{cabinet.ville}}\nTél : {{cabinet.telephone}}\nEmail : {{cabinet.email}}\n\n{{lieu}}, le {{date}}\n\n{{destinataire.civilite}} {{destinataire.nom}}\n{{destinataire.adresse}}\n{{destinataire.cp}} {{destinataire.ville}}\n\nObjet : {{objet_lettre}}\nRéf. dossier : {{reference_dossier}}\n\n{{destinataire.civilite}},	\N	{lettre,courrier,simple,en-tête}	f	t	\N	0	\N	\N
cml82hbaa0003hqsdwuxv29te	2026-02-04 13:32:15.587	2026-02-04 13:32:15.587	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête requête	REQUÊTE\n\nPrésentée à {{juridiction}}\n\nPAR :\n{{requerant.nom}}, {{requerant.qualite}}\nDemeurant : {{requerant.adresse}}\n\nAyant pour avocat : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\nToque n°{{avocat.toque}}\n\nTendant à voir ordonner {{objet_requete}}	\N	{requête,en-tête,ordonnance}	f	t	\N	0	\N	\N
cml88g72z000m521vpjyagym7	2026-02-04 16:19:21.18	2026-02-04 16:19:21.18	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Rétractation	CONCLUSIONS AUX FINS DE RÉTRACTATION\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nDemande la rétractation de l'ordonnance rendue le {{date_ordonnance}} par le Président du Tribunal Judiciaire.	{}	{retractation,intro}	f	t	11	0	\N	\N
cml82hbad0005hqsdm9m7x2qy	2026-02-04 13:32:15.59	2026-02-04 13:32:15.59	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête assignation en référé	ASSIGNATION EN RÉFÉRÉ\n\nDevant {{juridiction}}, statuant en référé\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}, {{demandeur.qualite}}, demeurant {{demandeur.adresse}},\n\nAyant pour avocat constitué : Maître {{avocat.nom}}, avocat au barreau de {{avocat.barreau}}, Toque n°{{avocat.toque}},\n\nJ'ai, {{huissier.nom}}, Huissier de Justice associé près le Tribunal Judiciaire de {{huissier.ressort}},\n\nDONNÉ ASSIGNATION À :\n\n{{defendeur.nom}}, demeurant {{defendeur.adresse}},\n\nD'avoir à comparaître le {{date_audience}} à {{heure_audience}}\nDevant {{juridiction}}, statuant en référé,\nSis {{adresse_juridiction}}	\N	{assignation,référé,urgence,en-tête}	f	t	\N	0	\N	\N
cml82hbag0007hqsdfp1cgad6	2026-02-04 13:32:15.592	2026-02-04 13:32:15.592	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête sommation interpellative	SOMMATION INTERPELLATIVE\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{requerant.nom}}, {{requerant.qualite}}, demeurant {{requerant.adresse}},\n\nJ'ai, {{huissier.nom}}, Huissier de Justice,\n\nSOMMÉ {{somme.nom}}, demeurant {{somme.adresse}},\n\nDE RÉPONDRE AUX QUESTIONS SUIVANTES :\n\n{{#each questions}}\n{{@index}}. {{this}}\n{{/each}}\n\nEt lui ai déclaré que ses réponses seront consignées dans le présent acte et pourront être utilisées en justice.	\N	{sommation,interpellative,huissier,preuve}	f	t	\N	0	\N	\N
cml82hbai0009hqsd511u2gf2	2026-02-04 13:32:15.594	2026-02-04 13:32:15.594	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête protocole d'accord	PROTOCOLE D'ACCORD TRANSACTIONNEL\n\nENTRE LES SOUSSIGNÉS :\n\n{{partie1.nom}}, {{partie1.forme_juridique}}, au capital de {{partie1.capital}} euros,\nimmatriculée au RCS de {{partie1.rcs}} sous le numéro {{partie1.siret}},\ndont le siège social est situé {{partie1.siege}},\nreprésentée par {{partie1.representant}}, en sa qualité de {{partie1.qualite_representant}},\n\nCi-après dénommée « {{partie1.denomination}} »,\n\nD'UNE PART,\n\nET :\n\n{{partie2.nom}}, {{partie2.forme_juridique}}, au capital de {{partie2.capital}} euros,\nimmatriculée au RCS de {{partie2.rcs}} sous le numéro {{partie2.siret}},\ndont le siège social est situé {{partie2.siege}},\nreprésentée par {{partie2.representant}}, en sa qualité de {{partie2.qualite_representant}},\n\nCi-après dénommée « {{partie2.denomination}} »,\n\nD'AUTRE PART,\n\nEnsemble désignées « les Parties »,\n\nIL A ÉTÉ PRÉALABLEMENT EXPOSÉ CE QUI SUIT :	\N	{protocole,accord,transaction,en-tête}	f	t	\N	0	\N	\N
cml82hbak000bhqsd3pqyllng	2026-02-04 13:32:15.597	2026-02-04 13:32:15.597	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Rupture contrat de travail	I. EXPOSÉ DES FAITS\n\n{{salarie.nom}} a été embauché par la société {{employeur.nom}} le {{date_embauche}} en qualité de {{poste}} selon contrat de travail à durée {{type_contrat}}.\n\nSa rémunération mensuelle brute s'élevait à {{salaire_brut}} euros.\n\nLe {{date_rupture}}, {{employeur.nom}} a procédé à {{type_rupture}} du contrat de travail de {{salarie.nom}} dans les circonstances suivantes :\n\n{{circonstances_rupture}}\n\nCette rupture est intervenue sans que {{motifs_contestation}}.	\N	{faits,travail,rupture,licenciement,"contrat travail"}	f	t	\N	0	\N	\N
cml82hbam000dhqsdq2kziiy7	2026-02-04 13:32:15.599	2026-02-04 13:32:15.599	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Vice caché	I. EXPOSÉ DES FAITS\n\nPar acte {{type_acte}} en date du {{date_vente}}, {{vendeur.nom}} a vendu à {{acheteur.nom}} {{bien_vendu}} moyennant le prix de {{prix_vente}} euros.\n\nPostérieurement à la vente, {{acheteur.nom}} a découvert l'existence des vices suivants :\n\n{{#each vices}}\n- {{this.description}} (constaté le {{this.date_decouverte}})\n{{/each}}\n\nCes vices, antérieurs à la vente et cachés lors de celle-ci, rendent le bien impropre à l'usage auquel il était destiné, à savoir {{usage_prevu}}.\n\nUne expertise {{type_expertise}} réalisée par {{expert.nom}} le {{date_expertise}} a confirmé l'existence et la gravité de ces vices.	\N	{faits,"vice caché",vente,garantie}	f	t	\N	0	\N	\N
cml82hbao000fhqsd8dikwudd	2026-02-04 13:32:15.601	2026-02-04 13:32:15.601	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Concurrence déloyale	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} exerce une activité de {{activite}} depuis {{date_creation}} et jouit d'une notoriété établie dans ce secteur.\n\n{{defendeur.nom}}, ancien {{relation_anterieure}} de {{demandeur.nom}} jusqu'au {{date_fin_relation}}, a créé la société {{societe_concurrente.nom}} le {{date_creation_concurrent}}.\n\nDepuis lors, {{defendeur.nom}} se livre à des actes de concurrence déloyale caractérisés par :\n\n{{#each actes_deloyaux}}\n- {{this.description}}\n{{/each}}\n\nCes agissements ont causé à {{demandeur.nom}} un préjudice commercial considérable, se traduisant par {{description_prejudice}}.	\N	{faits,"concurrence déloyale",commercial,préjudice}	f	t	\N	0	\N	\N
cml82hbar000hhqsdu663xnr8	2026-02-04 13:32:15.603	2026-02-04 13:32:15.603	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Recouvrement impayés	I. EXPOSÉ DES FAITS\n\n{{creancier.nom}} a fourni à {{debiteur.nom}} les prestations/marchandises suivantes :\n\n{{#each factures}}\n- Facture n°{{this.numero}} du {{this.date}} d'un montant de {{this.montant}} euros HT (échéance : {{this.echeance}})\n{{/each}}\n\nLe montant total des sommes dues s'élève à {{montant_total}} euros TTC.\n\nMalgré plusieurs relances amiables en date des {{dates_relances}}, {{debiteur.nom}} n'a procédé à aucun règlement.\n\nUne mise en demeure lui a été adressée par lettre recommandée avec accusé de réception le {{date_mise_en_demeure}}, restée sans effet à ce jour.	\N	{faits,impayés,recouvrement,créance,facture}	f	t	\N	0	\N	\N
cml82hbat000jhqsdw54powdy	2026-02-04 13:32:15.605	2026-02-04 13:32:15.605	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Responsabilité civile	I. EXPOSÉ DES FAITS\n\nLe {{date_fait_dommageable}}, {{victime.nom}} a subi un dommage dans les circonstances suivantes :\n\n{{description_circonstances}}\n\nCe dommage est directement imputable à {{responsable.nom}} qui {{description_fait_generateur}}.\n\n{{victime.nom}} a subi les préjudices suivants :\n\n{{#each prejudices}}\n- {{this.nature}} : {{this.description}} (évaluation provisoire : {{this.montant}} euros)\n{{/each}}\n\nUn rapport d'expertise établi par {{expert.nom}} le {{date_expertise}} confirme l'imputabilité du dommage et évalue le préjudice définitif à {{montant_total_prejudice}} euros.	\N	{faits,responsabilité,dommage,préjudice,indemnisation}	f	t	\N	0	\N	\N
cml82hbav000lhqsdc5gl3nv8	2026-02-04 13:32:15.607	2026-02-04 13:32:15.607	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1231-1 Code Civil (Dommages-intérêts)	II. DISCUSSION EN DROIT\n\nA. Sur les dommages-intérêts pour inexécution\n\nL'article 1231-1 du Code civil dispose :\n« Le débiteur est condamné, s'il y a lieu, au paiement de dommages et intérêts soit à raison de l'inexécution de l'obligation, soit à raison du retard dans l'exécution, s'il ne justifie pas que l'exécution a été empêchée par la force majeure. »\n\nEn l'espèce, {{defendeur.nom}} n'a pas exécuté son obligation de {{obligation_inexecutee}}.\n\nCette inexécution a causé à {{demandeur.nom}} un préjudice direct et certain s'élevant à {{montant_prejudice}} euros, correspondant à {{nature_prejudice}}.	\N	{moyens,droit,dommages-intérêts,1231-1,inexécution}	f	t	\N	0	\N	\N
cml82hbax000nhqsd3bt19pud	2026-02-04 13:32:15.61	2026-02-04 13:32:15.61	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1240 Code Civil (Responsabilité délictuelle)	II. DISCUSSION EN DROIT\n\nA. Sur la responsabilité délictuelle\n\nL'article 1240 du Code civil dispose :\n« Tout fait quelconque de l'homme, qui cause à autrui un dommage, oblige celui par la faute duquel il est arrivé à le réparer. »\n\nTrois conditions doivent être réunies :\n1. Une faute : {{defendeur.nom}} a commis une faute en {{description_faute}} ;\n2. Un dommage : {{demandeur.nom}} a subi un préjudice de {{montant_prejudice}} euros ;\n3. Un lien de causalité : le dommage est la conséquence directe et certaine de la faute commise.\n\nLa responsabilité de {{defendeur.nom}} est donc engagée sur le fondement de l'article 1240 du Code civil.	\N	{moyens,droit,"responsabilité délictuelle",1240,faute}	f	t	\N	0	\N	\N
cml82hbb2000phqsdj4lt2c0r	2026-02-04 13:32:15.615	2026-02-04 13:32:15.615	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1641 Code Civil (Garantie des vices cachés)	II. DISCUSSION EN DROIT\n\nA. Sur la garantie des vices cachés\n\nL'article 1641 du Code civil dispose :\n« Le vendeur est tenu de la garantie à raison des défauts cachés de la chose vendue qui la rendent impropre à l'usage auquel on la destine, ou qui diminuent tellement cet usage que l'acheteur ne l'aurait pas acquise, ou n'en aurait donné qu'un moindre prix, s'il les avait connus. »\n\nLe vice est caractérisé lorsque :\n- Il est antérieur à la vente : en l'espèce, {{preuve_anteriorite}} ;\n- Il est caché : {{demandeur.nom}} ne pouvait le déceler lors de la vente ;\n- Il est grave : le bien est impropre à {{usage_prevu}}.\n\n{{demandeur.nom}} est donc fondé à exercer l'action rédhibitoire ou estimatoire prévue à l'article 1644 du Code civil.	\N	{moyens,droit,"vice caché",1641,vente,garantie}	f	t	\N	0	\N	\N
cml82hbb5000rhqsdizu9noiu	2026-02-04 13:32:15.618	2026-02-04 13:32:15.618	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1792 Code Civil (Responsabilité décennale)	II. DISCUSSION EN DROIT\n\nA. Sur la responsabilité décennale des constructeurs\n\nL'article 1792 du Code civil dispose :\n« Tout constructeur d'un ouvrage est responsable de plein droit, envers le maître ou l'acquéreur de l'ouvrage, des dommages, même résultant d'un vice du sol, qui compromettent la solidité de l'ouvrage ou qui, l'affectant dans l'un de ses éléments constitutifs ou l'un de ses éléments d'équipement, le rendent impropre à sa destination. »\n\nEn l'espèce :\n- La réception des travaux est intervenue le {{date_reception}} ;\n- Les désordres sont apparus le {{date_apparition_desordres}}, soit dans le délai décennal ;\n- Ces désordres {{nature_desordres}} compromettent la solidité de l'ouvrage / rendent l'ouvrage impropre à sa destination.\n\nLa responsabilité de {{constructeur.nom}} est donc engagée de plein droit.	\N	{moyens,droit,construction,1792,décennale,constructeur}	f	t	\N	0	\N	\N
cml82hbb8000thqsd4lhrxxa1	2026-02-04 13:32:15.62	2026-02-04 13:32:15.62	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article L.442-1 Code de Commerce (Pratiques restrictives)	II. DISCUSSION EN DROIT\n\nA. Sur les pratiques restrictives de concurrence\n\nL'article L.442-1 du Code de commerce dispose :\n« I. - Engage la responsabilité de son auteur et l'oblige à réparer le préjudice causé le fait, dans le cadre de la négociation commerciale, de la conclusion ou de l'exécution d'un contrat, par toute personne exerçant des activités de production, de distribution ou de services :\n1° D'obtenir ou de tenter d'obtenir de l'autre partie un avantage ne correspondant à aucune contrepartie ou manifestement disproportionné au regard de la valeur de la contrepartie consentie ;\n2° De soumettre ou de tenter de soumettre l'autre partie à des obligations créant un déséquilibre significatif dans les droits et obligations des parties. »\n\nEn l'espèce, {{defendeur.nom}} a {{description_pratique_restrictive}}.	\N	{moyens,droit,commerce,L442-1,"pratiques restrictives",déséquilibre}	f	t	\N	0	\N	\N
cml82hbba000vhqsd7qh9gqta	2026-02-04 13:32:15.622	2026-02-04 13:32:15.622	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article L.1235-1 Code du Travail (Licenciement sans cause)	II. DISCUSSION EN DROIT\n\nA. Sur le licenciement sans cause réelle et sérieuse\n\nL'article L.1235-1 du Code du travail dispose :\n« En cas de litige, le juge, à qui il appartient d'apprécier la régularité de la procédure suivie et le caractère réel et sérieux des motifs invoqués par l'employeur, forme sa conviction au vu des éléments fournis par les parties après avoir ordonné, au besoin, toutes les mesures d'instruction qu'il estime utiles. »\n\nLe licenciement de {{salarie.nom}} est dépourvu de cause réelle et sérieuse car :\n\n{{#each motifs_contestation}}\n- {{this}}\n{{/each}}\n\n{{salarie.nom}} est donc fondé à solliciter les indemnités prévues à l'article L.1235-3 du Code du travail.	\N	{moyens,droit,travail,L1235-1,licenciement,"cause réelle sérieuse"}	f	t	\N	0	\N	\N
cml82hbbc000xhqsdc203njz0	2026-02-04 13:32:15.624	2026-02-04 13:32:15.624	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Jurisprudence concurrence déloyale	B. Sur la concurrence déloyale - Jurisprudence constante\n\nIl est de jurisprudence constante que constitue un acte de concurrence déloyale le fait de :\n\n- Détourner la clientèle d'un concurrent par des moyens déloyaux (Com., 12 février 2020, n°18-17.731) ;\n- Débaucher massivement les salariés d'un concurrent (Com., 24 janvier 2018, n°16-22.325) ;\n- Créer une confusion dans l'esprit de la clientèle (Com., 10 septembre 2013, n°12-19.588) ;\n- Dénigrer les produits ou services d'un concurrent (Com., 24 septembre 2013, n°12-19.790).\n\nEn l'espèce, {{defendeur.nom}} s'est rendu coupable de {{actes_concurrence_deloyale}}.\n\nLa jurisprudence admet que le préjudice résultant d'actes de concurrence déloyale peut être évalué en fonction du trouble commercial subi (Com., 12 février 2020, n°18-17.731).	\N	{moyens,jurisprudence,"concurrence déloyale",cassation}	f	t	\N	0	\N	\N
cml82hbbe000zhqsd72co8vev	2026-02-04 13:32:15.626	2026-02-04 13:32:15.626	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Jurisprudence responsabilité contractuelle	B. Sur la responsabilité contractuelle - Rappel jurisprudentiel\n\nLa Cour de cassation rappelle de manière constante que :\n\n« Le créancier d'une obligation contractuelle inexécutée a le choix de poursuivre l'exécution forcée de l'obligation ou la résolution du contrat avec dommages et intérêts » (Civ. 1ère, 2 avril 2014, n°13-14.287).\n\n« L'inexécution d'une obligation contractuelle est en elle-même constitutive d'une faute, sans qu'il soit nécessaire de caractériser un comportement fautif distinct » (Civ. 3ème, 6 juillet 2017, n°16-17.151).\n\n« Le préjudice né de l'inexécution d'un contrat consiste dans la perte éprouvée et le gain manqué » (Com., 14 juin 2016, n°15-12.576).\n\nEn l'espèce, l'inexécution contractuelle de {{defendeur.nom}} justifie {{remede_sollicite}}.	\N	{moyens,jurisprudence,"responsabilité contractuelle",cassation,inexécution}	f	t	\N	0	\N	\N
cml85wbxt0007m3wj5vqqkalb	2026-02-04 15:07:55.122	2026-02-04 15:07:55.122	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête saisine conseil prud'hommes	SAISINE DU CONSEIL DE PRUD'HOMMES DE {{juridiction}}\n\nDEMANDEUR :\n{{salarie.civilite}} {{salarie.nom}} {{salarie.prenom}}\nDemeurant : {{salarie.adresse}}\nN° Sécurité Sociale : {{salarie.nss}}\n\nDÉFENDEUR :\n{{employeur.nom}}\nSIRET : {{employeur.siret}}\nSiège social : {{employeur.adresse}}\nReprésenté par : {{employeur.representant}}	\N	{prud'hommes,travail,saisine,en-tête}	f	t	\N	0	\N	\N
cml82hbbg0011hqsd1x2ts9fx	2026-02-04 13:32:15.628	2026-02-04 13:32:15.628	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 700 CPC et dépens	C. Sur l'article 700 du Code de procédure civile et les dépens\n\nL'article 700 du Code de procédure civile dispose :\n« Le juge condamne la partie tenue aux dépens ou qui perd son procès à payer à l'autre partie la somme qu'il détermine, au titre des frais exposés et non compris dans les dépens. »\n\nIl serait particulièrement inéquitable de laisser à la charge de {{demandeur.nom}} les frais irrépétibles engagés pour la défense de ses droits.\n\nEn conséquence, {{defendeur.nom}} devra être condamné à verser à {{demandeur.nom}} la somme de {{montant_article_700}} euros au titre de l'article 700 du CPC.\n\n{{defendeur.nom}} supportera en outre les entiers dépens de l'instance, en application de l'article 696 du Code de procédure civile.	\N	{moyens,droit,"article 700",dépens,frais}	f	t	\N	0	\N	\N
cml82hbbj0013hqsd97vmunzc	2026-02-04 13:32:15.631	2026-02-04 13:32:15.631	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Exécution provisoire	D. Sur l'exécution provisoire\n\nConformément aux articles 514 et suivants du Code de procédure civile, l'exécution provisoire est de droit pour les décisions de première instance.\n\nEn tout état de cause, la situation justifie que l'exécution provisoire soit ordonnée :\n\n- L'ancienneté de la créance ({{anciennete_creance}}) ;\n- L'urgence de la situation ({{description_urgence}}) ;\n- L'absence de risque de conséquences manifestement excessives.\n\nIl est en effet de jurisprudence constante que « l'exécution provisoire peut être ordonnée lorsque le juge l'estime nécessaire et compatible avec la nature de l'affaire » (Civ. 2ème, 10 mars 2016, n°15-12.876).\n\nEn conséquence, il est demandé au Tribunal d'ordonner l'exécution provisoire du jugement à intervenir.	\N	{moyens,"exécution provisoire",procédure,urgence}	f	t	\N	0	\N	\N
cml82hbbl0015hqsduxi7pcsj	2026-02-04 13:32:15.633	2026-02-04 13:32:15.633	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause pénale	ARTICLE {{numero}} - CLAUSE PÉNALE\n\n{{numero}}.1 - En cas de manquement par l'une des Parties à l'une quelconque de ses obligations au titre du présent contrat, la Partie défaillante sera redevable de plein droit, après mise en demeure restée infructueuse pendant un délai de {{delai_mise_en_demeure}} jours, d'une indemnité forfaitaire de {{montant_penalite}} euros, sans préjudice de tous dommages et intérêts complémentaires.\n\n{{numero}}.2 - Cette clause pénale est stipulée à titre de dommages et intérêts forfaitaires et définitifs, les Parties renonçant expressément à solliciter du juge la révision de son montant en application de l'article 1231-5 du Code civil.\n\n{{numero}}.3 - Le paiement de cette indemnité n'aura pas pour effet de libérer la Partie défaillante de son obligation d'exécuter le contrat.	\N	{clause,pénale,sanction,"indemnité forfaitaire"}	f	t	\N	0	\N	\N
cml82hbbn0017hqsd4tnmrxd1	2026-02-04 13:32:15.635	2026-02-04 13:32:15.635	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause résolutoire	ARTICLE {{numero}} - CLAUSE RÉSOLUTOIRE\n\n{{numero}}.1 - En cas de manquement grave par l'une des Parties à ses obligations essentielles au titre du présent contrat, et notamment :\n{{#each obligations_essentielles}}\n- {{this}}\n{{/each}}\n\nle contrat sera résolu de plein droit {{delai_resolution}} jours après l'envoi d'une mise en demeure par lettre recommandée avec accusé de réception restée sans effet, sans qu'il soit besoin d'aucune formalité judiciaire.\n\n{{numero}}.2 - La résolution sera acquise sans préjudice de tous dommages et intérêts que pourrait réclamer la Partie non défaillante.\n\n{{numero}}.3 - La présente clause résolutoire ne fait pas obstacle à la faculté pour la Partie non défaillante de solliciter l'exécution forcée du contrat plutôt que sa résolution.	\N	{clause,résolutoire,résolution,contrat}	f	t	\N	0	\N	\N
cml82hbbp0019hqsdbdawi33h	2026-02-04 13:32:15.638	2026-02-04 13:32:15.638	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de réserve de propriété	ARTICLE {{numero}} - RÉSERVE DE PROPRIÉTÉ\n\n{{numero}}.1 - Le transfert de propriété des {{biens_vises}} est suspendu jusqu'au paiement intégral du prix, en principal et accessoires. Le défaut de paiement pourra entraîner la revendication des biens.\n\n{{numero}}.2 - Toutefois, les risques de perte et de détérioration des biens seront transférés à l'Acheteur dès la livraison.\n\n{{numero}}.3 - L'Acheteur s'engage à :\n- Conserver les biens sous réserve de propriété dans des conditions propres à en assurer l'identification ;\n- Les assurer contre tous risques, la police devant mentionner l'existence de la clause de réserve de propriété ;\n- Informer immédiatement le Vendeur de toute saisie pratiquée par un tiers.\n\n{{numero}}.4 - En cas de revente des biens avant complet paiement du prix, l'Acheteur s'engage à mentionner la présente clause au sous-acquéreur et à informer le Vendeur de cette revente.	\N	{clause,"réserve de propriété",transfert,paiement}	f	t	\N	0	\N	\N
cml82hbbt001bhqsd6uylvrm6	2026-02-04 13:32:15.641	2026-02-04 13:32:15.641	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause attributive de juridiction	ARTICLE {{numero}} - ATTRIBUTION DE JURIDICTION\n\n{{numero}}.1 - TOUS LES LITIGES AUXQUELS LE PRÉSENT CONTRAT POURRAIT DONNER LIEU, CONCERNANT TANT SA VALIDITÉ, SON INTERPRÉTATION, SON EXÉCUTION, SA RÉSOLUTION, LEURS CONSÉQUENCES ET LEURS SUITES, SERONT SOUMIS AU {{juridiction_competente}}.\n\n{{numero}}.2 - Cette clause attributive de juridiction s'applique même en cas de pluralité de défendeurs, d'appel en garantie ou de référé.\n\n{{numero}}.3 - Les Parties déclarent avoir la qualité de commerçants et reconnaissent que le présent contrat a été conclu pour les besoins de leur activité professionnelle.	\N	{clause,attributive,juridiction,compétence,tribunal}	f	t	\N	0	\N	\N
cml82hbbv001dhqsdxk1j9t6t	2026-02-04 13:32:15.644	2026-02-04 13:32:15.644	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause compromissoire	ARTICLE {{numero}} - CLAUSE COMPROMISSOIRE\n\n{{numero}}.1 - Tous différends découlant du présent contrat ou en relation avec celui-ci seront tranchés définitivement suivant le Règlement d'arbitrage de {{institution_arbitrage}}, par {{nombre_arbitres}} arbitre(s) nommé(s) conformément à ce Règlement.\n\n{{numero}}.2 - Le siège de l'arbitrage sera {{siege_arbitrage}}.\n\n{{numero}}.3 - La langue de l'arbitrage sera {{langue_arbitrage}}.\n\n{{numero}}.4 - Le droit applicable au fond du litige sera {{droit_applicable}}.\n\n{{numero}}.5 - La sentence arbitrale sera définitive et s'imposera aux Parties, qui s'engagent à l'exécuter de bonne foi. Les Parties renoncent expressément à tout recours en annulation, sauf pour les motifs prévus par les articles 1520 et suivants du Code de procédure civile.	\N	{clause,compromissoire,arbitrage,litige}	f	t	\N	0	\N	\N
cml85wbxw0009m3wjin7n6sih	2026-02-04 15:07:55.125	2026-02-04 15:07:55.125	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête acte de signification	ACTE DE SIGNIFICATION\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de {{requerant.nom}}, {{requerant.qualite}},\nDemeurant {{requerant.adresse}},\n\nJ'ai, {{huissier.nom}}, Commissaire de Justice,\ndemeurant {{huissier.adresse}},\n\nSIGNIFIÉ À :\n\n{{destinataire.nom}}\n{{destinataire.adresse}}\n\nLe document suivant :	\N	{signification,huissier,"commissaire justice"}	f	t	\N	0	\N	\N
cml82hbby001fhqsd3ov9sylk	2026-02-04 13:32:15.646	2026-02-04 13:32:15.646	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de médiation préalable	ARTICLE {{numero}} - MÉDIATION PRÉALABLE OBLIGATOIRE\n\n{{numero}}.1 - Préalablement à toute action judiciaire ou arbitrale, les Parties s'engagent à soumettre tout différend relatif à la validité, l'interprétation ou l'exécution du présent contrat à une procédure de médiation.\n\n{{numero}}.2 - La médiation sera conduite selon le règlement de {{organisme_mediation}}, par un médiateur choisi d'un commun accord ou, à défaut, désigné par cet organisme.\n\n{{numero}}.3 - La médiation se déroulera à {{lieu_mediation}} en langue {{langue_mediation}}.\n\n{{numero}}.4 - Les Parties s'engagent à participer de bonne foi à la médiation pendant une durée minimale de {{duree_mediation}} avant de pouvoir saisir toute juridiction.\n\n{{numero}}.5 - Les frais de médiation seront partagés par moitié entre les Parties, sauf accord contraire. Les communications intervenues lors de la médiation resteront confidentielles.	\N	{clause,médiation,préalable,amiable,MARD}	f	t	\N	0	\N	\N
cml82hbc0001hhqsd8q6mo10d	2026-02-04 13:32:15.648	2026-02-04 13:32:15.648	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de hardship (Imprévision)	ARTICLE {{numero}} - CLAUSE DE HARDSHIP (IMPRÉVISION)\n\n{{numero}}.1 - Si, postérieurement à la conclusion du présent contrat, survient un changement de circonstances imprévisible lors de la conclusion du contrat et rendant l'exécution excessivement onéreuse pour une Partie, celle-ci peut demander une renégociation du contrat à l'autre Partie.\n\n{{numero}}.2 - Les circonstances visées incluent notamment :\n- Les modifications substantielles des conditions économiques ;\n- Les évolutions législatives ou réglementaires ;\n- Les événements affectant significativement l'équilibre contractuel.\n\n{{numero}}.3 - La Partie invoquant la clause doit notifier à l'autre Partie, par lettre recommandée avec accusé de réception :\n- La nature du changement de circonstances ;\n- Son impact sur l'équilibre du contrat ;\n- Les modifications qu'elle propose.\n\n{{numero}}.4 - Les Parties s'engagent à négocier de bonne foi pendant {{duree_negociation}} jours. À défaut d'accord, les Parties pourront saisir {{instance_competente}} aux fins de révision ou de résiliation du contrat.	\N	{clause,hardship,imprévision,renégociation,1195}	f	t	\N	0	\N	\N
cml82hbc2001jhqsdijhfqtm9	2026-02-04 13:32:15.65	2026-02-04 13:32:15.65	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause MAC (Material Adverse Change)	ARTICLE {{numero}} - CLAUSE MAC (CHANGEMENT DÉFAVORABLE SIGNIFICATIF)\n\n{{numero}}.1 - Un « Changement Défavorable Significatif » (« MAC ») désigne tout événement, circonstance ou changement qui, individuellement ou conjointement avec d'autres, a ou est raisonnablement susceptible d'avoir un effet défavorable significatif sur :\n- L'activité, les actifs, la situation financière ou les résultats de la Société ;\n- La capacité du Vendeur à exécuter ses obligations au titre du présent contrat.\n\n{{numero}}.2 - Ne constituent pas un MAC :\n- Les changements affectant l'économie ou les marchés financiers en général ;\n- Les changements affectant le secteur d'activité de la Société dans son ensemble ;\n- Les changements résultant de l'annonce ou de la réalisation de l'Opération.\n\n{{numero}}.3 - En cas de survenance d'un MAC entre la date de signature et la Date de Réalisation, le Cessionnaire pourra :\n- Soit renoncer à l'Opération sans indemnité ;\n- Soit demander une réduction du Prix de Cession proportionnelle à l'impact du MAC.	\N	{clause,MAC,"changement défavorable",cession,M&A}	f	t	\N	0	\N	\N
cml82hbc4001lhqsdl1jfn633	2026-02-04 13:32:15.652	2026-02-04 13:32:15.652	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de représentations et garanties	ARTICLE {{numero}} - REPRÉSENTATIONS ET GARANTIES DU CÉDANT\n\n{{numero}}.1 - Le Cédant déclare et garantit au Cessionnaire que les déclarations suivantes sont exactes et complètes à la date des présentes et le resteront à la Date de Réalisation :\n\na) Capacité et pouvoirs : Le Cédant a la pleine capacité et tous les pouvoirs nécessaires pour conclure et exécuter le présent contrat.\n\nb) Propriété des titres : Le Cédant est propriétaire des Parts cédées, libres de tout nantissement, gage ou sûreté.\n\nc) Comptes sociaux : Les comptes annuels de la Société pour l'exercice clos le {{date_cloture}} donnent une image fidèle du patrimoine, de la situation financière et des résultats de la Société.\n\nd) Litiges : Il n'existe aucun litige, procédure ou enquête en cours ou, à la connaissance du Cédant, menaçant, susceptible d'avoir un effet défavorable significatif sur la Société.\n\ne) Conformité : La Société exerce ses activités en conformité avec toutes les lois et réglementations applicables.	\N	{clause,représentations,garanties,déclarations,cession,M&A}	f	t	\N	0	\N	\N
cml82hbc6001nhqsd875u0g7u	2026-02-04 13:32:15.655	2026-02-04 13:32:15.655	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'ajustement de prix	ARTICLE {{numero}} - AJUSTEMENT DU PRIX DE CESSION\n\n{{numero}}.1 - Le Prix de Cession sera ajusté à la hausse ou à la baisse en fonction de la variation de la Situation Nette Comptable de la Société entre la Date de Référence ({{date_reference}}) et la Date de Réalisation.\n\n{{numero}}.2 - Définitions :\n- « Situation Nette de Référence » : {{montant_snr}} euros, telle qu'elle ressort du bilan au {{date_reference}}.\n- « Situation Nette de Réalisation » : la situation nette comptable de la Société à la Date de Réalisation, déterminée selon les mêmes méthodes comptables.\n\n{{numero}}.3 - Modalités d'ajustement :\n- Si la Situation Nette de Réalisation est supérieure à la Situation Nette de Référence, le Prix de Cession sera majoré de la différence ;\n- Si la Situation Nette de Réalisation est inférieure à la Situation Nette de Référence, le Prix de Cession sera réduit de la différence.\n\n{{numero}}.4 - Les comptes de Réalisation seront établis par {{expert_comptable}} dans les {{delai_etablissement}} jours suivant la Date de Réalisation et soumis à l'approbation des Parties.	\N	{clause,"ajustement prix","locked box","completion accounts",cession,M&A}	f	t	\N	0	\N	\N
cml85wbxc0001m3wj2igcwn0l	2026-02-04 15:07:55.104	2026-02-04 15:07:55.104	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête conclusions d'appel	CONCLUSIONS D'APPEL\n\nPOUR :\n{{appelant.nom}}, {{appelant.qualite}}\nDemeurant {{appelant.adresse}}\n\nAPPELANT\n\nAyant pour avocat : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\nToque n°{{avocat.toque}}\n\nCONTRE :\n\n{{intime.nom}}, {{intime.qualite}}\nDemeurant {{intime.adresse}}\n\nINTIMÉ	\N	{conclusions,appel,en-tête}	f	t	\N	0	\N	\N
cml85wbxn0003m3wjej8s8518	2026-02-04 15:07:55.116	2026-02-04 15:07:55.116	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête requête JAF	REQUÊTE AUX FINS DE {{objet_requete}}\n\nÀ Monsieur/Madame le Juge aux Affaires Familiales\nprès le Tribunal Judiciaire de {{juridiction}}\n\nLe requérant :\n{{requerant.civilite}} {{requerant.nom}} {{requerant.prenom}}\nNé(e) le {{requerant.date_naissance}} à {{requerant.lieu_naissance}}\nDe nationalité {{requerant.nationalite}}\nProfession : {{requerant.profession}}\nDemeurant : {{requerant.adresse}}	\N	{requête,JAF,famille,divorce}	f	t	\N	0	\N	\N
cml88g72w000i521viuoi7gl9	2026-02-04 16:19:21.176	2026-02-04 16:19:21.176	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Récusation	CONCLUSIONS AUX FINS DE RÉCUSATION\n\nPour : {{client.nom}}\n\nDemande la récusation de Monsieur/Madame {{juge.nom}}, juge au Tribunal Judiciaire de {{juridiction}}.	{}	{recusation,intro}	f	t	9	0	\N	\N
cml85wbxz000bm3wje41ifut0	2026-02-04 15:07:55.127	2026-02-04 15:07:55.127	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête opposition ordonnance injonction payer	OPPOSITION À ORDONNANCE PORTANT INJONCTION DE PAYER\n\nJe soussigné(e) {{opposant.nom}},\nDemeurant {{opposant.adresse}},\n\nFais opposition à l'ordonnance portant injonction de payer rendue le {{date_ordonnance}}\npar le {{juridiction}}\nà la requête de {{creancier.nom}}\npour un montant principal de {{montant}} euros.\n\nNuméro de minute : {{numero_minute}}\nNuméro RG : {{numero_rg}}	\N	{opposition,"injonction de payer",procédure}	f	t	\N	0	\N	\N
cml85wby3000dm3wjdgisx09c	2026-02-04 15:07:55.131	2026-02-04 15:07:55.131	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête QPC	QUESTION PRIORITAIRE DE CONSTITUTIONNALITÉ\n\nMÉMOIRE DISTINCT ET MOTIVÉ\nprésenté en application de l'article 23-1 de l'ordonnance n°58-1067 du 7 novembre 1958\n\nDevant : {{juridiction}}\n\nPar : {{partie.nom}}\nReprésenté par : Maître {{avocat.nom}}\n\nSur la constitutionnalité des dispositions de l'article {{article_conteste}} du {{code_vise}}\nau regard des droits et libertés garantis par la Constitution	\N	{QPC,constitutionnel,en-tête}	f	t	\N	0	\N	\N
cml85wby5000fm3wj7kjjs2uj	2026-02-04 15:07:55.133	2026-02-04 15:07:55.133	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête référé expertise	ASSIGNATION EN RÉFÉRÉ-EXPERTISE\nArticle 145 du Code de procédure civile\n\nDevant le Président du {{juridiction}}, statuant en référé\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}\nDemeurant {{demandeur.adresse}}\n\nAyant pour avocat : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}	\N	{référé,expertise,"145 CPC",en-tête}	f	t	\N	0	\N	\N
cml85wby7000hm3wjqx0vmllx	2026-02-04 15:07:55.136	2026-02-04 15:07:55.136	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête lettre de résiliation	{{expediteur.nom}}\n{{expediteur.adresse}}\n{{expediteur.cp}} {{expediteur.ville}}\n\nLettre Recommandée avec AR\n\n{{lieu}}, le {{date}}\n\n{{destinataire.nom}}\n{{destinataire.adresse}}\n{{destinataire.cp}} {{destinataire.ville}}\n\nObjet : Résiliation du contrat {{reference_contrat}}\nRéf : {{reference_dossier}}\n\nMadame, Monsieur,\n\nPar la présente, je vous notifie ma décision de résilier le contrat {{type_contrat}} conclu le {{date_contrat}} entre nos parties.	\N	{résiliation,contrat,lettre,LRAR}	f	t	\N	0	\N	\N
cml85wby9000jm3wj9dm2300e	2026-02-04 15:07:55.138	2026-02-04 15:07:55.138	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête contrat de travail CDI	CONTRAT DE TRAVAIL À DURÉE INDÉTERMINÉE\n\nENTRE LES SOUSSIGNÉS :\n\n{{employeur.nom}}, {{employeur.forme}}\nSIRET : {{employeur.siret}}\nSiège social : {{employeur.adresse}}\nReprésentée par {{employeur.representant}}, en qualité de {{employeur.qualite}}\n\nCi-après dénommée « l'Employeur »\n\nD'une part,\n\nET :\n\n{{salarie.civilite}} {{salarie.nom}} {{salarie.prenom}}\nNé(e) le {{salarie.date_naissance}} à {{salarie.lieu_naissance}}\nDe nationalité {{salarie.nationalite}}\nN° Sécurité Sociale : {{salarie.nss}}\nDemeurant : {{salarie.adresse}}\n\nCi-après dénommé(e) « le Salarié »\n\nD'autre part,\n\nIL A ÉTÉ CONVENU CE QUI SUIT :	\N	{"contrat travail",CDI,embauche,en-tête}	f	t	\N	0	\N	\N
cml85wbye000lm3wj8wk4bjba	2026-02-04 15:07:55.142	2026-02-04 15:07:55.142	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête bail commercial	BAIL COMMERCIAL\nArticles L.145-1 et suivants du Code de commerce\n\nENTRE LES SOUSSIGNÉS :\n\nLE BAILLEUR :\n{{bailleur.nom}}, {{bailleur.qualite}}\nDemeurant/Siège : {{bailleur.adresse}}\n{{bailleur.rcs}}\n\nLE PRENEUR :\n{{preneur.nom}}, {{preneur.forme}}\nSIRET : {{preneur.siret}}\nSiège social : {{preneur.siege}}\nReprésenté par {{preneur.representant}}\n\nIL A ÉTÉ CONVENU CE QUI SUIT :\n\nDESIGNATION DES LOCAUX :\nLe Bailleur donne à bail au Preneur qui accepte les locaux situés :\n{{adresse_locaux}}\nD'une superficie de {{superficie}} m²	\N	{bail,commercial,location,en-tête}	f	t	\N	0	\N	\N
cml85wbyh000nm3wj8z1ppedt	2026-02-04 15:07:55.145	2026-02-04 15:07:55.145	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête statuts SAS	STATUTS\n\nSOCIÉTÉ PAR ACTIONS SIMPLIFIÉE\n\n{{societe.denomination}}\n\nSociété par Actions Simplifiée\nau capital de {{societe.capital}} euros\nSiège social : {{societe.siege}}\n\n\nTITRE I - FORME - OBJET - DÉNOMINATION - SIÈGE - DURÉE\n\nArticle 1 - Forme\nIl est formé entre les propriétaires des actions ci-après créées et de celles qui pourront l'être ultérieurement, une société par actions simplifiée régie par les articles L.227-1 et suivants du Code de commerce.	\N	{statuts,SAS,constitution,société}	f	t	\N	0	\N	\N
cml85wbyj000pm3wj1gvz7w4h	2026-02-04 15:07:55.147	2026-02-04 15:07:55.147	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête PV AG ordinaire	PROCÈS-VERBAL DE L'ASSEMBLÉE GÉNÉRALE ORDINAIRE\ndu {{date_ag}}\n\n{{societe.denomination}}\n{{societe.forme}} au capital de {{societe.capital}} euros\nSiège social : {{societe.siege}}\n{{societe.rcs}}\n\nL'an deux mille {{annee}}, le {{date_ag}},\nà {{heure_ag}}, les associés de la société {{societe.denomination}}\nse sont réunis en Assemblée Générale Ordinaire au siège social,\nsur convocation du {{convocateur}}.\n\nÉTAIENT PRÉSENTS OU REPRÉSENTÉS :	\N	{PV,"assemblée générale",AGO,société}	f	t	\N	0	\N	\N
cml85wbyl000rm3wjwsgf8xqw	2026-02-04 15:07:55.149	2026-02-04 15:07:55.149	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête testament olographe	CECI EST MON TESTAMENT\n\nJe soussigné(e) {{testateur.nom}} {{testateur.prenom}},\nNé(e) le {{testateur.date_naissance}} à {{testateur.lieu_naissance}},\nDemeurant {{testateur.adresse}},\nSain(e) d'esprit et de corps,\n\nRévoque tous testaments antérieurs et exprime mes dernières volontés comme suit :	\N	{testament,olographe,succession,en-tête}	f	t	\N	0	\N	\N
cml85wbyn000tm3wj0kdmcxgs	2026-02-04 15:07:55.151	2026-02-04 15:07:55.151	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête donation	ACTE DE DONATION\n\nENTRE LES SOUSSIGNÉS :\n\nLE DONATEUR :\n{{donateur.civilite}} {{donateur.nom}} {{donateur.prenom}}\nNé(e) le {{donateur.date_naissance}} à {{donateur.lieu_naissance}}\nDemeurant {{donateur.adresse}}\n\nLE DONATAIRE :\n{{donataire.civilite}} {{donataire.nom}} {{donataire.prenom}}\nNé(e) le {{donataire.date_naissance}} à {{donataire.lieu_naissance}}\nDemeurant {{donataire.adresse}}\n\nIL A ÉTÉ EXPOSÉ ET CONVENU CE QUI SUIT :	\N	{donation,libéralité,succession,en-tête}	f	t	\N	0	\N	\N
cml85wbyp000vm3wjh354kq1h	2026-02-04 15:07:55.154	2026-02-04 15:07:55.154	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Divorce contentieux	I. EXPOSÉ DES FAITS\n\n{{epoux1.civilite}} {{epoux1.nom}} et {{epoux2.civilite}} {{epoux2.nom}} se sont mariés le {{date_mariage}} à {{lieu_mariage}}.\n\nDe cette union sont issus {{nombre_enfants}} enfant(s) :\n{{#each enfants}}\n- {{this.prenom}}, né(e) le {{this.date_naissance}}\n{{/each}}\n\nLes époux sont séparés de fait depuis le {{date_separation}}.\n\nLa vie commune est devenue impossible en raison de {{motifs_divorce}}.	\N	{faits,divorce,famille,séparation}	f	t	\N	0	\N	\N
cml85wbyr000xm3wjgdqa549l	2026-02-04 15:07:55.155	2026-02-04 15:07:55.155	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Accident du travail	I. EXPOSÉ DES FAITS\n\nLe {{date_accident}}, {{victime.nom}}, salarié de {{employeur.nom}} en qualité de {{poste}}, a été victime d'un accident du travail.\n\nCirconstances de l'accident :\n{{description_accident}}\n\nConséquences médicales :\n- ITT initiale : {{duree_itt}} jours\n- Consolidation le {{date_consolidation}}\n- Taux d'IPP : {{taux_ipp}}%\n\nL'accident a été reconnu comme accident du travail par la CPAM le {{date_reconnaissance}}.	\N	{faits,"accident travail",AT,indemnisation}	f	t	\N	0	\N	\N
cml85wbyt000zm3wj5c7sewwf	2026-02-04 15:07:55.157	2026-02-04 15:07:55.157	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Contrefaçon marque	I. EXPOSÉ DES FAITS\n\n{{titulaire.nom}} est titulaire de la marque « {{marque.denomination}} » enregistrée sous le n°{{marque.numero}} le {{marque.date_depot}} en classes {{marque.classes}}.\n\nOr, {{contrefacteur.nom}} commercialise depuis le {{date_debut_contrefacon}} des produits portant un signe identique/similaire à cette marque, à savoir {{description_signe_litigieux}}.\n\nCes actes de contrefaçon ont été constatés par :\n{{#each preuves}}\n- {{this.description}} ({{this.date}})\n{{/each}}	\N	{faits,contrefaçon,marque,"propriété intellectuelle"}	f	t	\N	0	\N	\N
cml85wbyv0011m3wjhlt92yds	2026-02-04 15:07:55.16	2026-02-04 15:07:55.16	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Malfaçons construction	I. EXPOSÉ DES FAITS\n\n{{maitre_ouvrage.nom}} a confié à {{constructeur.nom}} la réalisation de {{nature_travaux}} par contrat du {{date_contrat}}.\n\nLes travaux ont été réceptionnés le {{date_reception}}, avec les réserves suivantes :\n{{#each reserves}}\n- {{this}}\n{{/each}}\n\nPostérieurement à la réception, les désordres suivants sont apparus :\n{{#each desordres}}\n- {{this.description}} (constaté le {{this.date}})\n{{/each}}\n\nUne expertise judiciaire ordonnée le {{date_ordonnance_expertise}} et réalisée par {{expert.nom}} a conclu que ces désordres engagent la responsabilité de {{constructeur.nom}}.	\N	{faits,construction,malfaçons,désordres}	f	t	\N	0	\N	\N
cml85wbyx0013m3wj2mr55uvo	2026-02-04 15:07:55.162	2026-02-04 15:07:55.162	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Trouble de voisinage	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} est propriétaire/locataire du bien situé {{demandeur.adresse}} depuis le {{date_occupation}}.\n\n{{defendeur.nom}}, occupant le bien situé {{defendeur.adresse}}, cause depuis le {{date_debut_troubles}} des troubles anormaux de voisinage caractérisés par :\n{{#each troubles}}\n- {{this.nature}} : {{this.description}}\n{{/each}}\n\nCes nuisances excèdent les inconvénients normaux du voisinage et causent un préjudice à {{demandeur.nom}} consistant en {{description_prejudice}}.	\N	{faits,voisinage,troubles,nuisances}	f	t	\N	0	\N	\N
cml85wbyz0015m3wjbepauh55	2026-02-04 15:07:55.163	2026-02-04 15:07:55.163	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Harcèlement moral travail	I. EXPOSÉ DES FAITS\n\n{{salarie.nom}} a été embauché(e) par {{employeur.nom}} le {{date_embauche}} en qualité de {{poste}}.\n\nDepuis le {{date_debut_harcelement}}, {{salarie.nom}} est victime d'agissements répétés de harcèlement moral de la part de {{harceleur.nom}}, {{harceleur.qualite}}, caractérisés par :\n{{#each agissements}}\n- Le {{this.date}} : {{this.description}}\n{{/each}}\n\nCes agissements ont entraîné une dégradation de la santé de {{salarie.nom}}, attestée par {{preuves_medicales}}.	\N	{faits,harcèlement,moral,travail}	f	t	\N	0	\N	\N
cml85wbz10017m3wjhufyg3c0	2026-02-04 15:07:55.165	2026-02-04 15:07:55.165	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Rupture brutale relations commerciales	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} et {{defendeur.nom}} entretenaient des relations commerciales établies depuis {{duree_relation}} ans, portant sur {{objet_relation}}.\n\nLe chiffre d'affaires annuel réalisé avec {{defendeur.nom}} représentait en moyenne {{pourcentage_ca}}% du chiffre d'affaires de {{demandeur.nom}}.\n\nPar courrier du {{date_rupture}}, {{defendeur.nom}} a notifié à {{demandeur.nom}} la cessation de leurs relations commerciales avec un préavis de seulement {{duree_preavis_accorde}}, alors que la durée de préavis raisonnablement attendue était de {{duree_preavis_attendue}}.	\N	{faits,rupture,"relations commerciales",L442-1}	f	t	\N	0	\N	\N
cml85wbz60019m3wjq6nfn3nr	2026-02-04 15:07:55.17	2026-02-04 15:07:55.17	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Abus de biens sociaux	I. EXPOSÉ DES FAITS\n\n{{dirigeant.nom}} a exercé les fonctions de {{dirigeant.qualite}} de la société {{societe.nom}} du {{date_debut_mandat}} au {{date_fin_mandat}}.\n\nDurant cette période, il a commis les actes suivants constitutifs d'abus de biens sociaux :\n{{#each abus}}\n- {{this.date}} : {{this.description}} pour un montant de {{this.montant}} euros\n{{/each}}\n\nCes détournements ont été découverts le {{date_decouverte}} à l'occasion de {{circonstances_decouverte}}.	\N	{faits,"abus biens sociaux",pénal,société}	f	t	\N	0	\N	\N
cml85wbz8001bm3wj3cni580h	2026-02-04 15:07:55.172	2026-02-04 15:07:55.172	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Refus de vente	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} exerce une activité de {{activite}} et est un client régulier de {{defendeur.nom}} depuis {{duree_relation}}.\n\nLe {{date_refus}}, {{demandeur.nom}} a passé commande auprès de {{defendeur.nom}} pour {{description_commande}}.\n\nCette commande a été refusée par {{defendeur.nom}} au motif suivant : {{motif_invoque}}.\n\nCe refus constitue une pratique discriminatoire car {{justification_discrimination}}.	\N	{faits,"refus de vente",discrimination,commercial}	f	t	\N	0	\N	\N
cml85wbza001dm3wj1jzkt3hd	2026-02-04 15:07:55.174	2026-02-04 15:07:55.174	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Liquidation judiciaire	I. EXPOSÉ DES FAITS\n\nLa société {{societe.nom}}, {{societe.forme}} au capital de {{societe.capital}} euros, immatriculée sous le numéro {{societe.siret}}, exerçait une activité de {{societe.activite}}.\n\nPar jugement du {{date_jugement_lj}}, le Tribunal de Commerce de {{juridiction}} a prononcé la liquidation judiciaire de la société.\n\nMaître {{liquidateur.nom}} a été désigné en qualité de liquidateur judiciaire.\n\nLa date de cessation des paiements a été fixée au {{date_cessation_paiements}}.	\N	{faits,"liquidation judiciaire","procédure collective"}	f	t	\N	0	\N	\N
cml85wbzc001fm3wj3v2pm8j2	2026-02-04 15:07:55.176	2026-02-04 15:07:55.176	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article L.1232-1 Code du Travail (Licenciement)	II. DISCUSSION EN DROIT\n\nA. Sur la cause réelle et sérieuse du licenciement\n\nL'article L.1232-1 du Code du travail dispose :\n« Tout licenciement pour motif personnel est motivé dans les conditions définies par le présent chapitre. Il est justifié par une cause réelle et sérieuse. »\n\nLa cause doit être :\n- Réelle : existante, exacte et objective ;\n- Sérieuse : d'une gravité suffisante rendant impossible la poursuite du contrat.\n\nEn l'espèce, le licenciement de {{salarie.nom}} ne repose sur aucune cause réelle et sérieuse car {{motifs_contestation}}.	\N	{moyens,droit,licenciement,L1232-1,travail}	f	t	\N	0	\N	\N
cml85wbze001hm3wj5tsfupwu	2026-02-04 15:07:55.179	2026-02-04 15:07:55.179	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1343-2 Code Civil (Intérêts)	B. Sur les intérêts moratoires\n\nL'article 1343-2 du Code civil dispose :\n« Les intérêts échus, dus au moins pour une année entière, produisent intérêt si le contrat l'a prévu ou si une décision de justice le précise. »\n\nL'article 1231-6 prévoit que les dommages et intérêts dus à raison du retard dans le paiement d'une obligation de somme d'argent consistent dans l'intérêt au taux légal.\n\nEn conséquence, la condamnation devra être assortie des intérêts au taux légal à compter de {{date_mise_en_demeure}} pour les sommes réclamées à titre principal, et à compter du prononcé de la décision pour les sommes allouées à titre de dommages et intérêts.	\N	{moyens,droit,intérêts,1343-2,anatocisme}	f	t	\N	0	\N	\N
cml85wbzg001jm3wjpwdulrgn	2026-02-04 15:07:55.181	2026-02-04 15:07:55.181	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1195 Code Civil (Imprévision)	C. Sur l'imprévision\n\nL'article 1195 du Code civil dispose :\n« Si un changement de circonstances imprévisible lors de la conclusion du contrat rend l'exécution excessivement onéreuse pour une partie qui n'avait pas accepté d'en assumer le risque, celle-ci peut demander une renégociation du contrat à son cocontractant. »\n\nEn l'espèce, {{description_changement_circonstances}} constitue un changement imprévisible qui :\n- N'était pas prévisible lors de la conclusion du contrat le {{date_contrat}} ;\n- Rend l'exécution excessivement onéreuse pour {{partie.nom}} ;\n- N'avait pas été assumé contractuellement par {{partie.nom}}.\n\n{{partie.nom}} est donc fondé(e) à solliciter la révision judiciaire du contrat.	\N	{moyens,droit,imprévision,1195,révision}	f	t	\N	0	\N	\N
cml85wbzj001lm3wjnrjjzqqq	2026-02-04 15:07:55.183	2026-02-04 15:07:55.183	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1104 Code Civil (Bonne foi)	D. Sur l'obligation de bonne foi\n\nL'article 1104 du Code civil dispose :\n« Les contrats doivent être négociés, formés et exécutés de bonne foi. Cette disposition est d'ordre public. »\n\nLa jurisprudence sanctionne notamment :\n- Le comportement déloyal dans l'exécution du contrat (Com., 10 juillet 2007) ;\n- L'usage abusif d'une prérogative contractuelle (Civ. 1ère, 16 février 1999) ;\n- Le refus de renégociation abusif (Com., 3 octobre 2006).\n\nEn l'espèce, {{defendeur.nom}} a manqué à son obligation de bonne foi en {{description_manquement}}.	\N	{moyens,droit,"bonne foi",1104,loyauté}	f	t	\N	0	\N	\N
cml85wbzl001nm3wjiggn6wga	2026-02-04 15:07:55.186	2026-02-04 15:07:55.186	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Vice du consentement (Erreur)	E. Sur l'erreur\n\nL'article 1132 du Code civil dispose :\n« L'erreur de droit ou de fait, à moins qu'elle ne soit inexcusable, est une cause de nullité du contrat lorsqu'elle porte sur les qualités essentielles de la prestation due ou sur celles du cocontractant. »\n\nL'erreur commise par {{partie.nom}} porte sur {{objet_erreur}}, qui constitue une qualité essentielle car {{justification_qualite_essentielle}}.\n\nCette erreur est excusable car {{justification_excusabilite}}.\n\nEn conséquence, la nullité du contrat doit être prononcée.	\N	{moyens,droit,erreur,"vice consentement",nullité}	f	t	\N	0	\N	\N
cml85wbzn001pm3wj24dhzbos	2026-02-04 15:07:55.188	2026-02-04 15:07:55.188	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Vice du consentement (Dol)	F. Sur le dol\n\nL'article 1137 du Code civil dispose :\n« Le dol est le fait pour un contractant d'obtenir le consentement de l'autre par des manœuvres ou des mensonges. Constitue également un dol la dissimulation intentionnelle par l'un des contractants d'une information dont il sait le caractère déterminant pour l'autre partie. »\n\n{{defendeur.nom}} a commis un dol en {{description_dol}}.\n\nCette manœuvre/réticence était déterminante du consentement de {{demandeur.nom}}, qui n'aurait pas contracté ou aurait contracté à des conditions différentes s'il avait connu {{information_dissimilee}}.\n\nLa nullité du contrat doit être prononcée avec allocation de dommages et intérêts.	\N	{moyens,droit,dol,"vice consentement",nullité}	f	t	\N	0	\N	\N
cml85wbzp001rm3wj6gkiryb9	2026-02-04 15:07:55.19	2026-02-04 15:07:55.19	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Prescription biennale travail	G. Sur la prescription\n\nL'article L.1471-1 du Code du travail dispose :\n« Toute action portant sur l'exécution du contrat de travail se prescrit par deux ans à compter du jour où celui qui l'exerce a connu ou aurait dû connaître les faits lui permettant d'exercer son droit. »\n\nEn l'espèce, l'action de {{partie.nom}} est recevable car :\n- Le point de départ de la prescription est le {{date_connaissance_faits}} ;\n- La saisine du Conseil de Prud'hommes est intervenue le {{date_saisine}} ;\n- L'action a donc été introduite dans le délai de deux ans.	\N	{moyens,droit,prescription,travail,L1471-1}	f	t	\N	0	\N	\N
cml85wbzs001tm3wj1kfe29ua	2026-02-04 15:07:55.192	2026-02-04 15:07:55.192	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Prescription quinquennale	H. Sur la prescription quinquennale\n\nL'article 2224 du Code civil dispose :\n« Les actions personnelles ou mobilières se prescrivent par cinq ans à compter du jour où le titulaire d'un droit a connu ou aurait dû connaître les faits lui permettant de l'exercer. »\n\nLe point de départ du délai de prescription est fixé au {{date_point_depart}} car c'est à cette date que {{demandeur.nom}} a eu connaissance de {{faits_permettant_agir}}.\n\nL'action ayant été introduite le {{date_action}}, elle est recevable.	\N	{moyens,droit,prescription,2224,quinquennale}	f	t	\N	0	\N	\N
cml85wbzu001vm3wj1krfc2tx	2026-02-04 15:07:55.194	2026-02-04 15:07:55.194	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Préjudice économique	I. Sur le préjudice économique\n\nLe préjudice économique subi par {{demandeur.nom}} comprend :\n\n1. La perte éprouvée :\n{{#each pertes}}\n- {{this.description}} : {{this.montant}} euros\n{{/each}}\nSous-total pertes : {{total_pertes}} euros\n\n2. Le gain manqué :\n{{#each gains_manques}}\n- {{this.description}} : {{this.montant}} euros\n{{/each}}\nSous-total gains manqués : {{total_gains_manques}} euros\n\nTOTAL PRÉJUDICE ÉCONOMIQUE : {{total_prejudice}} euros	\N	{moyens,préjudice,économique,dommages-intérêts}	f	t	\N	0	\N	\N
cml85wbzy001xm3wjrwc0dxif	2026-02-04 15:07:55.199	2026-02-04 15:07:55.199	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Préjudice moral	J. Sur le préjudice moral\n\n{{demandeur.nom}} a subi un préjudice moral résultant de {{source_prejudice}}.\n\nCe préjudice se manifeste par :\n{{#each manifestations}}\n- {{this}}\n{{/each}}\n\nIl est attesté par {{preuves_prejudice_moral}}.\n\nEu égard à la gravité des faits et à leurs conséquences sur {{demandeur.nom}}, le préjudice moral sera justement réparé par l'allocation d'une somme de {{montant_moral}} euros à titre de dommages et intérêts.	\N	{moyens,préjudice,moral,dommages-intérêts}	f	t	\N	0	\N	\N
cml85wc01001zm3wj6bkvbnsp	2026-02-04 15:07:55.201	2026-02-04 15:07:55.201	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Référé expertise	PAR CES MOTIFS\n\nPlaise au Président statuant en référé :\n\n- ORDONNER une mesure d'expertise judiciaire ;\n\n- DESIGNER tel expert qu'il plaira au Président de nommer avec pour mission de :\n  * Se rendre sur les lieux situés {{adresse_lieux}} ;\n  * Décrire les désordres constatés ;\n  * Rechercher les causes des désordres ;\n  * Déterminer les responsabilités ;\n  * Évaluer les travaux de reprise ;\n  * Chiffrer les préjudices ;\n\n- FIXER la consignation à la somme de {{montant_consignation}} euros ;\n\n- RÉSERVER les dépens.	\N	{dispositif,référé,expertise,"145 CPC"}	f	t	\N	0	\N	\N
cml85wc030021m3wjwpzxxfhg	2026-02-04 15:07:55.203	2026-02-04 15:07:55.203	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Référé provision	PAR CES MOTIFS\n\nPlaise au Président statuant en référé :\n\n- CONSTATER que l'obligation de {{defendeur.nom}} n'est pas sérieusement contestable ;\n\n- CONDAMNER {{defendeur.nom}} à verser à {{demandeur.nom}} une provision de {{montant_provision}} euros à valoir sur l'indemnisation de son préjudice ;\n\n- ORDONNER l'exécution provisoire de droit ;\n\n- CONDAMNER {{defendeur.nom}} aux dépens ainsi qu'à verser à {{demandeur.nom}} la somme de {{montant_article_700}} euros sur le fondement de l'article 700 du CPC.	\N	{dispositif,référé,provision,"835 CPC"}	f	t	\N	0	\N	\N
cml85wc050023m3wj18u5glks	2026-02-04 15:07:55.205	2026-02-04 15:07:55.205	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Nullité contrat	PAR CES MOTIFS\n\nPlaise au Tribunal :\n\n- PRONONCER la nullité du contrat conclu le {{date_contrat}} entre {{partie1.nom}} et {{partie2.nom}} pour cause de {{motif_nullite}} ;\n\n- ORDONNER les restitutions réciproques ;\n\n- CONDAMNER {{partie_fautive.nom}} à verser à {{partie_victime.nom}} la somme de {{montant_dommages}} euros à titre de dommages et intérêts ;\n\n- CONDAMNER {{partie_fautive.nom}} aux entiers dépens.	\N	{dispositif,nullité,contrat,restitutions}	f	t	\N	0	\N	\N
cml85wc070025m3wjgmbew5u0	2026-02-04 15:07:55.207	2026-02-04 15:07:55.207	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Prud'hommes licenciement	PAR CES MOTIFS\n\nPlaise au Conseil de Prud'hommes :\n\n- DIRE ET JUGER que le licenciement de {{salarie.nom}} est dépourvu de cause réelle et sérieuse ;\n\n- CONDAMNER {{employeur.nom}} à verser à {{salarie.nom}} les sommes suivantes :\n  * {{montant_indemnite_licenciement}} euros à titre d'indemnité pour licenciement sans cause réelle et sérieuse (article L.1235-3 du Code du travail) ;\n  * {{montant_preavis}} euros au titre de l'indemnité compensatrice de préavis ;\n  * {{montant_cp_preavis}} euros au titre des congés payés afférents ;\n  * {{montant_article_700}} euros au titre de l'article 700 du CPC ;\n\n- ORDONNER la remise des documents de fin de contrat rectifiés ;\n\n- CONDAMNER {{employeur.nom}} aux dépens.	\N	{dispositif,prud'hommes,licenciement,travail}	f	t	\N	0	\N	\N
cml85wc090027m3wj95bxsm0s	2026-02-04 15:07:55.209	2026-02-04 15:07:55.209	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Divorce par consentement mutuel	PAR CES MOTIFS\n\nPlaise au Juge aux Affaires Familiales :\n\n- HOMOLOGUER la convention de divorce par consentement mutuel ;\n\n- PRONONCER le divorce de {{epoux1.nom}} et {{epoux2.nom}} ;\n\n- ORDONNER la mention du divorce en marge de l'acte de mariage ;\n\n- DIRE que chaque partie conservera la charge de ses propres dépens.	\N	{dispositif,divorce,"consentement mutuel",famille}	f	t	\N	0	\N	\N
cml85wc0b0029m3wjgju4qsif	2026-02-04 15:07:55.212	2026-02-04 15:07:55.212	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Injonction de faire	PAR CES MOTIFS\n\nPlaise au Tribunal :\n\n- ENJOINDRE {{defendeur.nom}} de {{obligation_a_executer}} dans un délai de {{delai}} à compter de la signification du présent jugement ;\n\n- DIRE que passé ce délai, {{defendeur.nom}} sera redevable d'une astreinte de {{montant_astreinte}} euros par jour de retard ;\n\n- SE RÉSERVER la liquidation de l'astreinte ;\n\n- CONDAMNER {{defendeur.nom}} aux dépens.	\N	{dispositif,injonction,faire,astreinte}	f	t	\N	0	\N	\N
cml85wc0e002bm3wjyr6v68p2	2026-02-04 15:07:55.214	2026-02-04 15:07:55.214	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Interdiction et cessation	PAR CES MOTIFS\n\nPlaise au Tribunal :\n\n- INTERDIRE à {{defendeur.nom}} de {{comportement_interdit}} sous astreinte de {{montant_astreinte}} euros par infraction constatée ;\n\n- ORDONNER la cessation de {{actes_litigieux}} ;\n\n- ORDONNER la publication du présent jugement dans {{support_publication}} aux frais de {{defendeur.nom}} ;\n\n- CONDAMNER {{defendeur.nom}} à verser à {{demandeur.nom}} la somme de {{montant_dommages}} euros à titre de dommages et intérêts.	\N	{dispositif,interdiction,cessation,astreinte,concurrence}	f	t	\N	0	\N	\N
cml85wc0g002dm3wjaramyz2p	2026-02-04 15:07:55.216	2026-02-04 15:07:55.216	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Formule signature client	Fait à {{lieu}}, le {{date}}\nEn {{nombre_exemplaires}} exemplaires originaux.\n\n{{client.nom}}\n(signature précédée de la mention « Lu et approuvé »)\n\n{{client.signature}}	\N	{signature,client,formule}	f	t	\N	0	\N	\N
cml85wc0i002fm3wjhtf3ttp6	2026-02-04 15:07:55.218	2026-02-04 15:07:55.218	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Formule signature électronique	Le présent document a été signé électroniquement conformément aux dispositions du Règlement (UE) n°910/2014 du 23 juillet 2014 (eIDAS).\n\nSignatures électroniques qualifiées :\n\n{{#each signataires}}\n- {{this.nom}} : Certificat n°{{this.numero_certificat}}\n  Date de signature : {{this.date_signature}}\n  Autorité de certification : {{this.autorite_certification}}\n{{/each}}	\N	{signature,électronique,eIDAS}	f	t	\N	0	\N	\N
cml85wc0k002hm3wjc8ydz3vt	2026-02-04 15:07:55.22	2026-02-04 15:07:55.22	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Mentions légales pied de page	---\n{{cabinet.denomination}} - {{cabinet.forme}}\nSiège social : {{cabinet.adresse}}\nTél : {{cabinet.telephone}} - Email : {{cabinet.email}}\nBarreau de {{avocat.barreau}} - Toque n°{{avocat.toque}}\n{{#if cabinet.rcs}}RCS {{cabinet.rcs}} - {{/if}}{{#if cabinet.tva}}TVA {{cabinet.tva}}{{/if}}\n\nDocument confidentiel - Toute reproduction interdite	\N	{"mentions légales","pied de page",footer}	f	t	\N	0	\N	\N
cml85wc0l002jm3wjep9cjbzh	2026-02-04 15:07:55.222	2026-02-04 15:07:55.222	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Clause de confidentialité fin de document	Le présent document et les informations qu'il contient sont strictement confidentiels et destinés à l'usage exclusif de leur(s) destinataire(s). Toute utilisation, divulgation ou reproduction, même partielle, non autorisée est interdite.\n\nSi vous avez reçu ce document par erreur, merci de le détruire et d'en informer immédiatement l'expéditeur.	\N	{confidentialité,clause,"fin document"}	f	t	\N	0	\N	\N
cml85wc0o002lm3wjivpjc0c3	2026-02-04 15:07:55.224	2026-02-04 15:07:55.224	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Annexes et pièces jointes	LISTE DES ANNEXES\n\n{{#each annexes}}\nAnnexe {{@index}} : {{this.titre}}\n{{#if this.description}}    {{this.description}}{{/if}}\n{{/each}}\n\nLes annexes font partie intégrante du présent {{type_document}}.	\N	{annexes,"pièces jointes",liste}	f	t	\N	0	\N	\N
cml85wc0q002nm3wj9mlq2nfi	2026-02-04 15:07:55.226	2026-02-04 15:07:55.226	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de force majeure	ARTICLE {{numero}} - FORCE MAJEURE\n\n{{numero}}.1 - Aucune des Parties ne sera tenue responsable vis-à-vis de l'autre Partie d'un manquement à ses obligations contractuelles si ce manquement résulte d'un événement de force majeure au sens de l'article 1218 du Code civil.\n\n{{numero}}.2 - Sont notamment considérés comme cas de force majeure : les catastrophes naturelles, guerres, actes de terrorisme, grèves générales, décisions gouvernementales, épidémies ou pandémies.\n\n{{numero}}.3 - La Partie invoquant la force majeure devra en informer l'autre Partie dans un délai de {{delai_notification}} jours.\n\n{{numero}}.4 - Si l'événement de force majeure se prolonge au-delà de {{duree_suspension}} mois, chaque Partie pourra résilier le contrat sans indemnité.	\N	{clause,"force majeure",1218,exonération}	f	t	\N	0	\N	\N
cml85wc0t002pm3wj9irwxw1d	2026-02-04 15:07:55.229	2026-02-04 15:07:55.229	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de non-sollicitation de personnel	ARTICLE {{numero}} - NON-SOLLICITATION DE PERSONNEL\n\nChacune des Parties s'engage à ne pas solliciter, embaucher ou faire embaucher, directement ou indirectement, tout salarié ou collaborateur de l'autre Partie, pendant toute la durée du présent contrat et pendant une période de {{duree}} mois suivant son terme.\n\nEn cas de violation de cette obligation, la Partie défaillante versera à l'autre une indemnité forfaitaire de {{montant}} euros par salarié ou collaborateur concerné.	\N	{clause,non-sollicitation,personnel,salarié}	f	t	\N	0	\N	\N
cml85wc0v002rm3wjcxm0ck2x	2026-02-04 15:07:55.231	2026-02-04 15:07:55.231	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de propriété intellectuelle	ARTICLE {{numero}} - PROPRIÉTÉ INTELLECTUELLE\n\n{{numero}}.1 - Les droits de propriété intellectuelle sur les {{objets_pi}} créés dans le cadre du présent contrat sont cédés à {{cessionnaire}} dès leur création, pour le monde entier et pour toute la durée légale de protection.\n\n{{numero}}.2 - Cette cession comprend les droits de reproduction, représentation, adaptation, traduction et commercialisation.\n\n{{numero}}.3 - Le Créateur garantit que les {{objets_pi}} ne portent pas atteinte aux droits des tiers et s'engage à indemniser {{cessionnaire}} de toute réclamation à ce titre.\n\n{{numero}}.4 - Le prix convenu inclut la rémunération de cette cession de droits.	\N	{clause,"propriété intellectuelle","cession droits",PI}	f	t	\N	0	\N	\N
cml85wc0y002tm3wjsznnwexx	2026-02-04 15:07:55.234	2026-02-04 15:07:55.234	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de données personnelles (RGPD)	ARTICLE {{numero}} - PROTECTION DES DONNÉES PERSONNELLES\n\n{{numero}}.1 - Dans le cadre de l'exécution du présent contrat, les Parties s'engagent à respecter la réglementation applicable en matière de protection des données personnelles, notamment le Règlement (UE) 2016/679 du 27 avril 2016 (RGPD).\n\n{{numero}}.2 - {{partie_RT}} agit en qualité de responsable de traitement.\n\n{{numero}}.3 - {{partie_ST}} agit en qualité de sous-traitant et s'engage notamment à :\n- Traiter les données uniquement sur instruction documentée du responsable de traitement ;\n- Garantir la confidentialité des données ;\n- Mettre en œuvre les mesures de sécurité appropriées ;\n- Assister le responsable de traitement pour répondre aux demandes des personnes concernées.	\N	{clause,RGPD,"données personnelles",sous-traitance}	f	t	\N	0	\N	\N
cml85wc0z002vm3wjmhyxnsgj	2026-02-04 15:07:55.236	2026-02-04 15:07:55.236	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de limitation de responsabilité	ARTICLE {{numero}} - LIMITATION DE RESPONSABILITÉ\n\n{{numero}}.1 - La responsabilité totale de {{partie_limitee}} au titre du présent contrat ne pourra excéder {{plafond}} euros.\n\n{{numero}}.2 - En aucun cas, {{partie_limitee}} ne sera responsable des dommages indirects, notamment le manque à gagner, la perte de clientèle, la perte de données ou l'atteinte à l'image.\n\n{{numero}}.3 - Ces limitations ne s'appliquent pas en cas de faute lourde ou intentionnelle, ou en cas d'atteinte à l'intégrité physique des personnes.\n\n{{numero}}.4 - Les Parties reconnaissent que ces limitations sont équilibrées et reflètent l'économie du contrat.	\N	{clause,"limitation responsabilité",plafond,exclusion}	f	t	\N	0	\N	\N
cml85wc11002xm3wjbwryjxqs	2026-02-04 15:07:55.237	2026-02-04 15:07:55.237	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de divisibilité	ARTICLE {{numero}} - DIVISIBILITÉ\n\nSi l'une quelconque des stipulations du présent contrat était déclarée nulle ou inopposable en application d'une loi, d'un règlement ou à la suite d'une décision de justice devenue définitive, elle serait réputée non écrite, sans que cela n'affecte la validité des autres stipulations qui demeureront pleinement applicables.\n\nLes Parties s'engagent à négocier de bonne foi pour remplacer la stipulation nulle ou inopposable par une stipulation valide ayant un effet économique aussi proche que possible.	\N	{clause,divisibilité,"nullité partielle",validité}	f	t	\N	0	\N	\N
cml85wc13002zm3wj7l1nsakb	2026-02-04 15:07:55.239	2026-02-04 15:07:55.239	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'intégralité	ARTICLE {{numero}} - INTÉGRALITÉ DE L'ACCORD\n\nLe présent contrat et ses annexes constituent l'intégralité de l'accord entre les Parties sur son objet.\n\nIl annule et remplace tous accords, lettres d'intention, pourparlers et documents antérieurs ayant le même objet.\n\nAucune modification du présent contrat ne sera valable sans un avenant écrit signé par les deux Parties.	\N	{clause,intégralité,"accord complet",modification}	f	t	\N	0	\N	\N
cml85wc140031m3wjznmzffp3	2026-02-04 15:07:55.241	2026-02-04 15:07:55.241	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de renonciation	ARTICLE {{numero}} - NON-RENONCIATION\n\nLe fait pour l'une des Parties de ne pas se prévaloir d'un manquement de l'autre Partie à l'une quelconque des obligations visées au présent contrat ne saurait être interprété comme une renonciation à se prévaloir dans l'avenir d'un tel manquement.\n\nToute renonciation à l'application du présent contrat devra faire l'objet d'un accord exprès et écrit des Parties.	\N	{clause,renonciation,tolérance,droits}	f	t	\N	0	\N	\N
cml85wc160033m3wjchqiv9d2	2026-02-04 15:07:55.243	2026-02-04 15:07:55.243	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de cession de contrat	ARTICLE {{numero}} - CESSION\n\n{{numero}}.1 - Le présent contrat est conclu intuitu personae et ne pourra être cédé ou transféré par l'une des Parties sans l'accord préalable écrit de l'autre Partie.\n\n{{numero}}.2 - Par exception, {{partie}} pourra librement céder le présent contrat à toute société de son groupe (au sens de l'article L.233-3 du Code de commerce) ou à tout cessionnaire de tout ou partie de ses activités.\n\n{{numero}}.3 - En cas de cession autorisée, le cessionnaire sera tenu de toutes les obligations du cédant au titre du présent contrat.	\N	{clause,"cession contrat","intuitu personae",transfert}	f	t	\N	0	\N	\N
cml85wc180035m3wjrhwngual	2026-02-04 15:07:55.244	2026-02-04 15:07:55.244	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de révision de prix	ARTICLE {{numero}} - RÉVISION DU PRIX\n\n{{numero}}.1 - Le prix sera révisé {{periodicite}} en fonction de l'évolution de l'indice {{indice_reference}} publié par {{organisme_publication}}.\n\n{{numero}}.2 - La formule de révision est la suivante :\nP1 = P0 x (I1/I0)\nOù :\n- P1 = prix révisé\n- P0 = prix initial ({{prix_initial}} euros)\n- I1 = dernier indice connu à la date de révision\n- I0 = indice à la date de conclusion ({{indice_initial}})\n\n{{numero}}.3 - La révision ne pourra conduire à une augmentation supérieure à {{plafond_augmentation}}% par an.	\N	{clause,"révision prix",indexation,indice}	f	t	\N	0	\N	\N
cml85wc1a0037m3wjrkjo1kqn	2026-02-04 15:07:55.246	2026-02-04 15:07:55.246	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de pénalités de retard	ARTICLE {{numero}} - PÉNALITÉS DE RETARD\n\nEn cas de retard de paiement, le débiteur sera de plein droit redevable :\n\n{{numero}}.1 - D'intérêts de retard calculés au taux de {{taux_interet}}% l'an (ou au taux prévu à l'article L.441-10 du Code de commerce pour les relations commerciales entre professionnels), à compter de la date d'échéance ;\n\n{{numero}}.2 - D'une indemnité forfaitaire pour frais de recouvrement de {{indemnite_forfaitaire}} euros, conformément à l'article D.441-5 du Code de commerce ;\n\n{{numero}}.3 - Des frais de recouvrement effectivement exposés si ceux-ci excèdent l'indemnité forfaitaire.	\N	{clause,pénalités,retard,intérêts,paiement}	f	t	\N	0	\N	\N
cml88g72y000k521vhls1iakg	2026-02-04 16:19:21.178	2026-02-04 16:19:21.178	cml88g71z0000521vp3t710u4	INTRO	Intro Requête Ordonnance sur Requête	REQUÊTE AUX FINS D'ORDONNANCE SUR REQUÊTE\n\nPrésentée par :\n{{client.nom}}\n\nÀ Monsieur le Président du Tribunal Judiciaire de {{juridiction}},\n\nLa présente requête est présentée sur le fondement de l'article 493 du Code de procédure civile.	{}	{ordonnance,requete,intro}	f	t	10	0	\N	\N
cml85wc1b0039m3wj65o78j36	2026-02-04 15:07:55.248	2026-02-04 15:07:55.248	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de notification	ARTICLE {{numero}} - NOTIFICATIONS\n\nToute notification ou communication au titre du présent contrat devra être faite par écrit et sera réputée valablement effectuée si elle est adressée :\n\n- Pour {{partie1.nom}} : {{partie1.adresse_notification}}\n- Pour {{partie2.nom}} : {{partie2.adresse_notification}}\n\nToute notification sera réputée reçue :\n- En cas de lettre recommandée avec AR : à la date de première présentation ;\n- En cas d'email avec accusé de réception : à la date d'envoi ;\n- En cas de remise en main propre : à la date de remise.\n\nToute modification d'adresse devra être notifiée à l'autre Partie dans les meilleurs délais.	\N	{clause,notification,communication,adresse}	f	t	\N	0	\N	\N
cml85wc1d003bm3wjfb5nfy0p	2026-02-04 15:07:55.25	2026-02-04 15:07:55.25	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de durée et renouvellement	ARTICLE {{numero}} - DURÉE\n\n{{numero}}.1 - Le présent contrat est conclu pour une durée de {{duree_initiale}} à compter de {{date_effet}}.\n\n{{numero}}.2 - À l'issue de cette période initiale, le contrat sera renouvelé par tacite reconduction pour des périodes successives de {{duree_renouvellement}}, sauf dénonciation par l'une des Parties moyennant un préavis de {{preavis}} adressé par lettre recommandée avec accusé de réception.\n\n{{numero}}.3 - Le nombre de renouvellements n'est pas limité / Le contrat ne pourra être renouvelé plus de {{nombre_max_renouvellements}} fois.	\N	{clause,durée,renouvellement,"tacite reconduction"}	f	t	\N	0	\N	\N
cml85wc1f003dm3wj9hsxtos5	2026-02-04 15:07:55.252	2026-02-04 15:07:55.252	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de résiliation anticipée	ARTICLE {{numero}} - RÉSILIATION ANTICIPÉE\n\n{{numero}}.1 - Chaque Partie pourra résilier le présent contrat par anticipation :\n- En cas de manquement grave de l'autre Partie à ses obligations, non remédié dans un délai de {{delai_remediation}} jours suivant mise en demeure ;\n- En cas d'ouverture d'une procédure collective à l'encontre de l'autre Partie ;\n- En cas de changement de contrôle de l'autre Partie.\n\n{{numero}}.2 - La résiliation prendra effet {{delai_effet}} jours après notification par lettre recommandée avec AR.\n\n{{numero}}.3 - La résiliation est sans préjudice des dommages et intérêts éventuellement dus à la Partie non défaillante.	\N	{clause,résiliation,anticipée,manquement}	f	t	\N	0	\N	\N
cml85wc1h003fm3wjdzcszs28	2026-02-04 15:07:55.253	2026-02-04 15:07:55.253	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'audit	ARTICLE {{numero}} - DROIT D'AUDIT\n\n{{numero}}.1 - {{partie_beneficiaire}} se réserve le droit de procéder ou faire procéder, à ses frais, à tout audit destiné à vérifier le respect par {{partie_auditee}} de ses obligations au titre du présent contrat.\n\n{{numero}}.2 - L'audit sera réalisé pendant les heures ouvrables, moyennant un préavis de {{preavis_audit}} jours ouvrés.\n\n{{numero}}.3 - {{partie_auditee}} s'engage à coopérer pleinement à l'audit et à donner accès à tous documents et informations utiles.\n\n{{numero}}.4 - Les résultats de l'audit seront confidentiels.	\N	{clause,audit,vérification,contrôle}	f	t	\N	0	\N	\N
cml88g72e0002521vd4ncnwe7	2026-02-04 16:19:21.158	2026-02-04 16:19:21.158	cml88g71z0000521vp3t710u4	INTRO	Intro Assignation Tribunal Judiciaire	L'AN DEUX MILLE VINGT-SIX\nEt le {{date_assignation}}\n\nÀ la requête de :\n{{client.civilite}} {{client.nom}} {{client.prenom}}\nDemeurant {{client.adresse}}\n{{client.code_postal}} {{client.ville}}\n\nReprésenté par Maître {{avocat.nom}} {{avocat.prenom}}\nAvocat au Barreau de {{avocat.barreau}}\n{{cabinet.adresse}}\n\nJ'ai, {{huissier.nom}} {{huissier.prenom}}, Huissier de Justice associé de la SCP {{huissier.scp}}, demeurant {{huissier.adresse}}, et exerçant en cette ville,\n\nDONNÉ ASSIGNATION À :\n\n{{adversaire.civilite}} {{adversaire.nom}} {{adversaire.prenom}}\nDemeurant {{adversaire.adresse}}\n{{adversaire.code_postal}} {{adversaire.ville}}\n\nÀ COMPARAÎTRE devant le Tribunal Judiciaire de {{juridiction}}, Palais de Justice {{juridiction.adresse}}, le {{date_audience}} à {{heure_audience}}.	{}	{assignation,tribunal-judiciaire,intro}	f	t	1	0	\N	\N
cml88g72l0004521v67f38gmg	2026-02-04 16:19:21.165	2026-02-04 16:19:21.165	cml88g71z0000521vp3t710u4	INTRO	Intro Assignation Référé Urgence	L'AN DEUX MILLE VINGT-SIX\nEt le {{date_assignation}}\n\nEN RÉFÉRÉ D'HEURE À HEURE\n\nÀ la requête de :\n{{client.nom}}\nAgissant en qualité de {{client.qualite}}\n\nAyant pour avocat :\nMaître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nJ'ai {{huissier.nom}}, Huissier de Justice,\n\nDONNÉ ASSIGNATION EN RÉFÉRÉ D'HEURE À HEURE À :\n\n{{adversaire.nom}}\n\nPour voir statuer par le Président du Tribunal Judiciaire statuant en référé le {{date_audience}} à {{heure_audience}}.\n\nIL Y A URGENCE car {{motif_urgence}}.	{}	{refere,urgence,intro}	f	t	2	0	\N	\N
cml88g72m0006521vrm2xxfs7	2026-02-04 16:19:21.167	2026-02-04 16:19:21.167	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions en Défense	TRIBUNAL JUDICIAIRE DE {{juridiction}}\n\nCONCLUSIONS EN DÉFENSE\n\nPour :\n{{client.civilite}} {{client.nom}} {{client.prenom}}\nDemeurant {{client.adresse}}\n\nReprésenté par :\nMaître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nCONTRE :\n\n{{adversaire.nom}}\n\nAffaire RG nº {{numero_rg}}\n\nPLAISE AU TRIBUNAL,	{}	{conclusions,defense,intro}	f	t	3	0	\N	\N
cml88g72o0008521v6l79d856	2026-02-04 16:19:21.168	2026-02-04 16:19:21.168	cml88g71z0000521vp3t710u4	INTRO	Intro Requête en Référé	REQUÊTE EN RÉFÉRÉ\n\nPrésentée par :\n{{client.nom}}\n{{client.adresse}}\n\nReprésenté par Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nCONTRE :\n\n{{adversaire.nom}}\n{{adversaire.adresse}}\n\nMonsieur le Président du Tribunal Judiciaire de {{juridiction}},	{}	{requete,refere,intro}	f	t	4	0	\N	\N
cml88g72p000a521vt2ugqmlk	2026-02-04 16:19:21.17	2026-02-04 16:19:21.17	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Incident	CONCLUSIONS SUR INCIDENT\n\nAffaire RG nº {{numero_rg}}\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nPLAISE AU TRIBUNAL,\n\nSur l'incident soulevé par la partie adverse,	{}	{conclusions,incident,intro}	f	t	5	0	\N	\N
cml88g72r000c521vlxm2tbb5	2026-02-04 16:19:21.171	2026-02-04 16:19:21.171	cml88g71z0000521vp3t710u4	INTRO	Intro Mémoire en Réplique	MÉMOIRE EN RÉPLIQUE\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nAffaire : {{numero_rg}}\n\nEn réponse aux conclusions déposées par la partie adverse le {{date_conclusions_adversaire}},	{}	{replique,memoire,intro}	f	t	6	0	\N	\N
cml88g72s000e521vgrroa0zf	2026-02-04 16:19:21.173	2026-02-04 16:19:21.173	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Appel	COUR D'APPEL DE {{juridiction}}\n\nCONCLUSIONS D'APPELANT\n\nPour : {{client.nom}}\nAPPELANT\n\nContre : {{adversaire.nom}}\nINTIMÉ\n\nAffaire nº {{numero_rg}}\n\nPLAISE À LA COUR,	{}	{appel,conclusions,intro}	f	t	7	0	\N	\N
cml88g72t000g521vgtu9w5zz	2026-02-04 16:19:21.174	2026-02-04 16:19:21.174	cml88g71z0000521vp3t710u4	INTRO	Intro Contredit	CONTREDIT\n\nAffaire RG nº {{numero_rg}}\n\nPour : {{client.nom}}\n\nCONTESTE LA COMPÉTENCE DU TRIBUNAL\n\nAu visa de l'article 75 du Code de procédure civile,	{}	{contredit,competence,intro}	f	t	8	0	\N	\N
cml88g731000o521vamlkkqum	2026-02-04 16:19:21.181	2026-02-04 16:19:21.181	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Référé-Provision	CONCLUSIONS EN RÉFÉRÉ-PROVISION\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nSur le fondement de l'article 835 alinéa 2 du Code de procédure civile,\n\nPLAISE AU PRÉSIDENT,	{}	{refere,provision,intro}	f	t	12	0	\N	\N
cml88g733000q521v59duxkoq	2026-02-04 16:19:21.183	2026-02-04 16:19:21.183	cml88g71z0000521vp3t710u4	INTRO	Intro Assignation Jour Fixe	ASSIGNATION À JOUR FIXE\n\nL'AN DEUX MILLE VINGT-SIX\nLe {{date_assignation}}\n\nÀ la requête de : {{client.nom}}\n\nMuni d'une ordonnance rendue le {{date_ordonnance}} par le Président du Tribunal Judiciaire de {{juridiction}} autorisant l'assignation à jour fixe,\n\nJ'ai assigné : {{adversaire.nom}}\n\nÀ comparaître le {{date_audience}} à {{heure_audience}}.	{}	{jour-fixe,assignation,intro}	f	t	13	0	\N	\N
cml88g734000s521vlmw8r7ax	2026-02-04 16:19:21.184	2026-02-04 16:19:21.184	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Intervention Volontaire	CONCLUSIONS D'INTERVENTION VOLONTAIRE\n\nPour : {{client.nom}}\nINTERVENANT\n\nDans l'instance opposant :\n\n{{demandeur.nom}}\nDEMANDEUR\n\nÀ\n\n{{defendeur.nom}}\nDÉFENDEUR\n\nAffaire RG nº {{numero_rg}}\n\nPLAISE AU TRIBUNAL recevoir l'intervention de {{client.nom}},	{}	{intervention,volontaire,intro}	f	t	14	0	\N	\N
cml88g735000u521vsg18vhsw	2026-02-04 16:19:21.185	2026-02-04 16:19:21.185	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Appel en Garantie	CONCLUSIONS D'APPEL EN GARANTIE\n\nPour : {{client.nom}}\nDÉFENDEUR ET DEMANDEUR À L'APPEL EN GARANTIE\n\nAppelle en garantie :\n\n{{garant.nom}}\n\nEn vue d'être relevé et garanti de toute condamnation qui pourrait être prononcée à son encontre.	{}	{garantie,appel-garantie,intro}	f	t	15	0	\N	\N
cml88g736000w521vv9dwdvqy	2026-02-04 16:19:21.186	2026-02-04 16:19:21.186	cml88g71z0000521vp3t710u4	FAITS	Chronologie Relation Contractuelle	EXPOSÉ DES FAITS\n\nLa relation contractuelle entre les parties s'est établie selon la chronologie suivante :\n\n- Le {{date_1}} : {{evenement_1}}\n- Le {{date_2}} : {{evenement_2}}\n- Le {{date_3}} : {{evenement_3}}\n- Le {{date_4}} : {{evenement_4}}\n\nForce est de constater que {{constatation_principale}}.	{}	{chronologie,contrat,faits}	f	t	1	0	\N	\N
cml88g737000y521v0sp6dmjv	2026-02-04 16:19:21.188	2026-02-04 16:19:21.188	cml88g71z0000521vp3t710u4	FAITS	Rappel Contrat Commercial	Par contrat en date du {{date_contrat}}, la société {{client.nom}} et la société {{adversaire.nom}} ont conclu un accord commercial portant sur {{objet_contrat}}.\n\nAux termes de ce contrat, il était notamment prévu que :\n- {{clause_1}}\n- {{clause_2}}\n- {{clause_3}}\n\nLe contrat prévoyait une durée de {{duree_contrat}} et un montant total de {{montant_contrat}} euros.	{}	{contrat,commercial,faits}	f	t	2	0	\N	\N
cml88g7380010521v8v0pf884	2026-02-04 16:19:21.189	2026-02-04 16:19:21.189	cml88g71z0000521vp3t710u4	FAITS	Inexécution Contractuelle Détaillée	Or, {{adversaire.nom}} n'a pas respecté ses obligations contractuelles, et ce à plusieurs égards :\n\n1. {{manquement_1}} alors que le contrat prévoyait {{obligation_contractuelle_1}}\n\n2. {{manquement_2}} en violation de l'article {{article_contrat_2}} du contrat\n\n3. {{manquement_3}}\n\nMalgré une mise en demeure adressée par lettre recommandée avec accusé de réception en date du {{date_mise_en_demeure}}, restée sans réponse, {{adversaire.nom}} persiste dans son inexécution.	{}	{inexecution,manquements,faits}	f	t	3	0	\N	\N
cml88g73a0012521vfng0ohzi	2026-02-04 16:19:21.19	2026-02-04 16:19:21.19	cml88g71z0000521vp3t710u4	FAITS	Contexte Cession Parts Sociales	La société {{societe_cible}} est une société {{forme_juridique}} au capital de {{capital}} euros, immatriculée au RCS de {{ville_rcs}} sous le numéro {{numero_rcs}}.\n\nMonsieur/Madame {{cedant.nom}} détenait {{nombre_parts}} parts sociales de la société {{societe_cible}}, représentant {{pourcentage}}% du capital social.\n\nPar protocole de cession en date du {{date_protocole}}, Monsieur/Madame {{cedant.nom}} a cédé l'intégralité de ses parts sociales à Monsieur/Madame {{cessionnaire.nom}} pour un prix de {{prix_cession}} euros.	{}	{cession,parts-sociales,faits}	f	t	4	0	\N	\N
cml88g73b0014521v1mmtupxt	2026-02-04 16:19:21.191	2026-02-04 16:19:21.191	cml88g71z0000521vp3t710u4	FAITS	Litige Livraison Marchandises	Le {{date_commande}}, {{client.nom}} a passé commande auprès de {{adversaire.nom}} pour l'achat de {{description_marchandises}}, pour un montant total de {{montant}} euros TTC.\n\nLa livraison devait intervenir le {{date_livraison_prevue}}.\n\nOr, à ce jour, {{adversaire.nom}} n'a toujours pas procédé à la livraison des marchandises commandées, malgré le paiement intégral effectué par {{client.nom}} le {{date_paiement}}.	{}	{livraison,marchandises,vente,faits}	f	t	5	0	\N	\N
cml88g73c0016521vpptdo7n1	2026-02-04 16:19:21.192	2026-02-04 16:19:21.192	cml88g71z0000521vp3t710u4	FAITS	Accident Circulation Détaillé	Le {{date_accident}} à {{heure_accident}}, un accident de la circulation s'est produit {{lieu_accident}}.\n\n{{client.nom}}, qui circulait à bord du véhicule {{marque_vehicule_client}} immatriculé {{immatriculation_client}}, a été heurté par le véhicule conduit par {{adversaire.nom}}, de marque {{marque_vehicule_adversaire}} immatriculé {{immatriculation_adversaire}}.\n\nLes circonstances de l'accident sont les suivantes : {{circonstances_detaillees}}.\n\nUn constat amiable d'accident a été établi sur place.	{}	{accident,circulation,faits}	f	t	6	0	\N	\N
cml88g73d0018521v8nv8mlww	2026-02-04 16:19:21.193	2026-02-04 16:19:21.193	cml88g71z0000521vp3t710u4	FAITS	Rupture Abusive Contrat Travail	{{client.nom}} a été embauché(e) par la société {{employeur}} en qualité de {{poste}} par contrat de travail à durée {{type_contrat}} en date du {{date_embauche}}.\n\nLe {{date_licenciement}}, {{client.nom}} a été convoqué(e) à un entretien préalable au licenciement.\n\nPar lettre recommandée en date du {{date_lettre_licenciement}}, {{employeur}} a notifié à {{client.nom}} son licenciement pour {{motif_licenciement}}.\n\nOr, ce licenciement est dépourvu de cause réelle et sérieuse pour les raisons suivantes : {{arguments}}.	{}	{travail,licenciement,faits}	f	t	7	0	\N	\N
cml88g73e001a521vr9lcyh1r	2026-02-04 16:19:21.194	2026-02-04 16:19:21.194	cml88g71z0000521vp3t710u4	FAITS	Troubles Voisinage	{{client.nom}} est propriétaire d'un bien immobilier situé {{adresse_client}}, dont il/elle a fait l'acquisition le {{date_acquisition}}.\n\nDepuis le {{date_debut_troubles}}, {{client.nom}} subit des troubles anormaux de voisinage causés par {{adversaire.nom}}, propriétaire du bien situé {{adresse_adversaire}}.\n\nCes troubles se manifestent notamment par : {{description_troubles}}.\n\nMalgré plusieurs courriers de réclamation, dont le dernier en date du {{date_dernier_courrier}}, {{adversaire.nom}} n'a pris aucune mesure pour faire cesser ces nuisances.	{}	{voisinage,troubles,immobilier,faits}	f	t	8	0	\N	\N
cml88g76q005u521vuxf591dk	2026-02-04 16:19:21.314	2026-02-04 16:19:21.314	cml88g71z0000521vp3t710u4	DISPOSITIF	Désistement	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDONNER ACTE à {{client.nom}} de son désistement d'instance et d'action,\n\nCONSTATER l'extinction de l'instance,\n\nDIRE que chaque partie conservera la charge de ses propres dépens.	{}	{desistement,procedure,dispositif}	f	t	25	0	\N	\N
cml88g73f001c521vcqqf772a	2026-02-04 16:19:21.196	2026-02-04 16:19:21.196	cml88g71z0000521vp3t710u4	FAITS	Vice Caché Vente Immobilière	Par acte authentique en date du {{date_vente}}, {{client.nom}} a acquis auprès de {{vendeur}} un bien immobilier situé {{adresse_bien}} pour un prix de {{prix_vente}} euros.\n\nPostérieurement à la vente, {{client.nom}} a découvert que le bien était affecté des vices suivants : {{description_vices}}.\n\nCes vices, qui existaient au jour de la vente et qui n'étaient pas apparents lors de la visite, rendent le bien impropre à l'usage auquel il est destiné.\n\nUn rapport d'expertise établi le {{date_expertise}} par {{expert}} confirme l'existence et la gravité de ces vices.	{}	{vice-cache,vente,immobilier,faits}	f	t	9	0	\N	\N
cml88g73g001e521vo5wrzbou	2026-02-04 16:19:21.197	2026-02-04 16:19:21.197	cml88g71z0000521vp3t710u4	FAITS	Impayés Loyers Commercial	Par bail commercial en date du {{date_bail}}, {{bailleur}} a donné à bail à {{preneur}} des locaux à usage commercial situés {{adresse_locaux}}, moyennant un loyer mensuel de {{montant_loyer}} euros HT.\n\nÀ compter du mois de {{mois_premier_impaye}}, {{preneur}} a cessé de régler les loyers et charges.\n\nÀ ce jour, le montant total des impayés s'élève à {{montant_total_impaye}} euros, correspondant à {{nombre_mois}} mois de loyers impayés.\n\nMalgré une mise en demeure par acte d'huissier en date du {{date_commandement}}, {{preneur}} n'a procédé à aucun règlement.	{}	{bail,commercial,impaye,faits}	f	t	10	0	\N	\N
cml88g73h001g521vo3tl0upg	2026-02-04 16:19:21.198	2026-02-04 16:19:21.198	cml88g71z0000521vp3t710u4	FAITS	Défaut Conformité Produit	Le {{date_achat}}, {{client.nom}} a fait l'acquisition auprès de {{vendeur}} d'un {{produit}} pour un prix de {{prix}} euros.\n\nDès la première utilisation, {{client.nom}} a constaté que le produit ne présentait pas les caractéristiques annoncées, à savoir : {{non_conformites}}.\n\nLe produit livré ne correspond donc pas à la description qui en avait été faite et ne possède pas les qualités essentielles attendues.	{}	{conformite,produit,consommation,faits}	f	t	11	0	\N	\N
cml88g73j001i521vgm37bhcw	2026-02-04 16:19:21.199	2026-02-04 16:19:21.199	cml88g71z0000521vp3t710u4	FAITS	Diffamation Publique	Le {{date_publication}}, {{adversaire.nom}} a publié sur {{support_publication}} les propos suivants :\n\n"{{propos_litigieux}}"\n\nCes propos, qui imputent à {{client.nom}} des faits précis portant atteinte à son honneur et à sa considération, constituent une diffamation publique au sens de l'article 29 de la loi du 29 juillet 1881.	{}	{diffamation,presse,faits}	f	t	12	0	\N	\N
cml88g73k001k521v3b82sqhs	2026-02-04 16:19:21.2	2026-02-04 16:19:21.2	cml88g71z0000521vp3t710u4	FAITS	Concurrence Déloyale	{{client.nom}} exerce l'activité de {{activite}} depuis {{date_creation}}.\n\nOr, {{adversaire.nom}}, ancien {{relation_anterieure}}, a commis les actes de concurrence déloyale suivants :\n\n1. {{acte_deloyal_1}}\n2. {{acte_deloyal_2}}\n3. {{acte_deloyal_3}}\n\nCes agissements ont causé à {{client.nom}} un préjudice commercial considérable.	{}	{concurrence,deloyale,commercial,faits}	f	t	13	0	\N	\N
cml88g73n001m521v1d8iib8a	2026-02-04 16:19:21.203	2026-02-04 16:19:21.203	cml88g71z0000521vp3t710u4	FAITS	Divorce Contexte Familial	{{client.nom}} et {{conjoint.nom}} se sont mariés le {{date_mariage}} à la mairie de {{lieu_mariage}}, sous le régime de {{regime_matrimonial}}.\n\nDe cette union sont issus {{nombre_enfants}} enfant(s) :\n{{liste_enfants}}\n\nLa vie commune a cessé le {{date_separation}}, date à laquelle {{circonstances_separation}}.\n\nLe divorce est demandé pour {{motif_divorce}}.	{}	{divorce,famille,faits}	f	t	14	0	\N	\N
cml88g73o001o521vpfloyyiv	2026-02-04 16:19:21.205	2026-02-04 16:19:21.205	cml88g71z0000521vp3t710u4	FAITS	Succession Litigieuse	{{defunt.nom}} est décédé(e) le {{date_deces}} à {{lieu_deces}}, laissant pour lui/elle succéder :\n{{liste_heritiers}}\n\nLe patrimoine successoral comprend notamment :\n{{liste_biens}}\n\nUn désaccord est survenu entre les héritiers concernant {{objet_litige}}.	{}	{succession,heritage,faits}	f	t	15	0	\N	\N
cml88g73p001q521v9sde8oa5	2026-02-04 16:19:21.206	2026-02-04 16:19:21.206	cml88g71z0000521vp3t710u4	FAITS	Prêt Non Remboursé	Par acte sous seing privé en date du {{date_pret}}, {{client.nom}} a consenti à {{emprunteur}} un prêt d'un montant de {{montant_pret}} euros.\n\nCe prêt devait être remboursé selon les modalités suivantes : {{modalites_remboursement}}.\n\nOr, {{emprunteur}} n'a effectué que {{nombre_echeances}} échéances sur les {{total_echeances}} prévues.\n\nLe solde restant dû s'élève à {{solde_du}} euros, outre les intérêts.	{}	{pret,creance,faits}	f	t	16	0	\N	\N
cml88g73q001s521vsmd3yssd	2026-02-04 16:19:21.207	2026-02-04 16:19:21.207	cml88g71z0000521vp3t710u4	FAITS	Malfaçons Construction	{{client.nom}} a confié à {{constructeur}} la réalisation de {{travaux}} pour un montant de {{montant_travaux}} euros, selon devis accepté le {{date_devis}}.\n\nLa réception des travaux est intervenue le {{date_reception}}, avec les réserves suivantes : {{reserves}}.\n\nPostérieurement à la réception, les désordres suivants sont apparus : {{desordres}}.\n\nUne expertise judiciaire ordonnée le {{date_ordonnance_expertise}} a confirmé les malfaçons.	{}	{construction,malfacons,faits}	f	t	17	0	\N	\N
cml88g73r001u521v5bympfqg	2026-02-04 16:19:21.208	2026-02-04 16:19:21.208	cml88g71z0000521vp3t710u4	FAITS	Contrefaçon Marque	{{client.nom}} est titulaire de la marque "{{nom_marque}}" enregistrée à l'INPI sous le numéro {{numero_depot}} le {{date_depot}}, pour désigner les produits et services suivants : {{classes}}.\n\nOr, {{adversaire.nom}} commercialise des produits/services sous le signe "{{signe_litigieux}}", reproduisant de manière identique/similaire la marque de {{client.nom}}.\n\nCes actes de contrefaçon portent gravement atteinte aux droits de propriété intellectuelle de {{client.nom}}.	{}	{contrefacon,marque,propriete-intellectuelle,faits}	f	t	18	0	\N	\N
cml88g73s001w521vqeqj5k5d	2026-02-04 16:19:21.209	2026-02-04 16:19:21.209	cml88g71z0000521vp3t710u4	FAITS	Harcèlement Moral Travail	{{client.nom}} occupe le poste de {{poste}} au sein de {{employeur}} depuis le {{date_embauche}}.\n\nDepuis le {{date_debut_harcelement}}, {{client.nom}} est victime d'agissements répétés de harcèlement moral de la part de {{harceleur}}, se manifestant par :\n{{agissements}}\n\nCes agissements ont eu pour effet une dégradation des conditions de travail et de l'état de santé de {{client.nom}}, ainsi qu'en attestent {{preuves}}.	{}	{harcelement,travail,faits}	f	t	19	0	\N	\N
cml88g73t001y521vaxtg9lb6	2026-02-04 16:19:21.21	2026-02-04 16:19:21.21	cml88g71z0000521vp3t710u4	FAITS	Rupture Brutale Relations Commerciales	{{client.nom}} et {{adversaire.nom}} entretenaient des relations commerciales établies depuis {{duree_relation}}.\n\nLe chiffre d'affaires annuel moyen réalisé avec {{adversaire.nom}} s'élevait à {{ca_moyen}} euros, représentant {{pourcentage}}% du chiffre d'affaires total de {{client.nom}}.\n\nPar courrier du {{date_rupture}}, {{adversaire.nom}} a notifié la cessation des relations commerciales avec effet au {{date_effet}}, soit un préavis de {{duree_preavis}} seulement.\n\nCe préavis est manifestement insuffisant au regard de la durée de la relation commerciale.	{}	{rupture,commercial,L442-1,faits}	f	t	20	0	\N	\N
cml88g73v0020521va0x0yhy2	2026-02-04 16:19:21.211	2026-02-04 16:19:21.211	cml88g71z0000521vp3t710u4	FAITS	Accident Médical	Le {{date_intervention}}, {{client.nom}} a subi une intervention chirurgicale {{type_intervention}} pratiquée par le Docteur {{medecin}} au sein de {{etablissement}}.\n\nSuite à cette intervention, {{client.nom}} a présenté les complications suivantes : {{complications}}.\n\nL'expertise médicale diligentée par {{expert}} a mis en évidence {{conclusions_expertise}}.\n\nLe taux d'IPP a été évalué à {{taux_ipp}}%.	{}	{medical,responsabilite,faits}	f	t	21	0	\N	\N
cml88g73w0022521v5z26q0mc	2026-02-04 16:19:21.212	2026-02-04 16:19:21.212	cml88g71z0000521vp3t710u4	FAITS	Non-paiement Factures	Dans le cadre de relations commerciales habituelles, {{client.nom}} a établi les factures suivantes à l'attention de {{adversaire.nom}} :\n\n{{liste_factures}}\n\nMalgré plusieurs relances amiables, dont la dernière en date du {{date_derniere_relance}}, ces factures demeurent impayées.\n\nLe montant total de la créance s'élève à {{montant_total}} euros TTC, outre les pénalités de retard.	{}	{factures,impaye,commercial,faits}	f	t	22	0	\N	\N
cml88g73x0024521v2k2abwby	2026-02-04 16:19:21.214	2026-02-04 16:19:21.214	cml88g71z0000521vp3t710u4	FAITS	Expulsion Locataire	Par bail d'habitation en date du {{date_bail}}, {{bailleur}} a donné à bail à {{locataire}} un logement situé {{adresse_logement}}.\n\n{{locataire}} ne s'est pas acquitté de ses obligations locatives depuis le {{date_premier_impaye}}.\n\nUn commandement de payer visant la clause résolutoire a été délivré le {{date_commandement}}.\n\nDeux mois s'étant écoulés sans régularisation, le bail est résilié de plein droit.	{}	{expulsion,bail,habitation,faits}	f	t	23	0	\N	\N
cml88g73y0026521v9zj1ktmx	2026-02-04 16:19:21.215	2026-02-04 16:19:21.215	cml88g71z0000521vp3t710u4	FAITS	Garantie Décennale	{{client.nom}} a fait construire {{ouvrage}} par {{constructeur}}, la réception étant intervenue le {{date_reception}}.\n\nDans le délai de la garantie décennale, des désordres sont apparus, rendant l'ouvrage impropre à sa destination :\n{{description_desordres}}\n\nCes désordres compromettent la solidité de l'ouvrage et/ou le rendent impropre à sa destination, engageant la responsabilité décennale du constructeur.	{}	{decennale,construction,faits}	f	t	24	0	\N	\N
cml88g7400028521vqjlu9adz	2026-02-04 16:19:21.216	2026-02-04 16:19:21.216	cml88g71z0000521vp3t710u4	FAITS	Abus de Confiance	{{client.nom}} a remis à {{adversaire.nom}} la somme de {{montant}} euros / les biens suivants : {{biens}}, à charge pour ce dernier de {{mission}}.\n\nOr, {{adversaire.nom}} a détourné ces fonds/biens en les utilisant à des fins personnelles, à savoir : {{utilisation_frauduleuse}}.\n\nMalgré mise en demeure, {{adversaire.nom}} refuse de restituer les sommes/biens détournés.	{}	{abus-confiance,penal,faits}	f	t	25	0	\N	\N
cml88g742002a521vzg1sjbol	2026-02-04 16:19:21.218	2026-02-04 16:19:21.218	cml88g71z0000521vp3t710u4	MOYENS	Article 1103 Code Civil - Force Obligatoire	SUR LE FONDEMENT DE L'ARTICLE 1103 DU CODE CIVIL\n\nAux termes de l'article 1103 du Code civil, "les contrats légalement formés tiennent lieu de loi à ceux qui les ont faits".\n\nEn l'espèce, le contrat liant les parties, conclu le {{date_contrat}}, est parfaitement valide et produit tous ses effets.\n\n{{adversaire.nom}} ne peut donc se soustraire unilatéralement à ses obligations contractuelles, sous peine de voir sa responsabilité contractuelle engagée.	{}	{article-1103,pacta-sunt-servanda,moyens}	f	t	1	0	\N	\N
cml88g743002c521vosmq5vyc	2026-02-04 16:19:21.22	2026-02-04 16:19:21.22	cml88g71z0000521vp3t710u4	MOYENS	Article 1217 Code Civil - Inexécution	SUR L'INEXÉCUTION CONTRACTUELLE\n\nL'article 1217 du Code civil dispose que "la partie envers laquelle l'engagement n'a pas été exécuté, ou l'a été imparfaitement, peut :\n- refuser d'exécuter ou suspendre l'exécution de sa propre obligation ;\n- poursuivre l'exécution forcée en nature de l'obligation ;\n- obtenir une réduction du prix ;\n- provoquer la résolution du contrat ;\n- demander réparation des conséquences de l'inexécution".\n\nEn l'espèce, l'inexécution par {{adversaire.nom}} de ses obligations contractuelles justifie que {{client.nom}} sollicite {{option_choisie}}.	{}	{article-1217,inexecution,moyens}	f	t	2	0	\N	\N
cml88g744002e521v7p8k1pgt	2026-02-04 16:19:21.221	2026-02-04 16:19:21.221	cml88g71z0000521vp3t710u4	MOYENS	Article 1231-1 Code Civil - Dommages-Intérêts	SUR LES DOMMAGES-INTÉRÊTS\n\nAux termes de l'article 1231-1 du Code civil, "le débiteur est condamné, s'il y a lieu, au paiement de dommages et intérêts soit à raison de l'inexécution de l'obligation, soit à raison du retard dans l'exécution, s'il ne justifie pas que l'exécution a été empêchée par la force majeure".\n\nEn l'espèce, {{client.nom}} a subi un préjudice direct et certain du fait de l'inexécution par {{adversaire.nom}}, préjudice qu'il convient d'évaluer à {{montant_prejudice}} euros.	{}	{article-1231-1,dommages-interets,moyens}	f	t	3	0	\N	\N
cml88g745002g521vybf7v9b1	2026-02-04 16:19:21.222	2026-02-04 16:19:21.222	cml88g71z0000521vp3t710u4	MOYENS	Article 1240 Code Civil - Responsabilité Délictuelle	SUR LA RESPONSABILITÉ DÉLICTUELLE\n\nL'article 1240 du Code civil dispose que "tout fait quelconque de l'homme, qui cause à autrui un dommage, oblige celui par la faute duquel il est arrivé à le réparer".\n\nEn l'espèce, la responsabilité de {{adversaire.nom}} est engagée dès lors que sont réunies les trois conditions :\n\n1. Une faute : {{description_faute}}\n2. Un dommage : {{description_dommage}}\n3. Un lien de causalité : {{lien_causalite}}	{}	{article-1240,responsabilite,delictuelle,moyens}	f	t	4	0	\N	\N
cml88g746002i521vhodfo31h	2026-02-04 16:19:21.223	2026-02-04 16:19:21.223	cml88g71z0000521vp3t710u4	MOYENS	Article 1245 Code Civil - Produits Défectueux	SUR LA RESPONSABILITÉ DU FAIT DES PRODUITS DÉFECTUEUX\n\nAux termes de l'article 1245 du Code civil, "le producteur est responsable du dommage causé par un défaut de son produit, qu'il soit ou non lié par un contrat avec la victime".\n\nEn l'espèce, le produit {{description_produit}} fabriqué par {{producteur}} présente un défaut de {{nature_defaut}} qui a causé {{dommage}}.\n\nLa responsabilité de {{producteur}} est donc engagée, sans qu'il soit besoin de prouver une faute de sa part.	{}	{article-1245,produits-defectueux,moyens}	f	t	5	0	\N	\N
cml88g748002k521vacuh2a39	2026-02-04 16:19:21.224	2026-02-04 16:19:21.224	cml88g71z0000521vp3t710u4	MOYENS	Article 1641 Code Civil - Garantie Vices Cachés	SUR LA GARANTIE DES VICES CACHÉS\n\nAux termes de l'article 1641 du Code civil, "le vendeur est tenu de la garantie à raison des défauts cachés de la chose vendue qui la rendent impropre à l'usage auquel on la destine, ou qui diminuent tellement cet usage que l'acheteur ne l'aurait pas acquise, ou n'en aurait donné qu'un moindre prix, s'il les avait connus".\n\nLe vice invoqué remplit les conditions légales :\n- Il est caché : {{demonstration_caractere_cache}}\n- Il est antérieur à la vente : {{demonstration_anteriorite}}\n- Il est grave : {{demonstration_gravite}}	{}	{article-1641,vice-cache,moyens}	f	t	6	0	\N	\N
cml88g749002m521vhxya4cte	2026-02-04 16:19:21.225	2026-02-04 16:19:21.225	cml88g71z0000521vp3t710u4	MOYENS	Article 1792 Code Civil - Responsabilité Décennale	SUR LA RESPONSABILITÉ DÉCENNALE\n\nL'article 1792 du Code civil dispose que "tout constructeur d'un ouvrage est responsable de plein droit, envers le maître ou l'acquéreur de l'ouvrage, des dommages, même résultant d'un vice du sol, qui compromettent la solidité de l'ouvrage ou qui, l'affectant dans l'un de ses éléments constitutifs ou l'un de ses éléments d'équipement, le rendent impropre à sa destination".\n\nLes désordres constatés compromettent la solidité de l'ouvrage / rendent l'ouvrage impropre à sa destination, engageant ainsi la responsabilité décennale de {{constructeur}}.	{}	{article-1792,decennale,construction,moyens}	f	t	7	0	\N	\N
cml88g74a002o521vw2vqw2x8	2026-02-04 16:19:21.227	2026-02-04 16:19:21.227	cml88g71z0000521vp3t710u4	MOYENS	Article L.442-1 Code Commerce - Rupture Brutale	SUR LA RUPTURE BRUTALE DES RELATIONS COMMERCIALES\n\nL'article L.442-1 II du Code de commerce sanctionne "le fait, par toute personne exerçant des activités de production, de distribution ou de services de rompre brutalement, même partiellement, une relation commerciale établie, en l'absence d'un préavis écrit qui tienne compte notamment de la durée de la relation commerciale".\n\nEn l'espèce, la relation commerciale était établie depuis {{duree_relation}}, justifiant un préavis d'au moins {{duree_preavis_necessaire}}.\n\nLe préavis accordé de {{duree_preavis_accorde}} est manifestement insuffisant.	{}	{L442-1,rupture-brutale,commercial,moyens}	f	t	8	0	\N	\N
cml88g74b002q521va73e2tzo	2026-02-04 16:19:21.228	2026-02-04 16:19:21.228	cml88g71z0000521vp3t710u4	MOYENS	Article L.1232-1 Code Travail - Licenciement	SUR L'ABSENCE DE CAUSE RÉELLE ET SÉRIEUSE\n\nAux termes de l'article L.1232-1 du Code du travail, "tout licenciement pour motif personnel est motivé" et doit reposer sur "une cause réelle et sérieuse".\n\nEn l'espèce, le motif invoqué par l'employeur ne constitue pas une cause réelle et sérieuse de licenciement car {{argumentation}}.\n\nLe licenciement de {{client.nom}} est donc dépourvu de cause réelle et sérieuse.	{}	{L1232-1,licenciement,travail,moyens}	f	t	9	0	\N	\N
cml88g74e002s521v7a2unise	2026-02-04 16:19:21.23	2026-02-04 16:19:21.23	cml88g71z0000521vp3t710u4	MOYENS	Article 835 CPC - Référé Provision	SUR LA PROVISION\n\nL'article 835 alinéa 2 du Code de procédure civile dispose que "le président du tribunal judiciaire peut accorder une provision au créancier dans le cas où l'obligation n'est pas sérieusement contestable".\n\nEn l'espèce, l'obligation de {{adversaire.nom}} n'est pas sérieusement contestable dès lors que :\n{{argumentation}}\n\nIl y a donc lieu d'accorder à {{client.nom}} une provision de {{montant}} euros.	{}	{article-835,refere,provision,moyens}	f	t	10	0	\N	\N
cml88g74f002u521vpioir7p9	2026-02-04 16:19:21.232	2026-02-04 16:19:21.232	cml88g71z0000521vp3t710u4	MOYENS	Article 834 CPC - Référé Trouble Illicite	SUR LE TROUBLE MANIFESTEMENT ILLICITE\n\nL'article 834 du Code de procédure civile dispose que "le président du tribunal judiciaire peut toujours, même en présence d'une contestation sérieuse, prescrire en référé les mesures conservatoires ou de remise en état qui s'imposent, soit pour prévenir un dommage imminent, soit pour faire cesser un trouble manifestement illicite".\n\nEn l'espèce, {{adversaire.nom}} commet un trouble manifestement illicite en {{description_trouble}}.\n\nIl y a lieu d'ordonner {{mesure_sollicitee}}.	{}	{article-834,refere,trouble-illicite,moyens}	f	t	11	0	\N	\N
cml88g74h002w521vdyx94cqg	2026-02-04 16:19:21.233	2026-02-04 16:19:21.233	cml88g71z0000521vp3t710u4	MOYENS	Article 1195 Code Civil - Imprévision	SUR L'IMPRÉVISION\n\nAux termes de l'article 1195 du Code civil, "si un changement de circonstances imprévisible lors de la conclusion du contrat rend l'exécution excessivement onéreuse pour une partie qui n'avait pas accepté d'en assumer le risque, celle-ci peut demander une renégociation du contrat à son cocontractant".\n\nEn l'espèce, {{evenement_imprevisible}} constitue un changement de circonstances imprévisible rendant l'exécution du contrat excessivement onéreuse pour {{client.nom}}.	{}	{article-1195,imprevision,moyens}	f	t	12	0	\N	\N
cml88g74i002y521vv4nx38ek	2026-02-04 16:19:21.234	2026-02-04 16:19:21.234	cml88g71z0000521vp3t710u4	MOYENS	Article 1178 Code Civil - Nullité Contrat	SUR LA NULLITÉ DU CONTRAT\n\nL'article 1178 du Code civil dispose qu'"un contrat qui ne remplit pas les conditions requises pour sa validité est nul".\n\nEn l'espèce, le contrat est nul pour {{cause_nullite}} :\n{{argumentation}}\n\nLa nullité doit être prononcée avec toutes conséquences de droit.	{}	{article-1178,nullite,moyens}	f	t	13	0	\N	\N
cml88g74j0030521vk54lrhrw	2026-02-04 16:19:21.236	2026-02-04 16:19:21.236	cml88g71z0000521vp3t710u4	MOYENS	Article 1143 Code Civil - Violence Économique	SUR LA VIOLENCE ÉCONOMIQUE\n\nL'article 1143 du Code civil dispose qu'"il y a également violence lorsqu'une partie, abusant de l'état de dépendance dans lequel se trouve son cocontractant à son égard, obtient de lui un engagement qu'il n'aurait pas souscrit en l'absence d'une telle contrainte et en tire un avantage manifestement excessif".\n\nEn l'espèce, {{adversaire.nom}} a abusé de l'état de dépendance de {{client.nom}} pour obtenir {{avantage_excessif}}.	{}	{article-1143,violence-economique,moyens}	f	t	14	0	\N	\N
cml88g74k0032521v4qldymfa	2026-02-04 16:19:21.237	2026-02-04 16:19:21.237	cml88g71z0000521vp3t710u4	MOYENS	Article 1137 Code Civil - Dol	SUR LE DOL\n\nAux termes de l'article 1137 du Code civil, "le dol est le fait pour un contractant d'obtenir le consentement de l'autre par des manœuvres ou des mensonges" ou par "la dissimulation intentionnelle par l'un des contractants d'une information dont il sait le caractère déterminant pour l'autre partie".\n\nEn l'espèce, {{adversaire.nom}} a volontairement dissimulé/menti sur {{element_dolosif}}, information déterminante du consentement de {{client.nom}}.	{}	{article-1137,dol,moyens}	f	t	15	0	\N	\N
cml88g74m0034521v22yipkfj	2026-02-04 16:19:21.238	2026-02-04 16:19:21.238	cml88g71z0000521vp3t710u4	MOYENS	Article 1104 Code Civil - Bonne Foi	SUR L'OBLIGATION DE BONNE FOI\n\nL'article 1104 du Code civil dispose que "les contrats doivent être négociés, formés et exécutés de bonne foi. Cette disposition est d'ordre public".\n\nEn l'espèce, {{adversaire.nom}} a manqué à son obligation de bonne foi en {{comportement_deloyal}}.\n\nCe comportement engage sa responsabilité contractuelle.	{}	{article-1104,bonne-foi,moyens}	f	t	16	0	\N	\N
cml88g74n0036521vxi4yiay9	2026-02-04 16:19:21.239	2026-02-04 16:19:21.239	cml88g71z0000521vp3t710u4	MOYENS	Article 1112-1 Code Civil - Devoir Information	SUR LE DEVOIR D'INFORMATION PRÉCONTRACTUEL\n\nL'article 1112-1 du Code civil dispose que "celle des parties qui connaît une information dont l'importance est déterminante pour le consentement de l'autre doit l'en informer dès lors que, légitimement, cette dernière ignore cette information ou fait confiance à son cocontractant".\n\n{{adversaire.nom}} connaissait {{information_dissimilee}}, information déterminante, et n'en a pas informé {{client.nom}}.	{}	{article-1112-1,information,precontractuel,moyens}	f	t	17	0	\N	\N
cml88g74o0038521valcanlgp	2026-02-04 16:19:21.24	2026-02-04 16:19:21.24	cml88g71z0000521vp3t710u4	MOYENS	Article L.217-4 Code Consommation - Conformité	SUR LE DÉFAUT DE CONFORMITÉ\n\nL'article L.217-4 du Code de la consommation impose au vendeur de "livrer un bien conforme au contrat et répond des défauts de conformité existant lors de la délivrance".\n\nLe produit livré n'est pas conforme car {{description_non_conformite}}.\n\n{{client.nom}} est en droit de demander {{option_consommateur}}.	{}	{L217-4,conformite,consommation,moyens}	f	t	18	0	\N	\N
cml88g74r003a521vug41zhdp	2026-02-04 16:19:21.243	2026-02-04 16:19:21.243	cml88g71z0000521vp3t710u4	MOYENS	Article L.121-16 Code Consommation - Rétractation	SUR LE DROIT DE RÉTRACTATION\n\nL'article L.221-18 du Code de la consommation dispose que "le consommateur dispose d'un délai de quatorze jours pour exercer son droit de rétractation d'un contrat conclu à distance".\n\nEn l'espèce, {{client.nom}} a exercé son droit de rétractation dans le délai légal par {{moyen_retractation}} en date du {{date_retractation}}.\n\n{{adversaire.nom}} est tenu de rembourser l'intégralité des sommes versées.	{}	{L221-18,retractation,consommation,moyens}	f	t	19	0	\N	\N
cml88g74s003c521vm7wva7mx	2026-02-04 16:19:21.245	2026-02-04 16:19:21.245	cml88g71z0000521vp3t710u4	MOYENS	Article 544 Code Civil - Droit Propriété	SUR L'ATTEINTE AU DROIT DE PROPRIÉTÉ\n\nL'article 544 du Code civil dispose que "la propriété est le droit de jouir et disposer des choses de la manière la plus absolue, pourvu qu'on n'en fasse pas un usage prohibé par les lois ou par les règlements".\n\nLes agissements de {{adversaire.nom}} constituent une atteinte au droit de propriété de {{client.nom}} en ce que {{atteinte}}.\n\nIl y a lieu d'ordonner la cessation de ces atteintes sous astreinte.	{}	{article-544,propriete,moyens}	f	t	20	0	\N	\N
cml88g74t003e521vnn5tr2m6	2026-02-04 16:19:21.246	2026-02-04 16:19:21.246	cml88g71z0000521vp3t710u4	MOYENS	Trouble Anormal de Voisinage	SUR LE TROUBLE ANORMAL DE VOISINAGE\n\nLe principe selon lequel "nul ne doit causer à autrui un trouble anormal de voisinage" est un principe général du droit consacré par la jurisprudence.\n\nLa responsabilité fondée sur les troubles de voisinage est une responsabilité objective, indépendante de toute faute.\n\nEn l'espèce, les nuisances causées par {{adversaire.nom}} excèdent les inconvénients normaux du voisinage en raison de {{caractere_anormal}}.	{}	{voisinage,trouble-anormal,moyens}	f	t	21	0	\N	\N
cml88g74u003g521vqo08divo	2026-02-04 16:19:21.247	2026-02-04 16:19:21.247	cml88g71z0000521vp3t710u4	MOYENS	Article L.713-2 CPI - Contrefaçon Marque	SUR LA CONTREFAÇON DE MARQUE\n\nL'article L.713-2 du Code de la propriété intellectuelle dispose que "sont interdits, sauf autorisation du titulaire de la marque, la reproduction, l'usage ou l'apposition d'une marque [...] pour des produits ou services identiques à ceux désignés dans l'enregistrement".\n\nEn l'espèce, {{adversaire.nom}} reproduit/imite la marque {{marque}} de {{client.nom}} sans autorisation, ce qui constitue un acte de contrefaçon.	{}	{L713-2,contrefacon,marque,moyens}	f	t	22	0	\N	\N
cml88g74v003i521vmmpmjuzi	2026-02-04 16:19:21.248	2026-02-04 16:19:21.248	cml88g71z0000521vp3t710u4	MOYENS	Article L.122-4 CPI - Contrefaçon Droit Auteur	SUR LA CONTREFAÇON DE DROIT D'AUTEUR\n\nL'article L.122-4 du Code de la propriété intellectuelle dispose que "toute représentation ou reproduction intégrale ou partielle faite sans le consentement de l'auteur ou de ses ayants droit ou ayants cause est illicite".\n\nEn l'espèce, {{adversaire.nom}} a reproduit/représenté l'œuvre {{oeuvre}} de {{client.nom}} sans autorisation, ce qui constitue une contrefaçon.	{}	{L122-4,contrefacon,droit-auteur,moyens}	f	t	23	0	\N	\N
cml88g74w003k521vqnwxh6jx	2026-02-04 16:19:21.249	2026-02-04 16:19:21.249	cml88g71z0000521vp3t710u4	MOYENS	Article 1242 alinéa 1 Code Civil - Responsabilité Fait Choses	SUR LA RESPONSABILITÉ DU FAIT DES CHOSES\n\nL'article 1242 alinéa 1 du Code civil dispose qu'"on est responsable non seulement du dommage que l'on cause par son propre fait, mais encore de celui qui est causé par le fait [...] des choses que l'on a sous sa garde".\n\n{{adversaire.nom}} était gardien de {{chose}} au moment des faits.\n\nCette chose a été l'instrument du dommage, ce qui engage la responsabilité de plein droit de son gardien.	{}	{article-1242,fait-des-choses,garde,moyens}	f	t	24	0	\N	\N
cml88g74y003m521vrda4vsql	2026-02-04 16:19:21.25	2026-02-04 16:19:21.25	cml88g71z0000521vp3t710u4	MOYENS	Article 1242 alinéa 4 Code Civil - Responsabilité Employeur	SUR LA RESPONSABILITÉ DE L'EMPLOYEUR DU FAIT DE SES PRÉPOSÉS\n\nL'article 1242 alinéa 5 du Code civil dispose que "les maîtres et les commettants sont responsables du dommage causé par leurs domestiques et préposés dans les fonctions auxquelles ils les ont employés".\n\nLe dommage a été causé par {{prepose}}, salarié de {{commettant}}, dans l'exercice de ses fonctions.\n\n{{commettant}} est donc responsable de ce dommage.	{}	{article-1242,prepose,employeur,moyens}	f	t	25	0	\N	\N
cml88g74z003o521vkcuy8rjx	2026-02-04 16:19:21.251	2026-02-04 16:19:21.251	cml88g71z0000521vp3t710u4	MOYENS	Article 145 CPC - Mesures Instruction In Futurum	SUR LA MESURE D'INSTRUCTION IN FUTURUM\n\nL'article 145 du Code de procédure civile dispose que "s'il existe un motif légitime de conserver ou d'établir avant tout procès la preuve de faits dont pourrait dépendre la solution d'un litige, les mesures d'instruction légalement admissibles peuvent être ordonnées à la demande de tout intéressé".\n\nEn l'espèce, {{client.nom}} justifie d'un motif légitime tenant à {{motif}}.\n\nLa mesure sollicitée est nécessaire pour préserver la preuve de {{elements}}.	{}	{article-145,instruction,in-futurum,moyens}	f	t	26	0	\N	\N
cml88g750003q521v7mqyu8ii	2026-02-04 16:19:21.252	2026-02-04 16:19:21.252	cml88g71z0000521vp3t710u4	MOYENS	Article 700 CPC - Frais Irrépétibles	SUR LES FRAIS IRRÉPÉTIBLES\n\nL'article 700 du Code de procédure civile dispose que "le juge condamne la partie tenue aux dépens ou qui perd son procès à payer à l'autre partie la somme qu'il détermine, au titre des frais exposés et non compris dans les dépens".\n\nEn l'espèce, il serait inéquitable de laisser à la charge de {{client.nom}} les frais qu'il/elle a dû exposer pour assurer la défense de ses intérêts.\n\nIl est demandé la somme de {{montant}} euros à ce titre.	{}	{article-700,frais,moyens}	f	t	27	0	\N	\N
cml88g751003s521v6xxyv3sd	2026-02-04 16:19:21.253	2026-02-04 16:19:21.253	cml88g71z0000521vp3t710u4	MOYENS	Article 514 CPC - Exécution Provisoire	SUR L'EXÉCUTION PROVISOIRE\n\nL'article 514 du Code de procédure civile dispose que "les décisions de première instance sont de droit exécutoires à titre provisoire".\n\nL'exécution provisoire de droit est pleinement justifiée en l'espèce au regard de {{motifs}}.\n\nIl n'y a pas lieu d'en écarter l'application.	{}	{article-514,execution-provisoire,moyens}	f	t	28	0	\N	\N
cml88g752003u521vjtqs2ofo	2026-02-04 16:19:21.255	2026-02-04 16:19:21.255	cml88g71z0000521vp3t710u4	MOYENS	Astreinte	SUR L'ASTREINTE\n\nIl est demandé au Tribunal d'assortir la condamnation d'une astreinte de {{montant_astreinte}} euros par jour de retard à compter de la signification de la décision à intervenir.\n\nEn effet, il y a lieu de craindre que {{adversaire.nom}} n'exécute pas spontanément la décision, compte tenu de {{motifs_crainte}}.\n\nL'astreinte sollicitée est proportionnée à l'enjeu du litige.	{}	{astreinte,execution,moyens}	f	t	29	0	\N	\N
cml88g754003w521vxofp30s6	2026-02-04 16:19:21.256	2026-02-04 16:19:21.256	cml88g71z0000521vp3t710u4	MOYENS	Article L.1152-1 Code Travail - Harcèlement Moral	SUR LE HARCÈLEMENT MORAL\n\nL'article L.1152-1 du Code du travail dispose qu'"aucun salarié ne doit subir les agissements répétés de harcèlement moral qui ont pour objet ou pour effet une dégradation de ses conditions de travail susceptible de porter atteinte à ses droits et à sa dignité, d'altérer sa santé physique ou mentale ou de compromettre son avenir professionnel".\n\n{{client.nom}} produit des éléments laissant supposer l'existence d'un harcèlement : {{elements_presumes}}.\n\nIl appartient à l'employeur de prouver que ces agissements ne sont pas constitutifs d'un tel harcèlement.	{}	{L1152-1,harcelement,travail,moyens}	f	t	30	0	\N	\N
cml88g755003y521vm2oe88z5	2026-02-04 16:19:21.258	2026-02-04 16:19:21.258	cml88g71z0000521vp3t710u4	MOYENS	Article 1224 Code Civil - Résolution	SUR LA RÉSOLUTION DU CONTRAT\n\nL'article 1224 du Code civil dispose que "la résolution résulte soit de l'application d'une clause résolutoire soit, en cas d'inexécution suffisamment grave, d'une notification du créancier au débiteur ou d'une décision de justice".\n\nL'inexécution de {{adversaire.nom}} est suffisamment grave pour justifier la résolution judiciaire du contrat.\n\nEn effet, {{gravite_inexecution}}.	{}	{article-1224,resolution,moyens}	f	t	31	0	\N	\N
cml88g7570040521vrlzlzzif	2026-02-04 16:19:21.259	2026-02-04 16:19:21.259	cml88g71z0000521vp3t710u4	MOYENS	Article 1347 Code Civil - Compensation	SUR LA COMPENSATION\n\nL'article 1347 du Code civil dispose que "la compensation est l'extinction simultanée d'obligations réciproques entre deux personnes".\n\nEn l'espèce, {{client.nom}} détient sur {{adversaire.nom}} une créance de {{montant_creance}} euros.\n\nPar ailleurs, {{adversaire.nom}} prétend détenir sur {{client.nom}} une créance de {{montant_dette}} euros.\n\nLa compensation légale s'opère de plein droit.	{}	{article-1347,compensation,moyens}	f	t	32	0	\N	\N
cml88g75a0042521vqernntuk	2026-02-04 16:19:21.262	2026-02-04 16:19:21.262	cml88g71z0000521vp3t710u4	MOYENS	Prescription Acquisitive Immobilière	SUR LA PRESCRIPTION ACQUISITIVE\n\nAux termes de l'article 2258 du Code civil, "la prescription acquisitive est un moyen d'acquérir un bien ou un droit par l'effet de la possession sans que celui qui l'allègue soit obligé d'en rapporter un titre".\n\n{{client.nom}} possède le bien litigieux de manière continue, paisible, publique, non équivoque et à titre de propriétaire depuis plus de {{duree}} ans.\n\nLes conditions de la prescription acquisitive sont donc réunies.	{}	{prescription,acquisitive,immobilier,moyens}	f	t	33	0	\N	\N
cml88g75c0044521vvmqcyp0a	2026-02-04 16:19:21.265	2026-02-04 16:19:21.265	cml88g71z0000521vp3t710u4	MOYENS	Article 2224 Code Civil - Prescription Extinctive	SUR LA PRESCRIPTION\n\nL'article 2224 du Code civil dispose que "les actions personnelles ou mobilières se prescrivent par cinq ans à compter du jour où le titulaire d'un droit a connu ou aurait dû connaître les faits lui permettant de l'exercer".\n\nEn l'espèce, l'action de {{adversaire.nom}} est prescrite dès lors que {{argumentation_prescription}}.\n\nL'action doit donc être déclarée irrecevable comme prescrite.	{}	{article-2224,prescription,extinctive,moyens}	f	t	34	0	\N	\N
cml88g75d0046521vgatx1i7d	2026-02-04 16:19:21.266	2026-02-04 16:19:21.266	cml88g71z0000521vp3t710u4	MOYENS	Force Majeure	SUR LA FORCE MAJEURE\n\nL'article 1218 du Code civil dispose qu'"il y a force majeure en matière contractuelle lorsqu'un événement échappant au contrôle du débiteur, qui ne pouvait être raisonnablement prévu lors de la conclusion du contrat et dont les effets ne peuvent être évités par des mesures appropriées, empêche l'exécution de son obligation par le débiteur".\n\nEn l'espèce, {{evenement}} constitue un cas de force majeure car :\n- Il était imprévisible : {{demonstration_imprevisibilite}}\n- Il était irrésistible : {{demonstration_irresistibilite}}\n- Il était extérieur : {{demonstration_exteriorite}}	{}	{force-majeure,exoneration,moyens}	f	t	35	0	\N	\N
cml88g75f0048521vwtm4gpmt	2026-02-04 16:19:21.267	2026-02-04 16:19:21.267	cml88g71z0000521vp3t710u4	MOYENS	Exception Inexécution	SUR L'EXCEPTION D'INEXÉCUTION\n\nL'article 1219 du Code civil dispose qu'"une partie peut refuser d'exécuter son obligation, alors même que celle-ci est exigible, si l'autre n'exécute pas la sienne et si cette inexécution est suffisamment grave".\n\nEn l'espèce, {{adversaire.nom}} n'a pas exécuté son obligation de {{obligation_adverse}}.\n\nCette inexécution est suffisamment grave pour justifier que {{client.nom}} suspende l'exécution de sa propre obligation.	{}	{exception-inexecution,moyens}	f	t	36	0	\N	\N
cml88g75h004a521vw2uona5k	2026-02-04 16:19:21.269	2026-02-04 16:19:21.269	cml88g71z0000521vp3t710u4	MOYENS	Défaut Qualité Agir	SUR LE DÉFAUT DE QUALITÉ À AGIR\n\nL'article 31 du Code de procédure civile dispose que "l'action est ouverte à tous ceux qui ont un intérêt légitime au succès ou au rejet d'une prétention, sous réserve des cas dans lesquels la loi attribue le droit d'agir aux seules personnes qu'elle qualifie pour élever ou combattre une prétention".\n\nEn l'espèce, {{adversaire.nom}} n'a pas qualité à agir car {{argumentation}}.\n\nL'action doit être déclarée irrecevable.	{}	{qualite,recevabilite,moyens}	f	t	37	0	\N	\N
cml88g75j004c521vng92fane	2026-02-04 16:19:21.271	2026-02-04 16:19:21.271	cml88g71z0000521vp3t710u4	MOYENS	Défaut Intérêt Agir	SUR LE DÉFAUT D'INTÉRÊT À AGIR\n\nL'article 31 du Code de procédure civile subordonne la recevabilité de l'action à l'existence d'un "intérêt légitime au succès ou au rejet d'une prétention".\n\nL'intérêt à agir doit être né, actuel, direct et personnel.\n\nEn l'espèce, {{adversaire.nom}} ne justifie d'aucun intérêt à agir car {{argumentation}}.	{}	{interet,recevabilite,moyens}	f	t	38	0	\N	\N
cml88g75k004e521veylava8y	2026-02-04 16:19:21.272	2026-02-04 16:19:21.272	cml88g71z0000521vp3t710u4	MOYENS	Chose Jugée	SUR L'AUTORITÉ DE LA CHOSE JUGÉE\n\nL'article 1355 du Code civil dispose que "l'autorité de la chose jugée n'a lieu qu'à l'égard de ce qui a fait l'objet du jugement".\n\nIl faut identité de parties, de cause et d'objet.\n\nEn l'espèce, le litige a déjà été tranché par {{decision_anterieure}} rendue le {{date_decision}}.\n\nLes demandes de {{adversaire.nom}} se heurtent donc à l'autorité de la chose jugée.	{}	{chose-jugee,recevabilite,moyens}	f	t	39	0	\N	\N
cml88g75m004g521vzxvig8n4	2026-02-04 16:19:21.274	2026-02-04 16:19:21.274	cml88g71z0000521vp3t710u4	MOYENS	Incompétence Territoriale	SUR L'INCOMPÉTENCE TERRITORIALE\n\nL'article 42 du Code de procédure civile dispose que "la juridiction territorialement compétente est, sauf disposition contraire, celle du lieu où demeure le défendeur".\n\nEn l'espèce, {{adversaire.nom}} a saisi le Tribunal Judiciaire de {{juridiction_saisie}} alors que le Tribunal compétent est celui de {{juridiction_competente}}.\n\nLe Tribunal devra se déclarer incompétent.	{}	{competence,territoriale,moyens}	f	t	40	0	\N	\N
cml88g75o004i521vnxhpva0r	2026-02-04 16:19:21.276	2026-02-04 16:19:21.276	cml88g71z0000521vp3t710u4	DISPOSITIF	Condamnation Paiement Somme	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_principal}} € au titre de {{nature_creance}},\n\nASSORTIE des intérêts au taux légal à compter du {{date_interets}},\n\nCONDAMNER {{adversaire.nom}} aux dépens de l'instance,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_451}} € au titre de l'article 700 du Code de procédure civile.	{}	{condamnation,paiement,dispositif}	f	t	1	0	\N	\N
cml88g75p004k521v49dd03ec	2026-02-04 16:19:21.278	2026-02-04 16:19:21.278	cml88g71z0000521vp3t710u4	DISPOSITIF	Résolution Contrat + Dommages-Intérêts	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nPRONONCER la résolution du contrat conclu le {{date_contrat}} entre les parties aux torts exclusifs de {{adversaire.nom}},\n\nCONDAMNER {{adversaire.nom}} à restituer à {{client.nom}} toutes les sommes perçues, soit {{montant_restitution}} €,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{resolution,dommages,dispositif}	f	t	2	0	\N	\N
cml88g75r004m521v6u4xygzy	2026-02-04 16:19:21.279	2026-02-04 16:19:21.279	cml88g71z0000521vp3t710u4	DISPOSITIF	Nullité Contrat	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nPRONONCER la nullité du contrat conclu le {{date_contrat}} entre {{client.nom}} et {{adversaire.nom}},\n\nORDONNER les restitutions réciproques,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nCONDAMNER {{adversaire.nom}} aux dépens et aux frais irrépétibles.	{}	{nullite,dispositif}	f	t	3	0	\N	\N
cml88g75s004o521vv8w12rz1	2026-02-04 16:19:21.281	2026-02-04 16:19:21.281	cml88g71z0000521vp3t710u4	DISPOSITIF	Exécution Forcée Obligation	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONDAMNER {{adversaire.nom}} à exécuter son obligation de {{obligation}} sous astreinte de {{montant_astreinte}} € par jour de retard à compter de la signification de la décision,\n\nSe réserver la liquidation de l'astreinte,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{execution-forcee,astreinte,dispositif}	f	t	4	0	\N	\N
cml88g75u004q521vl5xdobqa	2026-02-04 16:19:21.282	2026-02-04 16:19:21.282	cml88g71z0000521vp3t710u4	DISPOSITIF	Référé Provision	PAR CES MOTIFS\n\nLe Président est prié de :\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} une provision de {{montant_provision}} € à valoir sur l'indemnisation de son préjudice,\n\nDIRE n'y avoir lieu à référé pour le surplus,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC,\n\nDIRE la présente ordonnance exécutoire de droit à titre provisoire.	{}	{refere,provision,dispositif}	f	t	5	0	\N	\N
cml88g75w004s521vloj2amve	2026-02-04 16:19:21.284	2026-02-04 16:19:21.284	cml88g71z0000521vp3t710u4	DISPOSITIF	Référé Injonction	PAR CES MOTIFS\n\nLe Président est prié de :\n\nORDONNER à {{adversaire.nom}} de {{injonction}} sous astreinte de {{montant_astreinte}} € par jour de retard,\n\nDIRE que l'astreinte commencera à courir à l'expiration d'un délai de {{delai}} jours à compter de la signification de la présente ordonnance,\n\nSe réserver la liquidation de l'astreinte,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{refere,injonction,dispositif}	f	t	6	0	\N	\N
cml88g75x004u521vu0n8ti2x	2026-02-04 16:19:21.286	2026-02-04 16:19:21.286	cml88g71z0000521vp3t710u4	DISPOSITIF	Expulsion + Arriérés	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONSTATER l'acquisition de la clause résolutoire,\n\nORDONNER l'expulsion de {{locataire}} et de tous occupants de son chef des locaux situés {{adresse}} avec le concours de la force publique si nécessaire,\n\nCONDAMNER {{locataire}} au paiement des arriérés de loyers et charges, soit {{montant_arrieres}} €,\n\nCONDAMNER {{locataire}} à une indemnité d'occupation égale au montant du loyer et des charges jusqu'à libération effective des lieux,\n\nCONDAMNER {{locataire}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{expulsion,bail,dispositif}	f	t	7	0	\N	\N
cml88g75z004w521vg4ib6c8i	2026-02-04 16:19:21.288	2026-02-04 16:19:21.288	cml88g71z0000521vp3t710u4	DISPOSITIF	Licenciement Sans Cause	PAR CES MOTIFS\n\nLe Conseil de prud'hommes est prié de :\n\nDIRE ET JUGER le licenciement de {{client.nom}} sans cause réelle et sérieuse,\n\nCONDAMNER {{employeur}} à verser à {{client.nom}} les sommes suivantes :\n- {{montant_indemnite}} € à titre d'indemnité pour licenciement sans cause réelle et sérieuse,\n- {{montant_preavis}} € à titre d'indemnité compensatrice de préavis, outre {{montant_cp_preavis}} € au titre des congés payés afférents,\n- {{montant_licenciement}} € à titre d'indemnité légale/conventionnelle de licenciement,\n\nORDONNER la remise des documents de fin de contrat rectifiés sous astreinte,\n\nCONDAMNER {{employeur}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{licenciement,prudhommes,dispositif}	f	t	8	0	\N	\N
cml88g761004y521v6sjjp8u8	2026-02-04 16:19:21.29	2026-02-04 16:19:21.29	cml88g71z0000521vp3t710u4	DISPOSITIF	Contrefaçon Marque	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDIRE ET JUGER que {{adversaire.nom}} s'est rendu coupable de contrefaçon de la marque {{marque}},\n\nINTERDIRE à {{adversaire.nom}} de fabriquer, importer, exporter, commercialiser tout produit portant cette marque, sous astreinte de {{montant_astreinte}} € par infraction constatée,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nORDONNER la publication de la décision dans {{publications}} aux frais de {{adversaire.nom}},\n\nCONDAMNER {{adversaire.nom}} aux dépens.	{}	{contrefacon,marque,dispositif}	f	t	9	0	\N	\N
cml88g7620050521vb43702qf	2026-02-04 16:19:21.291	2026-02-04 16:19:21.291	cml88g71z0000521vp3t710u4	DISPOSITIF	Vice Caché Rédhibitoire	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nÀ titre principal :\nPRONONCER la résolution de la vente intervenue le {{date_vente}},\nCONDAMNER {{vendeur}} à restituer le prix de vente de {{prix}} €,\n\nÀ titre subsidiaire :\nCONDAMNER {{vendeur}} à verser une réduction de prix de {{montant_reduction}} €,\n\nEn tout état de cause :\nCONDAMNER {{vendeur}} à payer {{montant_di}} € de dommages-intérêts,\nCONDAMNER {{vendeur}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{vice-cache,vente,dispositif}	f	t	10	0	\N	\N
cml88g7640052521vvh2mk93d	2026-02-04 16:19:21.292	2026-02-04 16:19:21.292	cml88g71z0000521vp3t710u4	DISPOSITIF	Responsabilité Décennale	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDÉCLARER {{constructeur}} responsable des désordres affectant l'ouvrage sur le fondement de l'article 1792 du Code civil,\n\nCONDAMNER {{constructeur}} et son assureur {{assureur}} in solidum à payer à {{client.nom}} :\n- {{montant_travaux}} € au titre des travaux de reprise,\n- {{montant_prejudice}} € au titre du préjudice de jouissance,\n\nCONDAMNER {{constructeur}} aux dépens incluant les frais d'expertise.	{}	{decennale,construction,dispositif}	f	t	11	0	\N	\N
cml88g7660054521v46czgzp0	2026-02-04 16:19:21.295	2026-02-04 16:19:21.295	cml88g71z0000521vp3t710u4	DISPOSITIF	Troubles Voisinage	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONSTATER l'existence de troubles anormaux de voisinage,\n\nCONDAMNER {{adversaire.nom}} à faire cesser les troubles sous astreinte de {{montant_astreinte}} € par jour de retard,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € en réparation du préjudice subi,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{voisinage,troubles,dispositif}	f	t	12	0	\N	\N
cml88g7680056521vngkypdpd	2026-02-04 16:19:21.296	2026-02-04 16:19:21.296	cml88g71z0000521vp3t710u4	DISPOSITIF	Divorce Consentement Mutuel	PAR CES MOTIFS\n\nLe Juge aux affaires familiales est prié de :\n\nHOMOLOGUER la convention de divorce réglant les conséquences du divorce,\n\nPRONONCER le divorce aux torts partagés / pour altération définitive du lien conjugal,\n\nCONSTATER l'accord des époux sur {{points_accord}},\n\nDIRE que chaque partie conservera la charge de ses propres dépens.	{}	{divorce,famille,dispositif}	f	t	13	0	\N	\N
cml88g7690058521vzphzl4s0	2026-02-04 16:19:21.297	2026-02-04 16:19:21.297	cml88g71z0000521vp3t710u4	DISPOSITIF	Garde Enfants	PAR CES MOTIFS\n\nLe Juge aux affaires familiales est prié de :\n\nFIXER la résidence habituelle de l'enfant {{enfant.nom}} au domicile de {{parent_gardien}},\n\nFIXER le droit de visite et d'hébergement de {{autre_parent}} comme suit : {{modalites_dvh}},\n\nFIXER la contribution à l'entretien et à l'éducation de l'enfant à la somme de {{montant_pension}} € par mois,\n\nDIRE que cette contribution sera indexée sur l'indice des prix à la consommation.	{}	{garde,enfants,famille,dispositif}	f	t	14	0	\N	\N
cml88g76a005a521v98d71u0x	2026-02-04 16:19:21.299	2026-02-04 16:19:21.299	cml88g71z0000521vp3t710u4	DISPOSITIF	Rupture Brutale Relations Commerciales	PAR CES MOTIFS\n\nLe Tribunal de commerce est prié de :\n\nDIRE ET JUGER que {{adversaire.nom}} a rompu brutalement les relations commerciales établies avec {{client.nom}},\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} :\n- {{montant_marge}} € au titre de la perte de marge brute sur la durée du préavis insuffisant,\n- {{montant_frais}} € au titre des frais de reconversion,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{rupture-brutale,commercial,dispositif}	f	t	15	0	\N	\N
cml88g76c005c521vv9uuxa1g	2026-02-04 16:19:21.3	2026-02-04 16:19:21.3	cml88g71z0000521vp3t710u4	DISPOSITIF	Mesures Conservatoires	PAR CES MOTIFS\n\nLe Juge de l'exécution est prié de :\n\nAUTORISER {{client.nom}} à pratiquer une saisie conservatoire sur les comptes bancaires de {{adversaire.nom}}, jusqu'à concurrence de {{montant}} €,\n\nDIRE que la présente ordonnance sera caduque si l'assignation au fond n'est pas délivrée dans le mois de son exécution,\n\nDISPENSER le requérant de la signification préalable de la présente ordonnance.	{}	{saisie,conservatoire,dispositif}	f	t	16	0	\N	\N
cml88g76d005e521vh5p6crja	2026-02-04 16:19:21.302	2026-02-04 16:19:21.302	cml88g71z0000521vp3t710u4	DISPOSITIF	Mesure Expertise	PAR CES MOTIFS\n\nLe Président / Le Tribunal est prié de :\n\nORDONNER une mesure d'expertise judiciaire,\n\nDÉSIGNER tel expert qu'il plaira avec mission de :\n{{missions_expert}}\n\nFIXER la provision à consigner à la somme de {{provision}} €,\n\nDIRE que l'expert déposera son rapport dans un délai de {{delai}} mois.	{}	{expertise,judiciaire,dispositif}	f	t	17	0	\N	\N
cml88g76f005g521vdzx22fub	2026-02-04 16:19:21.304	2026-02-04 16:19:21.304	cml88g71z0000521vp3t710u4	DISPOSITIF	Concurrence Déloyale	PAR CES MOTIFS\n\nLe Tribunal de commerce est prié de :\n\nDIRE ET JUGER que {{adversaire.nom}} a commis des actes de concurrence déloyale au préjudice de {{client.nom}},\n\nCONDAMNER {{adversaire.nom}} à cesser ses agissements sous astreinte,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nORDONNER la publication de la décision aux frais de {{adversaire.nom}}.	{}	{concurrence,deloyale,dispositif}	f	t	18	0	\N	\N
cml88g76h005i521v6w4l3u8n	2026-02-04 16:19:21.305	2026-02-04 16:19:21.305	cml88g71z0000521vp3t710u4	DISPOSITIF	Débouté	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDÉCLARER {{adversaire.nom}} mal fondé en l'ensemble de ses demandes,\n\nL'EN DÉBOUTER purement et simplement,\n\nCONDAMNER {{adversaire.nom}} aux dépens de l'instance,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_451}} € au titre de l'article 700 du Code de procédure civile.	{}	{debout,defense,dispositif}	f	t	19	0	\N	\N
cml88g76i005k521v9uj0qoec	2026-02-04 16:19:21.307	2026-02-04 16:19:21.307	cml88g71z0000521vp3t710u4	DISPOSITIF	Sursis à Statuer	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nORDONNER le sursis à statuer dans l'attente de {{evenement_attendu}},\n\nRENVOYER l'affaire à une audience de mise en état ultérieure,\n\nRÉSERVER les dépens.	{}	{sursis,procedure,dispositif}	f	t	20	0	\N	\N
cml88g76k005m521vth4y5cgb	2026-02-04 16:19:21.308	2026-02-04 16:19:21.308	cml88g71z0000521vp3t710u4	DISPOSITIF	Jonction Instances	PAR CES MOTIFS\n\nLe Juge de la mise en état est prié de :\n\nORDONNER la jonction des instances RG nº {{rg_1}} et RG nº {{rg_2}},\n\nDIRE que l'affaire se poursuivra sous le numéro RG {{rg_principal}}.	{}	{jonction,procedure,dispositif}	f	t	21	0	\N	\N
cml88g76l005o521va5a3suh9	2026-02-04 16:19:21.309	2026-02-04 16:19:21.309	cml88g71z0000521vp3t710u4	DISPOSITIF	Irrecevabilité	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDÉCLARER l'action de {{adversaire.nom}} irrecevable pour {{motif_irrecevabilite}},\n\nCONDAMNER {{adversaire.nom}} aux dépens de l'instance,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_451}} € au titre de l'article 700 du Code de procédure civile.	{}	{irrecevabilite,fin-non-recevoir,dispositif}	f	t	22	0	\N	\N
cml88g76n005q521vkfmxy3ur	2026-02-04 16:19:21.311	2026-02-04 16:19:21.311	cml88g71z0000521vp3t710u4	DISPOSITIF	Radiation	PAR CES MOTIFS\n\nLe Juge de la mise en état est prié de :\n\nCONSTATER que {{partie_defaillante}} n'a pas accompli les diligences mises à sa charge,\n\nORDONNER la radiation de l'affaire du rôle,\n\nRÉSERVER les dépens.	{}	{radiation,procedure,dispositif}	f	t	23	0	\N	\N
cml88g76o005s521va9wne6nq	2026-02-04 16:19:21.313	2026-02-04 16:19:21.313	cml88g71z0000521vp3t710u4	DISPOSITIF	Caducité Citation	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONSTATER la caducité de la citation délivrée le {{date_citation}},\n\nCONSTATER en conséquence l'extinction de l'instance,\n\nCONDAMNER {{demandeur}} aux dépens.	{}	{caducite,procedure,dispositif}	f	t	24	0	\N	\N
cml88g76r005w521vt9s0x3d0	2026-02-04 16:19:21.316	2026-02-04 16:19:21.316	cml88g71z0000521vp3t710u4	CLAUSE	Clause Résolutoire Standard	CLAUSE RÉSOLUTOIRE\n\nLe présent contrat sera résilié de plein droit, un mois après mise en demeure restée sans effet, en cas de manquement par l'une des parties à l'une quelconque de ses obligations.\n\nLa résiliation prendra effet à la date indiquée dans la mise en demeure.\n\nCette résiliation s'effectuera sans préjudice de tous dommages et intérêts auxquels la partie lésée pourrait prétendre.	{}	{clause,resolutoire,contrat}	f	t	1	0	\N	\N
cml88g76t005y521v8gj9u0yc	2026-02-04 16:19:21.318	2026-02-04 16:19:21.318	cml88g71z0000521vp3t710u4	CLAUSE	Clause Attributive de Juridiction	ATTRIBUTION DE JURIDICTION\n\nTout litige relatif à la formation, l'exécution ou l'interprétation du présent contrat sera soumis à la compétence exclusive du Tribunal de Commerce / Tribunal Judiciaire de {{ville}}.\n\nCette clause s'applique même en cas de référé, de pluralité de défendeurs ou d'appel en garantie.	{}	{clause,competence,juridiction}	f	t	2	0	\N	\N
cml88g76v0060521vx13ab0zi	2026-02-04 16:19:21.319	2026-02-04 16:19:21.319	cml88g71z0000521vp3t710u4	CLAUSE	Clause Compromissoire Arbitrage	CLAUSE COMPROMISSOIRE\n\nTous les litiges auxquels le présent contrat pourrait donner lieu, concernant tant sa validité, son interprétation, son exécution, sa résolution, leurs conséquences et leurs suites, seront soumis à arbitrage conformément au Règlement d'arbitrage de {{organisme_arbitrage}}.\n\nL'arbitrage sera conduit par {{nombre}} arbitre(s) désigné(s) conformément au Règlement.\n\nLe siège de l'arbitrage sera fixé à {{ville}}.\n\nLa langue de l'arbitrage sera le français.	{}	{clause,arbitrage,compromissoire}	f	t	3	0	\N	\N
cml88g76w0062521v8vd848jy	2026-02-04 16:19:21.32	2026-02-04 16:19:21.32	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Confidentialité	CONFIDENTIALITÉ\n\nLes parties s'engagent à considérer comme strictement confidentielles et à ne pas divulguer à des tiers, pendant la durée du contrat et pendant une période de {{duree}} ans après son terme, les informations de toute nature, commerciales, industrielles, techniques, financières, nominatives, dont elles pourraient avoir connaissance dans le cadre du présent contrat.\n\nCette obligation de confidentialité ne s'applique pas aux informations qui :\n- sont ou deviennent publiques sans faute de la partie réceptrice ;\n- sont reçues licitement d'un tiers autorisé à les divulguer ;\n- doivent être divulguées en vertu de la loi ou d'une décision de justice.	{}	{clause,confidentialite,contrat}	f	t	4	0	\N	\N
cml88g76y0064521vhcbw3dwv	2026-02-04 16:19:21.322	2026-02-04 16:19:21.322	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Non-Concurrence	NON-CONCURRENCE\n\n{{partie_obligee}} s'engage à ne pas exercer, directement ou indirectement, une activité concurrente de celle de {{beneficiaire}} pendant une durée de {{duree}} à compter de la fin du présent contrat.\n\nCette interdiction s'applique dans le secteur géographique suivant : {{zone_geographique}}.\n\nEn contrepartie de cette obligation, {{beneficiaire}} versera à {{partie_obligee}} une indemnité de {{montant}} €.\n\nToute violation de cette clause entraînera le versement d'une indemnité forfaitaire de {{penalite}} € par infraction constatée, sans préjudice de tous dommages et intérêts.	{}	{clause,non-concurrence,contrat}	f	t	5	0	\N	\N
cml88g7700066521vu500prh2	2026-02-04 16:19:21.324	2026-02-04 16:19:21.324	cml88g71z0000521vp3t710u4	CLAUSE	Clause Pénale	CLAUSE PÉNALE\n\nEn cas d'inexécution par l'une des parties de l'une quelconque de ses obligations au titre du présent contrat, cette partie sera redevable de plein droit, après mise en demeure restée infructueuse pendant {{delai}} jours, d'une pénalité forfaitaire de {{montant}} €, sans préjudice de tous dommages et intérêts complémentaires que pourrait réclamer la partie lésée.\n\nCette pénalité est due sans qu'il soit nécessaire de prouver l'existence ou l'étendue d'un quelconque préjudice.	{}	{clause,penale,contrat}	f	t	6	0	\N	\N
cml88g7710068521vba2az4lz	2026-02-04 16:19:21.326	2026-02-04 16:19:21.326	cml88g71z0000521vp3t710u4	CLAUSE	Clause Limitative Responsabilité	LIMITATION DE RESPONSABILITÉ\n\nLa responsabilité de {{partie}} au titre du présent contrat ne pourra excéder {{montant_ou_pourcentage}}.\n\nCette limitation de responsabilité ne s'applique pas :\n- en cas de faute lourde ou dolosive ;\n- en cas de décès ou de dommage corporel ;\n- aux obligations essentielles du contrat.\n\nEn aucun cas {{partie}} ne pourra être tenu responsable des dommages indirects, tels que perte de données, perte d'exploitation, manque à gagner ou atteinte à l'image.	{}	{clause,responsabilite,limitation}	f	t	7	0	\N	\N
cml88g773006a521vosb3jek6	2026-02-04 16:19:21.327	2026-02-04 16:19:21.327	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Force Majeure	FORCE MAJEURE\n\nAucune partie ne sera responsable d'un retard ou d'une inexécution de ses obligations résultant d'un cas de force majeure au sens de l'article 1218 du Code civil.\n\nSont notamment considérés comme cas de force majeure : les catastrophes naturelles, les guerres, les grèves, les pannes d'électricité ou de télécommunications, les épidémies, les décisions gouvernementales.\n\nLa partie affectée devra notifier l'autre partie dans un délai de {{delai}} jours et prendre toutes mesures pour limiter les effets de la force majeure.\n\nSi la force majeure persiste au-delà de {{duree}}, chaque partie pourra résilier le contrat sans indemnité.	{}	{clause,force-majeure,contrat}	f	t	8	0	\N	\N
cml88g774006c521v4xmlpe5t	2026-02-04 16:19:21.328	2026-02-04 16:19:21.328	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Propriété Intellectuelle	PROPRIÉTÉ INTELLECTUELLE\n\nSauf stipulation expresse contraire, les droits de propriété intellectuelle relatifs aux {{creations}} créés dans le cadre du présent contrat sont et demeurent la propriété exclusive de {{titulaire}}.\n\n{{autre_partie}} ne pourra utiliser ces créations que dans le cadre strict de l'exécution du présent contrat.\n\nToute utilisation non autorisée constituerait une contrefaçon engageant la responsabilité de {{autre_partie}}.	{}	{clause,propriete-intellectuelle,contrat}	f	t	9	0	\N	\N
cml88g775006e521vekwesynh	2026-02-04 16:19:21.33	2026-02-04 16:19:21.33	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Cession Droits Auteur	CESSION DE DROITS D'AUTEUR\n\n{{cedant}} cède à {{cessionnaire}}, à titre {{exclusif_non_exclusif}}, l'ensemble des droits patrimoniaux d'auteur portant sur {{oeuvre}}, à savoir :\n\n- le droit de reproduction sur tout support connu ou inconnu à ce jour ;\n- le droit de représentation par tout moyen connu ou inconnu à ce jour ;\n- le droit de modification, adaptation, traduction ;\n- le droit de commercialisation et d'exploitation.\n\nCette cession est consentie pour le monde entier et pour la durée légale de protection du droit d'auteur.\n\nEn contrepartie de cette cession, {{cessionnaire}} versera à {{cedant}} la somme de {{montant}} €.	{}	{clause,droit-auteur,cession}	f	t	10	0	\N	\N
cml88g776006g521vczih4opl	2026-02-04 16:19:21.331	2026-02-04 16:19:21.331	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Prix	PRIX ET MODALITÉS DE PAIEMENT\n\nLe prix de {{prestation_bien}} est fixé à {{montant}} € HT, soit {{montant_ttc}} € TTC au taux de TVA de {{taux_tva}}%.\n\nCe prix sera payable selon les modalités suivantes : {{modalites_paiement}}.\n\nTout retard de paiement entraînera de plein droit :\n- l'exigibilité d'intérêts de retard au taux de {{taux}}% ;\n- une indemnité forfaitaire pour frais de recouvrement de {{indemnite}} €.	{}	{clause,prix,paiement}	f	t	11	0	\N	\N
cml88g778006i521vhwofeyni	2026-02-04 16:19:21.332	2026-02-04 16:19:21.332	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Révision Prix	RÉVISION DE PRIX\n\nLe prix sera révisé annuellement à la date anniversaire du contrat selon la formule suivante :\n\nP1 = P0 x (I1/I0)\n\nOù :\n- P0 est le prix initial\n- P1 est le prix révisé\n- I0 est l'indice {{indice}} publié à la date de signature\n- I1 est le dernier indice {{indice}} connu à la date de révision\n\nEn cas de disparition de l'indice de référence, les parties conviendront d'un nouvel indice de remplacement.	{}	{clause,revision,prix}	f	t	12	0	\N	\N
cml88g779006k521v24zbwjjd	2026-02-04 16:19:21.334	2026-02-04 16:19:21.334	cml88g71z0000521vp3t710u4	CLAUSE	Clause Réserve Propriété	RÉSERVE DE PROPRIÉTÉ\n\n{{vendeur}} se réserve la propriété des biens vendus jusqu'au paiement intégral du prix, en principal et accessoires.\n\nÀ défaut de paiement à l'échéance, {{vendeur}} pourra revendiquer les biens vendus et en reprendre possession.\n\n{{acheteur}} s'engage à :\n- assurer les biens contre tous risques ;\n- permettre l'accès à ses locaux pour la reprise des biens ;\n- ne pas céder ou nantir les biens.	{}	{clause,reserve-propriete,vente}	f	t	13	0	\N	\N
cml88g77c006m521v0nboakt3	2026-02-04 16:19:21.336	2026-02-04 16:19:21.336	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Garantie	GARANTIE\n\n{{garant}} garantit {{beneficiaire}} contre tout défaut de {{objet_garantie}} pendant une durée de {{duree}} à compter de {{point_depart}}.\n\nCette garantie couvre {{etendue_garantie}}.\n\nPour bénéficier de cette garantie, {{beneficiaire}} devra notifier le défaut par écrit dans un délai de {{delai}} jours suivant sa découverte.\n\n{{garant}} s'engage à remédier au défaut par {{modalites_reparation}} dans un délai de {{delai_reparation}}.	{}	{clause,garantie,contrat}	f	t	14	0	\N	\N
cml88g77d006o521vnpxcsbqw	2026-02-04 16:19:21.337	2026-02-04 16:19:21.337	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Non-Sollicitation	NON-SOLLICITATION\n\nPendant la durée du contrat et pendant une période de {{duree}} suivant son terme, chaque partie s'interdit de solliciter, embaucher ou faire travailler, directement ou indirectement, tout collaborateur de l'autre partie ayant participé à l'exécution du présent contrat.\n\nEn cas de manquement à cette obligation, la partie défaillante sera redevable d'une indemnité forfaitaire de {{montant}} €.	{}	{clause,non-sollicitation,personnel}	f	t	15	0	\N	\N
cml88g77e006q521vasv633sj	2026-02-04 16:19:21.338	2026-02-04 16:19:21.338	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Médiation Préalable	MÉDIATION PRÉALABLE\n\nEn cas de différend relatif au présent contrat, les parties s'engagent à tenter de résoudre leur litige à l'amiable par voie de médiation avant toute action judiciaire.\n\nLa médiation sera confiée à {{mediateur_ou_organisme}}.\n\nLe processus de médiation ne pourra excéder {{duree}}.\n\nLes frais de médiation seront partagés par moitié entre les parties.\n\nÀ défaut d'accord dans ce délai, les parties retrouveront leur liberté de saisir les tribunaux compétents.	{}	{clause,mediation,reglement-litiges}	f	t	16	0	\N	\N
cml88g77f006s521vbajjdscw	2026-02-04 16:19:21.339	2026-02-04 16:19:21.339	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Intuitu Personae	INTUITU PERSONAE\n\nLe présent contrat est conclu en considération de la personne de {{partie}}, en raison de {{qualites}}.\n\nEn conséquence, {{partie}} ne pourra céder ou transférer le bénéfice du présent contrat à un tiers sans l'accord préalable et écrit de {{autre_partie}}.\n\nTout changement de contrôle de {{partie}} devra être notifié à {{autre_partie}} qui pourra résilier le contrat de plein droit dans un délai de {{delai}} jours suivant cette notification.	{}	{clause,intuitu-personae,contrat}	f	t	17	0	\N	\N
cml88g77h006u521vpb2903gs	2026-02-04 16:19:21.341	2026-02-04 16:19:21.341	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Divisibilité	DIVISIBILITÉ\n\nSi l'une quelconque des dispositions du présent contrat était déclarée nulle ou inapplicable, cette nullité ou inapplicabilité n'affecterait pas les autres dispositions qui demeureront en vigueur.\n\nLes parties s'efforceront, dans la mesure du possible, de remplacer la disposition nulle ou inapplicable par une disposition valide et applicable ayant un effet économique aussi proche que possible de la disposition initiale.	{}	{clause,divisibilite,nullite}	f	t	18	0	\N	\N
cml88g77j006w521vw7jp2ffd	2026-02-04 16:19:21.343	2026-02-04 16:19:21.343	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Renonciation	RENONCIATION\n\nLe fait pour l'une des parties de ne pas se prévaloir d'un manquement par l'autre partie à l'une quelconque des obligations visées dans le présent contrat ne saurait être interprété comme une renonciation à l'obligation en cause.\n\nUne telle tolérance ne pourra en aucun cas créer un droit acquis au profit de la partie défaillante.	{}	{clause,renonciation,tolerance}	f	t	19	0	\N	\N
cml88g77l006y521vxmfs9mwk	2026-02-04 16:19:21.345	2026-02-04 16:19:21.345	cml88g71z0000521vp3t710u4	CLAUSE	Clause Entire Agreement	INTÉGRALITÉ DE L'ACCORD\n\nLe présent contrat constitue l'intégralité de l'accord entre les parties et annule et remplace tous accords, propositions ou déclarations antérieurs, écrits ou verbaux, relatifs à son objet.\n\nAucune modification du présent contrat ne sera valable si elle n'est pas établie par écrit et signée par les deux parties.	{}	{clause,integralite,accord}	f	t	20	0	\N	\N
cml88g77m0070521vf650ciug	2026-02-04 16:19:21.347	2026-02-04 16:19:21.347	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Durée et Reconduction	DURÉE - RECONDUCTION\n\nLe présent contrat est conclu pour une durée de {{duree_initiale}} à compter de sa signature.\n\nÀ l'issue de cette période initiale, le contrat sera reconduit tacitement pour des périodes successives de {{duree_reconduction}}, sauf dénonciation par l'une des parties notifiée par lettre recommandée avec accusé de réception {{delai_preavis}} avant le terme de la période en cours.	{}	{clause,duree,reconduction}	f	t	21	0	\N	\N
cml88g77o0072521vj2000jc9	2026-02-04 16:19:21.348	2026-02-04 16:19:21.348	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Résiliation pour Convenance	RÉSILIATION POUR CONVENANCE\n\nChaque partie pourra résilier le présent contrat à tout moment et sans avoir à justifier d'aucun motif, moyennant un préavis de {{duree_preavis}} notifié par lettre recommandée avec accusé de réception.\n\nEn cas de résiliation, {{prestataire}} aura droit au paiement des prestations déjà réalisées et des frais engagés.	{}	{clause,resiliation,convenance}	f	t	22	0	\N	\N
cml88g77q0074521vtn13uxbe	2026-02-04 16:19:21.35	2026-02-04 16:19:21.35	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Assurance	ASSURANCE\n\n{{partie}} s'engage à souscrire et à maintenir en vigueur pendant toute la durée du contrat une assurance responsabilité civile professionnelle auprès d'une compagnie notoirement solvable couvrant les conséquences de sa responsabilité civile pour un montant minimum de {{montant}} € par sinistre.\n\n{{partie}} s'engage à fournir à première demande une attestation d'assurance justifiant de cette couverture.	{}	{clause,assurance,rc-pro}	f	t	23	0	\N	\N
cml88g77t0076521vln3abr3d	2026-02-04 16:19:21.354	2026-02-04 16:19:21.354	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Données Personnelles RGPD	DONNÉES PERSONNELLES\n\nLes parties s'engagent à respecter la réglementation applicable en matière de protection des données personnelles, notamment le Règlement (UE) 2016/679 (RGPD).\n\n{{responsable_traitement}} agit en qualité de responsable du traitement pour les données collectées dans le cadre du présent contrat.\n\n{{sous_traitant}} s'engage à :\n- ne traiter les données que sur instruction documentée ;\n- garantir la confidentialité des données ;\n- assister {{responsable_traitement}} pour répondre aux demandes d'exercice des droits ;\n- notifier toute violation de données dans un délai de 72 heures ;\n- supprimer ou restituer les données au terme du contrat.	{}	{clause,rgpd,donnees-personnelles}	f	t	24	0	\N	\N
cml88g77v0078521vzljfizp7	2026-02-04 16:19:21.355	2026-02-04 16:19:21.355	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Sous-Traitance	SOUS-TRAITANCE\n\n{{prestataire}} pourra faire appel à des sous-traitants pour l'exécution du présent contrat.\n\n{{prestataire}} restera seul responsable de la bonne exécution du contrat vis-à-vis de {{client}}.\n\n{{prestataire}} s'engage à ce que ses sous-traitants respectent les mêmes obligations que celles auxquelles il est lui-même soumis.\n\n{{mention_eventuelle_autorisation}}.	{}	{clause,sous-traitance,prestation}	f	t	25	0	\N	\N
cml88g77w007a521vc1kn77nq	2026-02-04 16:19:21.357	2026-02-04 16:19:21.357	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Notification	NOTIFICATIONS\n\nToute notification entre les parties devra être faite par écrit et sera considérée comme valablement effectuée :\n- si elle est remise en main propre, à la date de remise ;\n- si elle est envoyée par lettre recommandée avec accusé de réception, à la date de première présentation ;\n- si elle est envoyée par email, à la date d'envoi avec confirmation de réception.\n\nLes notifications seront adressées aux coordonnées suivantes :\n{{coordonnees_parties}}	{}	{clause,notification,formalisme}	f	t	26	0	\N	\N
cml88g77x007c521vkiqqh47f	2026-02-04 16:19:21.358	2026-02-04 16:19:21.358	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Audit	DROIT D'AUDIT\n\n{{beneficiaire}} aura le droit, à ses frais et moyennant un préavis de {{delai}} jours ouvrables, de procéder ou de faire procéder par un tiers de son choix à un audit des registres, documents et systèmes de {{partie_auditee}} relatifs à l'exécution du présent contrat.\n\n{{partie_auditee}} s'engage à coopérer pleinement à tout audit et à fournir toutes les informations nécessaires.\n\nL'audit sera réalisé pendant les heures ouvrables et dans le respect de la confidentialité.	{}	{clause,audit,controle}	f	t	27	0	\N	\N
cml88g77z007e521vpcr0f7xf	2026-02-04 16:19:21.359	2026-02-04 16:19:21.359	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Compliance	CONFORMITÉ RÉGLEMENTAIRE\n\nChaque partie s'engage à respecter l'ensemble des dispositions légales et réglementaires applicables à son activité, notamment en matière de :\n- lutte contre la corruption (Loi Sapin II) ;\n- devoir de vigilance ;\n- droit de la concurrence ;\n- réglementation environnementale.\n\nChaque partie garantit l'autre contre toute réclamation qui pourrait résulter d'un manquement à ces obligations.	{}	{clause,compliance,conformite}	f	t	28	0	\N	\N
cml88g780007g521vxoj1jk9a	2026-02-04 16:19:21.36	2026-02-04 16:19:21.36	cml88g71z0000521vp3t710u4	CLAUSE	Clause Anti-Corruption	ANTI-CORRUPTION\n\nLes parties déclarent avoir pris connaissance de et s'engagent à respecter la réglementation anti-corruption applicable, notamment la loi nº 2016-1691 du 9 décembre 2016 dite "Sapin II".\n\nChaque partie s'interdit de proposer, promettre, accorder ou solliciter, directement ou indirectement, tout avantage indu à un agent public ou à toute personne privée en vue d'obtenir ou conserver un marché ou tout autre avantage.\n\nTout manquement à cette obligation constituera une cause de résiliation immédiate du contrat aux torts exclusifs de la partie défaillante.	{}	{clause,anti-corruption,sapin-2}	f	t	29	0	\N	\N
cml88g781007i521v2qw1dvop	2026-02-04 16:19:21.362	2026-02-04 16:19:21.362	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Non-Débauchage	NON-DÉBAUCHAGE\n\nPendant la durée du contrat et pendant une période de {{duree}} ans suivant son terme, chaque partie s'interdit de :\n\n- débaucher tout salarié de l'autre partie ayant participé à l'exécution du présent contrat ;\n- embaucher un tel salarié dans un délai de {{delai}} mois suivant son départ de l'autre partie.\n\nEn cas de manquement, la partie défaillante versera à l'autre une indemnité forfaitaire égale à {{mois}} mois de la rémunération brute du salarié concerné.	{}	{clause,non-debauchage,personnel}	f	t	30	0	\N	\N
cml88g782007k521v6y7ysft3	2026-02-04 16:19:21.363	2026-02-04 16:19:21.363	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Sortie Associé	CLAUSE DE SORTIE\n\nEn cas de désaccord persistant entre les associés sur {{sujets}}, chaque associé pourra proposer d'acquérir les parts de l'autre associé ou de lui céder les siennes.\n\nL'associé destinataire de l'offre disposera d'un délai de {{delai}} pour accepter soit de vendre ses parts, soit d'acquérir les parts de l'autre aux mêmes conditions.\n\nÀ défaut de réponse dans ce délai, l'offre sera caduque.	{}	{clause,sortie,associes}	f	t	31	0	\N	\N
cml88g784007m521vjnok7juu	2026-02-04 16:19:21.364	2026-02-04 16:19:21.364	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Drag-Along	CLAUSE D'ENTRAÎNEMENT (DRAG-ALONG)\n\nEn cas de cession par les Associés Majoritaires (détenant au moins {{pourcentage}}% du capital) de l'intégralité de leurs parts à un tiers, les Associés Minoritaires s'engagent irrévocablement à céder l'intégralité de leurs parts au même cessionnaire, dans les mêmes conditions de prix et de modalités.\n\nLes Associés Majoritaires notifieront leur intention aux Associés Minoritaires au moins {{delai}} jours avant la cession envisagée.	{}	{clause,drag-along,cession}	f	t	32	0	\N	\N
cml88g785007o521vqvw57n1a	2026-02-04 16:19:21.365	2026-02-04 16:19:21.365	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Tag-Along	CLAUSE DE SORTIE CONJOINTE (TAG-ALONG)\n\nEn cas de cession par un Associé de ses parts à un tiers, les autres Associés auront la faculté de céder au même cessionnaire tout ou partie de leurs parts, au même prix et aux mêmes conditions.\n\nL'Associé cédant devra notifier aux autres Associés les conditions de la cession envisagée.\n\nLes autres Associés disposeront d'un délai de {{delai}} jours pour exercer leur droit de sortie conjointe.	{}	{clause,tag-along,cession}	f	t	33	0	\N	\N
cml88g786007q521vbvvav36z	2026-02-04 16:19:21.366	2026-02-04 16:19:21.366	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Agrément	CLAUSE D'AGRÉMENT\n\nToute cession de parts sociales à un tiers non associé est soumise à l'agrément préalable de la collectivité des associés statuant à la majorité de {{majorite}}.\n\nLe projet de cession devra être notifié à la société et aux associés par lettre recommandée avec accusé de réception.\n\nLa décision d'agrément devra intervenir dans un délai de {{delai}} jours à compter de la notification. À défaut de réponse dans ce délai, l'agrément sera réputé acquis.	{}	{clause,agrement,cession}	f	t	34	0	\N	\N
cml88g788007s521vbug3368y	2026-02-04 16:19:21.368	2026-02-04 16:19:21.368	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Préemption	DROIT DE PRÉEMPTION\n\nEn cas de projet de cession de parts par un associé, les autres associés bénéficieront d'un droit de préemption.\n\nL'associé cédant devra notifier aux autres associés les conditions de la cession envisagée, notamment l'identité de l'acquéreur, le nombre de parts, le prix et les modalités de paiement.\n\nLes associés disposeront d'un délai de {{delai}} jours pour exercer leur droit de préemption, au prorata de leur participation.	{}	{clause,preemption,cession}	f	t	35	0	\N	\N
cml88g789007u521vfgrnbvd0	2026-02-04 16:19:21.369	2026-02-04 16:19:21.369	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Standard Avocat	Fait à {{ville}}, le {{date_jour}}\n\nPour {{client.nom}},\nSon conseil,\n\nMaître {{avocat.nom}} {{avocat.prenom}}\nAvocat au Barreau de {{avocat.barreau}}\n{{cabinet.adresse}}\n{{cabinet.telephone}}\n{{cabinet.email}}	{}	{signature,avocat}	f	t	1	0	\N	\N
cml88g78a007w521v0682o7of	2026-02-04 16:19:21.37	2026-02-04 16:19:21.37	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Assignation Huissier	DONT ACTE\n\nCoût de l'acte : {{cout_acte}} €\n\n{{huissier.nom}} {{huissier.prenom}}\nHuissier de Justice\nSCP {{huissier.scp}}\n{{huissier.adresse}}	{}	{signature,huissier,assignation}	f	t	2	0	\N	\N
cml88g78b007y521vew68ol1k	2026-02-04 16:19:21.371	2026-02-04 16:19:21.371	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Conclusions Avocat Postulant	Sous toutes réserves,\n\nPour {{client.nom}},\nMaître {{avocat_postulant.nom}}, avocat postulant\nMaître {{avocat_plaidant.nom}}, avocat plaidant\n\nLe {{date_jour}}	{}	{signature,avocat,postulant}	f	t	3	0	\N	\N
cml88g78c0080521vmvdhp864	2026-02-04 16:19:21.373	2026-02-04 16:19:21.373	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Contrat Deux Parties	Fait en deux exemplaires originaux,\nà {{ville}}, le {{date_jour}}\n\nPour {{partie_1.nom}}                     Pour {{partie_2.nom}}\nReprésenté par : {{partie_1.representant}}   Représenté par : {{partie_2.representant}}\nFonction : {{partie_1.fonction}}            Fonction : {{partie_2.fonction}}\n\n\n_____________________                    _____________________\n(Signature précédée de la mention       (Signature précédée de la mention\n"Lu et approuvé")                       "Lu et approuvé")	{}	{signature,contrat,deux-parties}	f	t	4	0	\N	\N
cml88g78e0082521vumkeaawx	2026-02-04 16:19:21.374	2026-02-04 16:19:21.374	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Contrat Trois Parties	Fait en trois exemplaires originaux,\nà {{ville}}, le {{date_jour}}\n\nPour {{partie_1.nom}}          Pour {{partie_2.nom}}          Pour {{partie_3.nom}}\n\n\n\n_________________              _________________              _________________	{}	{signature,contrat,trois-parties}	f	t	5	0	\N	\N
cml88g78f0084521vsq1hq5gm	2026-02-04 16:19:21.376	2026-02-04 16:19:21.376	cml88g71z0000521vp3t710u4	SIGNATURE	Signature avec Paraphes	Le présent contrat, composé de {{nombre_pages}} pages, a été paraphé par les parties.\n\nFait à {{ville}}, le {{date_jour}}\nEn {{nombre_exemplaires}} exemplaires originaux\n\n{{partie_1.nom}}                              {{partie_2.nom}}\n\n\nSignature :                                   Signature :\n_________________________                     _________________________\nParaphe sur chaque page : ___                Paraphe sur chaque page : ___	{}	{signature,paraphes,contrat}	f	t	6	0	\N	\N
cml88g78g0086521vgxea0dvr	2026-02-04 16:19:21.377	2026-02-04 16:19:21.377	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Protocole Accord	Ainsi convenu entre les parties,\n\nFait à {{ville}}, le {{date_jour}}\n\nEn {{nombre}} exemplaires, un pour chaque partie\n\nLes Parties déclarent avoir lu et approuvé l'ensemble du présent protocole d'accord.\n\n\nPour {{partie_1}} :                           Pour {{partie_2}} :\n\n\n_____________________                         _____________________	{}	{signature,protocole,accord}	f	t	7	0	\N	\N
cml88g78j0088521vlybba19z	2026-02-04 16:19:21.379	2026-02-04 16:19:21.379	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Procès-Verbal AG	De tout ce que dessus, il a été dressé le présent procès-verbal qui a été signé, après lecture, par les membres du bureau.\n\nFait à {{ville}}, le {{date_jour}}\n\nLe Président de séance :                      Le Secrétaire de séance :\n\n\n_____________________                         _____________________\n{{president.nom}}                             {{secretaire.nom}}	{}	{signature,pv,ag}	f	t	8	0	\N	\N
cml88g78k008a521vu0tn3dzz	2026-02-04 16:19:21.38	2026-02-04 16:19:21.38	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Rapport Expert	En foi de quoi, j'ai établi le présent rapport.\n\nFait à {{ville}}, le {{date_jour}}\n\n{{expert.titre}} {{expert.nom}}\nExpert {{expert.specialite}}\nAgréé par la Cour d'appel de {{expert.cour}}\n\n\n_____________________	{}	{signature,expert,rapport}	f	t	9	0	\N	\N
cml88g78l008c521vwczg2jq3	2026-02-04 16:19:21.381	2026-02-04 16:19:21.381	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Courrier Avocat	Je vous prie d'agréer, {{formule_politesse}}, l'expression de mes salutations distinguées.\n\nMaître {{avocat.nom}} {{avocat.prenom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nP.J. : {{pieces_jointes}}	{}	{signature,courrier,avocat}	f	t	10	0	\N	\N
cmlb2q02h0001g0wk458tgphz	2026-02-06 16:02:19.481	2026-02-06 16:02:19.481	cml6vykdd0000jms2wwxl9s27	INTRO	En-tete cabinet	{cabinet.nom}\n{cabinet.adresse}\nTel: {cabinet.telephone} — Email: {cabinet.email}\nBarreau de {cabinet.barreau} — Toque {cabinet.toque}	[{"key": "cabinet.nom", "label": "Nom du cabinet"}, {"key": "cabinet.adresse", "label": "Adresse du cabinet"}, {"key": "cabinet.telephone", "label": "Telephone"}, {"key": "cabinet.email", "label": "Email"}, {"key": "cabinet.barreau", "label": "Barreau"}, {"key": "cabinet.toque", "label": "Toque"}]	{system,en-tete}	f	t	0	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q02q0003g0wkbqvoo46f	2026-02-06 16:02:19.491	2026-02-06 16:02:19.491	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Pied de page	{cabinet.nom} — SIRET {cabinet.siret} — Barreau de {cabinet.barreau} — Toque {cabinet.toque}\n{cabinet.adresse} — {cabinet.telephone}	[{"key": "cabinet.nom", "label": "Nom du cabinet"}, {"key": "cabinet.siret", "label": "SIRET"}, {"key": "cabinet.barreau", "label": "Barreau"}, {"key": "cabinet.toque", "label": "Toque"}, {"key": "cabinet.adresse", "label": "Adresse"}, {"key": "cabinet.telephone", "label": "Telephone"}]	{system,pied-de-page}	f	t	100	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q02u0005g0wkfn44ruzb	2026-02-06 16:02:19.494	2026-02-06 16:02:19.494	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Signature + Date	Fait a {cabinet.ville}, le {date}\n\n{avocat.signature}\nAvocat au Barreau de {cabinet.barreau}	[{"key": "cabinet.ville", "label": "Ville du cabinet"}, {"key": "date", "label": "Date du jour"}, {"key": "avocat.signature", "label": "Signature de l'avocat"}, {"key": "cabinet.barreau", "label": "Barreau"}]	{system,signature}	f	t	99	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q0310007g0wknz66bma7	2026-02-06 16:02:19.501	2026-02-06 16:02:19.501	cml6vykdd0000jms2wwxl9s27	INTRO	Identification des parties	ENTRE LES SOUSSIGNES :\n\nLe Cabinet {cabinet.nom}, represente par Me {avocat.nom_complet},\nAvocat au Barreau de {cabinet.barreau}, Toque n. {cabinet.toque},\nci-apres denomme "l'Avocat",\n\nET\n\n{client.civilite} {client.prenom} {client.nom},\nNe(e) le {client.date_naissance} a {client.lieu_naissance},\nDe nationalite {client.nationalite},\nDemeurant : {client.adresse}\nci-apres denomme(e) "le Client"	[{"key": "cabinet.nom"}, {"key": "avocat.nom_complet"}, {"key": "cabinet.barreau"}, {"key": "cabinet.toque"}, {"key": "client.civilite"}, {"key": "client.prenom"}, {"key": "client.nom"}, {"key": "client.date_naissance"}, {"key": "client.lieu_naissance"}, {"key": "client.nationalite"}, {"key": "client.adresse"}]	{standard,parties}	f	f	1	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q0360009g0wkqeq84mt6	2026-02-06 16:02:19.506	2026-02-06 16:02:19.506	cml6vykdd0000jms2wwxl9s27	CLAUSE	Objet de la mission	Le Client confie au Cabinet la mission suivante :\n{dossier.titre}\n\nCette mission comprend le conseil juridique, la redaction d'actes et, le cas echeant, la representation en justice.	[{"key": "dossier.titre"}]	{standard,mission}	f	f	2	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q039000bg0wkp07p5umq	2026-02-06 16:02:19.509	2026-02-06 16:02:19.509	cml6vykdd0000jms2wwxl9s27	CLAUSE	Conditions d'honoraires	Les honoraires de l'Avocat sont fixes comme suit :\n\n- Honoraire forfaitaire : ______ EUR HT\n- Ou honoraire au temps passe : ______ EUR HT / heure\n\nLes honoraires seront factures mensuellement et payables a 30 jours.\nUne provision de ______ EUR sera demandee a la signature de la presente convention.	[]	{standard,honoraires}	f	f	3	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q03c000dg0wkywzlp5ed	2026-02-06 16:02:19.513	2026-02-06 16:02:19.513	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de confidentialite	Les parties s'engagent a considerer comme strictement confidentiel l'ensemble des informations echangees dans le cadre de la presente mission.\n\nCette obligation de confidentialite survivra a la cessation de la mission pour une duree de deux (2) ans.	[]	{standard,confidentialite}	f	f	4	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q03f000fg0wkihc4kj6m	2026-02-06 16:02:19.515	2026-02-06 16:02:19.515	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'election de domicile	Pour l'execution des presentes, les parties font election de domicile :\n- L'Avocat : {cabinet.adresse}\n- Le Client : {client.adresse}	[{"key": "cabinet.adresse"}, {"key": "client.adresse"}]	{standard,domicile}	f	f	5	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2q03i000hg0wkahyp4p05	2026-02-06 16:02:19.518	2026-02-06 16:02:19.518	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Clause de juridiction	En cas de litige relatif a l'interpretation ou a l'execution de la presente convention, les parties conviennent de soumettre leur differend au Tribunal Judiciaire de {dossier.juridiction}.	[{"key": "dossier.juridiction"}]	{standard,juridiction}	f	f	6	0	cml6vykja0002jms2hhr4hfr3	\N
cmlb2qesw0005n7pqafsxgnva	2026-02-06 16:02:38.576	2026-02-06 16:02:38.586	cml6vykdd0000jms2wwxl9s27	CUSTOM	Mon bloc custom	Contenu de test {client.nom}	null	{custom,test}	f	f	50	0	cml6vykja0002jms2hhr4hfr3	2026-02-06 16:02:38.585
\.


--
-- Data for Name: builder_templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.builder_templates (id, "createdAt", "updatedAt", "tenantId", name, description, "documentType", juridiction, category, "blocksStructure", "requiredVariables", "outputFormat", "workflowConfig", "legalMentions", "isSystem", "usageCount", "createdById", "templateCategoryId", "deletedAt", "folderNature", "folderType", "isPersonalise", "sourceFileUrl") FROM stdin;
cml7z49kp0019b6ve8k82awgq	2026-02-04 11:58:07.994	2026-02-04 11:58:07.994	cml6vykdd0000jms2wwxl9s27	Assignation devant le Tribunal Judiciaire	Modèle d'assignation pour les litiges civils devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TJ"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml7z49kw001bb6ves1nms473	2026-02-04 11:58:08	2026-02-04 11:58:08	cml6vykdd0000jms2wwxl9s27	Assignation devant le Tribunal de Commerce	Modèle d'assignation pour les litiges commerciaux	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TC"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits - Litige commercial"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif - Condamnation pécuniaire"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml7z49kz001db6veejh2kl6a	2026-02-04 11:58:08.003	2026-02-04 11:58:08.003	cml6vykdd0000jms2wwxl9s27	Conclusions en défense	Modèle de conclusions pour la partie défenderesse	CONCLUSIONS	\N	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête conclusions"}, {"order": 2, "mandatory": true, "blockTitle": "Rappel des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml7z49l2001fb6vet4n3hx1w	2026-02-04 11:58:08.006	2026-02-04 11:58:08.006	cml6vykdd0000jms2wwxl9s27	Mise en demeure simple	Modèle de mise en demeure pour inexécution contractuelle	MISE_EN_DEMEURE	\N	Courriers	[{"order": 1, "mandatory": true, "blockTitle": "En-tête mise en demeure"}, {"order": 2, "mandatory": true, "blockTitle": "Corps mise en demeure"}, {"order": 3, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml7z49l4001hb6vepx7md3qy	2026-02-04 11:58:08.008	2026-02-04 11:58:08.008	cml6vykdd0000jms2wwxl9s27	Protocole de cession de parts sociales	Modèle complet pour cession de parts sociales SARL/SAS	PROTOCOLE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule cession"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Clause de non-concurrence"}, {"order": 4, "mandatory": true, "blockTitle": "Signatures parties"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml7z49l6001jb6ves3273zfw	2026-02-04 11:58:08.01	2026-02-04 11:58:08.01	cml6vykdd0000jms2wwxl9s27	Pacte d'associés SAS	Modèle de pacte d'associés pour SAS	PACTE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule pacte"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de sortie conjointe (tag-along)"}, {"order": 3, "mandatory": true, "blockTitle": "Clause d'entraînement (drag-along)"}, {"order": 4, "mandatory": true, "blockTitle": "Clause de confidentialité"}, {"order": 5, "mandatory": true, "blockTitle": "Signatures"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml7z49l8001lb6veuyll3l06	2026-02-04 11:58:08.013	2026-02-04 11:58:08.013	cml6vykdd0000jms2wwxl9s27	Garantie d'actif et passif (GAP)	Convention de garantie d'actif et passif autonome	GARANTIE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule GAP"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Signatures"}]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc1l003hm3wj39n2jc86	2026-02-04 15:07:55.257	2026-02-04 15:07:55.257	cml6vykdd0000jms2wwxl9s27	Assignation en référé expertise (145 CPC)	Pour obtenir une expertise judiciaire avant tout procès	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc1q003jm3wjwtdwmbed	2026-02-04 15:07:55.262	2026-02-04 15:07:55.262	cml6vykdd0000jms2wwxl9s27	Assignation en référé provision	Pour obtenir une provision sur créance non contestable	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc1s003lm3wjjbb6k188	2026-02-04 15:07:55.265	2026-02-04 15:07:55.265	cml6vykdd0000jms2wwxl9s27	Conclusions en réplique (demandeur)	Conclusions du demandeur en réponse aux conclusions adverses	CONCLUSIONS	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc1u003nm3wjm8r4abvv	2026-02-04 15:07:55.267	2026-02-04 15:07:55.267	cml6vykdd0000jms2wwxl9s27	Conclusions récapitulatives	Conclusions finales récapitulant l'ensemble des demandes	CONCLUSIONS	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc1w003pm3wjck7k16li	2026-02-04 15:07:55.269	2026-02-04 15:07:55.269	cml6vykdd0000jms2wwxl9s27	Opposition à ordonnance d'injonction de payer	Modèle d'opposition à une injonction de payer	OPPOSITION	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc1z003rm3wjy99rw0i3	2026-02-04 15:07:55.271	2026-02-04 15:07:55.271	cml6vykdd0000jms2wwxl9s27	Requête en rectification d'erreur matérielle	Pour corriger une erreur dans une décision de justice	REQUETE	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc20003tm3wj99o8k652	2026-02-04 15:07:55.273	2026-02-04 15:07:55.273	cml6vykdd0000jms2wwxl9s27	Assignation en contrefaçon de marque	Action en contrefaçon devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Propriété intellectuelle	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc22003vm3wjmg3ro57k	2026-02-04 15:07:55.275	2026-02-04 15:07:55.275	cml6vykdd0000jms2wwxl9s27	Assignation en concurrence déloyale	Action pour actes de concurrence déloyale	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc24003xm3wjldy6fglg	2026-02-04 15:07:55.277	2026-02-04 15:07:55.277	cml6vykdd0000jms2wwxl9s27	Assignation en rupture brutale	Action L.442-1 II pour rupture brutale de relations commerciales	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc26003zm3wjyrsa14r1	2026-02-04 15:07:55.279	2026-02-04 15:07:55.279	cml6vykdd0000jms2wwxl9s27	Déclaration de créance (procédure collective)	Déclaration au passif d'une procédure collective	DECLARATION	\N	Procédures collectives	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc280041m3wjssew9rzx	2026-02-04 15:07:55.281	2026-02-04 15:07:55.281	cml6vykdd0000jms2wwxl9s27	Revendication de marchandises	Action en revendication de biens vendus avec réserve de propriété	REQUETE	\N	Procédures collectives	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2a0043m3wjbxwu74sv	2026-02-04 15:07:55.282	2026-02-04 15:07:55.282	cml6vykdd0000jms2wwxl9s27	Saisine Conseil de Prud'hommes - Licenciement	Contestation d'un licenciement devant le CPH	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2c0045m3wjgeu64ato	2026-02-04 15:07:55.284	2026-02-04 15:07:55.284	cml6vykdd0000jms2wwxl9s27	Saisine CPH - Harcèlement moral	Action pour harcèlement moral au travail	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2e0047m3wj06pij6ko	2026-02-04 15:07:55.286	2026-02-04 15:07:55.286	cml6vykdd0000jms2wwxl9s27	Saisine CPH - Rappel de salaires	Action en rappel de salaires et accessoires	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2g0049m3wjhfnlw25t	2026-02-04 15:07:55.288	2026-02-04 15:07:55.288	cml6vykdd0000jms2wwxl9s27	Conclusions prud'homales (défense employeur)	Conclusions pour l'employeur en défense	CONCLUSIONS	\N	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2l004bm3wj7w4t2rpm	2026-02-04 15:07:55.294	2026-02-04 15:07:55.294	cml6vykdd0000jms2wwxl9s27	Transaction rupture contrat de travail	Protocole transactionnel suite à rupture du contrat	PROTOCOLE	\N	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2o004dm3wjs45npz8g	2026-02-04 15:07:55.296	2026-02-04 15:07:55.296	cml6vykdd0000jms2wwxl9s27	Requête divorce par consentement mutuel (notaire)	Convention de divorce par consentement mutuel	REQUETE	\N	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2q004fm3wjs205yrei	2026-02-04 15:07:55.298	2026-02-04 15:07:55.298	cml6vykdd0000jms2wwxl9s27	Requête divorce contentieux	Requête en divorce pour altération définitive du lien conjugal	REQUETE	JAF	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2r004hm3wj2wdk55vc	2026-02-04 15:07:55.3	2026-02-04 15:07:55.3	cml6vykdd0000jms2wwxl9s27	Requête modification pension alimentaire	Modification de la contribution à l'entretien des enfants	REQUETE	JAF	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2t004jm3wjwgiouwtf	2026-02-04 15:07:55.302	2026-02-04 15:07:55.302	cml6vykdd0000jms2wwxl9s27	Requête droits de visite et d'hébergement	Fixation ou modification du droit de visite	REQUETE	JAF	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2w004lm3wjf3hqr2xd	2026-02-04 15:07:55.304	2026-02-04 15:07:55.304	cml6vykdd0000jms2wwxl9s27	Assignation en garantie décennale	Action contre le constructeur au titre de l'article 1792 CC	ASSIGNATION	Tribunal Judiciaire	Construction	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2x004nm3wjfl8dqbb5	2026-02-04 15:07:55.306	2026-02-04 15:07:55.306	cml6vykdd0000jms2wwxl9s27	Assignation en garantie biennale	Action en garantie de bon fonctionnement	ASSIGNATION	\N	Construction	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc2z004pm3wj5woryjur	2026-02-04 15:07:55.307	2026-02-04 15:07:55.307	cml6vykdd0000jms2wwxl9s27	Assignation troubles de voisinage	Action pour troubles anormaux de voisinage	ASSIGNATION	\N	Immobilier	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc31004rm3wj3neqpnry	2026-02-04 15:07:55.309	2026-02-04 15:07:55.309	cml6vykdd0000jms2wwxl9s27	Assignation vice caché immobilier	Action rédhibitoire ou estimatoire	ASSIGNATION	\N	Immobilier	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc32004tm3wjhfxt4b15	2026-02-04 15:07:55.311	2026-02-04 15:07:55.311	cml6vykdd0000jms2wwxl9s27	Bail commercial 3-6-9	Modèle complet de bail commercial	CONTRAT	\N	Immobilier	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc34004vm3wj2ljsxir7	2026-02-04 15:07:55.313	2026-02-04 15:07:55.313	cml6vykdd0000jms2wwxl9s27	Contrat de cession de parts SARL	Cession de parts sociales de SARL	CONTRAT	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc36004xm3wjcvkgxpym	2026-02-04 15:07:55.314	2026-02-04 15:07:55.314	cml6vykdd0000jms2wwxl9s27	Contrat de cession d'actions SAS	Cession d'actions de SAS	CONTRAT	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc38004zm3wjtizfs2qd	2026-02-04 15:07:55.316	2026-02-04 15:07:55.316	cml6vykdd0000jms2wwxl9s27	Pacte d'associés SARL	Pacte d'associés pour SARL	PACTE	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3a0051m3wjfjce6k30	2026-02-04 15:07:55.318	2026-02-04 15:07:55.318	cml6vykdd0000jms2wwxl9s27	Lettre d'intention (LOI)	Lettre d'intention non engageante M&A	LETTRE	\N	M&A	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3c0053m3wjz2eta9ux	2026-02-04 15:07:55.32	2026-02-04 15:07:55.32	cml6vykdd0000jms2wwxl9s27	Protocole d'accord M&A	Protocole de cession complet avec GAP	PROTOCOLE	\N	M&A	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3d0055m3wjzo84driz	2026-02-04 15:07:55.322	2026-02-04 15:07:55.322	cml6vykdd0000jms2wwxl9s27	Contrat de franchise	Contrat de franchise commerciale	CONTRAT	\N	Distribution	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3f0057m3wjizfhwwr5	2026-02-04 15:07:55.324	2026-02-04 15:07:55.324	cml6vykdd0000jms2wwxl9s27	Contrat d'agent commercial	Contrat d'agence commerciale	CONTRAT	\N	Distribution	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3i0059m3wjaho36q4p	2026-02-04 15:07:55.326	2026-02-04 15:07:55.326	cml6vykdd0000jms2wwxl9s27	Contrat de prestation de services	Contrat B2B de prestation de services	CONTRAT	\N	Contrats commerciaux	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3k005bm3wjf23utuph	2026-02-04 15:07:55.328	2026-02-04 15:07:55.328	cml6vykdd0000jms2wwxl9s27	CGV B2B	Conditions générales de vente professionnels	CGV	\N	Contrats commerciaux	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3m005dm3wjysdg2s9z	2026-02-04 15:07:55.33	2026-02-04 15:07:55.33	cml6vykdd0000jms2wwxl9s27	NDA bilatéral	Accord de confidentialité bilatéral	CONTRAT	\N	Contrats commerciaux	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3o005fm3wj3tkrcl5f	2026-02-04 15:07:55.332	2026-02-04 15:07:55.332	cml6vykdd0000jms2wwxl9s27	Mise en demeure paiement facture	Mise en demeure précontentieuse pour impayé	MISE_EN_DEMEURE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3q005hm3wjb7zc0s7i	2026-02-04 15:07:55.334	2026-02-04 15:07:55.334	cml6vykdd0000jms2wwxl9s27	Mise en demeure exécution obligation	Mise en demeure d'exécuter une obligation contractuelle	MISE_EN_DEMEURE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3s005jm3wjtuocuvy5	2026-02-04 15:07:55.336	2026-02-04 15:07:55.336	cml6vykdd0000jms2wwxl9s27	Mise en demeure cessation agissements	Mise en demeure de cesser des agissements illicites	MISE_EN_DEMEURE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3u005lm3wj6cysq4w1	2026-02-04 15:07:55.338	2026-02-04 15:07:55.338	cml6vykdd0000jms2wwxl9s27	Lettre de résiliation	Résiliation de contrat avec préavis	LETTRE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3v005nm3wjv80g76f2	2026-02-04 15:07:55.34	2026-02-04 15:07:55.34	cml6vykdd0000jms2wwxl9s27	Lettre de réclamation	Réclamation amiable précontentieuse	LETTRE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3x005pm3wj5l6553z6	2026-02-04 15:07:55.342	2026-02-04 15:07:55.342	cml6vykdd0000jms2wwxl9s27	Statuts SAS	Statuts complets de SAS	STATUTS	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc3z005rm3wj0yno3mfq	2026-02-04 15:07:55.343	2026-02-04 15:07:55.343	cml6vykdd0000jms2wwxl9s27	Statuts SARL	Statuts complets de SARL	STATUTS	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc41005tm3wjgjxt8iex	2026-02-04 15:07:55.345	2026-02-04 15:07:55.345	cml6vykdd0000jms2wwxl9s27	PV AG Ordinaire Annuelle	PV d'approbation des comptes annuels	PV	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc43005vm3wjt91bvnip	2026-02-04 15:07:55.347	2026-02-04 15:07:55.347	cml6vykdd0000jms2wwxl9s27	PV AG Extraordinaire	PV de modification des statuts	PV	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml85wc45005xm3wjfp8ibdmm	2026-02-04 15:07:55.349	2026-02-04 15:07:55.349	cml6vykdd0000jms2wwxl9s27	PV nomination dirigeant	Décision de nomination d'un dirigeant	PV	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kws000lf0egi5diqzx0	2026-02-05 16:28:19.229	2026-02-05 16:28:19.229	cml6vyl1v0017jms2uzfefv85	Conclusions récapitulatives	Conclusions finales récapitulant l'ensemble des demandes	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kx1000nf0ege9jd9ozc	2026-02-05 16:28:19.237	2026-02-05 16:28:19.237	cml6vyl1v0017jms2uzfefv85	Opposition à ordonnance d'injonction de payer	Modèle d'opposition à une injonction de payer	OPPOSITION	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kxf000pf0egtefnkskn	2026-02-05 16:28:19.251	2026-02-05 16:28:19.251	cml6vyl1v0017jms2uzfefv85	Requête en rectification d'erreur matérielle	Pour corriger une erreur dans une décision de justice	REQUETE	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ksu0001f0ege4hmsa8z	2026-02-05 16:28:19.086	2026-02-05 16:28:19.086	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal Judiciaire	Modèle d'assignation pour les litiges civils devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TJ"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ktf0003f0egitlznk83	2026-02-05 16:28:19.106	2026-02-05 16:28:19.106	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal de Commerce	Modèle d'assignation pour les litiges commerciaux	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TC"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits - Litige commercial"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif - Condamnation pécuniaire"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ktt0005f0egl6qj0i0i	2026-02-05 16:28:19.122	2026-02-05 16:28:19.122	cml6vyl1v0017jms2uzfefv85	Conclusions en défense	Modèle de conclusions pour la partie défenderesse	CONCLUSIONS	\N	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête conclusions"}, {"order": 2, "mandatory": true, "blockTitle": "Rappel des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kud0007f0egvn772xx9	2026-02-05 16:28:19.14	2026-02-05 16:28:19.14	cml6vyl1v0017jms2uzfefv85	Mise en demeure simple	Modèle de mise en demeure pour inexécution contractuelle	MISE_EN_DEMEURE	\N	Courriers	[{"order": 1, "mandatory": true, "blockTitle": "En-tête mise en demeure"}, {"order": 2, "mandatory": true, "blockTitle": "Corps mise en demeure"}, {"order": 3, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kuq0009f0egcliicez3	2026-02-05 16:28:19.154	2026-02-05 16:28:19.154	cml6vyl1v0017jms2uzfefv85	Protocole de cession de parts sociales	Modèle complet pour cession de parts sociales SARL/SAS	PROTOCOLE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule cession"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Clause de non-concurrence"}, {"order": 4, "mandatory": true, "blockTitle": "Signatures parties"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kvb000bf0eg47nsteek	2026-02-05 16:28:19.173	2026-02-05 16:28:19.173	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SAS	Modèle de pacte d'associés pour SAS	PACTE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule pacte"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de sortie conjointe (tag-along)"}, {"order": 3, "mandatory": true, "blockTitle": "Clause d'entraînement (drag-along)"}, {"order": 4, "mandatory": true, "blockTitle": "Clause de confidentialité"}, {"order": 5, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kvo000df0egoz81b00t	2026-02-05 16:28:19.188	2026-02-05 16:28:19.188	cml6vyl1v0017jms2uzfefv85	Garantie d'actif et passif (GAP)	Convention de garantie d'actif et passif autonome	GARANTIE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule GAP"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kw3000ff0eguhg1ps1l	2026-02-05 16:28:19.203	2026-02-05 16:28:19.203	cml6vyl1v0017jms2uzfefv85	Assignation en référé expertise (145 CPC)	Pour obtenir une expertise judiciaire avant tout procès	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kwb000hf0eg4orvsl66	2026-02-05 16:28:19.211	2026-02-05 16:28:19.211	cml6vyl1v0017jms2uzfefv85	Assignation en référé provision	Pour obtenir une provision sur créance non contestable	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kwm000jf0egwrigk9vp	2026-02-05 16:28:19.222	2026-02-05 16:28:19.222	cml6vyl1v0017jms2uzfefv85	Conclusions en réplique (demandeur)	Conclusions du demandeur en réponse aux conclusions adverses	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kxk000rf0egody62ckq	2026-02-05 16:28:19.257	2026-02-05 16:28:19.257	cml6vyl1v0017jms2uzfefv85	Assignation en contrefaçon de marque	Action en contrefaçon devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Propriété intellectuelle	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ky5000tf0egrxk1tkef	2026-02-05 16:28:19.276	2026-02-05 16:28:19.276	cml6vyl1v0017jms2uzfefv85	Assignation en concurrence déloyale	Action pour actes de concurrence déloyale	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kym000vf0eg1t273ykx	2026-02-05 16:28:19.294	2026-02-05 16:28:19.294	cml6vyl1v0017jms2uzfefv85	Assignation en rupture brutale	Action L.442-1 II pour rupture brutale de relations commerciales	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kyt000xf0egiyb5k4rl	2026-02-05 16:28:19.301	2026-02-05 16:28:19.301	cml6vyl1v0017jms2uzfefv85	Déclaration de créance (procédure collective)	Déclaration au passif d'une procédure collective	DECLARATION	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kz4000zf0egjk4w9404	2026-02-05 16:28:19.312	2026-02-05 16:28:19.312	cml6vyl1v0017jms2uzfefv85	Revendication de marchandises	Action en revendication de biens vendus avec réserve de propriété	REQUETE	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kzh0011f0eglo4m3y21	2026-02-05 16:28:19.323	2026-02-05 16:28:19.323	cml6vyl1v0017jms2uzfefv85	Saisine Conseil de Prud'hommes - Licenciement	Contestation d'un licenciement devant le CPH	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7kzw0013f0eghrn4bklj	2026-02-05 16:28:19.34	2026-02-05 16:28:19.34	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Harcèlement moral	Action pour harcèlement moral au travail	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l0k0015f0egm3qfqp4b	2026-02-05 16:28:19.361	2026-02-05 16:28:19.361	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Rappel de salaires	Action en rappel de salaires et accessoires	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l0s0017f0egnwojbkum	2026-02-05 16:28:19.372	2026-02-05 16:28:19.372	cml6vyl1v0017jms2uzfefv85	Conclusions prud'homales (défense employeur)	Conclusions pour l'employeur en défense	CONCLUSIONS	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l100019f0egsubmvnxe	2026-02-05 16:28:19.38	2026-02-05 16:28:19.38	cml6vyl1v0017jms2uzfefv85	Transaction rupture contrat de travail	Protocole transactionnel suite à rupture du contrat	PROTOCOLE	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l17001bf0egivs1kl1s	2026-02-05 16:28:19.387	2026-02-05 16:28:19.387	cml6vyl1v0017jms2uzfefv85	Requête divorce par consentement mutuel (notaire)	Convention de divorce par consentement mutuel	REQUETE	\N	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l1d001df0egd9zvskdw	2026-02-05 16:28:19.394	2026-02-05 16:28:19.394	cml6vyl1v0017jms2uzfefv85	Requête divorce contentieux	Requête en divorce pour altération définitive du lien conjugal	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l1i001ff0egrbe33wdu	2026-02-05 16:28:19.398	2026-02-05 16:28:19.398	cml6vyl1v0017jms2uzfefv85	Requête modification pension alimentaire	Modification de la contribution à l'entretien des enfants	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l1o001hf0egn0v06kch	2026-02-05 16:28:19.404	2026-02-05 16:28:19.404	cml6vyl1v0017jms2uzfefv85	Requête droits de visite et d'hébergement	Fixation ou modification du droit de visite	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l1u001jf0eg63e3u0o6	2026-02-05 16:28:19.41	2026-02-05 16:28:19.41	cml6vyl1v0017jms2uzfefv85	Assignation en garantie décennale	Action contre le constructeur au titre de l'article 1792 CC	ASSIGNATION	Tribunal Judiciaire	Construction	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l1y001lf0eg001o8z22	2026-02-05 16:28:19.414	2026-02-05 16:28:19.414	cml6vyl1v0017jms2uzfefv85	Assignation en garantie biennale	Action en garantie de bon fonctionnement	ASSIGNATION	\N	Construction	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l27001nf0egpynqkypu	2026-02-05 16:28:19.423	2026-02-05 16:28:19.423	cml6vyl1v0017jms2uzfefv85	Assignation troubles de voisinage	Action pour troubles anormaux de voisinage	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l2d001pf0eg6zl89r8g	2026-02-05 16:28:19.429	2026-02-05 16:28:19.429	cml6vyl1v0017jms2uzfefv85	Assignation vice caché immobilier	Action rédhibitoire ou estimatoire	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l2i001rf0egbd3db474	2026-02-05 16:28:19.434	2026-02-05 16:28:19.434	cml6vyl1v0017jms2uzfefv85	Bail commercial 3-6-9	Modèle complet de bail commercial	CONTRAT	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l2p001tf0eg20e8tdat	2026-02-05 16:28:19.441	2026-02-05 16:28:19.441	cml6vyl1v0017jms2uzfefv85	Contrat de cession de parts SARL	Cession de parts sociales de SARL	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l2y001vf0eggk71yvlm	2026-02-05 16:28:19.45	2026-02-05 16:28:19.45	cml6vyl1v0017jms2uzfefv85	Contrat de cession d'actions SAS	Cession d'actions de SAS	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l33001xf0eghwjo92mk	2026-02-05 16:28:19.455	2026-02-05 16:28:19.455	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SARL	Pacte d'associés pour SARL	PACTE	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l3b001zf0eg1xzjaik0	2026-02-05 16:28:19.464	2026-02-05 16:28:19.464	cml6vyl1v0017jms2uzfefv85	Lettre d'intention (LOI)	Lettre d'intention non engageante M&A	LETTRE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l3p0021f0egdvq9lqi8	2026-02-05 16:28:19.477	2026-02-05 16:28:19.477	cml6vyl1v0017jms2uzfefv85	Protocole d'accord M&A	Protocole de cession complet avec GAP	PROTOCOLE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l3x0023f0egcvuudf6p	2026-02-05 16:28:19.485	2026-02-05 16:28:19.485	cml6vyl1v0017jms2uzfefv85	Contrat de franchise	Contrat de franchise commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l4d0025f0ege8f2cnsl	2026-02-05 16:28:19.501	2026-02-05 16:28:19.501	cml6vyl1v0017jms2uzfefv85	Contrat d'agent commercial	Contrat d'agence commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l4i0027f0egwpdqtpw9	2026-02-05 16:28:19.507	2026-02-05 16:28:19.507	cml6vyl1v0017jms2uzfefv85	Contrat de prestation de services	Contrat B2B de prestation de services	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l4v0029f0egu30f0xpp	2026-02-05 16:28:19.519	2026-02-05 16:28:19.519	cml6vyl1v0017jms2uzfefv85	CGV B2B	Conditions générales de vente professionnels	CGV	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l51002bf0egh15wja6r	2026-02-05 16:28:19.525	2026-02-05 16:28:19.525	cml6vyl1v0017jms2uzfefv85	NDA bilatéral	Accord de confidentialité bilatéral	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l5i002ff0eg5yy72jiq	2026-02-05 16:28:19.543	2026-02-05 16:28:19.543	cml6vyl1v0017jms2uzfefv85	Mise en demeure exécution obligation	Mise en demeure d'exécuter une obligation contractuelle	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l5q002hf0egvty8f982	2026-02-05 16:28:19.551	2026-02-05 16:28:19.551	cml6vyl1v0017jms2uzfefv85	Mise en demeure cessation agissements	Mise en demeure de cesser des agissements illicites	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l5w002jf0egasoroqze	2026-02-05 16:28:19.556	2026-02-05 16:28:19.556	cml6vyl1v0017jms2uzfefv85	Lettre de résiliation	Résiliation de contrat avec préavis	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l5z002lf0egy91noxxm	2026-02-05 16:28:19.56	2026-02-05 16:28:19.56	cml6vyl1v0017jms2uzfefv85	Lettre de réclamation	Réclamation amiable précontentieuse	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l65002nf0eg6ijyuh7b	2026-02-05 16:28:19.565	2026-02-05 16:28:19.565	cml6vyl1v0017jms2uzfefv85	Statuts SAS	Statuts complets de SAS	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l68002pf0eg1heywuhd	2026-02-05 16:28:19.568	2026-02-05 16:28:19.568	cml6vyl1v0017jms2uzfefv85	Statuts SARL	Statuts complets de SARL	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l6c002rf0eg30if16h4	2026-02-05 16:28:19.572	2026-02-05 16:28:19.572	cml6vyl1v0017jms2uzfefv85	PV AG Ordinaire Annuelle	PV d'approbation des comptes annuels	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l6f002tf0eg4ewsn602	2026-02-05 16:28:19.575	2026-02-05 16:28:19.575	cml6vyl1v0017jms2uzfefv85	PV AG Extraordinaire	PV de modification des statuts	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l6s002vf0egopmqxapw	2026-02-05 16:28:19.588	2026-02-05 16:28:19.588	cml6vyl1v0017jms2uzfefv85	PV nomination dirigeant	Décision de nomination d'un dirigeant	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rtg0001hcc1j2gcszbz	2026-02-05 16:28:28.18	2026-02-05 16:28:28.18	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal Judiciaire	Modèle d'assignation pour les litiges civils devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TJ"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rto0003hcc1muis1xyj	2026-02-05 16:28:28.188	2026-02-05 16:28:28.188	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal de Commerce	Modèle d'assignation pour les litiges commerciaux	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TC"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits - Litige commercial"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif - Condamnation pécuniaire"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ru10005hcc1ju0pumbr	2026-02-05 16:28:28.202	2026-02-05 16:28:28.202	cml6vyl1v0017jms2uzfefv85	Conclusions en défense	Modèle de conclusions pour la partie défenderesse	CONCLUSIONS	\N	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête conclusions"}, {"order": 2, "mandatory": true, "blockTitle": "Rappel des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ru90007hcc1f2gyd95z	2026-02-05 16:28:28.209	2026-02-05 16:28:28.209	cml6vyl1v0017jms2uzfefv85	Mise en demeure simple	Modèle de mise en demeure pour inexécution contractuelle	MISE_EN_DEMEURE	\N	Courriers	[{"order": 1, "mandatory": true, "blockTitle": "En-tête mise en demeure"}, {"order": 2, "mandatory": true, "blockTitle": "Corps mise en demeure"}, {"order": 3, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ruf0009hcc1a187moa4	2026-02-05 16:28:28.215	2026-02-05 16:28:28.215	cml6vyl1v0017jms2uzfefv85	Protocole de cession de parts sociales	Modèle complet pour cession de parts sociales SARL/SAS	PROTOCOLE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule cession"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Clause de non-concurrence"}, {"order": 4, "mandatory": true, "blockTitle": "Signatures parties"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ruz000bhcc1o7u0lb58	2026-02-05 16:28:28.235	2026-02-05 16:28:28.235	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SAS	Modèle de pacte d'associés pour SAS	PACTE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule pacte"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de sortie conjointe (tag-along)"}, {"order": 3, "mandatory": true, "blockTitle": "Clause d'entraînement (drag-along)"}, {"order": 4, "mandatory": true, "blockTitle": "Clause de confidentialité"}, {"order": 5, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rva000dhcc1npk3tkkn	2026-02-05 16:28:28.246	2026-02-05 16:28:28.246	cml6vyl1v0017jms2uzfefv85	Garantie d'actif et passif (GAP)	Convention de garantie d'actif et passif autonome	GARANTIE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule GAP"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rve000fhcc16bdc1il8	2026-02-05 16:28:28.25	2026-02-05 16:28:28.25	cml6vyl1v0017jms2uzfefv85	Assignation en référé expertise (145 CPC)	Pour obtenir une expertise judiciaire avant tout procès	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rvw000hhcc1p42q6bea	2026-02-05 16:28:28.268	2026-02-05 16:28:28.268	cml6vyl1v0017jms2uzfefv85	Assignation en référé provision	Pour obtenir une provision sur créance non contestable	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rw3000jhcc1dfdxg0ck	2026-02-05 16:28:28.275	2026-02-05 16:28:28.275	cml6vyl1v0017jms2uzfefv85	Conclusions en réplique (demandeur)	Conclusions du demandeur en réponse aux conclusions adverses	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rwb000lhcc1whnaa851	2026-02-05 16:28:28.283	2026-02-05 16:28:28.283	cml6vyl1v0017jms2uzfefv85	Conclusions récapitulatives	Conclusions finales récapitulant l'ensemble des demandes	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rwi000nhcc1dfofsw9f	2026-02-05 16:28:28.29	2026-02-05 16:28:28.29	cml6vyl1v0017jms2uzfefv85	Opposition à ordonnance d'injonction de payer	Modèle d'opposition à une injonction de payer	OPPOSITION	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rwr000phcc1gitq1ftm	2026-02-05 16:28:28.3	2026-02-05 16:28:28.3	cml6vyl1v0017jms2uzfefv85	Requête en rectification d'erreur matérielle	Pour corriger une erreur dans une décision de justice	REQUETE	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rwz000rhcc1imo7sh2m	2026-02-05 16:28:28.307	2026-02-05 16:28:28.307	cml6vyl1v0017jms2uzfefv85	Assignation en contrefaçon de marque	Action en contrefaçon devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Propriété intellectuelle	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rxa000thcc1nx4gs6c5	2026-02-05 16:28:28.319	2026-02-05 16:28:28.319	cml6vyl1v0017jms2uzfefv85	Assignation en concurrence déloyale	Action pour actes de concurrence déloyale	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rxe000vhcc1gfuckdud	2026-02-05 16:28:28.323	2026-02-05 16:28:28.323	cml6vyl1v0017jms2uzfefv85	Assignation en rupture brutale	Action L.442-1 II pour rupture brutale de relations commerciales	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rxs000xhcc12364stg4	2026-02-05 16:28:28.337	2026-02-05 16:28:28.337	cml6vyl1v0017jms2uzfefv85	Déclaration de créance (procédure collective)	Déclaration au passif d'une procédure collective	DECLARATION	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rxx000zhcc1h02p32n8	2026-02-05 16:28:28.341	2026-02-05 16:28:28.341	cml6vyl1v0017jms2uzfefv85	Revendication de marchandises	Action en revendication de biens vendus avec réserve de propriété	REQUETE	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ry70011hcc170kr2dfl	2026-02-05 16:28:28.351	2026-02-05 16:28:28.351	cml6vyl1v0017jms2uzfefv85	Saisine Conseil de Prud'hommes - Licenciement	Contestation d'un licenciement devant le CPH	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ryg0013hcc17arz99wg	2026-02-05 16:28:28.36	2026-02-05 16:28:28.36	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Harcèlement moral	Action pour harcèlement moral au travail	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ryk0015hcc11tm7tlpn	2026-02-05 16:28:28.364	2026-02-05 16:28:28.364	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Rappel de salaires	Action en rappel de salaires et accessoires	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7ryw0017hcc18zpzh7jq	2026-02-05 16:28:28.377	2026-02-05 16:28:28.377	cml6vyl1v0017jms2uzfefv85	Conclusions prud'homales (défense employeur)	Conclusions pour l'employeur en défense	CONCLUSIONS	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rz70019hcc1cij9a7nt	2026-02-05 16:28:28.388	2026-02-05 16:28:28.388	cml6vyl1v0017jms2uzfefv85	Transaction rupture contrat de travail	Protocole transactionnel suite à rupture du contrat	PROTOCOLE	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rzd001bhcc1pxzq40zd	2026-02-05 16:28:28.394	2026-02-05 16:28:28.394	cml6vyl1v0017jms2uzfefv85	Requête divorce par consentement mutuel (notaire)	Convention de divorce par consentement mutuel	REQUETE	\N	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rzq001dhcc1y2ar6ydj	2026-02-05 16:28:28.406	2026-02-05 16:28:28.406	cml6vyl1v0017jms2uzfefv85	Requête divorce contentieux	Requête en divorce pour altération définitive du lien conjugal	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rzv001fhcc17axo9ad4	2026-02-05 16:28:28.412	2026-02-05 16:28:28.412	cml6vyl1v0017jms2uzfefv85	Requête modification pension alimentaire	Modification de la contribution à l'entretien des enfants	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7rzy001hhcc1srnfr4g0	2026-02-05 16:28:28.415	2026-02-05 16:28:28.415	cml6vyl1v0017jms2uzfefv85	Requête droits de visite et d'hébergement	Fixation ou modification du droit de visite	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s02001jhcc1rup3yupb	2026-02-05 16:28:28.418	2026-02-05 16:28:28.418	cml6vyl1v0017jms2uzfefv85	Assignation en garantie décennale	Action contre le constructeur au titre de l'article 1792 CC	ASSIGNATION	Tribunal Judiciaire	Construction	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s06001lhcc1v6rol6t8	2026-02-05 16:28:28.422	2026-02-05 16:28:28.422	cml6vyl1v0017jms2uzfefv85	Assignation en garantie biennale	Action en garantie de bon fonctionnement	ASSIGNATION	\N	Construction	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s0d001nhcc1tdfcjheo	2026-02-05 16:28:28.429	2026-02-05 16:28:28.429	cml6vyl1v0017jms2uzfefv85	Assignation troubles de voisinage	Action pour troubles anormaux de voisinage	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s0m001phcc1a3eai8df	2026-02-05 16:28:28.437	2026-02-05 16:28:28.437	cml6vyl1v0017jms2uzfefv85	Assignation vice caché immobilier	Action rédhibitoire ou estimatoire	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s0w001rhcc11ylqim9y	2026-02-05 16:28:28.448	2026-02-05 16:28:28.448	cml6vyl1v0017jms2uzfefv85	Bail commercial 3-6-9	Modèle complet de bail commercial	CONTRAT	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s12001thcc15bk0gfh5	2026-02-05 16:28:28.455	2026-02-05 16:28:28.455	cml6vyl1v0017jms2uzfefv85	Contrat de cession de parts SARL	Cession de parts sociales de SARL	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s17001vhcc12gvhq572	2026-02-05 16:28:28.459	2026-02-05 16:28:28.459	cml6vyl1v0017jms2uzfefv85	Contrat de cession d'actions SAS	Cession d'actions de SAS	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s1a001xhcc1fc5ut87t	2026-02-05 16:28:28.463	2026-02-05 16:28:28.463	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SARL	Pacte d'associés pour SARL	PACTE	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s1d001zhcc1c78istur	2026-02-05 16:28:28.466	2026-02-05 16:28:28.466	cml6vyl1v0017jms2uzfefv85	Lettre d'intention (LOI)	Lettre d'intention non engageante M&A	LETTRE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s1m0021hcc1mgmhwtlg	2026-02-05 16:28:28.474	2026-02-05 16:28:28.474	cml6vyl1v0017jms2uzfefv85	Protocole d'accord M&A	Protocole de cession complet avec GAP	PROTOCOLE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s1s0023hcc11omc13l9	2026-02-05 16:28:28.48	2026-02-05 16:28:28.48	cml6vyl1v0017jms2uzfefv85	Contrat de franchise	Contrat de franchise commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s1z0025hcc13muo4xml	2026-02-05 16:28:28.487	2026-02-05 16:28:28.487	cml6vyl1v0017jms2uzfefv85	Contrat d'agent commercial	Contrat d'agence commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s270027hcc1kep2ovgz	2026-02-05 16:28:28.495	2026-02-05 16:28:28.495	cml6vyl1v0017jms2uzfefv85	Contrat de prestation de services	Contrat B2B de prestation de services	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s2b0029hcc15y08fmfn	2026-02-05 16:28:28.5	2026-02-05 16:28:28.5	cml6vyl1v0017jms2uzfefv85	CGV B2B	Conditions générales de vente professionnels	CGV	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s2j002bhcc13c0ed112	2026-02-05 16:28:28.507	2026-02-05 16:28:28.507	cml6vyl1v0017jms2uzfefv85	NDA bilatéral	Accord de confidentialité bilatéral	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s2o002dhcc1gu57n9ct	2026-02-05 16:28:28.512	2026-02-05 16:28:28.512	cml6vyl1v0017jms2uzfefv85	Mise en demeure paiement facture	Mise en demeure précontentieuse pour impayé	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s2y002fhcc1wzsveqkm	2026-02-05 16:28:28.522	2026-02-05 16:28:28.522	cml6vyl1v0017jms2uzfefv85	Mise en demeure exécution obligation	Mise en demeure d'exécuter une obligation contractuelle	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s33002hhcc1553dza5c	2026-02-05 16:28:28.528	2026-02-05 16:28:28.528	cml6vyl1v0017jms2uzfefv85	Mise en demeure cessation agissements	Mise en demeure de cesser des agissements illicites	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s3d002jhcc1r20hwlop	2026-02-05 16:28:28.538	2026-02-05 16:28:28.538	cml6vyl1v0017jms2uzfefv85	Lettre de résiliation	Résiliation de contrat avec préavis	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s3k002lhcc1dnaiva14	2026-02-05 16:28:28.544	2026-02-05 16:28:28.544	cml6vyl1v0017jms2uzfefv85	Lettre de réclamation	Réclamation amiable précontentieuse	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s3p002nhcc15yqeflzw	2026-02-05 16:28:28.549	2026-02-05 16:28:28.549	cml6vyl1v0017jms2uzfefv85	Statuts SAS	Statuts complets de SAS	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s40002phcc1sloaupfm	2026-02-05 16:28:28.561	2026-02-05 16:28:28.561	cml6vyl1v0017jms2uzfefv85	Statuts SARL	Statuts complets de SARL	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s4b002rhcc1krlznqx2	2026-02-05 16:28:28.571	2026-02-05 16:28:28.571	cml6vyl1v0017jms2uzfefv85	PV AG Ordinaire Annuelle	PV d'approbation des comptes annuels	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s4d002thcc1bdoo3j73	2026-02-05 16:28:28.574	2026-02-05 16:28:28.574	cml6vyl1v0017jms2uzfefv85	PV AG Extraordinaire	PV de modification des statuts	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7s4j002vhcc1n267ujdw	2026-02-05 16:28:28.579	2026-02-05 16:28:28.579	cml6vyl1v0017jms2uzfefv85	PV nomination dirigeant	Décision de nomination d'un dirigeant	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N	\N	\N	\N	f	\N
cml9o7l5a002df0egw7yndkbt	2026-02-05 16:28:19.533	2026-02-05 16:44:11.922	cml6vyl1v0017jms2uzfefv85	Mise en demeure paiement facture	Mise en demeure précontentieuse pour impayé	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	1	\N	\N	\N	\N	\N	f	\N
cmlb706vv0001hp340xsne4g9	2026-02-06 18:02:13.34	2026-02-06 18:02:13.34	cml88g71z0000521vp3t710u4	Assignation en Paiement - Tribunal Judiciaire	Assignation devant le Tribunal Judiciaire pour demande de condamnation au paiement d'une somme	ASSIGNATION	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 4, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 5, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 6, "title": "Article 1231-1 Code Civil - Dommages-Intérêts", "blockId": "cml88g744002e521v7p8k1pgt", "isOptional": true}, {"order": 7, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 8, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "client.nom", "adversaire.nom", "date_contrat", "objet_contrat", "montant_principal", "date_interets", "montant_451", "avocat.nom", "avocat.barreau", "huissier.nom", "juridiction", "date_audience"]	DOCX	{"category": "PROCEDURE", "description": "Assignation devant le Tribunal Judiciaire pour demande de condamnation au paiement d'une somme"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706w40003hp34w5mx0iio	2026-02-06 18:02:13.349	2026-02-06 18:02:13.349	cml88g71z0000521vp3t710u4	Assignation en Référé d'Heure à Heure	Assignation en référé d'urgence pour troubles manifestement illicites	ASSIGNATION	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Assignation Référé Urgence", "blockId": "cml88g72l0004521v67f38gmg", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "client.nom", "adversaire.nom", "motif_urgence", "date_audience", "heure_audience", "montant_principal"]	DOCX	{"category": "PROCEDURE", "description": "Assignation en référé d'urgence pour troubles manifestement illicites"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706w60005hp34mp466wc7	2026-02-06 18:02:13.351	2026-02-06 18:02:13.351	cml88g71z0000521vp3t710u4	Conclusions en Défense - Tribunal Judiciaire	Conclusions en défense pour répondre à une assignation	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions en Défense", "blockId": "cml88g72m0006521vrm2xxfs7", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Résolution Contrat + Dommages-Intérêts", "blockId": "cml88g75p004k521v49dd03ec", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg", "juridiction", "date_contrat", "avocat.nom", "avocat.barreau"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions en défense pour répondre à une assignation"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706w80007hp347m7yqzv6	2026-02-06 18:02:13.353	2026-02-06 18:02:13.353	cml88g71z0000521vp3t710u4	Requête en Référé - Mesures Conservatoires	Requête en référé pour obtenir des mesures conservatoires	REQUETE	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Requête en Référé", "blockId": "cml88g72o0008521v6l79d856", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "juridiction", "avocat.nom"]	DOCX	{"category": "PROCEDURE", "description": "Requête en référé pour obtenir des mesures conservatoires"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wa0009hp34pyvdb5ot	2026-02-06 18:02:13.354	2026-02-06 18:02:13.354	cml88g71z0000521vp3t710u4	Conclusions d'Appel - Cour d'Appel	Conclusions d'appelant devant la Cour d'Appel	CONCLUSIONS	Cour d'Appel	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Appel", "blockId": "cml88g72s000e521vgrroa0zf", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions d'appelant devant la Cour d'Appel"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wc000bhp341dorak9d	2026-02-06 18:02:13.357	2026-02-06 18:02:13.357	cml88g71z0000521vp3t710u4	Contredit - Déclinatoire de Compétence	Contredit contestant la compétence du tribunal	CONTREDIT	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Contredit", "blockId": "cml88g72t000g521vgtu9w5zz", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "numero_rg", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Contredit contestant la compétence du tribunal"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706we000dhp34n4one3b1	2026-02-06 18:02:13.358	2026-02-06 18:02:13.358	cml88g71z0000521vp3t710u4	Assignation à Jour Fixe	Assignation à jour fixe avec ordonnance préalable du président	ASSIGNATION	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Assignation Jour Fixe", "blockId": "cml88g733000q521v59duxkoq", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "client.nom", "adversaire.nom", "date_ordonnance", "juridiction", "date_audience", "heure_audience"]	DOCX	{"category": "PROCEDURE", "description": "Assignation à jour fixe avec ordonnance préalable du président"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wg000fhp345nhm3qyl	2026-02-06 18:02:13.36	2026-02-06 18:02:13.36	cml88g71z0000521vp3t710u4	Conclusions Référé-Provision	Conclusions en référé-provision pour créance non sérieusement contestable	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Référé-Provision", "blockId": "cml88g731000o521vamlkkqum", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "montant_principal"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions en référé-provision pour créance non sérieusement contestable"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wh000hhp34fn7vmssu	2026-02-06 18:02:13.362	2026-02-06 18:02:13.362	cml88g71z0000521vp3t710u4	Conclusions Intervention Volontaire	Conclusions d'intervention volontaire dans une instance en cours	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Intervention Volontaire", "blockId": "cml88g734000s521vlmw8r7ax", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "demandeur.nom", "defendeur.nom", "numero_rg"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions d'intervention volontaire dans une instance en cours"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wj000jhp34g4tyuoqu	2026-02-06 18:02:13.363	2026-02-06 18:02:13.363	cml88g71z0000521vp3t710u4	Conclusions Appel en Garantie	Conclusions pour appeler un tiers en garantie	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Appel en Garantie", "blockId": "cml88g735000u521vsg18vhsw", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "garant.nom"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions pour appeler un tiers en garantie"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wk000lhp34ip3bd6xy	2026-02-06 18:02:13.365	2026-02-06 18:02:13.365	cml88g71z0000521vp3t710u4	Ordonnance sur Requête - Saisie Conservatoire	Requête aux fins d'ordonnance sur requête pour saisie conservatoire	REQUETE	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Requête Ordonnance sur Requête", "blockId": "cml88g72y000k521vhls1iakg", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Requête aux fins d'ordonnance sur requête pour saisie conservatoire"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wm000nhp34ro6sjm5q	2026-02-06 18:02:13.366	2026-02-06 18:02:13.366	cml88g71z0000521vp3t710u4	Conclusions Rétractation Ordonnance	Conclusions aux fins de rétractation d'une ordonnance sur requête	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Rétractation", "blockId": "cml88g72z000m521vpjyagym7", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "date_ordonnance"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions aux fins de rétractation d'une ordonnance sur requête"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wo000php34cns0tx9f	2026-02-06 18:02:13.368	2026-02-06 18:02:13.368	cml88g71z0000521vp3t710u4	Conclusions Récusation Juge	Conclusions aux fins de récusation d'un magistrat	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Récusation", "blockId": "cml88g72w000i521viuoi7gl9", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "juge.nom", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions aux fins de récusation d'un magistrat"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wp000rhp343ot4dnp0	2026-02-06 18:02:13.37	2026-02-06 18:02:13.37	cml88g71z0000521vp3t710u4	Mémoire en Réplique	Mémoire en réplique suite aux conclusions adverses	MEMOIRE	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Mémoire en Réplique", "blockId": "cml88g72r000c521vlxm2tbb5", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg", "date_conclusions_adversaire"]	DOCX	{"category": "PROCEDURE", "description": "Mémoire en réplique suite aux conclusions adverses"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wr000thp34be7a0yrm	2026-02-06 18:02:13.371	2026-02-06 18:02:13.371	cml88g71z0000521vp3t710u4	Conclusions sur Incident	Conclusions sur incident soulevé en cours d'instance	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Incident", "blockId": "cml88g72p000a521vt2ugqmlk", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions sur incident soulevé en cours d'instance"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wt000vhp34q8z9feyw	2026-02-06 18:02:13.374	2026-02-06 18:02:13.374	cml88g71z0000521vp3t710u4	Contrat de Vente - Bien Mobilier	Contrat de vente d'un bien mobilier corporel	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 4, "title": "Clause Pénale", "blockId": "cml88g7700066521vu500prh2", "isOptional": true}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["vendeur.nom", "acquereur.nom", "prix_vente", "description_bien"]	DOCX	{"category": "CONTRAT", "description": "Contrat de vente d'un bien mobilier corporel"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706ww000xhp34eg5n2kj0	2026-02-06 18:02:13.377	2026-02-06 18:02:13.377	cml88g71z0000521vp3t710u4	Contrat de Prestation de Services	Contrat de prestation de services entre professionnels	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Clause Pénale", "blockId": "cml88g7700066521vu500prh2", "isOptional": true}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["prestataire.nom", "client.nom", "objet_prestation", "prix"]	DOCX	{"category": "CONTRAT", "description": "Contrat de prestation de services entre professionnels"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706wy000zhp34bwg5alim	2026-02-06 18:02:13.378	2026-02-06 18:02:13.378	cml88g71z0000521vp3t710u4	Bail Commercial	Bail commercial 3-6-9 pour locaux professionnels	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["bailleur.nom", "preneur.nom", "adresse_locaux", "montant_loyer"]	DOCX	{"category": "CONTRAT", "description": "Bail commercial 3-6-9 pour locaux professionnels"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x00011hp3456eaf82x	2026-02-06 18:02:13.38	2026-02-06 18:02:13.38	cml88g71z0000521vp3t710u4	Contrat de Mandat	Contrat de mandat général ou spécial	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["mandant.nom", "mandataire.nom", "objet_mandat"]	DOCX	{"category": "CONTRAT", "description": "Contrat de mandat général ou spécial"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x10013hp34txq4vfe4	2026-02-06 18:02:13.382	2026-02-06 18:02:13.382	cml88g71z0000521vp3t710u4	Contrat de Sous-Traitance	Contrat de sous-traitance industrielle ou commerciale	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Clause Pénale", "blockId": "cml88g7700066521vu500prh2", "isOptional": true}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["entrepreneur.nom", "soustraitant.nom", "objet"]	DOCX	{"category": "CONTRAT", "description": "Contrat de sous-traitance industrielle ou commerciale"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x30015hp348j58ab4v	2026-02-06 18:02:13.383	2026-02-06 18:02:13.383	cml88g71z0000521vp3t710u4	Contrat de Distribution	Contrat de distribution exclusive ou sélective	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["fournisseur.nom", "distributeur.nom", "territoire"]	DOCX	{"category": "CONTRAT", "description": "Contrat de distribution exclusive ou sélective"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x40017hp34v21wzsdp	2026-02-06 18:02:13.385	2026-02-06 18:02:13.385	cml88g71z0000521vp3t710u4	Contrat de Franchise	Contrat de franchise commerciale	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["franchiseur.nom", "franchise.nom", "redevance"]	DOCX	{"category": "CONTRAT", "description": "Contrat de franchise commerciale"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x50019hp34z1hkmmaf	2026-02-06 18:02:13.386	2026-02-06 18:02:13.386	cml88g71z0000521vp3t710u4	Promesse Unilatérale de Vente	Promesse unilatérale de vente immobilière	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["promettant.nom", "beneficiaire.nom", "prix", "delai_option"]	DOCX	{"category": "CONTRAT", "description": "Promesse unilatérale de vente immobilière"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x7001bhp34wthwv821	2026-02-06 18:02:13.387	2026-02-06 18:02:13.387	cml88g71z0000521vp3t710u4	Compromis de Vente Immobilier	Compromis de vente pour bien immobilier	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["vendeur.nom", "acquereur.nom", "adresse_bien", "prix"]	DOCX	{"category": "CONTRAT", "description": "Compromis de vente pour bien immobilier"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706x9001dhp34coqv58f0	2026-02-06 18:02:13.389	2026-02-06 18:02:13.389	cml88g71z0000521vp3t710u4	Avenant Contrat Commercial	Avenant modificatif à un contrat commercial existant	AVENANT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["partie1.nom", "partie2.nom", "date_contrat_initial", "modifications"]	DOCX	{"category": "CONTRAT", "description": "Avenant modificatif à un contrat commercial existant"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xb001fhp34pm57foit	2026-02-06 18:02:13.391	2026-02-06 18:02:13.391	cml88g71z0000521vp3t710u4	Protocole de Cession de Parts Sociales	Protocole de cession de parts sociales avec garantie d'actif et de passif	PROTOCOLE	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Contexte Cession Parts Sociales", "blockId": "cml88g73a0012521vfng0ohzi", "isOptional": false}, {"order": 3, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["cedant.nom", "cessionnaire.nom", "societe_cible", "prix_cession", "nombre_parts", "pourcentage", "montant_gap", "duree_gap"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Protocole de cession de parts sociales avec garantie d'actif et de passif"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xd001hhp34zj69djta	2026-02-06 18:02:13.393	2026-02-06 18:02:13.393	cml88g71z0000521vp3t710u4	Statuts SARL	Statuts constitutifs d'une SARL	STATUTS	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["denomination", "siege", "objet", "capital", "associes"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Statuts constitutifs d'une SARL"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xe001jhp346btp9qk7	2026-02-06 18:02:13.394	2026-02-06 18:02:13.394	cml88g71z0000521vp3t710u4	Statuts SAS	Statuts constitutifs d'une SAS	STATUTS	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["denomination", "siege", "objet", "capital", "president.nom"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Statuts constitutifs d'une SAS"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xg001lhp34ih94qc17	2026-02-06 18:02:13.396	2026-02-06 18:02:13.396	cml88g71z0000521vp3t710u4	Pacte d'Associés	Pacte d'associés extra-statutaire	PACTE	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "associes", "date_statuts"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Pacte d'associés extra-statutaire"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xh001nhp34ubzbn8zi	2026-02-06 18:02:13.398	2026-02-06 18:02:13.398	cml88g71z0000521vp3t710u4	PV Assemblée Générale Ordinaire	Procès-verbal d'assemblée générale ordinaire annuelle	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "date_ag", "president_seance", "resolutions"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Procès-verbal d'assemblée générale ordinaire annuelle"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xj001php34p29w31lk	2026-02-06 18:02:13.399	2026-02-06 18:02:13.399	cml88g71z0000521vp3t710u4	PV Assemblée Générale Extraordinaire	Procès-verbal d'AGE pour modification statutaire	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "date_age", "modifications_statutaires"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Procès-verbal d'AGE pour modification statutaire"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xk001rhp34cog0ao4t	2026-02-06 18:02:13.401	2026-02-06 18:02:13.401	cml88g71z0000521vp3t710u4	Augmentation de Capital	Résolution d'augmentation de capital social	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "capital_actuel", "montant_augmentation", "modalites"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Résolution d'augmentation de capital social"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xm001thp34ux47m3hq	2026-02-06 18:02:13.402	2026-02-06 18:02:13.402	cml88g71z0000521vp3t710u4	Dissolution Anticipée	Résolution de dissolution anticipée de société	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "motif_dissolution", "liquidateur.nom"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Résolution de dissolution anticipée de société"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xn001vhp34kxf5zin1	2026-02-06 18:02:13.403	2026-02-06 18:02:13.403	cml88g71z0000521vp3t710u4	Cession de Fonds de Commerce	Acte de cession de fonds de commerce	ACTE	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["vendeur.nom", "acquereur.nom", "fonds", "prix"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Acte de cession de fonds de commerce"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xo001xhp341two30ai	2026-02-06 18:02:13.405	2026-02-06 18:02:13.405	cml88g71z0000521vp3t710u4	Fusion-Absorption	Projet de fusion par absorption entre deux sociétés	PROJET	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe_absorbante", "societe_absorbee", "parite_echange"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Projet de fusion par absorption entre deux sociétés"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xq001zhp34fh63s90k	2026-02-06 18:02:13.407	2026-02-06 18:02:13.407	cml88g71z0000521vp3t710u4	Mise en Demeure de Payer	Lettre de mise en demeure pour impayés	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "client.nom", "montant_du", "delai_paiement"]	DOCX	{"category": "COURRIER", "description": "Lettre de mise en demeure pour impayés"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xs0021hp34wynsddg2	2026-02-06 18:02:13.408	2026-02-06 18:02:13.408	cml88g71z0000521vp3t710u4	Mise en Demeure d'Exécuter	Mise en demeure d'exécuter une obligation contractuelle	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "obligation", "delai"]	DOCX	{"category": "COURRIER", "description": "Mise en demeure d'exécuter une obligation contractuelle"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xt0023hp3456zucsky	2026-02-06 18:02:13.41	2026-02-06 18:02:13.41	cml88g71z0000521vp3t710u4	Notification de Résiliation	Courrier de notification de résiliation de contrat	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "date_contrat", "motif_resiliation", "date_effet"]	DOCX	{"category": "COURRIER", "description": "Courrier de notification de résiliation de contrat"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xu0025hp34qvnlfosr	2026-02-06 18:02:13.411	2026-02-06 18:02:13.411	cml88g71z0000521vp3t710u4	Convocation Assemblée Générale	Convocation à une assemblée générale d'associés	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "date_ag", "lieu", "ordre_du_jour"]	DOCX	{"category": "COURRIER", "description": "Convocation à une assemblée générale d'associés"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xw0027hp3445rwmcrj	2026-02-06 18:02:13.412	2026-02-06 18:02:13.412	cml88g71z0000521vp3t710u4	Réclamation Livraison Non-Conforme	Réclamation pour livraison non conforme à la commande	COURRIER	\N	COURRIER	[{"order": 1, "title": "Litige Livraison Marchandises", "blockId": "cml88g73b0014521v1mmtupxt", "isOptional": false}, {"order": 2, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "numero_commande", "date_livraison", "non_conformites"]	DOCX	{"category": "COURRIER", "description": "Réclamation pour livraison non conforme à la commande"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xx0029hp3471r5czz8	2026-02-06 18:02:13.414	2026-02-06 18:02:13.414	cml88g71z0000521vp3t710u4	Protestation Refus de Livraison	Protestation suite à un refus de livraison	COURRIER	\N	COURRIER	[{"order": 1, "title": "Litige Livraison Marchandises", "blockId": "cml88g73b0014521v1mmtupxt", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "date_refus", "motif_refus"]	DOCX	{"category": "COURRIER", "description": "Protestation suite à un refus de livraison"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706xz002bhp34aah65a8t	2026-02-06 18:02:13.416	2026-02-06 18:02:13.416	cml88g71z0000521vp3t710u4	Demande d'Indemnisation Assurance	Demande d'indemnisation auprès d'une compagnie d'assurance	COURRIER	\N	COURRIER	[{"order": 1, "title": "Accident Circulation Détaillé", "blockId": "cml88g73c0016521vpptdo7n1", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["compagnie", "numero_police", "date_sinistre", "montant_demande"]	DOCX	{"category": "COURRIER", "description": "Demande d'indemnisation auprès d'une compagnie d'assurance"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706y1002dhp343y285uyx	2026-02-06 18:02:13.417	2026-02-06 18:02:13.417	cml88g71z0000521vp3t710u4	Contestation Licenciement	Courrier de contestation d'un licenciement	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rupture Abusive Contrat Travail", "blockId": "cml88g73d0018521v8nv8mlww", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["employeur", "date_licenciement", "arguments_contestation"]	DOCX	{"category": "COURRIER", "description": "Courrier de contestation d'un licenciement"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706y2002fhp347f5tf1vb	2026-02-06 18:02:13.419	2026-02-06 18:02:13.419	cml88g71z0000521vp3t710u4	Demande de Documents	Demande de communication de documents ou pièces	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "documents_demandes", "delai"]	DOCX	{"category": "COURRIER", "description": "Demande de communication de documents ou pièces"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706y4002hhp34deofolyo	2026-02-06 18:02:13.42	2026-02-06 18:02:13.42	cml88g71z0000521vp3t710u4	Réponse à Mise en Demeure	Réponse à une mise en demeure reçue	COURRIER	\N	COURRIER	[{"order": 1, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 2, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "date_mise_en_demeure", "reponse"]	DOCX	{"category": "COURRIER", "description": "Réponse à une mise en demeure reçue"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706y7002jhp34k7vqbdss	2026-02-06 18:02:13.423	2026-02-06 18:02:13.423	cml88g71z0000521vp3t710u4	Assignation Vice Caché Immobilier	Assignation en garantie des vices cachés suite à une vente immobilière	ASSIGNATION	Tribunal Judiciaire	IMMOBILIER	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Vice Caché Vente Immobilière", "blockId": "cml88g73f001c521vcqqf772a", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Résolution Contrat + Dommages-Intérêts", "blockId": "cml88g75p004k521v49dd03ec", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "acquereur.nom", "vendeur.nom", "adresse_bien", "date_vente", "prix_vente", "description_vices", "expert.nom"]	DOCX	{"category": "IMMOBILIER", "description": "Assignation en garantie des vices cachés suite à une vente immobilière"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706y8002lhp3416nzan34	2026-02-06 18:02:13.425	2026-02-06 18:02:13.425	cml88g71z0000521vp3t710u4	Assignation Troubles de Voisinage	Assignation pour troubles anormaux de voisinage	ASSIGNATION	Tribunal Judiciaire	IMMOBILIER	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Troubles Voisinage", "blockId": "cml88g73e001a521vr9lcyh1r", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["demandeur.nom", "defendeur.nom", "adresse_demandeur", "adresse_defendeur", "description_troubles", "date_debut_troubles"]	DOCX	{"category": "IMMOBILIER", "description": "Assignation pour troubles anormaux de voisinage"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706ya002nhp340mek64ry	2026-02-06 18:02:13.426	2026-02-06 18:02:13.426	cml88g71z0000521vp3t710u4	Assignation Expulsion Impayés Loyers	Assignation en expulsion pour impayés de loyers avec clause résolutoire	ASSIGNATION	Tribunal Judiciaire	IMMOBILIER	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Impayés Loyers Commercial", "blockId": "cml88g73g001e521vo5wrzbou", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Résolution Contrat + Dommages-Intérêts", "blockId": "cml88g75p004k521v49dd03ec", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["bailleur.nom", "preneur.nom", "adresse_locaux", "montant_loyer", "montant_total_impaye", "nombre_mois", "date_commandement"]	DOCX	{"category": "IMMOBILIER", "description": "Assignation en expulsion pour impayés de loyers avec clause résolutoire"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706yc002php345mwhngn3	2026-02-06 18:02:13.428	2026-02-06 18:02:13.428	cml88g71z0000521vp3t710u4	Bail d'Habitation	Contrat de bail d'habitation meublée ou non meublée	CONTRAT	\N	IMMOBILIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["bailleur.nom", "locataire.nom", "adresse_logement", "loyer", "charges", "depot_garantie"]	DOCX	{"category": "IMMOBILIER", "description": "Contrat de bail d'habitation meublée ou non meublée"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
cmlb706ye002rhp34h99vj0ck	2026-02-06 18:02:13.43	2026-02-06 18:02:13.43	cml88g71z0000521vp3t710u4	État des Lieux Contradictoire	État des lieux d'entrée ou de sortie de location	ETAT_LIEUX	\N	IMMOBILIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["type_etat_lieux", "date", "adresse_logement", "bailleur.nom", "locataire.nom"]	DOCX	{"category": "IMMOBILIER", "description": "État des lieux d'entrée ou de sortie de location"}	\N	t	0	\N	\N	\N	\N	\N	f	\N
\.


--
-- Data for Name: client_access_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_access_logs (id, "createdAt", "accessId", action, "ipAddress", "userAgent") FROM stdin;
cml9krpwn000711bi27rzlbwe	2026-02-05 14:52:00.359	cml9kquol000511bis5jf9ebt	ACCOUNT_ACTIVATED	127.0.0.1	curl/8.5.0
cml9krwah000911biu0wbnj9v	2026-02-05 14:52:08.634	cml9kquol000511bis5jf9ebt	LOGIN	127.0.0.1	curl/8.5.0
cml9krwcm000b11bijsmtpetv	2026-02-05 14:52:08.71	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9ks4x7000d11bi9fh2njoa	2026-02-05 14:52:19.819	cml9kquol000511bis5jf9ebt	LOGIN	127.0.0.1	curl/8.5.0
cml9ks4y1000f11birbdbugcd	2026-02-05 14:52:19.849	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9ks4zc000h11bi1cflp194	2026-02-05 14:52:19.896	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9kskvu000r11bihu9vt38w	2026-02-05 14:52:40.506	cml9kquol000511bis5jf9ebt	LOGIN	127.0.0.1	curl/8.5.0
cml9kskww000t11bimijkihyo	2026-02-05 14:52:40.544	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9kskyv000v11biejtp5pop	2026-02-05 14:52:40.616	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cmlb53w0j0008veb5f6d3t78i	2026-02-06 17:09:06.643	cmlb53jwl0001veb5f18uapym	ACCOUNT_ACTIVATED	127.0.0.1	Python-urllib/3.12
cmlb53w0v000aveb5e8aipmj1	2026-02-06 17:09:06.656	cmlb53jwl0001veb5f18uapym	API_REQUEST	127.0.0.1	Python-urllib/3.12
cmlb53w1a000cveb54hlbmy8q	2026-02-06 17:09:06.67	cmlb53jwl0001veb5f18uapym	API_REQUEST	127.0.0.1	Python-urllib/3.12
cmlb53w1n000eveb5tkh0tjpb	2026-02-06 17:09:06.683	cmlb53jwl0001veb5f18uapym	API_REQUEST	127.0.0.1	Python-urllib/3.12
cmlb53w2k000kveb5tov5avz9	2026-02-06 17:09:06.717	cmlb53jwl0001veb5f18uapym	API_REQUEST	127.0.0.1	Python-urllib/3.12
cmlb53w2z000mveb5cv3q88wg	2026-02-06 17:09:06.731	cmlb53jwl0001veb5f18uapym	API_REQUEST	127.0.0.1	Python-urllib/3.12
\.


--
-- Data for Name: client_accesses; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_accesses (id, "createdAt", "updatedAt", "folderId", email, "passwordHash", "activationToken", "tokenExpiresAt", "isActivated", "lastLoginAt") FROM stdin;
cml9kquol000511bis5jf9ebt	2026-02-05 14:51:19.893	2026-02-05 14:52:40.502	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	jean.dupont@techcorp.fr	$2b$10$Xu3UCnjrutRuXs/J4bo6huQvCPY7n/s8O4V3tfvWw77wEEHeBx9qm	\N	\N	t	2026-02-05 14:52:40.501
cmlb53jwl0001veb5f18uapym	2026-02-06 17:08:50.95	2026-02-06 17:09:06.64	cmlb18ypu0004f4ha1yi87is2	wizard.test2@example.fr	$2b$10$J/P2o.bUX4sOciSLuIW63OuAhrQpUBh0xWyW6XA6X5BYtb0IxTRte	\N	\N	t	\N
cmlc7tcx20007g2ouzqsffwct	2026-02-07 11:12:40.359	2026-02-07 11:36:34.353	cmlc7t86l0003g2ouf76d74yj	jfper54@gmail.com	\N	86eb4011e2d7fac9d01727525bba1cf51f46e3b868c1c304cd6f104a0a3e194f	2026-02-14 11:36:34.35	f	\N
\.


--
-- Data for Name: client_consents; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_consents (id, "createdAt", "clientId", type, granted, "grantedAt", "ipAddress", "userAgent") FROM stdin;
cml6vyl0r0009jms2v73bxbzx	2026-02-03 17:41:57.868	cml6vykuw0006jms2difazkpa	DATA_PROCESSING	t	2026-02-03 17:41:57.868	192.168.1.100	\N
cml6vyl0r000ajms2e0pu8hwu	2026-02-03 17:41:57.868	cml6vykuw0006jms2difazkpa	EMAIL_NOTIFICATIONS	t	2026-02-03 17:41:57.868	192.168.1.100	\N
cml6vyl0r000bjms2rvuggnqr	2026-02-03 17:41:57.868	cml6vyl0p0008jms2dt1u0gp1	DATA_PROCESSING	t	2026-02-03 17:41:57.868	192.168.1.101	\N
\.


--
-- Data for Name: client_reminders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_reminders (id, "createdAt", "tenantId", "clientId", type, "referenceId", "scheduledAt", "sentAt", "reminderNumber", channel, status) FROM stdin;
cmlb53jx50002veb51824tuai	2026-02-06 17:08:50.97	cml6vykdd0000jms2wwxl9s27	cmlb18ypa0002f4haozbrecum	profile_completion	\N	2026-02-09 17:08:50.968	\N	1	email	pending
cmlb53jxc0003veb5vau7asn8	2026-02-06 17:08:50.976	cml6vykdd0000jms2wwxl9s27	cmlb18ypa0002f4haozbrecum	profile_completion	\N	2026-02-13 17:08:50.968	\N	2	email	pending
cmlb53jxe0004veb5zorlzgy1	2026-02-06 17:08:50.979	cml6vykdd0000jms2wwxl9s27	cmlb18ypa0002f4haozbrecum	profile_completion	\N	2026-02-20 17:08:50.968	\N	3	email	pending
cmlc7tcxb0008g2ouofkymmq1	2026-02-07 11:12:40.367	cml6vykdd0000jms2wwxl9s27	cmlc6ju1k0016yhmm97qv58zj	profile_completion	\N	2026-02-10 11:12:40.366	\N	1	email	pending
cmlc7tcxg0009g2ouwq55wqfu	2026-02-07 11:12:40.373	cml6vykdd0000jms2wwxl9s27	cmlc6ju1k0016yhmm97qv58zj	profile_completion	\N	2026-02-14 11:12:40.366	\N	2	email	pending
cmlc7tcxi000ag2ouplreq3n8	2026-02-07 11:12:40.375	cml6vykdd0000jms2wwxl9s27	cmlc6ju1k0016yhmm97qv58zj	profile_completion	\N	2026-02-21 11:12:40.366	\N	3	email	pending
cmlc8o3ef000063r7dovfqe6y	2026-02-07 11:36:34.36	cml6vykdd0000jms2wwxl9s27	cmlc6ju1k0016yhmm97qv58zj	profile_completion	\N	2026-02-10 11:36:34.359	\N	1	email	pending
cmlc8o3ei000163r7na3lsf3r	2026-02-07 11:36:34.362	cml6vykdd0000jms2wwxl9s27	cmlc6ju1k0016yhmm97qv58zj	profile_completion	\N	2026-02-14 11:36:34.359	\N	2	email	pending
cmlc8o3ej000263r7vpi4irmf	2026-02-07 11:36:34.364	cml6vykdd0000jms2wwxl9s27	cmlc6ju1k0016yhmm97qv58zj	profile_completion	\N	2026-02-21 11:36:34.359	\N	3	email	pending
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.clients (id, "createdAt", "updatedAt", type, "firstName", "lastName", "birthDate", "companyName", siret, "vatNumber", email, phone, mobile, address, "addressLine2", "postalCode", city, country, "hasExternet", "extranetPassword", "extranetActivatedAt", "extranetLastLoginAt", "invitationToken", "invitationSentAt", "invitationExpiresAt", "isActive", notes, "tenantId", "adressePro", capital, civilite, "complementAdressePerso", "complementAdressePro", "conjointDateNaissance", "conjointNationalite", "conjointNom", "conjointPrenom", "conjointProfession", "cpPro", "dateContratMariage", "deletedAt", "departementNaissance", "emailSecondaire", fax, "formeSociale", "lieuNaissance", "mereNomJeuneFille", "merePrenom", nationalite, "nbEnfantsMajeurs", "nbEnfantsMineurs", "nomUsage", "notaireMariage", "objetSocial", "paysNaissance", "paysPro", "pereNom", "perePrenom", profession, "profileCompletionPercent", "profileLastStep", "profileSubmittedAt", "profileSubmittedVersion", rcs, "regimeMatrimonial", secu, siege, "situationFamiliale", "telPro", "villePro") FROM stdin;
cml6vykuw0006jms2difazkpa	2026-02-03 17:41:57.657	2026-02-03 17:41:57.657	COMPANY	\N	\N	\N	Tech Corp SAS	98765432100012	\N	jean.dupont@techcorp.fr	01 23 45 67 89	\N	456 Avenue de la Tech	\N	75001	Paris	FR	t	$2b$12$sR8AP6dslrQvCMFA60H5NePCJ7KenwISMAs9W58Y1LXRKyQcagv3q	2026-02-03 17:41:57.656	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Française	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cml6vyl0p0008jms2dt1u0gp1	2026-02-03 17:41:57.865	2026-02-03 17:41:57.865	INDIVIDUAL	Marie	Durand	\N	\N	\N	\N	marie.durand@email.fr	06 12 34 56 78	\N	789 Rue des Fleurs	\N	49100	Angers	FR	t	$2b$12$UTgWyiWCdi4/nw4xSO5cv.E.dhLPpMwNd5915A8JAh6vCzSdoCb0q	2026-02-03 17:41:57.864	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Française	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cml8feb1j000110pf02s3lt88	2026-02-04 19:33:50.311	2026-02-04 19:33:50.311	COMPANY	\N	\N	\N	StartupX SARL	\N	\N	hello@startupx.fr	\N	\N	\N	\N	\N	\N	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Française	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cml8feb1q000310pfqjw2w14v	2026-02-04 19:33:50.319	2026-02-04 19:33:50.319	COMPANY	\N	\N	\N	InnovCo SAS	\N	\N	contact@innovco.fr	\N	\N	\N	\N	\N	\N	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Française	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
seed-client-dupont-pp	2026-02-06 14:25:51.928	2026-02-06 14:25:51.928	INDIVIDUAL	Jean	DUPONT	\N	\N	\N	\N	jean.dupont@example.fr	06 12 34 56 78	\N	15 rue de la République	\N	75001	Paris	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	M.	\N	\N	\N	\N	DUPONT	Marie	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Française	0	2	\N	\N	\N	\N	\N	\N	\N	Directeur général	38	1	\N	0	\N	communaute_legale	\N	\N	marie	\N	\N
seed-client-techcorp-pm	2026-02-06 14:25:51.937	2026-02-06 14:25:51.937	COMPANY	\N	\N	\N	Tech Corp SAS	98765432100012	\N	direction@techcorp-seed.fr	01 23 45 67 89	\N	100 avenue des Champs-Élysées	\N	75008	Paris	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	100 000 €	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SAS	\N	\N	\N	FranÃ§aise	0	0	\N	\N	Développement et édition de logiciels	\N	\N	\N	\N	\N	55	2	\N	0	Paris B 123 456 789	\N	\N	100 avenue des Champs-Élysées, 75008 Paris	\N	\N	\N
cmlc6ju1k0016yhmm97qv58zj	2026-02-07 10:37:16.377	2026-02-09 13:49:27.839	COMPANY	\N	\N	\N	sdf<s	\N	\N	jfper54@gmail.com	\N	\N	\N	\N	\N	\N	France	t	\N	\N	\N	d80af0c85e432b3ce94e9981421ad1b2034b83e602639a3f92500e0d75f50a5c	2026-02-09 13:49:27.837	2026-02-16 13:49:27.837	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	10	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb6wnpi000atwwibq1619g7	2026-02-06 17:59:28.518	2026-02-06 17:59:28.596	INDIVIDUAL	ClientModifie	TEST-E2E	\N	\N	\N	\N	test-e2e-1770400768495@test.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	\N	\N	\N	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 17:59:28.595	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb0cd22000111ycyr1u3abi	2026-02-06 14:55:43.898	2026-02-06 14:55:43.972	INDIVIDUAL	API	Test	\N	\N	\N	\N	test.api@example.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	5dcffea0dddbe598e3a2aff8d5f1c41b5ecba43fdbc99dc979681c23505eeede	2026-02-06 14:55:43.93	2026-02-13 14:55:43.93	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 14:55:43.971	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	Dupont	Jean	\N	26	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb18ypa0002f4haozbrecum	2026-02-06 15:21:04.94	2026-02-06 17:09:06.692	INDIVIDUAL	Jean	TestWizard	1985-03-15 00:00:00	\N	\N	\N	wizard.test2@example.fr	\N	\N	\N	\N	\N	\N	FR	t	\N	\N	\N	86c2467434054612f920421cf6dbde50af2521fc43f34d1f09997908ec8ad88e	2026-02-06 17:08:50.96	2026-02-13 17:08:50.946	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	M.	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	40	1	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb63n48000x1021lafmd6nw	2026-02-06 17:36:54.728	2026-02-06 17:36:54.805	INDIVIDUAL	ClientModifie	TEST-E2E	\N	\N	\N	\N	test-e2e-1770399414709@test.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	\N	\N	\N	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 17:36:54.804	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb6wsr4000ttwwicmehqmiu	2026-02-06 17:59:35.056	2026-02-06 17:59:35.12	INDIVIDUAL	ClientModifie	TEST-E2E	\N	\N	\N	\N	test-e2e-1770400775025@test.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	\N	\N	\N	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 17:59:35.12	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb6amcr0001bx8t8nqvtc99	2026-02-06 17:42:20.331	2026-02-06 17:42:20.404	INDIVIDUAL	ClientModifie	TEST-E2E	\N	\N	\N	\N	test-e2e-1770399740310@test.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	\N	\N	\N	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 17:42:20.403	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9mwg00001yhmm9793jvco	2026-02-06 19:15:52.128	2026-02-06 19:15:52.245	INDIVIDUAL	ClientModifie	TEST-E2E	\N	\N	\N	\N	test-e2e-1770405352088@test.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	\N	\N	\N	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 19:15:52.244	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb6y3qd001qtwwi7vsevje5	2026-02-06 18:00:35.941	2026-02-06 18:00:36.012	INDIVIDUAL	ClientModifie	TEST-E2E	\N	\N	\N	\N	test-e2e-1770400835929@test.fr	\N	\N	\N	\N	\N	\N	France	f	\N	\N	\N	\N	\N	\N	f	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-06 18:00:36.011	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	19	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldx70001o0tamiqnlfuf	2026-02-06 19:14:41.467	2026-02-06 19:14:41.467	INDIVIDUAL	Marie	Dupont	\N	\N	\N	\N	marie.dupont+demo@test.fr	06 12 34 56 78	\N	15 rue de la Paix	\N	75002	Paris	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldxj0003o0tact9t3n7s	2026-02-06 19:14:41.48	2026-02-06 19:14:41.48	INDIVIDUAL	Jean-Pierre	Martin	\N	\N	\N	\N	jp.martin+demo@test.fr	06 98 76 54 32	\N	8 avenue Foch	\N	69006	Lyon	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldxp0005o0taeu0aa0c9	2026-02-06 19:14:41.486	2026-02-06 19:14:41.486	COMPANY	\N	\N	\N	SCI Les Tilleuls	98765432100012	\N	sci.tilleuls+demo@test.fr	\N	\N	22 bd Haussmann	\N	75009	Paris	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SCI	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldxw0007o0tanjtunl3y	2026-02-06 19:14:41.492	2026-02-06 19:14:41.492	INDIVIDUAL	Sophie	Bernard	\N	\N	\N	\N	sophie.bernard+demo@test.fr	07 11 22 33 44	\N	3 place Bellecour	\N	69002	Lyon	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	Mme	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldy20009o0ta4lwkj7em	2026-02-06 19:14:41.498	2026-02-06 19:14:41.498	COMPANY	\N	\N	\N	SARL Tech Solutions	12398765400056	\N	tech.solutions+demo@test.fr	\N	\N	10 rue du Commerce	\N	44000	Nantes	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SARL	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldy6000bo0ta884dgygv	2026-02-06 19:14:41.503	2026-02-06 19:14:41.503	INDIVIDUAL	Pierre	Leroy	\N	\N	\N	\N	pierre.leroy+demo@test.fr	06 55 44 33 22	\N	45 rue Gambetta	\N	33000	Bordeaux	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
cmlb9ldyc000do0tayw7fbac9	2026-02-06 19:14:41.508	2026-02-06 19:14:41.508	INDIVIDUAL	Isabelle	Moreau	\N	\N	\N	\N	isabelle.moreau+demo@test.fr	06 77 88 99 00	\N	12 rue Victor Hugo	\N	31000	Toulouse	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27	\N	\N	Mme	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	FranÃ§aise	0	0	\N	\N	\N	\N	\N	\N	\N	\N	0	0	\N	0	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: conversation_participants; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.conversation_participants (id, "createdAt", "conversationId", "userId", "lastReadAt", "unreadCount", "notificationsEnabled") FROM stdin;
cmlb9lukt009bxjn8a175pwis	2026-02-06 19:15:03.053	cmlb9lukn009axjn8twr540rj	cml6vykp40004jms2d2rnfrpm	2026-02-06 19:15:03.052	0	t
cmlb9lukt009cxjn8ogeiw1nc	2026-02-06 19:15:03.053	cmlb9lukn009axjn8twr540rj	cml6vykja0002jms2hhr4hfr3	2026-02-06 08:02:03.052	0	t
cmlb9luln009mxjn8vp1zl9qn	2026-02-06 19:15:03.083	cmlb9lulk009lxjn8cmhfrifh	cml6vykp40004jms2d2rnfrpm	2026-02-06 19:15:03.082	0	t
cmlb9luln009nxjn81wbd9vqh	2026-02-06 19:15:03.083	cmlb9lulk009lxjn8cmhfrifh	cml6vykja0002jms2hhr4hfr3	2026-02-06 13:02:03.082	1	t
cmlb9lum7009vxjn8f60nq8bn	2026-02-06 19:15:03.103	cmlb9lum3009uxjn8bwqou45g	cml6vykp40004jms2d2rnfrpm	2026-02-06 19:15:03.102	0	t
cmlb9lum7009wxjn88vgogyoc	2026-02-06 19:15:03.103	cmlb9lum3009uxjn8bwqou45g	cml6vykja0002jms2hhr4hfr3	2026-02-06 13:47:03.102	2	t
cmlb9lumu00aaxjn8zqtgblbn	2026-02-06 19:15:03.127	cmlb9lums00a9xjn8kgzqgri6	cml6vykp40004jms2d2rnfrpm	2026-02-06 19:15:03.126	0	t
cmlb9lumv00abxjn8b99agne8	2026-02-06 19:15:03.127	cmlb9lums00a9xjn8kgzqgri6	cml6vykja0002jms2hhr4hfr3	2026-02-06 12:33:03.126	2	t
cmlb9luni00apxjn8qsvy9ujs	2026-02-06 19:15:03.151	cmlb9lung00aoxjn82aqttyw5	cml6vykp40004jms2d2rnfrpm	2026-02-06 19:15:03.15	0	t
cmlb9luni00aqxjn881vb3as2	2026-02-06 19:15:03.151	cmlb9lung00aoxjn82aqttyw5	cml6vykja0002jms2hhr4hfr3	2026-02-05 14:09:03.15	2	t
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.conversations (id, "createdAt", "updatedAt", subject, "folderId", "lastMessageAt", "tenantId") FROM stdin;
cmlb9lukn009axjn8twr540rj	2026-02-06 19:15:03.047	2026-02-06 19:15:03.047	Dossier Dupont - documents manquants	\N	2026-02-02 12:22:03.046	cml6vykdd0000jms2wwxl9s27
cmlb9lulk009lxjn8cmhfrifh	2026-02-06 19:15:03.08	2026-02-06 19:15:03.08	Organisation reunion cabinet	\N	2026-02-06 17:09:03.079	cml6vykdd0000jms2wwxl9s27
cmlb9lum3009uxjn8bwqou45g	2026-02-06 19:15:03.1	2026-02-06 19:15:03.1	Point cession SCI Tilleuls	\N	2026-02-04 08:20:03.099	cml6vykdd0000jms2wwxl9s27
cmlb9lums00a9xjn8kgzqgri6	2026-02-06 19:15:03.124	2026-02-06 19:15:03.124	Audience TGI - preparation	\N	2026-02-02 17:02:03.124	cml6vykdd0000jms2wwxl9s27
cmlb9lung00aoxjn82aqttyw5	2026-02-06 19:15:03.148	2026-02-06 19:15:03.148	Question procedure licenciement	\N	2026-02-06 12:43:03.148	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: deadlines; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.deadlines (id, "createdAt", "updatedAt", title, description, "dueDate", "dueTime", type, priority, status, reminders, "lastReminderSentAt", "folderId", "documentId", "assignedToId", "createdById", "tenantId", "isRecurring", "recurrenceRule", "completedAt", "completedById") FROM stdin;
cmlb9le5x005no0tajt0gmrjb	2026-02-06 19:14:41.781	2026-02-06 19:14:41.781	Audience TGI Paris	Audience TGI Paris - details a completer	2026-02-10 15:11:41.78	09:00	DEADLINE	HIGH	PENDING	\N	\N	\N	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le64005po0ta3zmnib9c	2026-02-06 19:14:41.788	2026-02-06 19:14:41.788	Depot conclusions	Depot conclusions - details a completer	2026-03-06 11:09:41.787	09:30	REMINDER	URGENT	PENDING	\N	\N	cmlaz9ydq0003i4b0dggysja4	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le67005ro0ta86fwfuho	2026-02-06 19:14:41.791	2026-02-06 19:14:41.791	RDV client Dupont	RDV client Dupont - details a completer	2026-01-30 14:13:41.79	09:30	MEETING	NORMAL	COMPLETED	\N	\N	\N	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le69005to0ta9dp1n6lo	2026-02-06 19:14:41.794	2026-02-06 19:14:41.794	Date limite appel	Date limite appel - details a completer	2026-03-13 13:58:41.793	10:45	TASK	NORMAL	PENDING	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6b005vo0taxe6ucxxd	2026-02-06 19:14:41.796	2026-02-06 19:14:41.796	Mediation prevue	Mediation prevue - details a completer	2026-01-24 17:30:41.795	10:00	HEARING	NORMAL	OVERDUE	\N	\N	\N	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	2026-02-06 19:14:41.795	\N
cmlb9le6e005xo0ta1082e3an	2026-02-06 19:14:41.798	2026-02-06 19:14:41.798	Audience mise en etat	Audience mise en etat - details a completer	2026-02-10 09:14:41.797	12:45	HEARING	HIGH	PENDING	\N	\N	\N	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6g005zo0tasyaj6z5h	2026-02-06 19:14:41.8	2026-02-06 19:14:41.8	Echeance paiement	Echeance paiement - details a completer	2026-02-10 14:06:41.799	09:30	TASK	LOW	PENDING	\N	\N	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6i0061o0tabv5ifrs7	2026-02-06 19:14:41.802	2026-02-06 19:14:41.802	Depot plainte	Depot plainte - details a completer	2026-02-08 09:35:41.801	11:15	DEADLINE	LOW	PENDING	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6j0063o0tapywqc6v3	2026-02-06 19:14:41.803	2026-02-06 19:14:41.803	Signature acte notarie	Signature acte notarie - details a completer	2026-03-06 12:01:41.803	10:00	DEADLINE	NORMAL	PENDING	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6k0065o0tarc47d8y3	2026-02-06 19:14:41.805	2026-02-06 19:14:41.805	Reunion cabinet	Reunion cabinet - details a completer	2026-03-19 15:57:41.804	11:15	DEADLINE	NORMAL	PENDING	\N	\N	cml8feb2e000910pfzh5ilxb7	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6n0067o0tatd4xoh7z	2026-02-06 19:14:41.807	2026-02-06 19:14:41.807	Rappel delai prescription	Rappel delai prescription - details a completer	2026-03-02 16:54:41.806	11:00	DEADLINE	NORMAL	PENDING	\N	\N	cmlb9ldyt000jo0taxfxaxno0	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6p0069o0ta90n617da	2026-02-06 19:14:41.809	2026-02-06 19:14:41.809	Audience Cour appel	Audience Cour appel - details a completer	2026-03-04 13:31:41.808	12:30	MEETING	LOW	PENDING	\N	\N	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6r006bo0tazx9k9uef	2026-02-06 19:14:41.811	2026-02-06 19:14:41.811	Visite expert immobilier	Visite expert immobilier - details a completer	2026-01-22 14:23:41.81	10:45	DEADLINE	HIGH	COMPLETED	\N	\N	cmlaz9ydq0003i4b0dggysja4	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6t006do0tap5gvoj4f	2026-02-06 19:14:41.813	2026-02-06 19:14:41.813	Depot memoire	Depot memoire - details a completer	2026-01-14 08:46:41.812	09:15	TASK	NORMAL	COMPLETED	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9le6u006fo0tawyyjkwu6	2026-02-06 19:14:41.815	2026-02-06 19:14:41.815	RDV notaire cession	RDV notaire cession - details a completer	2026-02-13 11:58:41.814	10:30	HEARING	URGENT	PENDING	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luga006zxjn817irb493	2026-02-06 19:15:02.891	2026-02-06 19:15:02.891	Audience TGI Paris	Audience TGI Paris - details a completer	2026-02-20 11:34:02.89	09:00	TASK	NORMAL	PENDING	\N	\N	cmlb9lty80001xjn8sorgq1d3	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9lugj0071xjn88hkm5yj7	2026-02-06 19:15:02.899	2026-02-06 19:15:02.899	Depot conclusions	Depot conclusions - details a completer	2026-02-28 17:42:02.898	10:30	MEETING	NORMAL	PENDING	\N	\N	cml6vyl0v000djms25rbug5x8	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9lugo0073xjn8gxp38ejd	2026-02-06 19:15:02.905	2026-02-06 19:15:02.905	RDV client Dupont	RDV client Dupont - details a completer	2026-03-02 10:24:02.903	09:15	HEARING	HIGH	PENDING	\N	\N	cmlaz9ydq0003i4b0dggysja4	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9lugt0075xjn8wd1485da	2026-02-06 19:15:02.909	2026-02-06 19:15:02.909	Date limite appel	Date limite appel - details a completer	2026-01-11 14:37:02.908	10:15	HEARING	HIGH	OVERDUE	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9lugx0077xjn8q93f9p0b	2026-02-06 19:15:02.913	2026-02-06 19:15:02.913	Mediation prevue	Mediation prevue - details a completer	2026-01-09 16:53:02.912	11:15	DEADLINE	NORMAL	OVERDUE	\N	\N	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luh10079xjn8lyr8589f	2026-02-06 19:15:02.917	2026-02-06 19:15:02.917	Audience mise en etat	Audience mise en etat - details a completer	2026-02-17 08:45:02.916	09:30	MEETING	LOW	PENDING	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luh4007bxjn8mcg7txec	2026-02-06 19:15:02.921	2026-02-06 19:15:02.921	Echeance paiement	Echeance paiement - details a completer	2026-01-30 15:37:02.92	12:30	DEADLINE	NORMAL	COMPLETED	\N	\N	cml6vyl0v000djms25rbug5x8	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	2026-02-06 19:15:02.92	\N
cmlb9luh8007dxjn8ban8kl3f	2026-02-06 19:15:02.924	2026-02-06 19:15:02.924	Depot plainte	Depot plainte - details a completer	2026-02-21 15:29:02.923	10:45	MEETING	LOW	PENDING	\N	\N	cml6vyl11000hjms2krxzvmzx	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luhb007fxjn8805z8c5r	2026-02-06 19:15:02.927	2026-02-06 19:15:02.927	Signature acte notarie	Signature acte notarie - details a completer	2026-03-16 14:55:02.926	10:45	REMINDER	URGENT	PENDING	\N	\N	cmlb9ltz2000bxjn8n1ih7loj	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luhe007hxjn8rjdnscxp	2026-02-06 19:15:02.931	2026-02-06 19:15:02.931	Reunion cabinet	Reunion cabinet - details a completer	2026-02-16 08:36:02.93	11:30	HEARING	HIGH	PENDING	\N	\N	\N	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luhh007jxjn82ajfdqum	2026-02-06 19:15:02.934	2026-02-06 19:15:02.934	Rappel delai prescription	Rappel delai prescription - details a completer	2026-02-08 13:51:02.932	12:00	TASK	NORMAL	PENDING	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luhl007lxjn801lv4dpk	2026-02-06 19:15:02.937	2026-02-06 19:15:02.937	Audience Cour appel	Audience Cour appel - details a completer	2026-02-08 10:05:02.936	10:15	TASK	NORMAL	PENDING	\N	\N	cmlb9ltym0005xjn8jqppbtxh	\N	cml6vykja0002jms2hhr4hfr3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luho007nxjn89d1zif7b	2026-02-06 19:15:02.94	2026-02-06 19:15:02.94	Visite expert immobilier	Visite expert immobilier - details a completer	2026-01-14 08:40:02.939	10:15	REMINDER	LOW	COMPLETED	\N	\N	\N	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luhr007pxjn82hswixvs	2026-02-06 19:15:02.944	2026-02-06 19:15:02.944	Depot memoire	Depot memoire - details a completer	2026-02-22 11:59:02.942	09:15	MEETING	NORMAL	PENDING	\N	\N	cmlaqnv9e000hyf6npv6echvh	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
cmlb9luhy007rxjn8xx30e3w9	2026-02-06 19:15:02.95	2026-02-06 19:15:02.95	RDV notaire cession	RDV notaire cession - details a completer	2026-01-10 17:16:02.949	09:30	HEARING	NORMAL	OVERDUE	\N	\N	cml6vyl0z000fjms24ukfhi3k	\N	cml6vykp40004jms2d2rnfrpm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	f	\N	\N	\N
\.


--
-- Data for Name: document_requests; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.document_requests (id, "createdAt", "updatedAt", "folderId", title, description, status, priority, "dueDate", "responseDocumentId", "responseDate", "responseNotes", "reminderCount", "lastReminderAt", "createdById", "tenantId") FROM stdin;
cml9fca98000rh7vhvlhli82s	2026-02-05 12:20:02.156	2026-02-05 12:20:02.156	cml6vyl0v000djms25rbug5x8	Kbis de moins de 3 mois	Merci de fournir un extrait Kbis de votre société datant de moins de 3 mois pour la constitution du dossier.	PENDING	HIGH	2026-02-12 12:20:02.155	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9fca9u000th7vhiks61p0e	2026-02-05 12:20:02.178	2026-02-05 12:20:02.178	cml6vyl0v000djms25rbug5x8	Pièce d'identité	Copie recto-verso de votre pièce d'identité en cours de validité.	PENDING	NORMAL	2026-02-19 12:20:02.177	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9fcaa8000vh7vhu6bquse0	2026-02-05 12:20:02.192	2026-02-05 12:20:02.192	cml6vyl0v000djms25rbug5x8	Derniers bilans comptables	Les 3 derniers bilans comptables certifiés par votre expert-comptable.	PENDING	URGENT	2026-02-08 12:20:02.189	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9kseai000j11bi8qvvdh5f	2026-02-05 14:52:31.963	2026-02-05 14:52:31.963	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	Justificatif de domicile	Merci de fournir un justificatif de domicile de moins de 3 mois (facture EDF, quittance de loyer, etc.)	PENDING	HIGH	2026-02-20 00:00:00	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9ksedi000n11bicid4rupz	2026-02-05 14:52:32.07	2026-02-05 14:52:32.07	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	Pièce d'identité	Veuillez fournir une copie de votre carte d'identité ou passeport en cours de validité.	PENDING	URGENT	2026-02-10 00:00:00	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le6x006ho0tasod3f2w9	2026-02-06 19:14:41.817	2026-02-06 19:14:41.817	cml8feb2q000f10pfwi9qm0ph	Justificatif de domicile	Merci de fournir : Justificatif de domicile	PENDING	URGENT	2026-02-21 15:10:41.816	\N	\N	\N	1	2026-02-05 11:24:41.816	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le72006jo0taheam14eo	2026-02-06 19:14:41.823	2026-02-06 19:14:41.823	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	Piece identite recto-verso	Merci de fournir : Piece identite recto-verso	PENDING	URGENT	2026-02-18 15:40:41.822	\N	\N	\N	1	2026-02-06 10:10:41.822	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le74006lo0taxnzsk7x7	2026-02-06 19:14:41.825	2026-02-06 19:14:41.825	cmlb17ims0002111v6gbo2rh6	RIB bancaire	Merci de fournir : RIB bancaire	PENDING	NORMAL	2026-03-02 17:24:41.824	\N	\N	\N	2	2026-02-06 17:23:41.824	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le76006no0tadu5b3wg1	2026-02-06 19:14:41.827	2026-02-06 19:14:41.827	cml8feb1z000510pf9trmhfa2	Avis imposition 2025	Merci de fournir : Avis imposition 2025	COMPLETED	URGENT	2026-02-20 11:32:41.826	\N	2026-02-06 15:39:41.826	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le78006po0taahniyg1o	2026-02-06 19:14:41.829	2026-02-06 19:14:41.829	cmlaqnv9e000hyf6npv6echvh	Certificat de non-gage	Merci de fournir : Certificat de non-gage	CANCELLED	NORMAL	2026-02-19 16:51:41.828	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7a006ro0tah2wz0f0z	2026-02-06 19:14:41.831	2026-02-06 19:14:41.831	cmlb185h4000j111vmhnvpqz9	Extrait Kbis	Merci de fournir : Extrait Kbis	PENDING	URGENT	2026-02-16 09:25:41.83	\N	\N	\N	0	2026-02-05 09:45:41.83	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7c006to0taj2iq20wu	2026-02-06 19:14:41.832	2026-02-06 19:14:41.832	cml8feb2q000f10pfwi9qm0ph	Attestation employeur	Merci de fournir : Attestation employeur	COMPLETED	URGENT	2026-03-05 09:21:41.832	\N	2026-02-03 09:20:41.832	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7e006vo0tau6lrpyb7	2026-02-06 19:14:41.834	2026-02-06 19:14:41.834	cmlb9ldyt000jo0taxfxaxno0	Bail en cours	Merci de fournir : Bail en cours	PENDING	NORMAL	2026-03-04 16:54:41.834	\N	\N	\N	2	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7g006xo0ta13netm77	2026-02-06 19:14:41.836	2026-02-06 19:14:41.836	cml8feb2t000h10pfy2cvm3la	Quittances de loyer	Merci de fournir : Quittances de loyer	CANCELLED	URGENT	2026-02-19 15:33:41.835	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7i006zo0ta3l8f9zl0	2026-02-06 19:14:41.839	2026-02-06 19:14:41.839	fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	Acte de naissance	Merci de fournir : Acte de naissance	PENDING	LOW	2026-02-15 12:11:41.838	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7k0071o0ta0ngjbvq7	2026-02-06 19:14:41.841	2026-02-06 19:14:41.841	cml8feb2i000b10pfg17hbnxm	Livret de famille	Merci de fournir : Livret de famille	PENDING	URGENT	2026-02-10 09:35:41.84	\N	\N	\N	1	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7m0073o0ta8ciwanwp	2026-02-06 19:14:41.842	2026-02-06 19:14:41.842	cmlb9ldz5000ro0ta3kzm9xhn	Contrat de travail	Merci de fournir : Contrat de travail	CANCELLED	HIGH	2026-02-09 16:52:41.842	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lui5007txjn8czap0k9g	2026-02-06 19:15:02.957	2026-02-06 19:15:02.957	cml6vyl11000hjms2krxzvmzx	Justificatif de domicile	Merci de fournir : Justificatif de domicile	CANCELLED	NORMAL	2026-02-18 11:46:02.956	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luib007vxjn8jr2dm976	2026-02-06 19:15:02.963	2026-02-06 19:15:02.963	cmlb9ldz5000ro0ta3kzm9xhn	Piece identite recto-verso	Merci de fournir : Piece identite recto-verso	PENDING	HIGH	2026-03-08 12:21:02.962	\N	\N	\N	0	2026-02-03 16:26:02.962	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luie007xxjn8uptg5k9j	2026-02-06 19:15:02.966	2026-02-06 19:15:02.966	cmlb9ldz7000to0ta68iy83zc	RIB bancaire	Merci de fournir : RIB bancaire	COMPLETED	HIGH	2026-02-27 16:24:02.965	\N	2026-02-02 16:40:02.965	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luii007zxjn8ohpq1tnl	2026-02-06 19:15:02.971	2026-02-06 19:15:02.971	cml6vyl11000hjms2krxzvmzx	Avis imposition 2025	Merci de fournir : Avis imposition 2025	PENDING	HIGH	2026-02-18 11:39:02.969	\N	\N	\N	1	2026-01-31 09:05:02.969	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luin0081xjn81kh9g8kb	2026-02-06 19:15:02.976	2026-02-06 19:15:02.976	cmlb9ltz2000bxjn8n1ih7loj	Certificat de non-gage	Merci de fournir : Certificat de non-gage	PENDING	LOW	2026-03-01 14:34:02.975	\N	\N	\N	2	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luis0083xjn89l6z7uju	2026-02-06 19:15:02.98	2026-02-06 19:15:02.98	cmlb9ldz5000ro0ta3kzm9xhn	Extrait Kbis	Merci de fournir : Extrait Kbis	PENDING	LOW	2026-03-02 13:35:02.979	\N	\N	\N	2	2026-02-03 11:49:02.979	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luiw0085xjn8jw7dklqn	2026-02-06 19:15:02.985	2026-02-06 19:15:02.985	cmlb9ltys0007xjn8hiblj6iz	Attestation employeur	Merci de fournir : Attestation employeur	CANCELLED	URGENT	2026-02-19 15:24:02.984	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luiz0087xjn8d43cl5br	2026-02-06 19:15:02.988	2026-02-06 19:15:02.988	cmlb9ldyq000ho0tab273yhyu	Bail en cours	Merci de fournir : Bail en cours	PENDING	URGENT	2026-02-25 17:04:02.987	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luj20089xjn842idgi6o	2026-02-06 19:15:02.99	2026-02-06 19:15:02.99	cmlb9ldyt000jo0taxfxaxno0	Quittances de loyer	Merci de fournir : Quittances de loyer	PENDING	LOW	2026-03-07 17:33:02.99	\N	\N	\N	0	2026-02-05 16:03:02.99	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luj5008bxjn8peut7gn8	2026-02-06 19:15:02.994	2026-02-06 19:15:02.994	cmlb9ltz2000bxjn8n1ih7loj	Acte de naissance	Merci de fournir : Acte de naissance	COMPLETED	LOW	2026-03-05 12:01:02.992	\N	2026-02-03 17:53:02.992	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luj8008dxjn8gamc3kx4	2026-02-06 19:15:02.997	2026-02-06 19:15:02.997	cmlb9ltz2000bxjn8n1ih7loj	Livret de famille	Merci de fournir : Livret de famille	PENDING	NORMAL	2026-02-11 08:58:02.996	\N	\N	\N	2	2026-02-02 17:54:02.996	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lujb008fxjn807sl18ln	2026-02-06 19:15:02.999	2026-02-06 19:15:02.999	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	Contrat de travail	Merci de fournir : Contrat de travail	COMPLETED	NORMAL	2026-03-05 12:11:02.998	\N	2026-02-04 16:56:02.998	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: document_tracking; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.document_tracking (id, "createdAt", "updatedAt", "documentId", status, "deliveryMethod", "signatureRequestId", "signatureStatus", "signedAt", "signedBy", "lrarTrackingNumber", "lrarStatus", "sentAt", "deliveredAt", "reminderCount", "lastReminderAt", "nextReminderAt", "autoRemindersEnabled") FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.documents (id, "createdAt", "updatedAt", name, description, type, tags, filename, "originalName", "mimeType", size, checksum, "bucketName", "objectKey", "isEncrypted", version, "parentId", status, "requiresSignature", "signatureDeadline", "validFrom", "validUntil", "archivedAt", "deletedAt", "folderId", "createdById", "tenantId", "folderCategoryId", "clientId", "docCategoryId", "docusignEnvelopeId", "docusignSentAt", "docusignSignedAt", "docusignStatus", "sendingboxDeliveredAt", "sendingboxSentAt", "sendingboxStatus", "sendingboxTrackingId", "templateId", "visibleExtranet") FROM stdin;
cml6vyl13000jjms232792l1y	2026-02-03 17:41:57.879	2026-02-03 17:41:57.879	Protocole de cession - Tech Corp	\N	CONTRACT	{}	protocole-cession-techcorp.pdf	Protocole de cession.pdf	application/pdf	2516582	abc123def456	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/protocole-cession-techcorp.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-08 17:41:57.878	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cml6vyl17000ljms2xfzrqdbk	2026-02-03 17:41:57.883	2026-02-03 17:41:57.883	Acte de garantie d'actif et de passif	\N	DEED	{}	acte-garantie-gap.pdf	GAP.pdf	application/pdf	1874329	def789ghi012	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/acte-garantie-gap.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-10 17:41:57.883	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cml6vyl19000njms2iu9iuwvv	2026-02-03 17:41:57.885	2026-02-03 17:41:57.885	Contrat de conseil juridique 2026	\N	CONTRACT	{}	contrat-conseil-2026.pdf	Contrat conseil.pdf	application/pdf	987654	ghi345jkl678	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/contrat-conseil-2026.pdf	t	1	\N	SIGNED	t	\N	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cml6vyl1b000pjms2707bomdj	2026-02-03 17:41:57.887	2026-02-03 17:41:57.887	Attestation de livraison - Matériel informatique	\N	CERTIFICATE	{}	attestation-livraison.pdf	Attestation.pdf	application/pdf	654321	jkl901mno234	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/attestation-livraison.pdf	t	1	\N	SENT	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb2hypl00071256add7xul3	2026-02-06 15:56:04.473	2026-02-06 15:56:04.473	Assignation TJ - Jean WizardTest2	Genere depuis le template: Assignation TJ	DEED	{}	1770393364463-assignation-tj---jean-wizardtest2.docx	assignation-tj---jean-wizardtest2.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	8255	dba1daa1590a084f58635cfba8a1fdf6ac34d9ae35deab0c40c3838103606651	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/1770393364463-assignation-tj---jean-wizardtest2.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb18ypu0004f4ha1yi87is2	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cml6vyl1d000rjms21ti62wqk	2026-02-03 17:41:57.889	2026-02-06 13:52:42.154	Avenant contrat commercial n°3	\N	AMENDMENT	{}	avenant-3.pdf	Avenant 3.pdf	application/pdf	456789	mno567pqr890	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/avenant-3.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-04 17:41:57.888	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9ldzw001bo0taxssipc28	2026-01-22 15:32:41.564	2026-02-06 19:14:41.565	Mise en demeure	Document genere pour le dossier	MEMORANDUM	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	310617	102e2e1e437ebe3ba87a151edcbb2cc5	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0v000djms25rbug5x8/b0d6597cb0b8e942.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb185hs0013111vlzb0r4hm	2026-02-06 15:20:27.06	2026-02-06 15:37:10.637	Acte de cession	\N	CONTRACT	{}	pending.docx	Acte de cession.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	0	pending	documents	pending/cmlb185h4000j111vmhnvpqz9/1770391227087-0	t	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb185h4000j111vmhnvpqz9	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	seed-client-techcorp-pm	cmlb185ha000l111vm5syjgzk	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb2dluc000151o73j4fvzem	2026-02-06 15:52:41.172	2026-02-06 15:52:41.172	Convention d'honoraires - Jean WizardTest2	Genere depuis le template: Convention d'honoraires	CONTRACT	{}	1770393161152-convention-dhonoraires---jean-wizardtest2.docx	convention-dhonoraires---jean-wizardtest2.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	8328	1f9b85f702529495405fc90d708fd536ecb88026bcf159aa6fef281561ff65f7	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/1770393161152-convention-dhonoraires---jean-wizardtest2.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb18ypu0004f4ha1yi87is2	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb2hynx000112569i3eq2pg	2026-02-06 15:56:04.413	2026-02-06 15:56:04.413	Lettre de mission - Jean WizardTest2	Genere depuis le template: Lettre de mission	LETTER	{}	1770393364402-lettre-de-mission---jean-wizardtest2.docx	lettre-de-mission---jean-wizardtest2.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	8050	44de4ab3004c7fe84813f87ed674c832c53ad9021f2a1383f87d8c59e60e8878	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/1770393364402-lettre-de-mission---jean-wizardtest2.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb18ypu0004f4ha1yi87is2	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le07001do0tailfu5nd1	2026-01-25 11:34:41.574	2026-02-06 19:14:41.575	Conclusions au fond	Document genere pour le dossier	DEED	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	346954	5fd59824f0720b9a767ba531ee0afba9	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0z000fjms24ukfhi3k/1cd1ed09c7e5449c.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0b001fo0talu5bo3bl	2026-01-15 16:29:41.579	2026-02-06 19:14:41.58	Assignation en justice	Document genere pour le dossier	DEED	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	476900	23c45a65c907df85d2042d6626bcb914	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0z000fjms24ukfhi3k/8216556c8e961ce6.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0f001ho0ta17afdrr5	2026-01-11 12:59:41.582	2026-02-06 19:14:41.583	Procuration	Document genere pour le dossier	CERTIFICATE	{}	procuration.docx	procuration.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	286820	3ce885a570eff628b09da530476b11e1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl11000hjms2krxzvmzx/89f0dc4d3017008e.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0k001jo0taoglmjhp0	2025-12-19 08:27:41.587	2026-02-06 19:14:41.588	Statuts SAS	Document genere pour le dossier	REPORT	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	167523	93be76470893c2739fe8048c856e9d0e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb1z000510pf9trmhfa2/44df26b29cd04c1a.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb1z000510pf9trmhfa2	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0n001lo0tam3xnlqmh	2025-12-16 17:34:41.591	2026-02-06 19:14:41.592	Avenant au contrat	Document genere pour le dossier	CONTRACT	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	399288	6954391d009447d995b369ad42dc1bc8	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb29000710pfjmjz3odz/e8a6e2e07522b7a2.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb29000710pfjmjz3odz	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0r001no0taxrfredl1	2026-01-25 12:03:41.594	2026-02-06 19:14:41.596	Conclusions au fond	Document genere pour le dossier	CERTIFICATE	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	480012	23230be123306c2415f6e57066af6d58	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb29000710pfjmjz3odz/3914570b22ff7d4f.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cml8feb29000710pfjmjz3odz	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0v001po0ta7nss9g69	2026-01-18 14:46:41.598	2026-02-06 19:14:41.599	Contrat de bail	Document genere pour le dossier	REPORT	{}	contrat_de_bail.pdf	contrat_de_bail.pdf	application/pdf	327138	1dcbac4ad839a42662d07c9b8943654a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2e000910pfzh5ilxb7/2ad10489851164a6.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb2e000910pfzh5ilxb7	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le0y001ro0ta174qzjay	2026-02-03 17:41:41.601	2026-02-06 19:14:41.602	Assignation en justice	Document genere pour le dossier	REPORT	{}	assignation_en_justice.docx	assignation_en_justice.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	310317	ac3174284ac1d787600a6f6318613b9b	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2e000910pfzh5ilxb7/25f1f948ef4281fb.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cml8feb2e000910pfzh5ilxb7	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le10001to0tadrwpybbe	2025-12-22 08:00:41.604	2026-02-06 19:14:41.605	Contrat de bail	Document genere pour le dossier	DEED	{}	contrat_de_bail.pdf	contrat_de_bail.pdf	application/pdf	321761	f3f9ad1b100e87449930b11bf203c5a0	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2e000910pfzh5ilxb7/f169a4960d80a651.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cml8feb2e000910pfzh5ilxb7	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le13001vo0tao24eb2hk	2026-01-08 14:26:41.607	2026-02-06 19:14:41.608	Preavis de licenciement	Document genere pour le dossier	CERTIFICATE	{}	preavis_de_licenciement.docx	preavis_de_licenciement.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	530841	e5ef8bc65cc161f34ea936c2eeb32cc8	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2i000b10pfg17hbnxm/8582876022d649f1.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2i000b10pfg17hbnxm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le16001xo0taztl0jdhu	2026-01-15 14:49:41.61	2026-02-06 19:14:41.611	Attestation de domicile	Document genere pour le dossier	CERTIFICATE	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	474826	9bb436be72994b6a302925c54838ac4f	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2i000b10pfg17hbnxm/691d3e20622fdfad.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2i000b10pfg17hbnxm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le19001zo0tah7ixl841	2026-01-30 16:34:41.613	2026-02-06 19:14:41.613	Acte notarie	Document genere pour le dossier	REPORT	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	295460	d53bbb0398874aef82171ac34881bbcc	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2i000b10pfg17hbnxm/69bb0177489ab933.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb2i000b10pfg17hbnxm	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1d0021o0tae4nxlp6m	2026-01-17 11:01:41.616	2026-02-06 19:14:41.617	Courrier tribunal	Document genere pour le dossier	DEED	{}	courrier_tribunal.docx	courrier_tribunal.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	187987	8aaa37223e13cbe3058308b5b1297331	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2l000d10pfe8y2gtge/413c325d0a36e170.docx	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb2l000d10pfe8y2gtge	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1f0023o0tauzjqlonp	2026-01-21 12:51:41.619	2026-02-06 19:14:41.62	Preavis de licenciement	Document genere pour le dossier	MEMORANDUM	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	260617	8120f3d5ccc42aa90a51bddc59f93311	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2q000f10pfwi9qm0ph/32e2a0f450dc63b8.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb2q000f10pfwi9qm0ph	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1i0025o0tazc9gcnyn	2026-01-19 09:42:41.621	2026-02-06 19:14:41.622	Courrier tribunal	Document genere pour le dossier	CONTRACT	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	248907	80d0f6d6e311d0963207500aeee78633	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/81f743f8574a6cee.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1l0027o0tairorsbjm	2026-01-06 14:54:41.625	2026-02-06 19:14:41.625	Conclusions au fond	Document genere pour le dossier	MINUTES	{}	conclusions_au_fond.docx	conclusions_au_fond.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	447629	766f2b2495d5dea4e7a713cfcea626bf	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/8fef5e2c387d6f4b.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1o0029o0tagwphqouy	2025-12-12 17:01:41.627	2026-02-06 19:14:41.628	PV assemblee generale	Document genere pour le dossier	DEED	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	148466	d8c44d1a0c930d13f981a425d9b580fd	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/8ce3cb690a15bfb6.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1q002bo0ta6onm1gv0	2026-01-27 11:48:41.63	2026-02-06 19:14:41.631	Assignation en justice	Document genere pour le dossier	LETTER	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	305681	0f579af317e8516f62beaaaa13dcfa01	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/2f18a7206f6cbf6f.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1t002do0tauimhmgnc	2025-12-30 10:42:41.633	2026-02-06 19:14:41.634	Note de synthese	Document genere pour le dossier	CERTIFICATE	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	360123	53319bfd7de86b1ad931566122583e4e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/a8e08603e2041540.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1w002fo0tahtavzaje	2026-01-01 10:06:41.636	2026-02-06 19:14:41.637	Conclusions au fond	Document genere pour le dossier	REPORT	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	181361	c2d6f37a0566dbce72d660e5311fd506	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/46a9cc700872d354.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le1z002ho0tafza4t511	2026-01-23 13:24:41.638	2026-02-06 19:14:41.639	PV assemblee generale	Document genere pour le dossier	MEMORANDUM	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	536230	6c21ea900265bc395874a07316b813c1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/c876370c757209ed.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le21002jo0ta8rcnh8j1	2026-01-10 14:20:41.641	2026-02-06 19:14:41.642	Conclusions au fond	Document genere pour le dossier	CERTIFICATE	{}	conclusions_au_fond.docx	conclusions_au_fond.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	152115	9cd30f394a1ffddbb6894b1c20b5d7d1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/6bb7bf617890d767.docx	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le23002lo0tas86ahqqo	2026-01-09 09:17:41.643	2026-02-06 19:14:41.644	Statuts SAS	Document genere pour le dossier	MINUTES	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	519410	b0c7e2cbd6e5f98520ade7d059174eba	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/3c30a3f46d7fcd78.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le26002no0tadntxkehv	2025-12-29 13:33:41.646	2026-02-06 19:14:41.647	Statuts SAS	Document genere pour le dossier	REPORT	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	438131	3a2b4b7da12f31a7bd8be806d942ae46	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/5cdc1123ffc63342.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le28002po0ta17igjv7x	2025-12-17 13:34:41.648	2026-02-06 19:14:41.649	Avenant au contrat	Document genere pour le dossier	DEED	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	70273	72ede10706fa7081e9edb37e22da0dc2	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/f7939d8d7b45be86.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2a002ro0tailel756t	2026-01-20 12:55:41.65	2026-02-06 19:14:41.651	Note de synthese	Document genere pour le dossier	REPORT	{}	note_de_synthese.docx	note_de_synthese.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	404745	787470a1267be58eb31b077e71f61f72	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/465db84e4b3a6b7c.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2d002to0taouvck3lo	2026-01-27 14:06:41.652	2026-02-06 19:14:41.653	Avenant au contrat	Document genere pour le dossier	LETTER	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	371788	aec0e04be01bd5569e545a9e12ee4be1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/434ee25ebdd73c27.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2e002vo0tazi4nmoh7	2026-01-25 17:59:41.654	2026-02-06 19:14:41.655	PV assemblee generale	Document genere pour le dossier	REPORT	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	358615	d4c5df0d5941599a9aae13d1a5fdf222	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/d5d271772a1b0058.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2g002xo0tasnrlsb5n	2026-01-18 10:29:41.656	2026-02-06 19:14:41.657	PV assemblee generale	Document genere pour le dossier	LETTER	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	501799	e5edb2914888d21d5d99dc1313684d16	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/5124903c08216c05.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2j002zo0ta2abzg677	2025-12-17 15:36:41.658	2026-02-06 19:14:41.659	Acte de cession	Document genere pour le dossier	CERTIFICATE	{}	acte_de_cession.docx	acte_de_cession.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	151665	1d782615f3e0bf94a877d41a3e3a3897	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4/feaa4cf2e2d5d64e.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2m0031o0tam1zpge9m	2026-02-04 12:55:41.661	2026-02-06 19:14:41.662	Attestation de domicile	Document genere pour le dossier	CERTIFICATE	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	310084	9b2f6f44a41858660cb848671247c098	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6/0d28f9a738f9c055.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2o0033o0taezf6qjlb	2025-12-30 11:34:41.663	2026-02-06 19:14:41.664	Note de synthese	Document genere pour le dossier	LETTER	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	309449	ec93968cc91401c7585e30db357986de	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6/2b7f585dee85bd65.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2q0035o0ta8mf066jq	2026-01-22 16:01:41.666	2026-02-06 19:14:41.667	Preavis de licenciement	Document genere pour le dossier	MINUTES	{}	preavis_de_licenciement.docx	preavis_de_licenciement.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	149144	5ecaa4d1857f2ada44b543b8feb90f57	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/e2e6bced9194dd2a.docx	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2s0037o0ta49kqux00	2025-12-29 12:01:41.668	2026-02-06 19:14:41.669	Requete en refere	Document genere pour le dossier	MINUTES	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	360978	8d434e97b2b2e0e228ecef51465bb1a3	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/f24a6fe995b04632.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le420047o0ta7vbc8ajv	2026-02-01 14:39:41.714	2026-02-06 19:14:41.715	Procuration	Document genere pour le dossier	CERTIFICATE	{}	procuration.pdf	procuration.pdf	application/pdf	166813	53d1b79c18b0671c065696631cf19983	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydq0003i4b0dggysja4/e25f8c25e70e095d.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlaz9ydq0003i4b0dggysja4	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2v0039o0takkbwjq30	2026-01-24 10:03:41.67	2026-02-06 19:14:41.671	Conclusions au fond	Document genere pour le dossier	CERTIFICATE	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	520462	771c40566f511690d560c703d99593ea	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/46689320bf5edab7.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le2y003bo0taa3h9kb82	2025-12-23 13:16:41.673	2026-02-06 19:14:41.674	Avenant au contrat	Document genere pour le dossier	REPORT	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	444788	895fb4194f9d7d1996115871dbd76020	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/724a50c146c8fadd.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le30003do0taf88aexxa	2026-01-16 09:16:41.675	2026-02-06 19:14:41.676	Note de synthese	Document genere pour le dossier	DEED	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	502938	53e86cd548cf614cd8385a6bc2bc4925	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/f157c555b9698b0c.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le33003fo0tanqk2blw2	2025-12-31 15:28:41.678	2026-02-06 19:14:41.679	Protocole transactionnel	Document genere pour le dossier	MINUTES	{}	protocole_transactionnel.pdf	protocole_transactionnel.pdf	application/pdf	123743	9790cc670db52b2d173e1ec47bb5d418	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/1bedd6edd1848361.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le35003ho0ta5bbscckv	2026-01-03 14:25:41.681	2026-02-06 19:14:41.682	PV assemblee generale	Document genere pour le dossier	MEMORANDUM	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	259781	d209ada790522bd09b5b924e3084ea80	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80/f75d862de6e67af9.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le38003jo0takypihowz	2026-01-02 15:05:41.683	2026-02-06 19:14:41.684	Mise en demeure	Document genere pour le dossier	CONTRACT	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	223641	db63a5913c9df98cb78ad779690431ac	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890/f44d2c0e77155f2b.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3b003lo0tafydcfyv5	2026-01-25 17:41:41.686	2026-02-06 19:14:41.687	Mise en demeure	Document genere pour le dossier	LETTER	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	58389	80f06f726536eadf5c6e4456f28e343e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890/155396231c43db66.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3d003no0tahksl1t0s	2026-01-29 15:00:41.689	2026-02-06 19:14:41.689	Assignation en justice	Document genere pour le dossier	REPORT	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	229745	d1c319831fb5e957d2a722c82dc94d87	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890/a92967d8061fc54a.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3f003po0taovl7y2we	2025-12-20 14:10:41.691	2026-02-06 19:14:41.692	Mise en demeure	Document genere pour le dossier	REPORT	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	243182	b2d2ff9bb3d9527a0031a5144f5876b0	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890/d24c183c89753f2d.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3i003ro0tafmdbx74b	2025-12-18 12:05:41.693	2026-02-06 19:14:41.694	Attestation de domicile	Document genere pour le dossier	REPORT	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	356896	39e0b12d2362506c0d759f1c30970c1a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c/6d17871484c9ceac.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3k003to0taeenzu9qw	2025-12-22 11:03:41.695	2026-02-06 19:14:41.696	Acte notarie	Document genere pour le dossier	REPORT	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	77185	ac14aaf0bc70436709bf74291c45da15	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaqnv9e000hyf6npv6echvh/3660aca839524d5d.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlaqnv9e000hyf6npv6echvh	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3n003vo0ta3hoh0hed	2025-12-24 11:06:41.698	2026-02-06 19:14:41.699	Acte notarie	Document genere pour le dossier	MEMORANDUM	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	297089	06dc05ae1e07014dd7b683dd7b03169f	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaqnv9e000hyf6npv6echvh/c32c284f9131b93b.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlaqnv9e000hyf6npv6echvh	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3q003xo0taiept5ntj	2025-12-17 14:46:41.701	2026-02-06 19:14:41.702	Procuration	Document genere pour le dossier	CONTRACT	{}	procuration.pdf	procuration.pdf	application/pdf	234759	60f2535f32c53eb06d3e134cb065434e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaqnv9e000hyf6npv6echvh/9aa8ac3e0b0dba01.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlaqnv9e000hyf6npv6echvh	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3t003zo0ta6157isf3	2026-02-02 13:38:41.704	2026-02-06 19:14:41.705	Courrier tribunal	Document genere pour le dossier	LETTER	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	508488	5d0f4dd39ff1a34cee6e957d29a1a3f5	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydk0001i4b0mf637jrl/7410fff4c59fa1b3.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlaz9ydk0001i4b0mf637jrl	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3v0041o0tak3gk4egp	2026-01-17 14:20:41.707	2026-02-06 19:14:41.708	Protocole transactionnel	Document genere pour le dossier	LETTER	{}	protocole_transactionnel.pdf	protocole_transactionnel.pdf	application/pdf	211514	f65de11b613574a0e79fb3762b1ea50a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydk0001i4b0mf637jrl/d5a62d59645206ed.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlaz9ydk0001i4b0mf637jrl	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le3y0043o0tam9ezrgyx	2025-12-24 16:03:41.709	2026-02-06 19:14:41.71	Requete en refere	Document genere pour le dossier	MINUTES	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	533413	cb67042bcedfecf924af55c3bc0f1f7a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydk0001i4b0mf637jrl/d8b456ac54782298.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlaz9ydk0001i4b0mf637jrl	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le400045o0tal3y2agn0	2025-12-20 08:35:41.711	2026-02-06 19:14:41.712	Protocole transactionnel	Document genere pour le dossier	CONTRACT	{}	protocole_transactionnel.pdf	protocole_transactionnel.pdf	application/pdf	543262	c8e9c29e16bf9e608999f6171df49745	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydk0001i4b0mf637jrl/37c933f15b4195a6.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlaz9ydk0001i4b0mf637jrl	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le450049o0ta0vjqbpui	2026-01-05 14:00:41.716	2026-02-06 19:14:41.717	Assignation en justice	Document genere pour le dossier	CERTIFICATE	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	54345	5af7f2bb654833ee572bb903e4bc02b7	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydq0003i4b0dggysja4/787347783592f7a6.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlaz9ydq0003i4b0dggysja4	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le48004bo0ta1o5krxfh	2025-12-25 12:13:41.719	2026-02-06 19:14:41.72	Requete en refere	Document genere pour le dossier	MEMORANDUM	{}	requete_en_refere.docx	requete_en_refere.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	63044	d0babc2edd494f7cfa4c826996351f40	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydq0003i4b0dggysja4/f13554b872f0f389.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlaz9ydq0003i4b0dggysja4	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4a004do0ta3imhmjvy	2025-12-09 08:55:41.722	2026-02-06 19:14:41.723	Procuration	Document genere pour le dossier	LETTER	{}	procuration.pdf	procuration.pdf	application/pdf	120534	d834772d43adbed90fc4b2b69dd89c22	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/e3536094dde2a4c8.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4d004fo0tair2vvuby	2026-01-13 09:55:41.724	2026-02-06 19:14:41.725	Avenant au contrat	Document genere pour le dossier	DEED	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	266522	00b3605d36dc35ab15827dd53b976f53	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/af4227de31871df2.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4f004ho0taxz9gaove	2026-01-20 08:36:41.727	2026-02-06 19:14:41.727	Acte notarie	Document genere pour le dossier	REPORT	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	53263	f9c093de6f7e8d1643aa51b8796b73fc	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/4e929b9d11ce61a2.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4h004jo0taplfnzywn	2026-01-17 12:42:41.729	2026-02-06 19:14:41.73	Statuts SAS	Document genere pour le dossier	LETTER	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	519626	5247bfa38a05f952189679804057037c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb185h4000j111vmhnvpqz9/e7b2c39639c4d4ae.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb185h4000j111vmhnvpqz9	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4k004lo0taozoexq24	2026-01-02 10:09:41.732	2026-02-06 19:14:41.732	Note de synthese	Document genere pour le dossier	DEED	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	167359	57604ff8bef5c4ba2f856084ed3ab8ff	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb18ypu0004f4ha1yi87is2/76b43572b46ba8c7.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb18ypu0004f4ha1yi87is2	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4n004no0tarp7epamn	2026-01-09 12:05:41.735	2026-02-06 19:14:41.735	Mise en demeure	Document genere pour le dossier	DEED	{}	mise_en_demeure.docx	mise_en_demeure.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	389689	06eb9cf573b6ee3b69cc469be7030e95	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyl000fo0ta56i3m5t7/f868b38d29b16a53.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldyl000fo0ta56i3m5t7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4p004po0tajv18inpd	2026-01-17 17:48:41.737	2026-02-06 19:14:41.738	Statuts SAS	Document genere pour le dossier	MEMORANDUM	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	544578	239fceecc79a80c0a9828b6a32db50d2	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyl000fo0ta56i3m5t7/ed7b7dd5411ed198.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldyl000fo0ta56i3m5t7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4r004ro0tacn7ivk65	2026-01-08 13:37:41.739	2026-02-06 19:14:41.74	Preavis de licenciement	Document genere pour le dossier	CONTRACT	{}	preavis_de_licenciement.docx	preavis_de_licenciement.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	147981	f6ca823e6e23b21fc0c2706d113e2f61	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyl000fo0ta56i3m5t7/ebd4d080cab73994.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldyl000fo0ta56i3m5t7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4u004to0ta6kmx8c27	2026-01-25 16:38:41.741	2026-02-06 19:14:41.742	Avenant au contrat	Document genere pour le dossier	MEMORANDUM	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	541147	4f43585544ba4bdb3068e726bbc7ff7c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyl000fo0ta56i3m5t7/8ac869b73ce69e68.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ldyl000fo0ta56i3m5t7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4w004vo0ta15ns5dr6	2025-12-13 08:21:41.743	2026-02-06 19:14:41.744	Assignation en justice	Document genere pour le dossier	MINUTES	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	127663	3c58452780304b514dbbe130cbdea192	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyq000ho0tab273yhyu/1f3cbb3b0640c09c.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ldyq000ho0tab273yhyu	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le4y004xo0tad6bv2ca0	2026-01-12 10:00:41.746	2026-02-06 19:14:41.747	Procuration	Document genere pour le dossier	MINUTES	{}	procuration.docx	procuration.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	335721	bae3d43c2642cc2d6ae5394a10468a67	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyq000ho0tab273yhyu/99daff10179634ab.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ldyq000ho0tab273yhyu	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le51004zo0taka5kxw3l	2025-12-14 14:28:41.749	2026-02-06 19:14:41.75	Requete en refere	Document genere pour le dossier	REPORT	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	310626	24caa679a4a407e72086a74d99b2adc4	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyt000jo0taxfxaxno0/38d53765caf0fae7.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldyt000jo0taxfxaxno0	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le540051o0taodk65zhk	2025-12-13 10:53:41.751	2026-02-06 19:14:41.752	Statuts SAS	Document genere pour le dossier	REPORT	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	384325	c1f361ed5527d09011145086c77fa6ce	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyv000lo0tagud0d5cn/fd588a387322d304.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldyv000lo0tagud0d5cn	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le570053o0tac8eubv7n	2026-01-18 13:52:41.754	2026-02-06 19:14:41.755	Mise en demeure	Document genere pour le dossier	CONTRACT	{}	mise_en_demeure.docx	mise_en_demeure.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	274743	6e9d8aa3e68a5c81d4c5ff91fac1e346	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyv000lo0tagud0d5cn/7e4dce0e9c71db56.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldyv000lo0tagud0d5cn	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5a0055o0tarn5xxehf	2026-01-04 09:04:41.757	2026-02-06 19:14:41.759	Conclusions au fond	Document genere pour le dossier	MEMORANDUM	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	318994	585c928bad22a85d1b7bbb55e7b1139f	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyv000lo0tagud0d5cn/655cf0653ed4e4ae.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldyv000lo0tagud0d5cn	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5d0057o0tacxl56ahh	2026-01-27 12:53:41.76	2026-02-06 19:14:41.761	Statuts SAS	Document genere pour le dossier	LETTER	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	267668	e3499d67c071491c97683d60b08c98b8	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/4c6d722b906c2048.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5g0059o0tat3hqekmn	2026-01-16 15:49:41.764	2026-02-06 19:14:41.765	Acte notarie	Document genere pour le dossier	CONTRACT	{}	acte_notarie.docx	acte_notarie.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	262107	942c6ec4c34e3aa023fbbec5f5a7a605	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/57a2ef0f4a7126c9.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5j005bo0tawf0dkqqb	2026-01-23 15:46:41.767	2026-02-06 19:14:41.768	Note de synthese	Document genere pour le dossier	CERTIFICATE	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	306794	cce315c8388b7bf68a99d8a8af964c29	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/8ac3bb3d9a5a58ba.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5m005do0ta7mt6w8jz	2025-12-15 16:31:41.769	2026-02-06 19:14:41.77	PV assemblee generale	Document genere pour le dossier	LETTER	{}	pv_assemblee_generale.docx	pv_assemblee_generale.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	218011	51e203e2036539b699040e7d025a43b0	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz2000po0taqlkknhzy/dff93f16c69f3481.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldz2000po0taqlkknhzy	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5o005fo0ta4462dvrm	2026-01-27 14:19:41.771	2026-02-06 19:14:41.772	Statuts SAS	Document genere pour le dossier	MEMORANDUM	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	159290	351b97c3a88142fd2bd894556d731a17	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz2000po0taqlkknhzy/f7963300b281853b.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldz2000po0taqlkknhzy	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5q005ho0tadu1ffrnz	2026-01-20 09:07:41.774	2026-02-06 19:14:41.775	Preavis de licenciement	Document genere pour le dossier	CERTIFICATE	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	137125	503b3f8c68111964c36b0995976b94c4	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz5000ro0ta3kzm9xhn/c36c3b7076e1e9d1.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ldz5000ro0ta3kzm9xhn	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5s005jo0tac40yxq2z	2025-12-20 10:34:41.776	2026-02-06 19:14:41.777	Avenant au contrat	Document genere pour le dossier	DEED	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	137237	ac2d09332af1ffe71003a22e9dc9783c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz5000ro0ta3kzm9xhn/d456720ed7004595.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ldz5000ro0ta3kzm9xhn	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9le5v005lo0tap569v4hb	2026-01-30 11:28:41.778	2026-02-06 19:14:41.779	Conclusions au fond	Document genere pour le dossier	MINUTES	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	136618	14934aa85790e9465d8563a2840b4708	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz7000to0ta68iy83zc/e46709dbd157c3fc.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldz7000to0ta68iy83zc	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu1d0011xjn89fv0tuxn	2026-01-15 11:03:02.352	2026-02-06 19:15:02.353	Note de synthese	Document genere pour le dossier	CONTRACT	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	443844	f99952c8a946d8e70f103faaeff9f159	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0v000djms25rbug5x8/571ecda9fa800561.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu1n0013xjn8rw742qgt	2026-01-11 16:01:02.361	2026-02-06 19:15:02.363	Procuration	Document genere pour le dossier	DEED	{}	procuration.pdf	procuration.pdf	application/pdf	222239	451952d1d9f162f025bff76deebab6d4	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0v000djms25rbug5x8/58987e4817b9e178.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu1u0015xjn819jppc4t	2026-01-25 14:20:02.369	2026-02-06 19:15:02.37	Acte notarie	Document genere pour le dossier	DEED	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	129227	8936c16accd9c5a1ea511b392d1ff60c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0v000djms25rbug5x8/769190c539e59042.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu200017xjn85c2t584b	2025-12-13 11:54:02.375	2026-02-06 19:15:02.376	Mise en demeure	Document genere pour le dossier	REPORT	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	389559	c26c2cf50634e4c50972324c34b1d59f	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0v000djms25rbug5x8/1e1a0c612a264f3d.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu250019xjn84jigab6z	2025-12-24 13:10:02.38	2026-02-06 19:15:02.381	Attestation de domicile	Document genere pour le dossier	MEMORANDUM	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	105673	f00cc98fcf042a2f8e9b81c67fc48969	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl0z000fjms24ukfhi3k/c22bfb9e02b40cb3.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu2d001bxjn8oj9kumft	2026-02-06 16:47:02.388	2026-02-06 19:15:02.389	Requete en refere	Document genere pour le dossier	LETTER	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	481480	ebfa823efc0a55e6c09096151bc6c75b	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl11000hjms2krxzvmzx/92d870bc62ede357.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu2l001dxjn89c8ycimm	2025-12-11 14:53:02.396	2026-02-06 19:15:02.397	Acte de cession	Document genere pour le dossier	CONTRACT	{}	acte_de_cession.pdf	acte_de_cession.pdf	application/pdf	432771	0e89d07e78d79a17ec62045048445aee	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl11000hjms2krxzvmzx/6fd02bdc715b914c.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu2q001fxjn8y9fx0xfb	2026-01-16 13:40:02.401	2026-02-06 19:15:02.402	Assignation en justice	Document genere pour le dossier	LETTER	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	156935	69ede886ed5144d5569e523658f413e4	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl11000hjms2krxzvmzx/c1e6f63b7ec190c9.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu2z001hxjn8uz6efhj5	2026-02-03 17:44:02.41	2026-02-06 19:15:02.411	Contrat de bail	Document genere pour le dossier	REPORT	{}	contrat_de_bail.docx	contrat_de_bail.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	318122	4ca407058919432b0496941f21017450	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml6vyl11000hjms2krxzvmzx/a041346ebcc81e6b.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu34001jxjn8n1k5pfk2	2025-12-31 13:34:02.415	2026-02-06 19:15:02.417	Mise en demeure	Document genere pour le dossier	MEMORANDUM	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	536696	af828840579cf59fa0f83d03f21fdbcd	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb1z000510pf9trmhfa2/93d43dc651a1e2da.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb1z000510pf9trmhfa2	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu3b001lxjn8ab48cvux	2025-12-30 15:37:02.422	2026-02-06 19:15:02.423	Preavis de licenciement	Document genere pour le dossier	CONTRACT	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	178396	d7f30bfc19e9304c83a44b6b8cb77feb	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb1z000510pf9trmhfa2/6ff0c30b988ed7ae.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb1z000510pf9trmhfa2	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu3h001nxjn8s6l4rdw4	2026-01-09 10:40:02.428	2026-02-06 19:15:02.429	Attestation de domicile	Document genere pour le dossier	CERTIFICATE	{}	attestation_de_domicile.docx	attestation_de_domicile.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	495117	8423c9e610a2fe44d6f1884765ff2fdd	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb29000710pfjmjz3odz/59af3660ab4f2c40.docx	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb29000710pfjmjz3odz	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu3p001pxjn8ipvfqbnn	2025-12-13 16:44:02.436	2026-02-06 19:15:02.438	Avenant au contrat	Document genere pour le dossier	MEMORANDUM	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	64711	85c5ad413de151c308a33dc3c01c5234	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb29000710pfjmjz3odz/96a0d2f31db8fb40.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb29000710pfjmjz3odz	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu3u001rxjn8o698hr4f	2026-01-10 12:07:02.441	2026-02-06 19:15:02.442	Avenant au contrat	Document genere pour le dossier	DEED	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	457997	6d69a1eb74c94a34c6ecf14aed4fe942	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2e000910pfzh5ilxb7/900dad44b5ac905a.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2e000910pfzh5ilxb7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu3z001txjn8d7eywrjy	2026-01-02 17:26:02.446	2026-02-06 19:15:02.447	Mise en demeure	Document genere pour le dossier	REPORT	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	473300	68eaf7140a8f5b13e0a6ae6d187a0fef	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2e000910pfzh5ilxb7/8d199ff4568ce4d4.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml8feb2e000910pfzh5ilxb7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu41001vxjn8htc59u03	2026-01-10 17:22:02.449	2026-02-06 19:15:02.45	Procuration	Document genere pour le dossier	DEED	{}	procuration.pdf	procuration.pdf	application/pdf	146241	2f73c364a4328efb1eb0b5708e80932a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2e000910pfzh5ilxb7/823862a6b3c39402.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb2e000910pfzh5ilxb7	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu48001xxjn8if04ev1v	2025-12-14 16:42:02.456	2026-02-06 19:15:02.457	Acte notarie	Document genere pour le dossier	CERTIFICATE	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	384228	3c9c344c888a9234d206e83be89f9cea	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2i000b10pfg17hbnxm/f8661e249a3552fc.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb2i000b10pfg17hbnxm	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu4b001zxjn8fl4yllf6	2026-01-17 12:35:02.459	2026-02-06 19:15:02.46	Assignation en justice	Document genere pour le dossier	MEMORANDUM	{}	assignation_en_justice.docx	assignation_en_justice.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	443354	f8c96dc9f657cb2cc43270581883aa41	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2i000b10pfg17hbnxm/a9ab06b445ced0d5.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml8feb2i000b10pfg17hbnxm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu4f0021xjn8pz60eioh	2026-01-18 15:23:02.462	2026-02-06 19:15:02.463	Attestation de domicile	Document genere pour le dossier	MINUTES	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	306841	800dee0f93f5596e35701f91d5bd18cb	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2l000d10pfe8y2gtge/ad79c150f5f46c2d.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb2l000d10pfe8y2gtge	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu4j0023xjn8pm469rfp	2026-01-11 15:42:02.467	2026-02-06 19:15:02.468	Courrier tribunal	Document genere pour le dossier	CONTRACT	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	295829	fc2fb1c76f2dc7b793b344f12505df6d	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2l000d10pfe8y2gtge/f3cd014cad7566c6.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2l000d10pfe8y2gtge	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu4t0025xjn8tcxs8kqw	2025-12-21 09:19:02.476	2026-02-06 19:15:02.478	PV assemblee generale	Document genere pour le dossier	DEED	{}	pv_assemblee_generale.docx	pv_assemblee_generale.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	463354	381cf84fe623bf565fb1cfb25722d2cc	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2l000d10pfe8y2gtge/6e6fee546daafbfe.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml8feb2l000d10pfe8y2gtge	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu4x0027xjn8xanfhewp	2025-12-10 14:45:02.48	2026-02-06 19:15:02.481	Statuts SAS	Document genere pour le dossier	LETTER	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	60669	0c59fc4f59504b2a96243818c35a2ae0	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2q000f10pfwi9qm0ph/8ab17c0e89a31b7f.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cml8feb2q000f10pfwi9qm0ph	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu520029xjn86e08hqvf	2025-12-31 11:31:02.485	2026-02-06 19:15:02.486	Procuration	Document genere pour le dossier	DEED	{}	procuration.docx	procuration.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	382981	86a9d870dafb164c23c1096820fec19a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2q000f10pfwi9qm0ph/d027cc3e72c5c349.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2q000f10pfwi9qm0ph	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu56002bxjn8tgwrdf1m	2026-01-03 13:59:02.489	2026-02-06 19:15:02.49	Protocole transactionnel	Document genere pour le dossier	CERTIFICATE	{}	protocole_transactionnel.docx	protocole_transactionnel.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	146382	09db3a44e35c8eee1ca06425e7cafce8	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/be6316ce667ae81f.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu5a002dxjn8fzlpkbo7	2025-12-12 15:51:02.493	2026-02-06 19:15:02.494	Statuts SAS	Document genere pour le dossier	REPORT	{}	statuts_sas.docx	statuts_sas.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	332461	999c99f25a25bb62f35e191f669e7ecd	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/b0c6e4815c77944e.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu5e002fxjn8zmikra6k	2025-12-23 11:52:02.497	2026-02-06 19:15:02.498	Attestation de domicile	Document genere pour le dossier	MINUTES	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	410663	7fe1aac845b9f443ecbc516f2c48f90b	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/478da3f16e651091.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu5h002hxjn894d12vny	2025-12-30 15:15:02.5	2026-02-06 19:15:02.502	Note de synthese	Document genere pour le dossier	MEMORANDUM	{}	note_de_synthese.docx	note_de_synthese.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	503359	f8c2c0f1a84156b38dcb50fd8e6c0fd2	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cml8feb2t000h10pfy2cvm3la/46edc95c316bb72a.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cml8feb2t000h10pfy2cvm3la	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu5m002jxjn80xr0x3b9	2026-01-13 17:41:02.505	2026-02-06 19:15:02.506	Acte notarie	Document genere pour le dossier	DEED	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	498717	9c76dd6bef73bd42359e07eb9ac83e89	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/25e0ed7805d0c603.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu5q002lxjn8a6jzaxxm	2026-02-02 17:26:02.509	2026-02-06 19:15:02.51	Courrier tribunal	Document genere pour le dossier	MINUTES	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	285715	99eacae5329ec30eade3cd6113d18293	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/8241eb139e1282d0.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu5w002nxjn8i6egvrb6	2026-01-25 08:46:02.515	2026-02-06 19:15:02.516	Assignation en justice	Document genere pour le dossier	DEED	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	165661	01fe4b967b4dfda4260ac09c96099e24	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/8f334c802231df92.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu60002pxjn858ob5e1x	2026-02-04 17:34:02.519	2026-02-06 19:15:02.52	Avenant au contrat	Document genere pour le dossier	CERTIFICATE	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	319458	73b0a19c45f87aff5d88859faf487aea	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379/34b7bebab7d5d958.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu64002rxjn8qyevcvlt	2025-12-25 17:01:02.523	2026-02-06 19:15:02.524	Conclusions au fond	Document genere pour le dossier	CONTRACT	{}	conclusions_au_fond.docx	conclusions_au_fond.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	458553	508d4b5323397c1d656b8c5d802114a9	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/bd14ea3284ace1d9.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu68002txjn80zsp7otb	2026-01-26 11:21:02.528	2026-02-06 19:15:02.529	PV assemblee generale	Document genere pour le dossier	MINUTES	{}	pv_assemblee_generale.docx	pv_assemblee_generale.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	198491	fe981527c2acd39356e57f47483a35b5	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/46b2da7ee46dab8b.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu6c002vxjn8cytmr8l3	2026-01-06 15:26:02.531	2026-02-06 19:15:02.532	Avenant au contrat	Document genere pour le dossier	DEED	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	300155	43f011d251b74dd9069363fef6ffc519	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/dd34f90c0d2525d4.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu6g002xxjn829m3kh9p	2026-01-05 16:02:02.535	2026-02-06 19:15:02.536	Requete en refere	Document genere pour le dossier	MEMORANDUM	{}	requete_en_refere.docx	requete_en_refere.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	52771	161cf5e788e8a04da779dbb00e370244	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730/84bf759e92bace4b.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu6k002zxjn87xujiglj	2026-01-20 08:23:02.539	2026-02-06 19:15:02.54	Requete en refere	Document genere pour le dossier	MEMORANDUM	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	321800	ed18180b50f7f858f5df2db52a6beede	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/c1a8c6e2889baf99.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu6r0031xjn83wld8072	2026-01-27 12:43:02.546	2026-02-06 19:15:02.547	Assignation en justice	Document genere pour le dossier	CONTRACT	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	196477	c2be8abf3be0011cb605cb4b7675e961	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/b7a4c6e82b4ac151.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu6w0033xjn8xw05kpyh	2026-01-31 13:20:02.551	2026-02-06 19:15:02.553	Attestation de domicile	Document genere pour le dossier	MEMORANDUM	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	196472	9824d8d06356fadc7dd23236e005a109	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00/c728cacdd73f8fcb.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu730035xjn86l1cusq9	2025-12-09 10:24:02.558	2026-02-06 19:15:02.559	Conclusions au fond	Document genere pour le dossier	LETTER	{}	conclusions_au_fond.docx	conclusions_au_fond.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	441355	07d670fd1c53006360798f921ca07e22	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4/7a20eb53ce0bff94.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu760037xjn873czajbr	2026-01-14 11:54:02.561	2026-02-06 19:15:02.562	Mise en demeure	Document genere pour le dossier	DEED	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	318344	d29431719821ac0db4aa54596b0ef054	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4/a1dff571a859f053.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu7b0039xjn8gzv44xdo	2025-12-24 10:29:02.566	2026-02-06 19:15:02.567	Courrier tribunal	Document genere pour le dossier	REPORT	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	417419	e3f91dafc02dc71c78f50145ee89af2b	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4/ea5eefe41c09785d.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu7f003bxjn8saoflm48	2026-01-06 14:19:02.57	2026-02-06 19:15:02.571	Note de synthese	Document genere pour le dossier	CERTIFICATE	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	219116	5106bec8de99acc5c05fe8d7140747b5	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6/93cf72d1ed13b357.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu7m003dxjn8ujbcrw8t	2025-12-26 14:39:02.577	2026-02-06 19:15:02.578	Requete en refere	Document genere pour le dossier	CONTRACT	{}	requete_en_refere.docx	requete_en_refere.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	109236	2fd9c96ecce860cd5aa5b0f0730972ea	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6/1f91a9c832f255b7.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu7q003fxjn8thhs4c0p	2026-01-15 17:54:02.581	2026-02-06 19:15:02.582	Mise en demeure	Document genere pour le dossier	CONTRACT	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	367756	e4b8ca3e101229466c8e3e1148793f17	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6/d641b29f663e292f.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu7u003hxjn80crvxjw5	2026-01-26 09:14:02.586	2026-02-06 19:15:02.586	Requete en refere	Document genere pour le dossier	MINUTES	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	446847	4c2ebf76543e2d02a40248e4a3485af8	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/e90543a03c97365d.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu7z003jxjn80rv108ba	2025-12-27 12:44:02.59	2026-02-06 19:15:02.591	Preavis de licenciement	Document genere pour le dossier	CONTRACT	{}	preavis_de_licenciement.docx	preavis_de_licenciement.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	405496	f3d724acdfd2ddc9639bf3e9172b1623	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/aa2e1057b1c4eaf8.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu83003lxjn8ccr75127	2026-01-25 17:56:02.595	2026-02-06 19:15:02.596	Conclusions au fond	Document genere pour le dossier	CERTIFICATE	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	508184	8583145637026288ac94034719c5394f	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/c497ec733e2021de.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu87003nxjn8xabegtb5	2025-12-12 09:53:02.599	2026-02-06 19:15:02.6	Statuts SAS	Document genere pour le dossier	CONTRACT	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	180743	8510696b1f559942a2bb2a5d2858e73b	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a/7be0daa219e2bc9c.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu8d003pxjn8s47my0ig	2026-01-18 15:20:02.605	2026-02-06 19:15:02.606	Protocole transactionnel	Document genere pour le dossier	REPORT	{}	protocole_transactionnel.pdf	protocole_transactionnel.pdf	application/pdf	167659	8b4a02c94b1c3acdce1b16c6f747b379	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/b7c2dd3cd077bbc0.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu8h003rxjn81hmfn929	2026-02-04 17:45:02.608	2026-02-06 19:15:02.609	Statuts SAS	Document genere pour le dossier	CERTIFICATE	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	394912	cafb19bf893bb35d6d5bca4e18980bd1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/8af638211ad1a005.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu8l003txjn8cz7r7kdz	2026-01-06 14:20:02.612	2026-02-06 19:15:02.613	Requete en refere	Document genere pour le dossier	REPORT	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	361975	113cd1d6c2c4955bd04b37105c95aa2c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/6ca7592778b59a89.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu8p003vxjn8930v7aky	2026-01-02 11:08:02.617	2026-02-06 19:15:02.618	PV assemblee generale	Document genere pour le dossier	REPORT	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	488947	40610f32ae7887dd87d7c5a8f84bc829	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6/6a44eebe312a75b9.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu8t003xxjn886omdrat	2025-12-29 09:09:02.621	2026-02-06 19:15:02.622	Protocole transactionnel	Document genere pour le dossier	REPORT	{}	protocole_transactionnel.pdf	protocole_transactionnel.pdf	application/pdf	393183	a8e29101fc1c5cf254936e32980b2071	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80/1be1921ee0edbe2f.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu8y003zxjn8a7kl4yfg	2025-12-22 08:26:02.625	2026-02-06 19:15:02.626	Contrat de bail	Document genere pour le dossier	MEMORANDUM	{}	contrat_de_bail.docx	contrat_de_bail.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	444158	45fef9262c64e74a95b5f0e800db41a1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80/7085705716ff6704.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu950041xjn86uagntdr	2026-01-03 14:00:02.632	2026-02-06 19:15:02.633	PV assemblee generale	Document genere pour le dossier	LETTER	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	278382	8bfd9e38a0aac3bbbb8e1c10f3bc90ab	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890/20136bbbf0dc07ee.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu9a0043xjn8qy8nd11j	2025-12-25 17:37:02.638	2026-02-06 19:15:02.639	Preavis de licenciement	Document genere pour le dossier	CONTRACT	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	352377	ad1df99eee4cb22192c19c988425e693	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c/d57c34b921f7a312.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu9i0045xjn8bwz0xnvh	2026-01-23 11:37:02.644	2026-02-06 19:15:02.646	Attestation de domicile	Document genere pour le dossier	CONTRACT	{}	attestation_de_domicile.pdf	attestation_de_domicile.pdf	application/pdf	538541	9edf3bd20deaa1ccdbb31cbbc45f17e1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaqnv9e000hyf6npv6echvh/b6593a613daa93b7.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlaqnv9e000hyf6npv6echvh	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu9m0047xjn8iz6b201n	2025-12-21 14:36:02.65	2026-02-06 19:15:02.651	Contrat de bail	Document genere pour le dossier	LETTER	{}	contrat_de_bail.docx	contrat_de_bail.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	173743	ea10408835f0349ed4813884fcbb4789	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaqnv9e000hyf6npv6echvh/1e766d555c2888af.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlaqnv9e000hyf6npv6echvh	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu9q0049xjn8a38xdkyn	2026-01-10 12:15:02.653	2026-02-06 19:15:02.654	Acte de cession	Document genere pour le dossier	CERTIFICATE	{}	acte_de_cession.pdf	acte_de_cession.pdf	application/pdf	431575	7003dbefae6492737607ded01abcafc1	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaqnv9e000hyf6npv6echvh/beedae67d3ea0d3d.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlaqnv9e000hyf6npv6echvh	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu9t004bxjn8n0lk468t	2025-12-14 08:46:02.656	2026-02-06 19:15:02.657	Avenant au contrat	Document genere pour le dossier	CONTRACT	{}	avenant_au_contrat.docx	avenant_au_contrat.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	172182	a880b8833947eb4b411a5419b6670ecc	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydk0001i4b0mf637jrl/9c3456f0e6c4839c.docx	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlaz9ydk0001i4b0mf637jrl	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lu9w004dxjn8xdv2leyt	2026-01-04 12:32:02.66	2026-02-06 19:15:02.661	Contrat de bail	Document genere pour le dossier	MINUTES	{}	contrat_de_bail.pdf	contrat_de_bail.pdf	application/pdf	503397	348e58912ed56432883216e4b4b0433e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydk0001i4b0mf637jrl/cb103034b67c8408.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlaz9ydk0001i4b0mf637jrl	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lua0004fxjn8nfd62a8q	2026-01-13 11:29:02.664	2026-02-06 19:15:02.665	PV assemblee generale	Document genere pour le dossier	MEMORANDUM	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	455906	5058f046a21b5125a173e216281a399d	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydq0003i4b0dggysja4/69fa07d21a9699c3.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlaz9ydq0003i4b0dggysja4	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lua5004hxjn8vlmpuhgo	2026-01-03 12:06:02.669	2026-02-06 19:15:02.67	Note de synthese	Document genere pour le dossier	MINUTES	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	251130	84af26391ce17a375a2e10257418ceed	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydq0003i4b0dggysja4/629ff43e7fa88085.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlaz9ydq0003i4b0dggysja4	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luaa004jxjn8hbf8z6xz	2026-02-01 08:32:02.673	2026-02-06 19:15:02.674	Acte de cession	Document genere pour le dossier	CERTIFICATE	{}	acte_de_cession.pdf	acte_de_cession.pdf	application/pdf	401069	a68919ee8faa76d347fda42d9174313e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlaz9ydq0003i4b0dggysja4/86c63ddaf7369ce2.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlaz9ydq0003i4b0dggysja4	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luad004lxjn8gk0bcgym	2026-01-22 17:49:02.677	2026-02-06 19:15:02.678	Conclusions au fond	Document genere pour le dossier	DEED	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	526265	6a7e570328816f6d82e74bbe62c2ef4d	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/4b15e6ee4e39a58e.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luah004nxjn8albxadx2	2026-01-21 11:52:02.681	2026-02-06 19:15:02.682	Conclusions au fond	Document genere pour le dossier	MINUTES	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	144976	6b8aee25e56c14dc7b59dc9974fa78e7	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/0bec680337b0b62d.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lual004pxjn8dhsbi7az	2026-01-04 08:46:02.684	2026-02-06 19:15:02.685	Acte de cession	Document genere pour le dossier	REPORT	{}	acte_de_cession.pdf	acte_de_cession.pdf	application/pdf	277248	7687fe2b6b5f6cf58d8ec92affa03dc6	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/d5af815a21fe92d8.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luaq004rxjn8vgzyshb1	2025-12-20 09:29:02.689	2026-02-06 19:15:02.69	Mise en demeure	Document genere pour le dossier	LETTER	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	478636	cf30e1db9cf7b41cdae21a64b180659e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb17ims0002111v6gbo2rh6/8827b8a0827efa16.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb17ims0002111v6gbo2rh6	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luax004txjn8qpy5dbbz	2026-01-29 15:32:02.696	2026-02-06 19:15:02.697	Procuration	Document genere pour le dossier	MINUTES	{}	procuration.pdf	procuration.pdf	application/pdf	444380	7fb400f3767c557d7e770553866f1e15	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb185h4000j111vmhnvpqz9/083860c5c33013f4.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb185h4000j111vmhnvpqz9	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lub2004vxjn85sny1a9r	2026-01-02 10:56:02.701	2026-02-06 19:15:02.703	Courrier tribunal	Document genere pour le dossier	CONTRACT	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	257979	275819b71b8b29bb6d5522fbd3242f06	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb185h4000j111vmhnvpqz9/5bfe2d2170f782c4.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb185h4000j111vmhnvpqz9	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lub7004xxjn8vraqq8lp	2025-12-25 13:47:02.706	2026-02-06 19:15:02.707	Requete en refere	Document genere pour le dossier	CERTIFICATE	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	427282	67bf1c6dd1c6d33cca76c50ffc914432	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb185h4000j111vmhnvpqz9/7f4960ffa6e33576.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb185h4000j111vmhnvpqz9	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lubf004zxjn8t0za0ym8	2026-02-06 13:32:02.715	2026-02-06 19:15:02.716	Acte de cession	Document genere pour le dossier	CONTRACT	{}	acte_de_cession.pdf	acte_de_cession.pdf	application/pdf	365458	4c0305323b684d628b4c401ad8c5c8dd	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb18ypu0004f4ha1yi87is2/f8fcbd545a9443f3.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb18ypu0004f4ha1yi87is2	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lubk0051xjn8ywdorknb	2026-01-25 08:18:02.719	2026-02-06 19:15:02.72	Assignation en justice	Document genere pour le dossier	CONTRACT	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	441389	9ea8569fe1e8f0d3a64d574f0065aceb	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb18ypu0004f4ha1yi87is2/11ccf947632e831d.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb18ypu0004f4ha1yi87is2	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lubp0053xjn865hklvwf	2025-12-17 17:29:02.724	2026-02-06 19:15:02.725	Mise en demeure	Document genere pour le dossier	LETTER	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	141942	a5037896a71a11c9a6e599987a8683c2	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyl000fo0ta56i3m5t7/0978224474f9a29e.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldyl000fo0ta56i3m5t7	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lubv0055xjn8c4tsvvjx	2025-12-17 11:51:02.73	2026-02-06 19:15:02.731	Acte notarie	Document genere pour le dossier	DEED	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	359937	fe2c62350ac598fb222a96c4e3833f99	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyl000fo0ta56i3m5t7/083085d26056e7f8.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldyl000fo0ta56i3m5t7	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lubz0057xjn84jwjs83e	2025-12-14 10:03:02.734	2026-02-06 19:15:02.735	Conclusions au fond	Document genere pour le dossier	REPORT	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	188397	86ad26ce5bfb5a26a1c1285b96fc0b00	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyq000ho0tab273yhyu/402909a2c219785b.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldyq000ho0tab273yhyu	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luc40059xjn8yekt1v5o	2026-01-11 15:46:02.74	2026-02-06 19:15:02.741	Mise en demeure	Document genere pour le dossier	LETTER	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	140982	e72a992a907069812fa642e3e3e65fad	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyt000jo0taxfxaxno0/14ea01281543a9c4.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldyt000jo0taxfxaxno0	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luc7005bxjn85milvnto	2026-02-03 15:03:02.743	2026-02-06 19:15:02.744	Requete en refere	Document genere pour le dossier	MINUTES	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	398266	a375ab7225576778e2fc6a37f0978880	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyt000jo0taxfxaxno0/ca19f200083d839c.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldyt000jo0taxfxaxno0	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lucd005dxjn8qw73l0a3	2026-01-13 08:33:02.747	2026-02-06 19:15:02.749	Mise en demeure	Document genere pour le dossier	CERTIFICATE	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	144532	bafef42ce6240d68531d8c69fdf3fafa	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyt000jo0taxfxaxno0/97c5555977cd735f.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ldyt000jo0taxfxaxno0	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luci005fxjn8oara3b5k	2025-12-23 08:11:02.753	2026-02-06 19:15:02.754	Avenant au contrat	Document genere pour le dossier	MINUTES	{}	avenant_au_contrat.docx	avenant_au_contrat.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	66722	c3bec28286bd9de9f00c69013daa5d85	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyt000jo0taxfxaxno0/2bb506551aba1fb2.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldyt000jo0taxfxaxno0	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lucm005hxjn841kmr4b6	2025-12-18 09:24:02.757	2026-02-06 19:15:02.758	Assignation en justice	Document genere pour le dossier	MEMORANDUM	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	200496	f94d694debf1ec451ad90433fa370727	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyv000lo0tagud0d5cn/960fd264ad1de1e2.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldyv000lo0tagud0d5cn	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lucq005jxjn8fwvjq5m0	2025-12-21 15:55:02.761	2026-02-06 19:15:02.762	Protocole transactionnel	Document genere pour le dossier	MINUTES	{}	protocole_transactionnel.pdf	protocole_transactionnel.pdf	application/pdf	112014	4e595188f5263685c676f70240e7ccdb	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/105661bea6535b76.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lucu005lxjn8fiq119at	2026-01-04 15:32:02.765	2026-02-06 19:15:02.766	Preavis de licenciement	Document genere pour le dossier	MEMORANDUM	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	94780	29b227e502db7dd745d7bb88db24b167	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/22e651007a39cf1f.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lucx005nxjn8dwbov0v2	2026-01-16 11:43:02.768	2026-02-06 19:15:02.769	Avenant au contrat	Document genere pour le dossier	LETTER	{}	avenant_au_contrat.pdf	avenant_au_contrat.pdf	application/pdf	352773	b07d70224808b05f61827cdaad8db23f	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/4a31816e3cd47e63.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lud0005pxjn8gku4omif	2026-01-06 12:13:02.771	2026-02-06 19:15:02.772	Preavis de licenciement	Document genere pour le dossier	DEED	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	80199	270a8924f1d1f3cc367d04e03e9581ce	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldyz000no0tavpxqe5f8/341443042aa07dcf.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ldyz000no0tavpxqe5f8	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lud3005rxjn8mbas4le6	2025-12-30 14:44:02.775	2026-02-06 19:15:02.776	Mise en demeure	Document genere pour le dossier	CONTRACT	{}	mise_en_demeure.docx	mise_en_demeure.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	248140	a1104530061fa37fe08460a506fa43c7	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz2000po0taqlkknhzy/f4407d1d1cadeec2.docx	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ldz2000po0taqlkknhzy	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lud6005txjn84pscmhbj	2026-01-30 11:35:02.778	2026-02-06 19:15:02.779	Assignation en justice	Document genere pour le dossier	CONTRACT	{}	assignation_en_justice.docx	assignation_en_justice.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	248584	314b6e276b00f263e89939d9c83f8aff	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz2000po0taqlkknhzy/bc0c4b83669a0f82.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldz2000po0taqlkknhzy	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lud9005vxjn8687qkm4n	2026-01-27 12:41:02.781	2026-02-06 19:15:02.782	Note de synthese	Document genere pour le dossier	CONTRACT	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	206170	90326c856aa7ac43ff31ebdbb278d248	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz2000po0taqlkknhzy/dfc3462a4928e49f.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ldz2000po0taqlkknhzy	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9ludd005xxjn8sn23qia4	2026-01-18 13:38:02.784	2026-02-06 19:15:02.785	Contrat de bail	Document genere pour le dossier	MEMORANDUM	{}	contrat_de_bail.pdf	contrat_de_bail.pdf	application/pdf	428587	6104a754c789eb3121daf11f12ac39b7	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz5000ro0ta3kzm9xhn/99962910cf848343.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldz5000ro0ta3kzm9xhn	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9ludj005zxjn84lnir6i5	2026-01-12 12:05:02.79	2026-02-06 19:15:02.791	Requete en refere	Document genere pour le dossier	CERTIFICATE	{}	requete_en_refere.docx	requete_en_refere.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	376805	04e156f3d0375db0a13458c4acf5c8cc	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ldz7000to0ta68iy83zc/96823ae62e6aa202.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ldz7000to0ta68iy83zc	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9ludq0061xjn8wnsxtpb9	2026-01-02 11:07:02.797	2026-02-06 19:15:02.798	Conclusions au fond	Document genere pour le dossier	MEMORANDUM	{}	conclusions_au_fond.docx	conclusions_au_fond.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	271605	a38a9bf308ecc2398ae5c0ee12a4258a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9lty80001xjn8sorgq1d3/fb6e4d69c5f714d5.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9lty80001xjn8sorgq1d3	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9ludt0063xjn8xv3dy38z	2026-01-14 13:02:02.801	2026-02-06 19:15:02.802	Mise en demeure	Document genere pour le dossier	CERTIFICATE	{}	mise_en_demeure.pdf	mise_en_demeure.pdf	application/pdf	539752	a981f167679b6817dd23a37b02b41561	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltyg0003xjn8p26kbkxt/5fc34fd4116a0ab5.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ltyg0003xjn8p26kbkxt	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9ludz0065xjn8lcr4afpu	2026-01-05 11:06:02.805	2026-02-06 19:15:02.807	Requete en refere	Document genere pour le dossier	CERTIFICATE	{}	requete_en_refere.pdf	requete_en_refere.pdf	application/pdf	323891	805b412df07eae76e6fc00d778338d4c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltyg0003xjn8p26kbkxt/54b62fc76e1dff37.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ltyg0003xjn8p26kbkxt	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lue40067xjn8uwhdca6t	2025-12-19 11:23:02.812	2026-02-06 19:15:02.813	Statuts SAS	Document genere pour le dossier	MINUTES	{}	statuts_sas.pdf	statuts_sas.pdf	application/pdf	245323	3e2e22830a8771b4a45a15ea0fee4058	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltyg0003xjn8p26kbkxt/b7798705341160ec.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ltyg0003xjn8p26kbkxt	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lue90069xjn829rewagn	2026-01-16 13:16:02.816	2026-02-06 19:15:02.818	Preavis de licenciement	Document genere pour le dossier	DEED	{}	preavis_de_licenciement.pdf	preavis_de_licenciement.pdf	application/pdf	326649	fd7aa5ebaf16ddde78a0a6d70aea21a6	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltyg0003xjn8p26kbkxt/778ae70b4a22d1f3.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ltyg0003xjn8p26kbkxt	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luef006bxjn85jnqk0zp	2026-01-18 11:47:02.822	2026-02-06 19:15:02.823	Conclusions au fond	Document genere pour le dossier	MEMORANDUM	{}	conclusions_au_fond.pdf	conclusions_au_fond.pdf	application/pdf	90464	66309c19e9cda26316008418ef17cb4a	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltym0005xjn8jqppbtxh/c07e248f38184fad.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ltym0005xjn8jqppbtxh	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luei006dxjn8c8nq4kzb	2025-12-11 12:42:02.826	2026-02-06 19:15:02.827	Courrier tribunal	Document genere pour le dossier	CERTIFICATE	{}	courrier_tribunal.docx	courrier_tribunal.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	153475	8b35802f72fd54cf00dcf50aea58d951	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltys0007xjn8hiblj6iz/4db4f79f20a968e6.docx	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ltys0007xjn8hiblj6iz	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lueq006fxjn8lukfttml	2026-01-31 08:35:02.832	2026-02-06 19:15:02.834	Acte notarie	Document genere pour le dossier	CERTIFICATE	{}	acte_notarie.pdf	acte_notarie.pdf	application/pdf	213719	71c3e818471573bf59996050b2053899	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltys0007xjn8hiblj6iz/34361dce46697322.pdf	f	1	\N	PENDING_SIGNATURE	f	\N	\N	\N	\N	\N	cmlb9ltys0007xjn8hiblj6iz	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luey006hxjn8h66qazyc	2025-12-24 12:04:02.841	2026-02-06 19:15:02.842	Note de synthese	Document genere pour le dossier	CERTIFICATE	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	530801	10de4c77e713d32d0180b4b2c486b3e0	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltys0007xjn8hiblj6iz/d396ba050fa52ded.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ltys0007xjn8hiblj6iz	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9luf8006jxjn85r4ljvk6	2025-12-25 10:49:02.852	2026-02-06 19:15:02.853	Assignation en justice	Document genere pour le dossier	MINUTES	{}	assignation_en_justice.pdf	assignation_en_justice.pdf	application/pdf	242708	37836ae370e52e06c44226d04a2af7da	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltyx0009xjn8ev7qvq1y/679f31b90a2a0a5d.pdf	f	1	\N	DRAFT	f	\N	\N	\N	\N	\N	cmlb9ltyx0009xjn8ev7qvq1y	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lufd006lxjn85p22xn2p	2025-12-26 11:06:02.856	2026-02-06 19:15:02.857	Note de synthese	Document genere pour le dossier	LETTER	{}	note_de_synthese.docx	note_de_synthese.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	150961	3d52a963ec0793c0b8679c5c189c26e6	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltyx0009xjn8ev7qvq1y/2a701502aa00c9e5.docx	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ltyx0009xjn8ev7qvq1y	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lufi006nxjn8mthea0bk	2025-12-16 08:15:02.861	2026-02-06 19:15:02.862	Note de synthese	Document genere pour le dossier	REPORT	{}	note_de_synthese.pdf	note_de_synthese.pdf	application/pdf	514873	898f92f1620b4e563a70ddbbdc87fe89	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltz2000bxjn8n1ih7loj/4f397f0a2ba69cdc.pdf	f	1	\N	SENT	f	\N	\N	\N	\N	\N	cmlb9ltz2000bxjn8n1ih7loj	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lufn006pxjn8vfv3uqj1	2025-12-25 14:15:02.866	2026-02-06 19:15:02.867	PV assemblee generale	Document genere pour le dossier	REPORT	{}	pv_assemblee_generale.pdf	pv_assemblee_generale.pdf	application/pdf	170600	048410552e1382557aa5bd39c808ed89	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltz2000bxjn8n1ih7loj/69369b81a71dde8f.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ltz2000bxjn8n1ih7loj	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lufs006rxjn8xlnxx5a5	2025-12-26 14:08:02.872	2026-02-06 19:15:02.873	Acte notarie	Document genere pour le dossier	CERTIFICATE	{}	acte_notarie.docx	acte_notarie.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	502170	9588fc56726844327012928aa1d0ab9d	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltz2000bxjn8n1ih7loj/1b70feee0433ce09.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ltz2000bxjn8n1ih7loj	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lufw006txjn8imo38fin	2025-12-17 12:13:02.875	2026-02-06 19:15:02.876	Courrier tribunal	Document genere pour le dossier	MEMORANDUM	{}	courrier_tribunal.pdf	courrier_tribunal.pdf	application/pdf	292292	74cf5b7c326fb9cde4f8292b3106b46c	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltz2000bxjn8n1ih7loj/7fd4ba33c19b481a.pdf	f	1	\N	SIGNED	f	\N	\N	\N	\N	\N	cmlb9ltz2000bxjn8n1ih7loj	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lufz006vxjn8ilq4q137	2025-12-18 10:44:02.879	2026-02-06 19:15:02.88	Acte de cession	Document genere pour le dossier	DEED	{}	acte_de_cession.pdf	acte_de_cession.pdf	application/pdf	207876	b98acec368a0de35a77a32352acc879e	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltz6000dxjn8q3ikm5q2/1a1cc5f662d72b7b.pdf	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ltz6000dxjn8q3ikm5q2	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
cmlb9lug7006xxjn8733hk4gl	2025-12-19 12:38:02.884	2026-02-06 19:15:02.887	Preavis de licenciement	Document genere pour le dossier	MEMORANDUM	{}	preavis_de_licenciement.docx	preavis_de_licenciement.docx	application/vnd.openxmlformats-officedocument.wordprocessingml.document	231485	f75772147efe0a2e890825a8d6fe7ed0	lexdoc-documents	cml6vykdd0000jms2wwxl9s27/cmlb9ltzc000fxjn8pe5zbquq/05dbbbfb44e70bdc.docx	f	1	\N	PENDING_REVIEW	f	\N	\N	\N	\N	\N	cmlb9ltzc000fxjn8pe5zbquq	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.email_logs (id, "createdAt", "to", subject, template, status, "errorMessage", "notificationId", "tenantId") FROM stdin;
\.


--
-- Data for Name: folder_categories; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_categories (id, "createdAt", "updatedAt", name, description, color, icon, "parentId", "displayOrder", "tenantId") FROM stdin;
cml9fca4d0001h7vhsvoms05d	2026-02-05 12:20:01.981	2026-02-05 12:20:01.981	Contentieux	Documents relatifs aux procédures contentieuses	#EF4444	Scale	\N	1	cml6vykdd0000jms2wwxl9s27
cml9fca4q0003h7vhssckybk0	2026-02-05 12:20:01.995	2026-02-05 12:20:01.995	Corporate	Documents de droit des sociétés	#3B82F6	Building	\N	2	cml6vykdd0000jms2wwxl9s27
cml9fca520005h7vhc62fheha	2026-02-05 12:20:02.005	2026-02-05 12:20:02.005	Contrats	Contrats et conventions	#10B981	FileSignature	\N	3	cml6vykdd0000jms2wwxl9s27
cml9fca5g0007h7vh661fe38w	2026-02-05 12:20:02.021	2026-02-05 12:20:02.021	Pièces Client	Documents fournis par le client	#F59E0B	Upload	\N	4	cml6vykdd0000jms2wwxl9s27
cml9fca5m0008h7vhoq20gqbn	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Assignations	Actes d'assignation	#F87171	FileText	cml9fca4d0001h7vhsvoms05d	1	cml6vykdd0000jms2wwxl9s27
cml9fca5m0009h7vhfqu69v0o	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Conclusions	Conclusions et mémoires	#FB923C	FileText	cml9fca4d0001h7vhsvoms05d	2	cml6vykdd0000jms2wwxl9s27
cml9fca5m000ah7vhf8jyhsof	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Pièces	Pièces du dossier	#FBBF24	Paperclip	cml9fca4d0001h7vhsvoms05d	3	cml6vykdd0000jms2wwxl9s27
cml9fca5m000bh7vhrsa2s3c0	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Jugements	Décisions de justice	#A78BFA	Gavel	cml9fca4d0001h7vhsvoms05d	4	cml6vykdd0000jms2wwxl9s27
cml9fca6u000ch7vhoejhtoui	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	Statuts	Statuts et modifications	#60A5FA	FileText	cml9fca4q0003h7vhssckybk0	1	cml6vykdd0000jms2wwxl9s27
cml9fca6u000dh7vhcktfw9sk	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	PV Assemblées	Procès-verbaux d'assemblées	#34D399	Users	cml9fca4q0003h7vhssckybk0	2	cml6vykdd0000jms2wwxl9s27
cml9fca6u000eh7vh9dx3l6pk	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	Cessions	Documents de cession	#818CF8	ArrowRightLeft	cml9fca4q0003h7vhssckybk0	3	cml6vykdd0000jms2wwxl9s27
cml9fca6u000fh7vhstat1869	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	Garanties	Garanties d'actif et passif	#F472B6	Shield	cml9fca4q0003h7vhssckybk0	4	cml6vykdd0000jms2wwxl9s27
cml9fca7l000gh7vhrbmskz0b	2026-02-05 12:20:02.097	2026-02-05 12:20:02.097	Contrats de travail	CDI, CDD, avenants	#2DD4BF	Briefcase	cml9fca520005h7vhc62fheha	1	cml6vykdd0000jms2wwxl9s27
cml9fca7l000hh7vhef7wy2sn	2026-02-05 12:20:02.097	2026-02-05 12:20:02.097	Contrats commerciaux	Vente, distribution, partenariat	#A3E635	Handshake	cml9fca520005h7vhc62fheha	2	cml6vykdd0000jms2wwxl9s27
cml9fca7l000ih7vhplroctgk	2026-02-05 12:20:02.097	2026-02-05 12:20:02.097	Baux	Baux commerciaux et professionnels	#FB7185	Home	cml9fca520005h7vhc62fheha	3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: folder_doc_categories; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_doc_categories (id, "createdAt", "folderId", name, ordre, icon) FROM stdin;
cmlaz9yds0005i4b0f9oqver8	2026-02-06 14:25:51.952	cmlaz9ydk0001i4b0mf637jrl	Actes et contrats	0	\N
cmlaz9ydv0007i4b0b9cpkbty	2026-02-06 14:25:51.955	cmlaz9ydk0001i4b0mf637jrl	Correspondances	1	\N
cmlaz9ydw0009i4b0kb4xp3jg	2026-02-06 14:25:51.957	cmlaz9ydk0001i4b0mf637jrl	Pièces justificatives	2	\N
cmlaz9ydy000bi4b0ssksud9c	2026-02-06 14:25:51.958	cmlaz9ydk0001i4b0mf637jrl	Formalités	3	\N
cmlaz9ydz000di4b0u9o87tzd	2026-02-06 14:25:51.959	cmlaz9ydq0003i4b0dggysja4	Actes de procédure	0	\N
cmlaz9ye0000fi4b0bcwgm0ug	2026-02-06 14:25:51.961	cmlaz9ydq0003i4b0dggysja4	Conclusions	1	\N
cmlaz9ye1000hi4b0g3ds6f03	2026-02-06 14:25:51.962	cmlaz9ydq0003i4b0dggysja4	Correspondances	2	\N
cmlaz9ye2000ji4b0ie542f5b	2026-02-06 14:25:51.963	cmlaz9ydq0003i4b0dggysja4	Pièces	3	\N
cmlaz9ye4000li4b0ni13i9hz	2026-02-06 14:25:51.964	cmlaz9ydq0003i4b0dggysja4	Décisions	4	\N
cmlb17in10004111vjlkbnh8p	2026-02-06 15:19:57.451	cmlb17ims0002111v6gbo2rh6	Actes et contrats	0	\N
cmlb17in30006111v6uq23nuq	2026-02-06 15:19:57.451	cmlb17ims0002111v6gbo2rh6	Correspondances	1	\N
cmlb17in50008111v916iojml	2026-02-06 15:19:57.451	cmlb17ims0002111v6gbo2rh6	Pièces justificatives	2	\N
cmlb17in6000a111vvtdjbn5g	2026-02-06 15:19:57.451	cmlb17ims0002111v6gbo2rh6	Formalités	3	\N
cmlb185ha000l111vm5syjgzk	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	Actes de procédure	0	\N
cmlb185hc000n111vpu3gh7qm	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	Conclusions	1	\N
cmlb185hd000p111vf8zmmwaz	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	Correspondances	2	\N
cmlb185he000r111vr3a6c5wd	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	Pièces	3	\N
cmlb185hf000t111vpw20do0a	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	Décisions	4	\N
cmlb18yqb0006f4hady3e9i1j	2026-02-06 15:21:04.94	cmlb18ypu0004f4ha1yi87is2	Actes et contrats	0	\N
cmlb18yqd0008f4hawfyl5fom	2026-02-06 15:21:04.94	cmlb18ypu0004f4ha1yi87is2	Correspondances	1	\N
cmlb18yqf000af4hacwh1u6g4	2026-02-06 15:21:04.94	cmlb18ypu0004f4ha1yi87is2	Pièces justificatives	2	\N
cmlb18yqg000cf4haallk1olm	2026-02-06 15:21:04.94	cmlb18ypu0004f4ha1yi87is2	Formalités	3	\N
cmlb1sqqw0001110l9xea9dxu	2026-02-06 15:36:27.752	cmlb18ypu0004f4ha1yi87is2	Test Phase2B	4	\N
\.


--
-- Data for Name: folder_persons; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_persons (id, "createdAt", "updatedAt", "folderId", "tenantId", type, role, "firstName", "lastName", company, email, phone, address, notes, "avocatAdverseId", barreau, cabinet, "clientId", ordre) FROM stdin;
cml9d6rdu000110v1tusjcjkg	2026-02-05 11:19:45.186	2026-02-05 11:24:12.516	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	PARTIE_ADVERSE	Jean	Dupont	\N	jean.dupont@example.com	06 12 34 56 78	123 rue de Paris, 75001 Paris	Client principal dans le litige	\N	\N	\N	\N	0
cmlaz9yeg000pi4b0q53ryph6	2026-02-06 14:25:51.976	2026-02-06 14:25:51.976	cmlaz9ydq0003i4b0dggysja4	cml6vykdd0000jms2wwxl9s27	MORALE	PARTIE_ADVERSE	\N	Alpha Distribution SAS	Alpha Distribution SAS	contact@alphadistrib.fr	01 98 76 54 32	50 boulevard Haussmann, 75009 Paris	\N	\N	\N	\N	\N	0
cmlaz9yej000ri4b00keiq3zm	2026-02-06 14:25:51.979	2026-02-06 14:25:51.979	cmlaz9ydq0003i4b0dggysja4	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	AVOCAT_ADVERSE	Sophie	MARTIN	\N	sophie.martin@cabinet-martin.fr	01 44 55 66 77	\N	\N	\N	Paris	Cabinet Martin & Associés	\N	1
cmlaz9yel000ti4b0x8xzgwbk	2026-02-06 14:25:51.981	2026-02-06 14:25:51.981	cmlaz9ydq0003i4b0dggysja4	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	EXPERT	Pierre	DURAND	\N	p.durand@expert-comptable.fr	02 41 33 44 55	\N	Expert-comptable désigné par le tribunal	\N	\N	\N	\N	2
cmlb17in7000c111v1hqfzg4p	2026-02-06 15:19:57.451	2026-02-06 15:19:57.451	cmlb17ims0002111v6gbo2rh6	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	CLIENT	\N	Tech Corp SAS	\N	direction@techcorp-seed.fr	01 23 45 67 89	\N	\N	\N	\N	\N	seed-client-techcorp-pm	0
cmlb185hh000v111vtmw538j8	2026-02-06 15:20:27.06	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	CLIENT	\N	Tech Corp SAS	\N	direction@techcorp-seed.fr	01 23 45 67 89	\N	\N	\N	\N	\N	seed-client-techcorp-pm	0
cmlb185hl000x111vnyiuh77n	2026-02-06 15:20:27.06	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	PARTIE_ADVERSE	\N	SARL Durand	\N	contact@durand.fr	\N	12 rue de la Paix, 49000 Angers	\N	\N	\N	\N	\N	0
cmlb185ho000z111vaq6mb6po	2026-02-06 15:20:27.06	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	AVOCAT_ADVERSE	\N	Me Martin	\N	martin@avocat.fr	\N	\N	\N	cmlb185hl000x111vnyiuh77n	Angers	Cabinet Martin	\N	0
cmlb185hq0011111v3sfglwuo	2026-02-06 15:20:27.06	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	POSTULANT	\N	Me Leroy	\N	\N	\N	\N	\N	\N	Nantes	Cabinet Leroy	\N	0
cmlb18yqh000ef4haizifdm8r	2026-02-06 15:21:04.94	2026-02-06 15:21:04.94	cmlb18ypu0004f4ha1yi87is2	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	CLIENT	Jean	WizardTest2	\N	wizard.test2@example.fr	\N	\N	\N	\N	\N	\N	cmlb18ypa0002f4haozbrecum	0
cmlb9ldzb000vo0taldw44cvz	2026-02-06 19:14:41.543	2026-02-06 19:14:41.543	cmlb9ldyl000fo0ta56i3m5t7	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	EXPERT	Catherine	Blanc	\N	person-f5ce19@avocat.fr	06 18422125	82 rue des Lilas	\N	\N	\N	\N	\N	0
cmlb9ldzg000xo0tags5lzj70	2026-02-06 19:14:41.549	2026-02-06 19:14:41.549	cmlb9ldyq000ho0tab273yhyu	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	AVOCAT_ADVERSE	Francois	Garnier	\N	person-657559@avocat.fr	06 50788645	70 rue de la Republique	\N	\N	\N	\N	\N	0
cmlb9ldzi000zo0tafdfcbdlr	2026-02-06 19:14:41.55	2026-02-06 19:14:41.55	cmlb9ldyt000jo0taxfxaxno0	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	NOTAIRE	Alain	Garnier	\N	person-e422b6@avocat.fr	06 58144229	85 rue du Marechal Foch	\N	\N	\N	\N	\N	0
cmlb9ldzk0011o0tayfstumot	2026-02-06 19:14:41.552	2026-02-06 19:14:41.552	cmlb9ldyv000lo0tagud0d5cn	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	AVOCAT_ADVERSE	Patrick	Garnier	\N	person-754730@avocat.fr	06 52734808	62 rue de la Republique	\N	\N	\N	\N	\N	0
cmlb9ldzm0013o0taghu72zrm	2026-02-06 19:14:41.554	2026-02-06 19:14:41.554	cmlb9ldyv000lo0tagud0d5cn	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	EXPERT	Catherine	Dubois	\N	person-f9392d@avocat.fr	06 85739516	35 rue du Marechal Foch	\N	\N	\N	\N	\N	1
cmlb9ldzp0015o0tacri600ew	2026-02-06 19:14:41.557	2026-02-06 19:14:41.557	cmlb9ldyz000no0tavpxqe5f8	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	AVOCAT_ADVERSE	Catherine	Garnier	\N	person-759894@avocat.fr	06 77353136	37 rue du Marechal Foch	\N	\N	\N	\N	\N	0
cmlb9ldzr0017o0ta2hrfxxkl	2026-02-06 19:14:41.559	2026-02-06 19:14:41.559	cmlb9ldyz000no0tavpxqe5f8	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	EXPERT	Francois	Roux	\N	person-78b8cb@avocat.fr	06 78060864	28 rue du Marechal Foch	\N	\N	\N	\N	\N	1
cmlb9ldzt0019o0tarczw6va6	2026-02-06 19:14:41.562	2026-02-06 19:14:41.562	cmlb9ldyz000no0tavpxqe5f8	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	TEMOIN	Catherine	Dubois	\N	person-e7dee0@avocat.fr	06 23371640	36 rue Jean Jaures	\N	\N	\N	\N	\N	2
cmlb9ltzm000hxjn8akye9lbw	2026-02-06 19:15:02.291	2026-02-06 19:15:02.291	cmlb9lty80001xjn8sorgq1d3	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	NOTAIRE	Patrick	Dubois	\N	person-c40cac@avocat.fr	06 61571616	84 rue de la Republique	\N	\N	\N	\N	\N	0
cmlb9ltzt000jxjn8t505d3n6	2026-02-06 19:15:02.298	2026-02-06 19:15:02.298	cmlb9ltyg0003xjn8p26kbkxt	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	TEMOIN	Catherine	Dubois	\N	person-d536b0@avocat.fr	06 23288665	65 rue de la Republique	\N	\N	\N	\N	\N	0
cmlb9ltzz000lxjn8w72xx32w	2026-02-06 19:15:02.303	2026-02-06 19:15:02.303	cmlb9ltym0005xjn8jqppbtxh	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	PARTIE_ADVERSE	Francois	Petit	\N	person-d2ad8c@avocat.fr	06 92001118	35 rue de la Republique	\N	\N	\N	\N	\N	0
cmlb9lu07000nxjn83nkcr14x	2026-02-06 19:15:02.311	2026-02-06 19:15:02.311	cmlb9ltym0005xjn8jqppbtxh	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	AVOCAT_ADVERSE	Catherine	Dubois	\N	person-9046be@avocat.fr	06 59826284	3 rue du Marechal Foch	\N	\N	\N	\N	\N	1
cmlb9lu0b000pxjn88iiklyex	2026-02-06 19:15:02.315	2026-02-06 19:15:02.315	cmlb9ltym0005xjn8jqppbtxh	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	EXPERT	Alain	Dubois	\N	person-7a087c@avocat.fr	06 49311166	17 rue Jean Jaures	\N	\N	\N	\N	\N	2
cmlb9lu0j000rxjn8b785w4lp	2026-02-06 19:15:02.323	2026-02-06 19:15:02.323	cmlb9ltys0007xjn8hiblj6iz	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	EXPERT	Patrick	Dubois	\N	person-14a10f@avocat.fr	06 64483767	36 rue du Marechal Foch	\N	\N	\N	\N	\N	0
cmlb9lu0p000txjn8a6r05qxm	2026-02-06 19:15:02.33	2026-02-06 19:15:02.33	cmlb9ltys0007xjn8hiblj6iz	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	TEMOIN	Catherine	Dubois	\N	person-3af9f2@avocat.fr	06 79895293	41 rue des Lilas	\N	\N	\N	\N	\N	1
cmlb9lu0x000vxjn8v8aafjzg	2026-02-06 19:15:02.337	2026-02-06 19:15:02.337	cmlb9ltys0007xjn8hiblj6iz	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	PARTIE_ADVERSE	Patrick	Roux	\N	person-be3908@avocat.fr	06 82072831	50 rue Jean Jaures	\N	\N	\N	\N	\N	2
cmlb9lu13000xxjn831jaz17e	2026-02-06 19:15:02.344	2026-02-06 19:15:02.344	cmlb9ltyx0009xjn8ev7qvq1y	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	NOTAIRE	Nathalie	Roux	\N	person-90cc81@avocat.fr	06 50692300	28 rue de la Republique	\N	\N	\N	\N	\N	0
cmlb9lu17000zxjn85hm4jvtu	2026-02-06 19:15:02.348	2026-02-06 19:15:02.348	cmlb9ltyx0009xjn8ev7qvq1y	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	TEMOIN	Francois	Blanc	\N	person-374991@avocat.fr	06 96664647	13 rue des Lilas	\N	\N	\N	\N	\N	1
\.


--
-- Data for Name: folder_templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_templates (id, "createdAt", "updatedAt", name, description, "folderType", structure, "tenantId") FROM stdin;
\.


--
-- Data for Name: folder_tree_templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_tree_templates (id, "createdAt", "updatedAt", "tenantId", name, "folderType", categories, "isDefault") FROM stdin;
cmlaz9yea000ni4b01d1pperh	2026-02-06 14:25:51.97	2026-02-06 14:25:51.97	cml6vykdd0000jms2wwxl9s27	Arborescence judiciaire	judiciaire	[{"name": "Actes de procédure", "ordre": 0}, {"name": "Conclusions", "ordre": 1}, {"name": "Correspondances", "ordre": 2}, {"name": "Pièces", "ordre": 3}, {"name": "Décisions", "ordre": 4}]	t
cmlaz9ye5000mi4b0t072m8rf	2026-02-06 14:25:51.966	2026-02-06 17:23:47.079	cml6vykdd0000jms2wwxl9s27	Arborescence juridique	juridique	[{"name": "Actes et contrats", "ordre": 0}, {"name": "Correspondances", "ordre": 1}, {"name": "Pièces justificatives", "ordre": 2}, {"name": "Formalités", "ordre": 3}]	f
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folders (id, "createdAt", "updatedAt", reference, title, description, type, status, "openedAt", "closedAt", "archivedAt", "clientId", "createdById", "tenantId", color, "metadataCession", "parentId", chambre, "dateAudience", "dateEcheance", "deletedAt", juridiction, nature, "numeroRG") FROM stdin;
cml6vyl0v000djms25rbug5x8	2026-02-03 17:41:57.872	2026-02-03 17:41:57.872	2026-001	Cession entreprise Tech Corp	Dossier de cession de parts sociales Tech Corp SAS	BUSINESS	IN_PROGRESS	2026-02-03 17:41:57.872	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml6vyl0z000fjms24ukfhi3k	2026-02-03 17:41:57.876	2026-02-03 17:41:57.876	2026-002	Contrats commerciaux	Rédaction contrats fournisseurs	CONTRACT	OPEN	2026-02-03 17:41:57.876	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml6vyl11000hjms2krxzvmzx	2026-02-03 17:41:57.877	2026-02-03 17:41:57.877	2026-003	Litige fournisseur	Contentieux livraison matériel informatique	LITIGATION	IN_PROGRESS	2026-02-03 17:41:57.877	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb1z000510pf9trmhfa2	2026-02-04 19:33:50.327	2026-02-04 19:33:50.327	DOS-2026-004	Tech Corp - Litige Commercial	Contentieux avec fournisseur	LITIGATION	OPEN	2026-02-04 19:33:50.327	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EF4444	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb29000710pfjmjz3odz	2026-02-04 19:33:50.337	2026-02-04 19:33:50.337	DOS-2026-005	Tech Corp - Contrat Distribution	Négociation contrat de distribution	CONTRACT	OPEN	2026-02-04 19:33:50.337	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#10B981	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb2e000910pfzh5ilxb7	2026-02-04 19:33:50.342	2026-02-04 19:33:50.342	DOS-2026-006	StartupX - Levée de Fonds	Série A - Documentation juridique	BUSINESS	OPEN	2026-02-04 19:33:50.342	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#8B5CF6	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb2i000b10pfg17hbnxm	2026-02-04 19:33:50.346	2026-02-04 19:33:50.346	DOS-2026-007	StartupX - Pacte Associés	Rédaction pacte d'associés	BUSINESS	OPEN	2026-02-04 19:33:50.346	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#F59E0B	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb2l000d10pfe8y2gtge	2026-02-04 19:33:50.35	2026-02-04 19:33:50.35	DOS-2026-008	InnovCo - Cession Parts Sociales	Cession de 30% des parts	BUSINESS	OPEN	2026-02-04 19:33:50.35	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EC4899	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb2q000f10pfwi9qm0ph	2026-02-04 19:33:50.354	2026-02-04 19:33:50.354	DOS-2026-009	InnovCo - Propriété Intellectuelle	Dépôt de marque et brevets	INTELLECTUAL	OPEN	2026-02-04 19:33:50.354	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#06B6D4	\N	\N	\N	\N	\N	\N	\N	\N	\N
cml8feb2t000h10pfy2cvm3la	2026-02-04 19:33:50.357	2026-02-04 19:33:50.357	DOS-2026-010	InnovCo - Contrat de Travail	Recrutement CTO	LABOR	OPEN	2026-02-04 19:33:50.357	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#14B8A6	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-101	Tech Corp - Restructuration 2026	Opération de restructuration complète	BUSINESS	OPEN	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-102	Tech Corp - Contentieux Fournisseur Alpha	Litige commercial avec fournisseur	LITIGATION	IN_PROGRESS	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EF4444	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-103	Tech Corp - Réseau Distribution	Mise en place réseau de distribution	CONTRACT	OPEN	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#10B981	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-104	StartupX - Levée Série A	Documentation juridique levée de fonds	BUSINESS	IN_PROGRESS	2026-02-04 20:53:56.607	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#8B5CF6	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-105	StartupX - Pacte Associés	Rédaction et négociation pacte	BUSINESS	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#F59E0B	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-106	StartupX - Recrutement CTO	Contrat de travail directeur technique	LABOR	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#06B6D4	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-107	InnovCo - Cession 30% Parts	Cession parts sociales à investisseur	BUSINESS	IN_PROGRESS	2026-02-04 20:53:56.607	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EC4899	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-108	InnovCo - Protection Marques	Dépôt et protection marques et brevets	INTELLECTUAL	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#14B8A6	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-109	InnovCo - Licence Technologie	Contrat de licence technologique	CONTRACT	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#0EA5E9	\N	\N	\N	\N	\N	\N	\N	\N	\N
fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-110	Tech Corp - Nouveau Siège Social	Négociation bail commercial nouveaux locaux	CONTRACT	OPEN	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#FBBF24	\N	\N	\N	\N	\N	\N	\N	\N	\N
cmlaqnv9e000hyf6npv6echvh	2026-02-06 10:24:44.546	2026-02-06 10:24:44.546	DOS-2026-0021	essai	\N	CRIMINAL	OPEN	2026-02-06 10:24:44.546	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	null	\N	\N	\N	\N	\N	\N	\N	\N
cmlaz9ydk0001i4b0mf637jrl	2026-02-06 14:25:51.944	2026-02-06 14:25:51.944	DOS-2026-SEED-001	Cession Tech Corp 2026	Cession de parts sociales de Tech Corp SAS	CONTRACT	IN_PROGRESS	2026-02-06 14:25:51.944	\N	\N	seed-client-dupont-pp	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	cession	\N
cmlaz9ydq0003i4b0dggysja4	2026-02-06 14:25:51.95	2026-02-06 14:25:51.95	DOS-2026-SEED-002	Litige Commercial Alpha Distribution	Contentieux suite rupture brutale de relation commerciale	LITIGATION	IN_PROGRESS	2026-02-06 14:25:51.95	\N	\N	seed-client-techcorp-pm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EF4444	\N	\N	3ème chambre	\N	\N	\N	Tribunal de Commerce	contentieux	2026/01234
cmlb17ims0002111v6gbo2rh6	2026-02-06 15:19:57.451	2026-02-06 15:19:57.451	DOS-2026-0024	Test Wizard Cession 2026	Dossier test wizard	CONTRACT	OPEN	2026-02-06 00:00:00	\N	\N	seed-client-techcorp-pm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	cession	\N
cmlb185h4000j111vmhnvpqz9	2026-02-06 15:20:27.06	2026-02-06 15:20:27.06	DOS-2026-0025	TechCorp c/ Durand 2026	Contentieux commercial	LITIGATION	OPEN	2026-02-06 00:00:00	\N	\N	seed-client-techcorp-pm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	1ere chambre	2026-03-15 00:00:00	\N	\N	TJ	\N	26/12345
cmlb18ypu0004f4ha1yi87is2	2026-02-06 15:21:04.94	2026-02-06 15:21:22.199	DOS-2026-0026	AGOA WizardTest2 2026	\N	CONTRACT	OPEN	2026-02-06 00:00:00	\N	\N	cmlb18ypa0002f4haozbrecum	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	agoa	\N
cmlb9ldyl000fo0ta56i3m5t7	2026-02-06 19:14:41.518	2026-02-06 19:14:41.518	DOS-2026-0027	Divorce Dupont/Martin	\N	FAMILY	PENDING	2025-11-09 10:29:41.517	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	divorce	\N
cmlb9ldyq000ho0tab273yhyu	2026-02-06 19:14:41.522	2026-02-06 19:14:41.522	DOS-2026-0028	Cession parts SCI Les Tilleuls	\N	BUSINESS	CLOSED	2025-12-02 15:38:41.521	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	cession	\N
cmlb9ldyt000jo0taxfxaxno0	2026-02-06 19:14:41.525	2026-02-06 19:14:41.525	DOS-2026-0029	Licenciement abusif Bernard c/ SARL Tech	\N	LABOR	OPEN	2025-12-10 15:27:41.524	\N	\N	cmlb9ldx70001o0tamiqnlfuf	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	contentieux_travail	\N
cmlb9ldyv000lo0tagud0d5cn	2026-02-06 19:14:41.528	2026-02-06 19:14:41.528	DOS-2026-0030	Acquisition immobiliere Leroy	\N	REAL_ESTATE	CLOSED	2026-01-11 11:52:41.527	\N	\N	cmlb9ldxw0007o0tanjtunl3y	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	acquisition	\N
cmlb9ldyz000no0tavpxqe5f8	2026-02-06 19:14:41.532	2026-02-06 19:14:41.532	DOS-2026-0031	Contentieux bail commercial Moreau	\N	LITIGATION	OPEN	2026-01-26 14:04:41.531	\N	\N	cmlb6amcr0001bx8t8nqvtc99	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	bail_commercial	\N
cmlb9ldz2000po0taqlkknhzy	2026-02-06 19:14:41.534	2026-02-06 19:14:41.534	DOS-2026-0032	Constitution SAS InnoTech	\N	BUSINESS	OPEN	2025-12-02 09:18:41.534	\N	\N	seed-client-techcorp-pm	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	creation_societe	\N
cmlb9ldz5000ro0ta3kzm9xhn	2026-02-06 19:14:41.537	2026-02-06 19:14:41.537	DOS-2026-0033	Succession Martin	\N	FAMILY	PENDING	2025-12-24 09:08:41.536	\N	\N	cmlb9ldxj0003o0tact9t3n7s	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	succession	\N
cmlb9ldz7000to0ta68iy83zc	2026-02-06 19:14:41.539	2026-02-06 19:14:41.539	DOS-2026-0034	Redaction contrat de travail CDI	\N	CONTRACT	IN_PROGRESS	2026-01-19 11:12:41.538	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	contrat_travail	\N
cmlb9lty80001xjn8sorgq1d3	2026-02-06 19:15:02.24	2026-02-06 19:15:02.24	DOS-2026-0035	Divorce Dupont/Martin	\N	FAMILY	CLOSED	2026-01-04 15:57:02.239	\N	\N	cmlb18ypa0002f4haozbrecum	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	divorce	\N
cmlb9ltyg0003xjn8p26kbkxt	2026-02-06 19:15:02.248	2026-02-06 19:15:02.248	DOS-2026-0036	Cession parts SCI Les Tilleuls	\N	BUSINESS	PENDING	2025-12-15 09:04:02.247	\N	\N	cmlb9ldxj0003o0tact9t3n7s	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	cession	\N
cmlb9ltym0005xjn8jqppbtxh	2026-02-06 19:15:02.255	2026-02-06 19:15:02.255	DOS-2026-0037	Licenciement abusif Bernard c/ SARL Tech	\N	LABOR	CLOSED	2026-01-17 09:30:02.254	\N	\N	cmlb9ldx70001o0tamiqnlfuf	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	contentieux_travail	\N
cmlb9ltys0007xjn8hiblj6iz	2026-02-06 19:15:02.26	2026-02-06 19:15:02.26	DOS-2026-0038	Acquisition immobiliere Leroy	\N	REAL_ESTATE	PENDING	2026-01-14 11:15:02.259	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	acquisition	\N
cmlb9ltyx0009xjn8ev7qvq1y	2026-02-06 19:15:02.265	2026-02-06 19:15:02.265	DOS-2026-0039	Contentieux bail commercial Moreau	\N	LITIGATION	IN_PROGRESS	2025-12-06 12:41:02.264	\N	\N	cmlb6wsr4000ttwwicmehqmiu	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	bail_commercial	\N
cmlb9ltz2000bxjn8n1ih7loj	2026-02-06 19:15:02.27	2026-02-06 19:15:02.27	DOS-2026-0040	Constitution SAS InnoTech	\N	BUSINESS	PENDING	2025-11-13 15:25:02.269	\N	\N	cmlb9ldxj0003o0tact9t3n7s	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	creation_societe	\N
cmlb9ltz6000dxjn8q3ikm5q2	2026-02-06 19:15:02.274	2026-02-06 19:15:02.274	DOS-2026-0041	Succession Martin	\N	FAMILY	PENDING	2026-01-05 14:20:02.273	\N	\N	cmlb9ldyc000do0tayw7fbac9	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	succession	\N
cmlb9ltzc000fxjn8pe5zbquq	2026-02-06 19:15:02.28	2026-02-06 19:15:02.28	DOS-2026-0042	Redaction contrat de travail CDI	\N	CONTRACT	PENDING	2025-12-17 12:43:02.279	\N	\N	cmlb63n48000x1021lafmd6nw	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N	\N	\N	\N	\N	\N	contrat_travail	\N
cmlc7t86l0003g2ouf76d74yj	2026-02-07 11:12:34.222	2026-02-07 11:12:34.222	DOS-2026-0043	Test Email Brevo	\N	LITIGATION	OPEN	2026-02-07 11:12:34.222	\N	\N	cmlc6ju1k0016yhmm97qv58zj	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	null	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.messages (id, "createdAt", "updatedAt", "conversationId", content, attachments, "senderId", "isEdited", "editedAt", "isDeleted", "deletedAt", "tenantId") FROM stdin;
cmlb9lul1009exjn83bvzgq3w	2026-02-02 08:22:03.046	2026-02-06 19:15:03.061	cmlb9lukn009axjn8twr540rj	Bonjour, pouvez-vous me confirmer la date de rendez-vous ?	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lul9009gxjn8zky3sn3i	2026-02-02 09:22:03.046	2026-02-06 19:15:03.069	cmlb9lukn009axjn8twr540rj	Oui, c'est prevu pour jeudi prochain a 14h.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luld009ixjn86mtlmzgj	2026-02-02 10:22:03.046	2026-02-06 19:15:03.074	cmlb9lukn009axjn8twr540rj	Parfait, je prepare les documents necessaires.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lulh009kxjn8luiovc4x	2026-02-02 11:22:03.046	2026-02-06 19:15:03.077	cmlb9lukn009axjn8twr540rj	N'oubliez pas d'apporter les conclusions au fond.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luls009pxjn8fdumz0mo	2026-02-06 14:09:03.079	2026-02-06 19:15:03.088	cmlb9lulk009lxjn8cmhfrifh	Bonjour, pouvez-vous me confirmer la date de rendez-vous ?	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lulw009rxjn8zbaray9n	2026-02-06 15:09:03.079	2026-02-06 19:15:03.093	cmlb9lulk009lxjn8cmhfrifh	Oui, c'est prevu pour jeudi prochain a 14h.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lum0009txjn8x4g1q4gw	2026-02-06 16:09:03.079	2026-02-06 19:15:03.097	cmlb9lulk009lxjn8cmhfrifh	Parfait, je prepare les documents necessaires.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lumc009yxjn8jb2w63hb	2026-02-04 02:20:03.099	2026-02-06 19:15:03.109	cmlb9lum3009uxjn8bwqou45g	Bonjour, pouvez-vous me confirmer la date de rendez-vous ?	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lumf00a0xjn8z0gis54i	2026-02-04 03:20:03.099	2026-02-06 19:15:03.111	cmlb9lum3009uxjn8bwqou45g	Oui, c'est prevu pour jeudi prochain a 14h.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lumg00a2xjn8e1c4x5uv	2026-02-04 04:20:03.099	2026-02-06 19:15:03.113	cmlb9lum3009uxjn8bwqou45g	Parfait, je prepare les documents necessaires.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lumj00a4xjn84v6kb6mr	2026-02-04 05:20:03.099	2026-02-06 19:15:03.115	cmlb9lum3009uxjn8bwqou45g	N'oubliez pas d'apporter les conclusions au fond.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lumm00a6xjn8hp0rd1ky	2026-02-04 06:20:03.099	2026-02-06 19:15:03.119	cmlb9lum3009uxjn8bwqou45g	Le client a confirme sa presence.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lump00a8xjn81ujwyc28	2026-02-04 07:20:03.099	2026-02-06 19:15:03.122	cmlb9lum3009uxjn8bwqou45g	J'ai recu les pieces complementaires.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lumy00adxjn863684fif	2026-02-02 11:02:03.124	2026-02-06 19:15:03.13	cmlb9lums00a9xjn8kgzqgri6	Bonjour, pouvez-vous me confirmer la date de rendez-vous ?	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lun100afxjn8znzzsw41	2026-02-02 12:02:03.124	2026-02-06 19:15:03.133	cmlb9lums00a9xjn8kgzqgri6	Oui, c'est prevu pour jeudi prochain a 14h.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lun300ahxjn8ufh6sz5f	2026-02-02 13:02:03.124	2026-02-06 19:15:03.135	cmlb9lums00a9xjn8kgzqgri6	Parfait, je prepare les documents necessaires.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lun700ajxjn8s7o8lp0l	2026-02-02 14:02:03.124	2026-02-06 19:15:03.14	cmlb9lums00a9xjn8kgzqgri6	N'oubliez pas d'apporter les conclusions au fond.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luna00alxjn8ym2ne8kw	2026-02-02 15:02:03.124	2026-02-06 19:15:03.142	cmlb9lums00a9xjn8kgzqgri6	Le client a confirme sa presence.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lund00anxjn8hp5kmjt2	2026-02-02 16:02:03.124	2026-02-06 19:15:03.146	cmlb9lums00a9xjn8kgzqgri6	J'ai recu les pieces complementaires.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lunm00asxjn84gfrdjs4	2026-02-06 06:43:03.148	2026-02-06 19:15:03.155	cmlb9lung00aoxjn82aqttyw5	Bonjour, pouvez-vous me confirmer la date de rendez-vous ?	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lunp00auxjn8yi1wx2ib	2026-02-06 07:43:03.148	2026-02-06 19:15:03.157	cmlb9lung00aoxjn82aqttyw5	Oui, c'est prevu pour jeudi prochain a 14h.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lunr00awxjn8zcfmc3fw	2026-02-06 08:43:03.148	2026-02-06 19:15:03.159	cmlb9lung00aoxjn82aqttyw5	Parfait, je prepare les documents necessaires.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lunu00ayxjn8ag7o9p92	2026-02-06 09:43:03.148	2026-02-06 19:15:03.162	cmlb9lung00aoxjn82aqttyw5	N'oubliez pas d'apporter les conclusions au fond.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9lunx00b0xjn8qfsc7v89	2026-02-06 10:43:03.148	2026-02-06 19:15:03.166	cmlb9lung00aoxjn82aqttyw5	Le client a confirme sa presence.	\N	cml6vykp40004jms2d2rnfrpm	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
cmlb9luo100b2xjn83w4g974l	2026-02-06 11:43:03.148	2026-02-06 19:15:03.169	cmlb9lung00aoxjn82aqttyw5	J'ai recu les pieces complementaires.	\N	cml6vykja0002jms2hhr4hfr3	f	\N	f	\N	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.notification_preferences (id, "createdAt", "updatedAt", "userId", "emailSignatures", "emailDocuments", "emailDeadlines", "emailMessages", "emailDigest", "digestFrequency", "pushEnabled", "pushSignatures", "pushDocuments", "pushDeadlines", "pushMessages") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.notifications (id, "createdAt", type, title, message, "entityType", "entityId", link, "isRead", "readAt", "emailSent", "emailSentAt", "userId", "tenantId") FROM stdin;
cmlb53w26000iveb59i52evxs	2026-02-06 17:09:06.703	CLIENT_STEP_COMPLETED	Fiche client mise à jour	Jean WizardTest2 a complété l'étape "Identité" (40%)	Client	cmlb18ypa0002f4haozbrecum	/clients/cmlb18ypa0002f4haozbrecum	f	\N	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7o0075o0tawbt2jarb	2026-01-25 17:59:41.844	SIGNATURE_COMPLETED	Dossier cree	Notification automatique concernant votre dossier.	Deadline	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	\N	t	2026-02-05 11:11:41.844	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le7r0077o0takmkskxwt	2026-01-25 11:18:41.847	DOCUMENT_REQUEST	Document partage	Notification automatique concernant votre dossier.	Document	cmlb9ldyq000ho0tab273yhyu	\N	f	\N	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le7t0079o0tapa2w9qmv	2026-02-02 11:28:41.849	MESSAGE_RECEIVED	Signature en attente	Notification automatique concernant votre dossier.	Deadline	cml8feb2e000910pfzh5ilxb7	\N	t	2026-02-06 16:54:41.849	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le7w007bo0tawhvb8igx	2026-02-05 13:32:41.851	CLIENT_ACCESS_CREATED	Document signe	Notification automatique concernant votre dossier.	Folder	cmlb17ims0002111v6gbo2rh6	\N	t	2026-02-06 14:43:41.851	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le80007do0tafh9zoa9k	2026-01-31 08:15:41.855	DOCUMENT_UPLOADED	Dossier cree	Notification automatique concernant votre dossier.	Folder	fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	\N	t	2026-02-06 17:18:41.855	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le82007fo0ta502qu9tl	2026-02-05 08:56:41.858	DEADLINE_APPROACHING	Deadline depassee	Notification automatique concernant votre dossier.	Deadline	cml8feb2e000910pfzh5ilxb7	\N	t	2026-02-04 08:22:41.858	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le84007ho0ta4c9qjhnw	2026-01-29 14:45:41.86	DOCUMENT_UPLOADED	Nouveau document depose	Notification automatique concernant votre dossier.	Signature	cmlb185h4000j111vmhnvpqz9	\N	t	2026-02-05 10:08:41.86	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le86007jo0taeal8n09t	2026-02-03 14:12:41.861	SIGNATURE_PENDING	Signature en attente	Notification automatique concernant votre dossier.	Deadline	fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	\N	f	\N	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le88007lo0taqdc127ax	2026-02-06 16:28:41.863	MESSAGE_RECEIVED	Nouveau message	Notification automatique concernant votre dossier.	Document	cml6vyl0v000djms25rbug5x8	\N	f	\N	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le89007no0tacb3k8llp	2026-01-28 13:11:41.865	DOCUMENT_REQUEST	Acces client active	Notification automatique concernant votre dossier.	Document	cmlb9ldyl000fo0ta56i3m5t7	\N	f	\N	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le8b007po0ta1ugn22vg	2026-02-02 14:48:41.866	MESSAGE_RECEIVED	Nouveau message	Notification automatique concernant votre dossier.	Document	cmlb185h4000j111vmhnvpqz9	\N	t	2026-02-04 15:45:41.866	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le8c007ro0tanru3bam1	2026-02-01 14:19:41.868	CLIENT_ACCESS_CREATED	Document partage	Notification automatique concernant votre dossier.	Document	fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	\N	t	2026-02-04 10:21:41.868	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9le8e007to0tat2dk6ter	2026-01-27 16:18:41.869	SIGNATURE_COMPLETED	Deadline depassee	Notification automatique concernant votre dossier.	Folder	cml8feb2l000d10pfe8y2gtge	\N	t	2026-02-04 14:20:41.869	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le8g007vo0ta5lsfhtei	2026-01-28 10:09:41.871	DOCUMENT_UPLOADED	Nouveau message	Notification automatique concernant votre dossier.	Deadline	cml6vyl0z000fjms24ukfhi3k	\N	t	2026-02-05 09:54:41.871	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9le8h007xo0tazm0r9mva	2026-02-06 09:48:41.873	SIGNATURE_COMPLETED	Deadline depassee	Notification automatique concernant votre dossier.	Deadline	cmlb185h4000j111vmhnvpqz9	\N	f	\N	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lujd008hxjn80n19seox	2026-01-25 10:05:03	SIGNATURE_PENDING	Demande de document	Notification automatique concernant votre dossier.	Deadline	cmlb9lty80001xjn8sorgq1d3	\N	t	2026-02-04 09:40:03	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9lujh008jxjn8nlg4wefk	2026-02-05 15:41:03.004	DOCUMENT_REQUEST	Rappel audience	Notification automatique concernant votre dossier.	Folder	cmlb9ldyt000jo0taxfxaxno0	\N	t	2026-02-06 09:39:03.004	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lujk008lxjn8o0qzmd6q	2026-02-05 14:26:03.008	MESSAGE_RECEIVED	Rappel audience	Notification automatique concernant votre dossier.	Document	fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	\N	t	2026-02-05 11:54:03.008	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lujn008nxjn8snyc20rn	2026-01-29 17:35:03.01	DEADLINE_APPROACHING	Acces client active	Notification automatique concernant votre dossier.	Folder	fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	\N	t	2026-02-06 12:24:03.01	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9lujq008pxjn87fh9vm96	2026-02-05 16:42:03.013	DOCUMENT_REQUEST	Acces client active	Notification automatique concernant votre dossier.	Signature	cml8feb2l000d10pfe8y2gtge	\N	t	2026-02-06 09:28:03.013	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lujt008rxjn80cksfsjv	2026-01-28 15:21:03.017	SIGNATURE_PENDING	Document partage	Notification automatique concernant votre dossier.	Signature	cmlb185h4000j111vmhnvpqz9	\N	f	\N	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9lujw008txjn89dphz7wg	2026-01-28 10:41:03.02	SIGNATURE_COMPLETED	Dossier cree	Notification automatique concernant votre dossier.	Signature	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	\N	t	2026-02-05 16:38:03.02	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9luk0008vxjn852uwnhuv	2026-01-24 09:29:03.023	DEADLINE_APPROACHING	Signature en attente	Notification automatique concernant votre dossier.	Document	cmlaz9ydk0001i4b0mf637jrl	\N	t	2026-02-06 16:28:03.023	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luk3008xxjn8kplnsvtr	2026-01-26 16:35:03.027	FOLDER_CREATED	Document partage	Notification automatique concernant votre dossier.	Document	cmlb9ltys0007xjn8hiblj6iz	\N	f	\N	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9luk6008zxjn8azq3c5ob	2026-02-03 11:01:03.029	DOCUMENT_UPLOADED	Nouveau document depose	Notification automatique concernant votre dossier.	Folder	cmlaz9ydk0001i4b0mf637jrl	\N	t	2026-02-06 09:05:03.029	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9luk90091xjn8ic6jvyph	2026-02-05 14:11:03.033	DOCUMENT_REQUEST	Document partage	Notification automatique concernant votre dossier.	Deadline	cml8feb29000710pfjmjz3odz	\N	t	2026-02-05 17:14:03.033	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9lukc0093xjn8ve5o83wa	2026-01-31 13:01:03.035	DOCUMENT_UPLOADED	Profil client complete	Notification automatique concernant votre dossier.	Deadline	fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	\N	t	2026-02-06 08:02:03.035	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cmlb9luke0095xjn80vgd87l1	2026-02-01 15:56:03.037	FOLDER_CREATED	Dossier cree	Notification automatique concernant votre dossier.	Document	fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	\N	t	2026-02-04 10:33:03.037	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9lukh0097xjn84w3lfu4j	2026-02-06 15:24:03.041	DEADLINE_APPROACHING	Document signe	Notification automatique concernant votre dossier.	Folder	cml6vyl0z000fjms24ukfhi3k	\N	f	\N	f	\N	cml6vykp40004jms2d2rnfrpm	cml6vykdd0000jms2wwxl9s27
cmlb9lukk0099xjn8rw4rti6g	2026-01-27 14:44:03.043	DOCUMENT_REQUEST	Demande de document	Notification automatique concernant votre dossier.	Document	cml8feb29000710pfjmjz3odz	\N	t	2026-02-05 15:59:03.043	f	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.push_subscriptions (id, "createdAt", "accessId", endpoint, keys) FROM stdin;
\.


--
-- Data for Name: registered_mails; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.registered_mails (id, "createdAt", "updatedAt", "documentId", "recipientName", "recipientAddress", "recipientCity", "recipientPostalCode", "recipientCountry", "sendingBoxId", "trackingNumber", status, "sentAt", "deliveredAt", "returnedAt", "proofUrl", cost) FROM stdin;
cml6vyl1p0014jms2af8xdbue	2026-02-03 17:41:57.902	2026-02-03 17:41:57.902	cml6vyl1b000pjms2707bomdj	Fournisseur Tech SARL	123 Rue du Commerce	Lyon	69001	FR	\N	FR123456789	IN_TRANSIT	2026-02-01 17:41:57.901	\N	\N	\N	\N
\.


--
-- Data for Name: reminder_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.reminder_logs (id, "createdAt", "trackingId", type, "sentAt", "sentTo", "emailSubject", "emailBody", status, "errorMessage") FROM stdin;
\.


--
-- Data for Name: signature_reminders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signature_reminders (id, "createdAt", "signatureId", "reminderNumber", "sentAt", "emailSent", "smsSent") FROM stdin;
cml6vyl1m0010jms2uk36e2zy	2026-02-03 17:41:57.898	cml6vyl1e000tjms2oi4th11h	1	2026-02-01 17:41:57.898	t	f
cml6vyl1m0011jms26zxu8vli	2026-02-03 17:41:57.898	cml6vyl1e000tjms2oi4th11h	2	2026-02-02 17:41:57.898	t	f
cml6vyl1m0012jms29qtoymzb	2026-02-03 17:41:57.898	cml6vyl1i000vjms2rmc6urqc	1	2026-02-02 17:41:57.898	t	f
cml7uwcpu0001rpkq0ilqjtk6	2026-02-04 10:00:00.354	cml6vyl1e000tjms2oi4th11h	3	2026-02-04 10:00:00.354	t	f
cml7uwcrr0003rpkqe7dxmqg6	2026-02-04 10:00:00.424	cml6vyl1i000vjms2rmc6urqc	2	2026-02-04 10:00:00.424	t	f
cml9ac89y0005nk90u2iydwi1	2026-02-05 10:00:01.509	cml6vyl1i000vjms2rmc6urqc	3	2026-02-05 10:00:01.509	t	f
cml9ac8dy0007nk90v7lklqbv	2026-02-05 10:00:01.653	cml6vyl1l000zjms2xq80j8mr	1	2026-02-05 10:00:01.653	t	f
cmlc57x7e0010yhmm71ymr89q	2026-02-07 10:00:00.984	cml6vyl1l000zjms2xq80j8mr	2	2026-02-07 10:00:00.984	t	f
cmlf03n5n0009oyefwpuyfxg4	2026-02-09 10:00:01.784	cml6vyl1l000zjms2xq80j8mr	3	2026-02-09 10:00:01.784	t	f
\.


--
-- Data for Name: signature_requests; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signature_requests (id, "createdAt", "updatedAt", "folderId", "documentId", "docusignEnvelopeId", signataires, "ordreSignature", "dateExpiration", "messagePersonnalise", statut, "sentAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: signatures; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signatures (id, "createdAt", "updatedAt", "documentId", "signerEmail", "signerName", "signerType", "transactionId", "signatureUrl", status, "invitedAt", "signedAt", "refusedAt", "expiredAt", "certificateUrl") FROM stdin;
cml6vyl1e000tjms2oi4th11h	2026-02-03 17:41:57.891	2026-02-03 17:41:57.891	cml6vyl13000jjms232792l1y	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-01-29 17:41:57.89	\N	\N	\N	\N
cml6vyl1i000vjms2rmc6urqc	2026-02-03 17:41:57.894	2026-02-03 17:41:57.894	cml6vyl17000ljms2xfzrqdbk	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-01-31 17:41:57.893	\N	\N	\N	\N
cml6vyl1j000xjms2aikx8iv1	2026-02-03 17:41:57.896	2026-02-03 17:41:57.896	cml6vyl19000njms2iu9iuwvv	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	SIGNED	2026-01-16 17:41:57.895	2026-01-19 17:41:57.895	\N	\N	\N
cml6vyl1l000zjms2xq80j8mr	2026-02-03 17:41:57.897	2026-02-03 17:41:57.897	cml6vyl1d000rjms21ti62wqk	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-02-03 11:41:57.896	\N	\N	\N	\N
\.


--
-- Data for Name: template_categories; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.template_categories (id, "createdAt", "updatedAt", name, description, icon, color, "displayOrder", "tenantId") FROM stdin;
cml9fca83000jh7vh4vzhpchi	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Contentieux	Templates pour les procédures contentieuses	Scale	#EF4444	1	cml6vykdd0000jms2wwxl9s27
cml9fca83000kh7vhuworsxey	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Corporate	Templates de droit des sociétés	Building	#3B82F6	2	cml6vykdd0000jms2wwxl9s27
cml9fca83000lh7vhzt8kzj8y	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Contrats	Templates de contrats	FileSignature	#10B981	3	cml6vykdd0000jms2wwxl9s27
cml9fca83000mh7vhqmbtni2v	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Courriers	Templates de courriers	Mail	#8B5CF6	4	cml6vykdd0000jms2wwxl9s27
cml9fca83000nh7vha6xyd4pm	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Immobilier	Templates immobilier	Home	#F59E0B	5	cml6vykdd0000jms2wwxl9s27
cml9fca83000oh7vhms0omora	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Social	Templates droit social	Users	#EC4899	6	cml6vykdd0000jms2wwxl9s27
cml9fca83000ph7vhiglst228	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Propriété intellectuelle	Templates PI/Marques/Brevets	Lightbulb	#14B8A6	7	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.templates (id, "createdAt", "updatedAt", "tenantId", name, description, category, "sourceFileUrl", variables, blocks, "folderType", "folderNature", "isSystem", "isPersonalise", "usageCount", "deletedAt") FROM stdin;
cmlb71w3d000lfg3x7t2gxnhy	2026-02-06 18:03:32.665	2026-02-06 18:03:32.665	cml6vykdd0000jms2wwxl9s27	Assignation en divorce contentieux	Assignation en divorce pour altération définitive du lien conjugal	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w3f000nfg3xorx8zeds	2026-02-06 18:03:32.667	2026-02-06 18:03:32.667	cml6vykdd0000jms2wwxl9s27	Conclusions CPAM - Indemnisation corporelle	Conclusions en indemnisation du préjudice corporel	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w3g000pfg3xob8cw9ip	2026-02-06 18:03:32.669	2026-02-06 18:03:32.669	cml6vykdd0000jms2wwxl9s27	Contrat de prestation de services	Contrat cadre de prestation de services	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3m000rfg3xijf2brgv	2026-02-06 18:03:32.674	2026-02-06 18:03:32.674	cml6vykdd0000jms2wwxl9s27	Contrat de travail CDI	Contrat de travail à durée indéterminée	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3o000tfg3xjxmju5bq	2026-02-06 18:03:32.676	2026-02-06 18:03:32.676	cml6vykdd0000jms2wwxl9s27	Contrat de travail CDD	Contrat de travail à durée déterminée	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3q000vfg3xu78wacq3	2026-02-06 18:03:32.678	2026-02-06 18:03:32.678	cml6vykdd0000jms2wwxl9s27	Bail commercial 3-6-9	Bail commercial classique	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3s000xfg3xjxw2fml7	2026-02-06 18:03:32.68	2026-02-06 18:03:32.68	cml6vykdd0000jms2wwxl9s27	Bail professionnel	Bail pour usage professionnel non commercial	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3u000zfg3xfil9e8v9	2026-02-06 18:03:32.682	2026-02-06 18:03:32.682	cml6vykdd0000jms2wwxl9s27	Protocole transactionnel	Transaction mettant fin à un litige (art. 2044 CC)	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3x0011fg3xwafmiu6t	2026-02-06 18:03:32.686	2026-02-06 18:03:32.686	cml6vykdd0000jms2wwxl9s27	Contrat de cession de fonds de commerce	Acte de cession de fonds de commerce	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w3z0013fg3x20pqmki4	2026-02-06 18:03:32.687	2026-02-06 18:03:32.687	cml6vykdd0000jms2wwxl9s27	Contrat de cession de parts sociales	Cession de parts de SARL	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w400015fg3xyv2v0qrq	2026-02-06 18:03:32.689	2026-02-06 18:03:32.689	cml6vykdd0000jms2wwxl9s27	Contrat de licence de marque	Licence d utilisation d une marque enregistrée	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w430017fg3xda8laoo4	2026-02-06 18:03:32.69	2026-02-06 18:03:32.69	cml6vykdd0000jms2wwxl9s27	NDA - Accord de confidentialité	Accord de confidentialité bilatéral	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w470019fg3xalax0kqo	2026-02-06 18:03:32.695	2026-02-06 18:03:32.695	cml6vykdd0000jms2wwxl9s27	Pacte d associés SARL	Pacte extra-statutaire entre associés de SARL	contrats	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w49001bfg3xqwtpsa9n	2026-02-06 18:03:32.697	2026-02-06 18:03:32.697	cml6vykdd0000jms2wwxl9s27	Convention d honoraires	Convention d honoraires avocat-client	contrats	\N	\N	\N	\N	\N	t	f	0	\N
cmlb2qers0001n7pqjqsnw2tp	2026-02-06 16:02:38.536	2026-02-06 16:02:38.564	cml6vykdd0000jms2wwxl9s27	Mon template test (modifie)	Template de test Phase 3	divers	\N	[]	[{"title": "En-tete", "blockId": "b1", "content": "test"}, {"title": "Corps", "blockId": "b2", "content": "test body"}]	les_deux	\N	f	t	0	2026-02-06 16:02:38.564
cmlb2qes60003n7pq6xraldz5	2026-02-06 16:02:38.551	2026-02-06 16:02:38.571	cml6vykdd0000jms2wwxl9s27	Mon template test (modifie) (Copie)	Template de test Phase 3	divers	\N	[]	[]	les_deux	\N	f	t	0	2026-02-06 16:02:38.57
cmlb71w2r0001fg3x9u8tao8d	2026-02-06 18:03:32.643	2026-02-06 18:03:32.643	cml6vykdd0000jms2wwxl9s27	Assignation en paiement - TJ	Assignation devant le Tribunal Judiciaire pour condamnation au paiement	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w2w0003fg3xnxw2m590	2026-02-06 18:03:32.649	2026-02-06 18:03:32.649	cml6vykdd0000jms2wwxl9s27	Assignation en référé	Assignation en référé (urgence ou provision)	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w2y0005fg3xbp8yavdc	2026-02-06 18:03:32.651	2026-02-06 18:03:32.651	cml6vykdd0000jms2wwxl9s27	Conclusions au fond - Demandeur	Conclusions récapitulatives en demande	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w300007fg3x17yelk19	2026-02-06 18:03:32.653	2026-02-06 18:03:32.653	cml6vykdd0000jms2wwxl9s27	Conclusions au fond - Défendeur	Conclusions récapitulatives en défense	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w320009fg3x99cw1hff	2026-02-06 18:03:32.655	2026-02-06 18:03:32.655	cml6vykdd0000jms2wwxl9s27	Conclusions d appel	Conclusions devant la Cour d appel	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w34000bfg3xqku3g1ct	2026-02-06 18:03:32.657	2026-02-06 18:03:32.657	cml6vykdd0000jms2wwxl9s27	Requête en injonction de payer	Requête au Président du TJ pour injonction de payer	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w36000dfg3xksq8y1ho	2026-02-06 18:03:32.659	2026-02-06 18:03:32.659	cml6vykdd0000jms2wwxl9s27	Opposition à injonction de payer	Opposition à ordonnance d injonction de payer	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w38000ffg3xwr257sl5	2026-02-06 18:03:32.66	2026-02-06 18:03:32.66	cml6vykdd0000jms2wwxl9s27	Assignation au fond - Tribunal de commerce	Assignation devant le Tribunal de commerce	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w39000hfg3xpkaxax4a	2026-02-06 18:03:32.662	2026-02-06 18:03:32.662	cml6vykdd0000jms2wwxl9s27	Conclusions incidents - Exception incompétence	Conclusions soulevant une exception d incompétence	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w3c000jfg3x6p5g748q	2026-02-06 18:03:32.664	2026-02-06 18:03:32.664	cml6vykdd0000jms2wwxl9s27	Requête en divorce par consentement mutuel	Convention de divorce par consentement mutuel (art. 229-1 CC)	actes_procedure	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w4g001dfg3xtj9uoar8	2026-02-06 18:03:32.704	2026-02-06 18:03:32.704	cml6vykdd0000jms2wwxl9s27	Mise en demeure de payer	Lettre de mise en demeure pour créance impayée	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w4k001ffg3xwqo3gw2v	2026-02-06 18:03:32.708	2026-02-06 18:03:32.708	cml6vykdd0000jms2wwxl9s27	Mise en demeure d exécuter	Mise en demeure d exécuter une obligation contractuelle	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w4n001hfg3xtc650lkg	2026-02-06 18:03:32.711	2026-02-06 18:03:32.711	cml6vykdd0000jms2wwxl9s27	Lettre de résiliation de contrat	Résiliation unilatérale pour manquement	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w4p001jfg3xs6yg7eeo	2026-02-06 18:03:32.713	2026-02-06 18:03:32.713	cml6vykdd0000jms2wwxl9s27	Courrier de relance amiable	Relance amiable avant procédure contentieuse	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w4q001lfg3xm1s1fd39	2026-02-06 18:03:32.714	2026-02-06 18:03:32.714	cml6vykdd0000jms2wwxl9s27	Dénonciation de bail	Congé donné au preneur ou au bailleur	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w4s001nfg3xo17edonb	2026-02-06 18:03:32.716	2026-02-06 18:03:32.716	cml6vykdd0000jms2wwxl9s27	Lettre au Bâtonnier - Difficultés confrère	Signalement de difficultés avec un confrère	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w4w001pfg3x9e2ra674	2026-02-06 18:03:32.718	2026-02-06 18:03:32.718	cml6vykdd0000jms2wwxl9s27	Courrier de constitution	Constitution d avocat en défense	courriers	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w50001rfg3xwpbqecx0	2026-02-06 18:03:32.724	2026-02-06 18:03:32.724	cml6vykdd0000jms2wwxl9s27	Demande de communication de pièces	Demande de communication contradictoire de pièces	courriers	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w51001tfg3xstg4mdlz	2026-02-06 18:03:32.725	2026-02-06 18:03:32.725	cml6vykdd0000jms2wwxl9s27	Lettre au greffe - Demande de copie	Demande de copie de jugement au greffe	courriers	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w53001vfg3x6ekzlrt3	2026-02-06 18:03:32.727	2026-02-06 18:03:32.727	cml6vykdd0000jms2wwxl9s27	Demande d aide juridictionnelle	Dossier de demande d AJ	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w55001xfg3xoaljgkz9	2026-02-06 18:03:32.729	2026-02-06 18:03:32.729	cml6vykdd0000jms2wwxl9s27	Notification de décision à client	Transmission de décision de justice au client	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w56001zfg3xes61n25k	2026-02-06 18:03:32.731	2026-02-06 18:03:32.731	cml6vykdd0000jms2wwxl9s27	Courrier CARPA - Séquestre	Instructions de séquestre à la CARPA	courriers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w580021fg3xb5i13rdb	2026-02-06 18:03:32.732	2026-02-06 18:03:32.732	cml6vykdd0000jms2wwxl9s27	Statuts SARL	Statuts constitutifs de SARL	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5a0023fg3xqu9lzrdw	2026-02-06 18:03:32.735	2026-02-06 18:03:32.735	cml6vykdd0000jms2wwxl9s27	Statuts SAS	Statuts constitutifs de SAS	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5c0025fg3x11ar7xv7	2026-02-06 18:03:32.737	2026-02-06 18:03:32.737	cml6vykdd0000jms2wwxl9s27	PV AGO annuelle	Procès-verbal d assemblée générale ordinaire annuelle	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5k0027fg3xbjclucw2	2026-02-06 18:03:32.744	2026-02-06 18:03:32.744	cml6vykdd0000jms2wwxl9s27	PV AGE - Modification statuts	PV assemblée générale extraordinaire	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5p0029fg3xjc7q63g0	2026-02-06 18:03:32.749	2026-02-06 18:03:32.749	cml6vykdd0000jms2wwxl9s27	PV transfert de siège social	Décision de transfert du siège social	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5s002bfg3x1sjgenfj	2026-02-06 18:03:32.752	2026-02-06 18:03:32.752	cml6vykdd0000jms2wwxl9s27	Dissolution anticipée - PV	PV de dissolution anticipée de société	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5t002dfg3xd1tgueir	2026-02-06 18:03:32.754	2026-02-06 18:03:32.754	cml6vykdd0000jms2wwxl9s27	Rapport de gestion annuel	Rapport de gestion du gérant ou président	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w5x002ffg3x3kbtcgqd	2026-02-06 18:03:32.757	2026-02-06 18:03:32.757	cml6vykdd0000jms2wwxl9s27	Lettre de démission de gérant	Démission du gérant de SARL	droit_societes	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w61002hfg3xrvvlto03	2026-02-06 18:03:32.761	2026-02-06 18:03:32.761	cml6vykdd0000jms2wwxl9s27	Attestation sur l honneur	Modèle d attestation sur l honneur (art. 202 CPC)	divers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w66002jfg3x7pzdzkw3	2026-02-06 18:03:32.766	2026-02-06 18:03:32.766	cml6vykdd0000jms2wwxl9s27	Pouvoir spécial de représentation	Pouvoir donné à un tiers pour représenter	divers	\N	\N	\N	\N	\N	t	f	0	\N
cmlb71w67002lfg3xxs0i2020	2026-02-06 18:03:32.768	2026-02-06 18:03:32.768	cml6vykdd0000jms2wwxl9s27	Déclaration de créance	Déclaration de créance au mandataire judiciaire	divers	\N	\N	\N	juridique	\N	t	f	0	\N
cmlb71w69002nfg3xl2z3ixfh	2026-02-06 18:03:32.769	2026-02-06 18:03:32.769	cml6vykdd0000jms2wwxl9s27	Acte de désistement d instance	Désistement d instance et d action	divers	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w6c002pfg3xxznqj9a6	2026-02-06 18:03:32.771	2026-02-06 18:03:32.771	cml6vykdd0000jms2wwxl9s27	Requête en rectification d erreur matérielle	Requête au juge en rectification d erreur matérielle	divers	\N	\N	\N	judiciaire	\N	t	f	0	\N
cmlb71w6k002rfg3x3aw5xsmh	2026-02-06 18:03:32.78	2026-02-06 18:03:32.78	cml6vykdd0000jms2wwxl9s27	Note en délibéré	Note en délibéré autorisée par le juge	divers	\N	\N	\N	judiciaire	\N	t	f	0	\N
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.tenant_settings (id, "createdAt", "updatedAt", "enableReminders", "reminderSchedule", "maxReminders", "defaultSignatureDeadlineDays", "emailFromName", "emailReplyTo", "emailSignature", "lrarSenderName", "lrarSenderAddress", "documentRetentionYears", "autoArchiveClosedFolders", "autoArchiveAfterDays", "enforceStrongPasswords", "sessionTimeoutMinutes", "require2FA", "allowClientUpload", "clientUploadMaxSizeMB", "tenantId", "docusignAccessToken", "docusignAccountId", "docusignAccountName", "docusignConnectedAt", "docusignRefreshToken", "sendingboxApiKey", "sendingboxConnectedAt", "reminderDelay1", "reminderDelay2", "reminderDelay3", "reminderNotify") FROM stdin;
cml6vyl7s001bjms2x4pqt7mo	2026-02-03 17:41:58.12	2026-02-03 17:41:58.12	t	1,3,5	3	7	\N	\N	\N	\N	\N	10	f	365	t	480	f	f	10	cml6vyl1v0017jms2uzfefv85	\N	\N	\N	\N	\N	\N	\N	3	7	14	t
cml6vyl1t0016jms240uih3kh	2026-02-03 17:41:57.905	2026-02-06 19:15:52.896	t	1,3,5	3	7	Cabinet Pragmavox	contact@pragmavox.fr	\N	\N	\N	10	f	365	t	480	f	f	10	cml6vykdd0000jms2wwxl9s27	\N	\N	\N	\N	\N	\N	\N	3	7	14	t
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.tenants (id, "createdAt", "updatedAt", name, "legalName", siret, address, "postalCode", city, country, phone, email, website, logo, "primaryColor", "isActive", "subscriptionTier", "maxUsers", "maxClients", "maxStorage", "trialEndsAt", "subscribedAt", barreau, "deletedAt", toque) FROM stdin;
cml6vyl1v0017jms2uzfefv85	2026-02-03 17:41:57.908	2026-02-03 17:41:57.908	Cabinet Juridicom	Cabinet Juridicom & Associés	98765432100013	\N	\N	\N	FR	\N	contact@juridicom.fr	\N	\N	#0066ff	t	BASIC	5	100	5368709120	\N	\N	\N	\N	\N
cml88g71z0000521vp3t710u4	2026-02-04 16:19:21.143	2026-02-04 16:19:21.143	LexDoc Système	\N	\N	\N	\N	\N	FR	\N	system@lexdoc.fr	\N	\N	#0066ff	t	TRIAL	5	100	5368709120	\N	\N	\N	\N	\N
cml6vykdd0000jms2wwxl9s27	2026-02-03 17:41:57.026	2026-02-06 14:25:51.915	Cabinet Pragmavox	Cabinet Pragmavox Avocat	12345678900011	123 Rue de la Paix	49000	Angers	FR	02 41 00 00 00	contact@pragmavox.fr	https://pragmavox.fr	\N	#0066ff	t	PRO	5	100	5368709120	\N	\N	Angers	\N	T-123
\.


--
-- Data for Name: timeline_events; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.timeline_events (id, "createdAt", "folderId", "documentId", type, description, metadata, "userId") FROM stdin;
cmlaz9yep000ui4b0lmlpqnpp	2026-01-15 09:00:00	cmlaz9ydk0001i4b0mf637jrl	\N	dossier_cree	Dossier créé par Me Bienaime	\N	cml6vykja0002jms2hhr4hfr3
cmlaz9yep000vi4b0lql8r4yn	2026-01-15 09:05:00	cmlaz9ydk0001i4b0mf637jrl	\N	personne_ajoutee	Client Jean DUPONT ajouté au dossier	\N	cml6vykja0002jms2hhr4hfr3
cmlaz9yep000wi4b0bnol8izr	2026-01-20 14:00:00	cmlaz9ydq0003i4b0dggysja4	\N	dossier_cree	Dossier contentieux créé par Me Bienaime	\N	cml6vykja0002jms2hhr4hfr3
cmlb17ine000e111vp8eamwk8	2026-02-06 15:19:57.451	cmlb17ims0002111v6gbo2rh6	\N	dossier_cree	Dossier "Test Wizard Cession 2026" créé	\N	cml6vykja0002jms2hhr4hfr3
cmlb185i10015111v79w4ohyu	2026-02-06 15:20:27.06	cmlb185h4000j111vmhnvpqz9	\N	dossier_cree	Dossier "TechCorp c/ Durand 2026" créé	\N	cml6vykja0002jms2hhr4hfr3
cmlb18yqo000gf4hainn8ddaa	2026-02-06 15:21:04.94	cmlb18ypu0004f4ha1yi87is2	\N	dossier_cree	Dossier "AGOA WizardTest2 2026" créé	\N	cml6vykja0002jms2hhr4hfr3
cmlb2dlum000351o7m2v6f6or	2026-02-06 15:52:41.182	cmlb18ypu0004f4ha1yi87is2	cmlb2dluc000151o73j4fvzem	document_cree	Document "Convention d'honoraires - Jean WizardTest2" genere depuis le template "Convention d'honoraires"	\N	cml6vykja0002jms2hhr4hfr3
cmlb2hyo500031256arwew4c0	2026-02-06 15:56:04.422	cmlb18ypu0004f4ha1yi87is2	cmlb2hynx000112569i3eq2pg	document_cree	Document "Lettre de mission - Jean WizardTest2" genere depuis le template "Lettre de mission"	\N	cml6vykja0002jms2hhr4hfr3
cmlb2hypu00091256e0z8utdr	2026-02-06 15:56:04.483	cmlb18ypu0004f4ha1yi87is2	cmlb2hypl00071256add7xul3	document_cree	Document "Assignation TJ - Jean WizardTest2" genere depuis le template "Assignation TJ"	\N	cml6vykja0002jms2hhr4hfr3
cmlb53jxg0006veb5dm13mwi0	2026-02-06 17:08:50.981	cmlb18ypu0004f4ha1yi87is2	\N	extranet_invitation	Invitation extranet envoyée à wizard.test2@example.fr	{"email": "wizard.test2@example.fr", "clientId": "cmlb18ypa0002f4haozbrecum"}	cml6vykja0002jms2hhr4hfr3
cmlb53w1y000gveb5kldqwor3	2026-02-06 17:09:06.695	cmlb18ypu0004f4ha1yi87is2	\N	extranet_profile_step	Client a complété l'étape Identité	{"step": 1, "percent": 40}	\N
cmlc7tcxk000cg2ou7y44nqf5	2026-02-07 11:12:40.377	cmlc7t86l0003g2ouf76d74yj	\N	extranet_invitation	Invitation extranet envoyée à jfper54@gmail.com	{"email": "jfper54@gmail.com", "clientId": "cmlc6ju1k0016yhmm97qv58zj"}	cml6vykja0002jms2hhr4hfr3
cmlc8o3el000463r731dytq0o	2026-02-07 11:36:34.365	cmlc7t86l0003g2ouf76d74yj	\N	extranet_invitation	Invitation extranet envoyée à jfper54@gmail.com	{"email": "jfper54@gmail.com", "clientId": "cmlc6ju1k0016yhmm97qv58zj"}	cml6vykja0002jms2hhr4hfr3
cmlf79qkv000boyef8yb9y98l	2026-02-09 13:20:43.471	cmlc7t86l0003g2ouf76d74yj	\N	formulaire_envoye	Formulaire de complétude envoyé à jfper54@gmail.com	{"email": "jfper54@gmail.com", "clientId": "cmlc6ju1k0016yhmm97qv58zj"}	cml6vykja0002jms2hhr4hfr3
cmlf8ap4d000doyef3i4s9n0z	2026-02-09 13:49:27.853	cmlc7t86l0003g2ouf76d74yj	\N	formulaire_envoye	Formulaire de complétude envoyé à jfper54@gmail.com	{"email": "jfper54@gmail.com", "clientId": "cmlc6ju1k0016yhmm97qv58zj"}	cml6vykja0002jms2hhr4hfr3
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.users (id, "createdAt", "updatedAt", email, password, "firstName", "lastName", phone, avatar, role, permissions, "isActive", "isEmailVerified", "emailVerifiedAt", "lastLoginAt", "resetToken", "resetTokenExpiresAt", "tenantId", "refreshTokens", "twoFactorEnabled", "twoFactorSecret", "onboardingCompleted", "onboardingStep") FROM stdin;
cml6vykja0002jms2hhr4hfr3	2026-02-03 17:41:57.238	2026-02-07 11:36:34.328	yves-marie.bienaime@pragmavox.fr	$2b$12$p1VevXVnTybDli3BCLSvGeslrpJw5/GqVeNZsog6jph447YHcDEou	Yves-Marie	Bienaimé	\N	\N	ADMIN	\N	t	t	2026-02-03 17:41:57.237	2026-02-07 11:36:34.327	\N	\N	cml6vykdd0000jms2wwxl9s27	{}	f	\N	t	5
cml6vykp40004jms2d2rnfrpm	2026-02-03 17:41:57.449	2026-02-03 17:41:57.449	assistant@pragmavox.fr	$2b$12$X04CXAF5kKlOVApw208cy.btG8k9PsUrTXUo1RUYdnytgEiAvLrf2	Sophie	Martin	\N	\N	ASSISTANT	\N	t	t	2026-02-03 17:41:57.448	\N	\N	\N	cml6vykdd0000jms2wwxl9s27	{}	f	\N	t	5
cml6vyl7q0019jms2mpbhvpm5	2026-02-03 17:41:58.118	2026-02-04 18:28:07.328	admin@juridicom.fr	$2b$12$oi3gWiJu07P.zzarhwQTX.V2Vu869ZzmqEeG2EyHXaGKaHtUXrfxy	Pierre	Legrand	\N	\N	ADMIN	\N	t	t	2026-02-03 17:41:58.117	2026-02-04 18:28:07.327	\N	\N	cml6vyl1v0017jms2uzfefv85	{}	f	\N	t	5
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: avocat_legal_info avocat_legal_info_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.avocat_legal_info
    ADD CONSTRAINT avocat_legal_info_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: builder_blocks builder_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_blocks
    ADD CONSTRAINT builder_blocks_pkey PRIMARY KEY (id);


--
-- Name: builder_templates builder_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_templates
    ADD CONSTRAINT builder_templates_pkey PRIMARY KEY (id);


--
-- Name: client_access_logs client_access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_access_logs
    ADD CONSTRAINT client_access_logs_pkey PRIMARY KEY (id);


--
-- Name: client_accesses client_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_accesses
    ADD CONSTRAINT client_accesses_pkey PRIMARY KEY (id);


--
-- Name: client_consents client_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_consents
    ADD CONSTRAINT client_consents_pkey PRIMARY KEY (id);


--
-- Name: client_reminders client_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_reminders
    ADD CONSTRAINT client_reminders_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: conversation_participants conversation_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: deadlines deadlines_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT deadlines_pkey PRIMARY KEY (id);


--
-- Name: document_requests document_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT document_requests_pkey PRIMARY KEY (id);


--
-- Name: document_tracking document_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_tracking
    ADD CONSTRAINT document_tracking_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: folder_categories folder_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_categories
    ADD CONSTRAINT folder_categories_pkey PRIMARY KEY (id);


--
-- Name: folder_doc_categories folder_doc_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_doc_categories
    ADD CONSTRAINT folder_doc_categories_pkey PRIMARY KEY (id);


--
-- Name: folder_persons folder_persons_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT folder_persons_pkey PRIMARY KEY (id);


--
-- Name: folder_templates folder_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_templates
    ADD CONSTRAINT folder_templates_pkey PRIMARY KEY (id);


--
-- Name: folder_tree_templates folder_tree_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_tree_templates
    ADD CONSTRAINT folder_tree_templates_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: registered_mails registered_mails_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.registered_mails
    ADD CONSTRAINT registered_mails_pkey PRIMARY KEY (id);


--
-- Name: reminder_logs reminder_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.reminder_logs
    ADD CONSTRAINT reminder_logs_pkey PRIMARY KEY (id);


--
-- Name: signature_reminders signature_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_reminders
    ADD CONSTRAINT signature_reminders_pkey PRIMARY KEY (id);


--
-- Name: signature_requests signature_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_requests
    ADD CONSTRAINT signature_requests_pkey PRIMARY KEY (id);


--
-- Name: signatures signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT signatures_pkey PRIMARY KEY (id);


--
-- Name: template_categories template_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.template_categories
    ADD CONSTRAINT template_categories_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: timeline_events timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_tenantId_idx" ON public.audit_logs USING btree ("tenantId");


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: avocat_legal_info_tenantId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "avocat_legal_info_tenantId_key" ON public.avocat_legal_info USING btree ("tenantId");


--
-- Name: backup_logs_startedAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "backup_logs_startedAt_idx" ON public.backup_logs USING btree ("startedAt");


--
-- Name: backup_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "backup_logs_tenantId_idx" ON public.backup_logs USING btree ("tenantId");


--
-- Name: builder_blocks_category_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX builder_blocks_category_idx ON public.builder_blocks USING btree (category);


--
-- Name: builder_blocks_isSystem_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_blocks_isSystem_idx" ON public.builder_blocks USING btree ("isSystem");


--
-- Name: builder_blocks_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_blocks_tenantId_idx" ON public.builder_blocks USING btree ("tenantId");


--
-- Name: builder_templates_category_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX builder_templates_category_idx ON public.builder_templates USING btree (category);


--
-- Name: builder_templates_documentType_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_documentType_idx" ON public.builder_templates USING btree ("documentType");


--
-- Name: builder_templates_isSystem_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_isSystem_idx" ON public.builder_templates USING btree ("isSystem");


--
-- Name: builder_templates_templateCategoryId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_templateCategoryId_idx" ON public.builder_templates USING btree ("templateCategoryId");


--
-- Name: builder_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_tenantId_idx" ON public.builder_templates USING btree ("tenantId");


--
-- Name: client_access_logs_accessId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_access_logs_accessId_idx" ON public.client_access_logs USING btree ("accessId");


--
-- Name: client_access_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_access_logs_createdAt_idx" ON public.client_access_logs USING btree ("createdAt");


--
-- Name: client_accesses_activationToken_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_accesses_activationToken_idx" ON public.client_accesses USING btree ("activationToken");


--
-- Name: client_accesses_activationToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "client_accesses_activationToken_key" ON public.client_accesses USING btree ("activationToken");


--
-- Name: client_accesses_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX client_accesses_email_idx ON public.client_accesses USING btree (email);


--
-- Name: client_accesses_folderId_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "client_accesses_folderId_email_key" ON public.client_accesses USING btree ("folderId", email);


--
-- Name: client_consents_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_consents_clientId_idx" ON public.client_consents USING btree ("clientId");


--
-- Name: client_reminders_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_reminders_clientId_idx" ON public.client_reminders USING btree ("clientId");


--
-- Name: client_reminders_scheduledAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_reminders_scheduledAt_idx" ON public.client_reminders USING btree ("scheduledAt");


--
-- Name: client_reminders_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX client_reminders_status_idx ON public.client_reminders USING btree (status);


--
-- Name: client_reminders_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_reminders_tenantId_idx" ON public.client_reminders USING btree ("tenantId");


--
-- Name: clients_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX clients_email_idx ON public.clients USING btree (email);


--
-- Name: clients_invitationToken_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_invitationToken_idx" ON public.clients USING btree ("invitationToken");


--
-- Name: clients_invitationToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "clients_invitationToken_key" ON public.clients USING btree ("invitationToken");


--
-- Name: clients_lastName_firstName_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_lastName_firstName_idx" ON public.clients USING btree ("lastName", "firstName");


--
-- Name: clients_tenantId_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_tenantId_email_idx" ON public.clients USING btree ("tenantId", email);


--
-- Name: clients_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_tenantId_idx" ON public.clients USING btree ("tenantId");


--
-- Name: conversation_participants_conversationId_userId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "conversation_participants_conversationId_userId_key" ON public.conversation_participants USING btree ("conversationId", "userId");


--
-- Name: conversation_participants_userId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversation_participants_userId_idx" ON public.conversation_participants USING btree ("userId");


--
-- Name: conversations_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversations_folderId_idx" ON public.conversations USING btree ("folderId");


--
-- Name: conversations_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversations_lastMessageAt_idx" ON public.conversations USING btree ("lastMessageAt");


--
-- Name: conversations_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversations_tenantId_idx" ON public.conversations USING btree ("tenantId");


--
-- Name: deadlines_assignedToId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_assignedToId_idx" ON public.deadlines USING btree ("assignedToId");


--
-- Name: deadlines_dueDate_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_dueDate_idx" ON public.deadlines USING btree ("dueDate");


--
-- Name: deadlines_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_folderId_idx" ON public.deadlines USING btree ("folderId");


--
-- Name: deadlines_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX deadlines_status_idx ON public.deadlines USING btree (status);


--
-- Name: deadlines_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_tenantId_idx" ON public.deadlines USING btree ("tenantId");


--
-- Name: document_requests_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "document_requests_folderId_idx" ON public.document_requests USING btree ("folderId");


--
-- Name: document_requests_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX document_requests_status_idx ON public.document_requests USING btree (status);


--
-- Name: document_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "document_requests_tenantId_idx" ON public.document_requests USING btree ("tenantId");


--
-- Name: document_tracking_documentId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "document_tracking_documentId_key" ON public.document_tracking USING btree ("documentId");


--
-- Name: document_tracking_lrarTrackingNumber_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "document_tracking_lrarTrackingNumber_key" ON public.document_tracking USING btree ("lrarTrackingNumber");


--
-- Name: document_tracking_nextReminderAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "document_tracking_nextReminderAt_idx" ON public.document_tracking USING btree ("nextReminderAt");


--
-- Name: document_tracking_signatureRequestId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "document_tracking_signatureRequestId_key" ON public.document_tracking USING btree ("signatureRequestId");


--
-- Name: document_tracking_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX document_tracking_status_idx ON public.document_tracking USING btree (status);


--
-- Name: documents_checksum_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX documents_checksum_idx ON public.documents USING btree (checksum);


--
-- Name: documents_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_clientId_idx" ON public.documents USING btree ("clientId");


--
-- Name: documents_docCategoryId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_docCategoryId_idx" ON public.documents USING btree ("docCategoryId");


--
-- Name: documents_folderCategoryId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_folderCategoryId_idx" ON public.documents USING btree ("folderCategoryId");


--
-- Name: documents_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_folderId_idx" ON public.documents USING btree ("folderId");


--
-- Name: documents_requiresSignature_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_requiresSignature_idx" ON public.documents USING btree ("requiresSignature");


--
-- Name: documents_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX documents_status_idx ON public.documents USING btree (status);


--
-- Name: documents_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_tenantId_idx" ON public.documents USING btree ("tenantId");


--
-- Name: email_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "email_logs_createdAt_idx" ON public.email_logs USING btree ("createdAt");


--
-- Name: email_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "email_logs_tenantId_idx" ON public.email_logs USING btree ("tenantId");


--
-- Name: folder_categories_parentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_categories_parentId_idx" ON public.folder_categories USING btree ("parentId");


--
-- Name: folder_categories_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_categories_tenantId_idx" ON public.folder_categories USING btree ("tenantId");


--
-- Name: folder_doc_categories_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_doc_categories_folderId_idx" ON public.folder_doc_categories USING btree ("folderId");


--
-- Name: folder_doc_categories_folderId_name_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "folder_doc_categories_folderId_name_key" ON public.folder_doc_categories USING btree ("folderId", name);


--
-- Name: folder_persons_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_persons_clientId_idx" ON public.folder_persons USING btree ("clientId");


--
-- Name: folder_persons_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_persons_folderId_idx" ON public.folder_persons USING btree ("folderId");


--
-- Name: folder_persons_role_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX folder_persons_role_idx ON public.folder_persons USING btree (role);


--
-- Name: folder_persons_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_persons_tenantId_idx" ON public.folder_persons USING btree ("tenantId");


--
-- Name: folder_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_templates_tenantId_idx" ON public.folder_templates USING btree ("tenantId");


--
-- Name: folder_tree_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_tree_templates_tenantId_idx" ON public.folder_tree_templates USING btree ("tenantId");


--
-- Name: folder_tree_templates_tenantId_name_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "folder_tree_templates_tenantId_name_key" ON public.folder_tree_templates USING btree ("tenantId", name);


--
-- Name: folders_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_clientId_idx" ON public.folders USING btree ("clientId");


--
-- Name: folders_parentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_parentId_idx" ON public.folders USING btree ("parentId");


--
-- Name: folders_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX folders_status_idx ON public.folders USING btree (status);


--
-- Name: folders_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_tenantId_idx" ON public.folders USING btree ("tenantId");


--
-- Name: folders_tenantId_reference_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "folders_tenantId_reference_key" ON public.folders USING btree ("tenantId", reference);


--
-- Name: messages_conversationId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "messages_conversationId_idx" ON public.messages USING btree ("conversationId");


--
-- Name: messages_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "messages_createdAt_idx" ON public.messages USING btree ("createdAt");


--
-- Name: messages_senderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "messages_senderId_idx" ON public.messages USING btree ("senderId");


--
-- Name: notification_preferences_userId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "notification_preferences_userId_key" ON public.notification_preferences USING btree ("userId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_isRead_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "notifications_userId_isRead_idx" ON public.notifications USING btree ("userId", "isRead");


--
-- Name: push_subscriptions_accessId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "push_subscriptions_accessId_idx" ON public.push_subscriptions USING btree ("accessId");


--
-- Name: push_subscriptions_endpoint_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX push_subscriptions_endpoint_key ON public.push_subscriptions USING btree (endpoint);


--
-- Name: registered_mails_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "registered_mails_documentId_idx" ON public.registered_mails USING btree ("documentId");


--
-- Name: registered_mails_sendingBoxId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "registered_mails_sendingBoxId_key" ON public.registered_mails USING btree ("sendingBoxId");


--
-- Name: registered_mails_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX registered_mails_status_idx ON public.registered_mails USING btree (status);


--
-- Name: registered_mails_trackingNumber_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "registered_mails_trackingNumber_idx" ON public.registered_mails USING btree ("trackingNumber");


--
-- Name: registered_mails_trackingNumber_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "registered_mails_trackingNumber_key" ON public.registered_mails USING btree ("trackingNumber");


--
-- Name: reminder_logs_sentAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "reminder_logs_sentAt_idx" ON public.reminder_logs USING btree ("sentAt");


--
-- Name: reminder_logs_trackingId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "reminder_logs_trackingId_idx" ON public.reminder_logs USING btree ("trackingId");


--
-- Name: signature_reminders_signatureId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signature_reminders_signatureId_idx" ON public.signature_reminders USING btree ("signatureId");


--
-- Name: signature_requests_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signature_requests_documentId_idx" ON public.signature_requests USING btree ("documentId");


--
-- Name: signature_requests_docusignEnvelopeId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signature_requests_docusignEnvelopeId_idx" ON public.signature_requests USING btree ("docusignEnvelopeId");


--
-- Name: signature_requests_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signature_requests_folderId_idx" ON public.signature_requests USING btree ("folderId");


--
-- Name: signatures_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_documentId_idx" ON public.signatures USING btree ("documentId");


--
-- Name: signatures_signerEmail_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_signerEmail_idx" ON public.signatures USING btree ("signerEmail");


--
-- Name: signatures_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX signatures_status_idx ON public.signatures USING btree (status);


--
-- Name: signatures_transactionId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_transactionId_idx" ON public.signatures USING btree ("transactionId");


--
-- Name: signatures_transactionId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "signatures_transactionId_key" ON public.signatures USING btree ("transactionId");


--
-- Name: template_categories_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "template_categories_tenantId_idx" ON public.template_categories USING btree ("tenantId");


--
-- Name: templates_category_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX templates_category_idx ON public.templates USING btree (category);


--
-- Name: templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "templates_tenantId_idx" ON public.templates USING btree ("tenantId");


--
-- Name: tenant_settings_tenantId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "tenant_settings_tenantId_key" ON public.tenant_settings USING btree ("tenantId");


--
-- Name: tenants_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX tenants_email_idx ON public.tenants USING btree (email);


--
-- Name: tenants_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX tenants_email_key ON public.tenants USING btree (email);


--
-- Name: tenants_siret_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX tenants_siret_idx ON public.tenants USING btree (siret);


--
-- Name: tenants_siret_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX tenants_siret_key ON public.tenants USING btree (siret);


--
-- Name: timeline_events_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "timeline_events_createdAt_idx" ON public.timeline_events USING btree ("createdAt");


--
-- Name: timeline_events_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "timeline_events_folderId_idx" ON public.timeline_events USING btree ("folderId");


--
-- Name: timeline_events_type_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX timeline_events_type_idx ON public.timeline_events USING btree (type);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: users_tenantId_role_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "users_tenantId_role_idx" ON public.users USING btree ("tenantId", role);


--
-- Name: audit_logs audit_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: avocat_legal_info avocat_legal_info_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.avocat_legal_info
    ADD CONSTRAINT "avocat_legal_info_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_logs backup_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT "backup_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: builder_blocks builder_blocks_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_blocks
    ADD CONSTRAINT "builder_blocks_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: builder_templates builder_templates_templateCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_templates
    ADD CONSTRAINT "builder_templates_templateCategoryId_fkey" FOREIGN KEY ("templateCategoryId") REFERENCES public.template_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: builder_templates builder_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_templates
    ADD CONSTRAINT "builder_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_access_logs client_access_logs_accessId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_access_logs
    ADD CONSTRAINT "client_access_logs_accessId_fkey" FOREIGN KEY ("accessId") REFERENCES public.client_accesses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_accesses client_accesses_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_accesses
    ADD CONSTRAINT "client_accesses_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_consents client_consents_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_consents
    ADD CONSTRAINT "client_consents_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: clients clients_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT "clients_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT "conversation_participants_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deadlines deadlines_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT "deadlines_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deadlines deadlines_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT "deadlines_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: deadlines deadlines_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT "deadlines_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_requests document_requests_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_requests document_requests_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_requests document_requests_responseDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_responseDocumentId_fkey" FOREIGN KEY ("responseDocumentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_requests document_requests_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_tracking document_tracking_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_tracking
    ADD CONSTRAINT "document_tracking_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: documents documents_docCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_docCategoryId_fkey" FOREIGN KEY ("docCategoryId") REFERENCES public.folder_doc_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_folderCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_folderCategoryId_fkey" FOREIGN KEY ("folderCategoryId") REFERENCES public.folder_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_categories folder_categories_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_categories
    ADD CONSTRAINT "folder_categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.folder_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_categories folder_categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_categories
    ADD CONSTRAINT "folder_categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_doc_categories folder_doc_categories_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_doc_categories
    ADD CONSTRAINT "folder_doc_categories_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_persons folder_persons_avocatAdverseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT "folder_persons_avocatAdverseId_fkey" FOREIGN KEY ("avocatAdverseId") REFERENCES public.folder_persons(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: folder_persons folder_persons_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT "folder_persons_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: folder_persons folder_persons_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT "folder_persons_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_persons folder_persons_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT "folder_persons_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_templates folder_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_templates
    ADD CONSTRAINT "folder_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folders folders_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: folders folders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: folders folders_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: folders folders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT "notification_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_accessId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_accessId_fkey" FOREIGN KEY ("accessId") REFERENCES public.client_accesses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: registered_mails registered_mails_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.registered_mails
    ADD CONSTRAINT "registered_mails_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reminder_logs reminder_logs_trackingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.reminder_logs
    ADD CONSTRAINT "reminder_logs_trackingId_fkey" FOREIGN KEY ("trackingId") REFERENCES public.document_tracking(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: signature_reminders signature_reminders_signatureId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_reminders
    ADD CONSTRAINT "signature_reminders_signatureId_fkey" FOREIGN KEY ("signatureId") REFERENCES public.signatures(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: signature_requests signature_requests_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_requests
    ADD CONSTRAINT "signature_requests_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: signature_requests signature_requests_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_requests
    ADD CONSTRAINT "signature_requests_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: signatures signatures_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT "signatures_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: template_categories template_categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.template_categories
    ADD CONSTRAINT "template_categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: templates templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT "templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT "tenant_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: timeline_events timeline_events_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT "timeline_events_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: timeline_events timeline_events_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT "timeline_events_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict NGDxBedIbUxKG3wrbENdTAiDl7klrOhpKKeDw6HwPT8fgbTR5uhUjDbT3BJ2jGV

