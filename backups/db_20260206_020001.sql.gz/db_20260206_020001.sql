--
-- PostgreSQL database dump
--

\restrict 0ZkkluHnRZ08mr0heKc3fp7L1Nh0AUUfVb46GNl8KvMs92IiIDZ9o5h6J06bUt9

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "users_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.tenant_settings DROP CONSTRAINT IF EXISTS "tenant_settings_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.template_categories DROP CONSTRAINT IF EXISTS "template_categories_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.signatures DROP CONSTRAINT IF EXISTS "signatures_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.signature_reminders DROP CONSTRAINT IF EXISTS "signature_reminders_signatureId_fkey";
ALTER TABLE IF EXISTS ONLY public.reminder_logs DROP CONSTRAINT IF EXISTS "reminder_logs_trackingId_fkey";
ALTER TABLE IF EXISTS ONLY public.registered_mails DROP CONSTRAINT IF EXISTS "registered_mails_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS "push_subscriptions_accessId_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS "notification_preferences_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS "messages_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS "folders_clientId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_templates DROP CONSTRAINT IF EXISTS "folder_templates_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS "folder_persons_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS "folder_persons_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_categories DROP CONSTRAINT IF EXISTS "folder_categories_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.folder_categories DROP CONSTRAINT IF EXISTS "folder_categories_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_folderCategoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.document_tracking DROP CONSTRAINT IF EXISTS "document_tracking_documentId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_responseDocumentId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS "document_requests_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS "deadlines_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS "deadlines_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS "deadlines_assignedToId_fkey";
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS "conversation_participants_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS "clients_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.client_consents DROP CONSTRAINT IF EXISTS "client_consents_clientId_fkey";
ALTER TABLE IF EXISTS ONLY public.client_accesses DROP CONSTRAINT IF EXISTS "client_accesses_folderId_fkey";
ALTER TABLE IF EXISTS ONLY public.client_access_logs DROP CONSTRAINT IF EXISTS "client_access_logs_accessId_fkey";
ALTER TABLE IF EXISTS ONLY public.builder_templates DROP CONSTRAINT IF EXISTS "builder_templates_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.builder_templates DROP CONSTRAINT IF EXISTS "builder_templates_templateCategoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.builder_blocks DROP CONSTRAINT IF EXISTS "builder_blocks_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.backup_logs DROP CONSTRAINT IF EXISTS "backup_logs_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.avocat_legal_info DROP CONSTRAINT IF EXISTS "avocat_legal_info_tenantId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_tenantId_fkey";
DROP INDEX IF EXISTS public."users_tenantId_role_idx";
DROP INDEX IF EXISTS public."users_tenantId_idx";
DROP INDEX IF EXISTS public."users_resetToken_key";
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.users_email_idx;
DROP INDEX IF EXISTS public.tenants_siret_key;
DROP INDEX IF EXISTS public.tenants_siret_idx;
DROP INDEX IF EXISTS public.tenants_email_key;
DROP INDEX IF EXISTS public.tenants_email_idx;
DROP INDEX IF EXISTS public."tenant_settings_tenantId_key";
DROP INDEX IF EXISTS public."template_categories_tenantId_idx";
DROP INDEX IF EXISTS public."signatures_transactionId_key";
DROP INDEX IF EXISTS public."signatures_transactionId_idx";
DROP INDEX IF EXISTS public.signatures_status_idx;
DROP INDEX IF EXISTS public."signatures_signerEmail_idx";
DROP INDEX IF EXISTS public."signatures_documentId_idx";
DROP INDEX IF EXISTS public."signature_reminders_signatureId_idx";
DROP INDEX IF EXISTS public."reminder_logs_trackingId_idx";
DROP INDEX IF EXISTS public."reminder_logs_sentAt_idx";
DROP INDEX IF EXISTS public."registered_mails_trackingNumber_key";
DROP INDEX IF EXISTS public."registered_mails_trackingNumber_idx";
DROP INDEX IF EXISTS public.registered_mails_status_idx;
DROP INDEX IF EXISTS public."registered_mails_sendingBoxId_key";
DROP INDEX IF EXISTS public."registered_mails_documentId_idx";
DROP INDEX IF EXISTS public.push_subscriptions_endpoint_key;
DROP INDEX IF EXISTS public."push_subscriptions_accessId_idx";
DROP INDEX IF EXISTS public."notifications_userId_isRead_idx";
DROP INDEX IF EXISTS public."notifications_tenantId_idx";
DROP INDEX IF EXISTS public."notifications_createdAt_idx";
DROP INDEX IF EXISTS public."notification_preferences_userId_key";
DROP INDEX IF EXISTS public."messages_senderId_idx";
DROP INDEX IF EXISTS public."messages_createdAt_idx";
DROP INDEX IF EXISTS public."messages_conversationId_idx";
DROP INDEX IF EXISTS public."folders_tenantId_reference_key";
DROP INDEX IF EXISTS public."folders_tenantId_idx";
DROP INDEX IF EXISTS public.folders_status_idx;
DROP INDEX IF EXISTS public."folders_parentId_idx";
DROP INDEX IF EXISTS public."folders_clientId_idx";
DROP INDEX IF EXISTS public."folder_templates_tenantId_idx";
DROP INDEX IF EXISTS public."folder_persons_tenantId_idx";
DROP INDEX IF EXISTS public."folder_persons_folderId_idx";
DROP INDEX IF EXISTS public."folder_categories_tenantId_idx";
DROP INDEX IF EXISTS public."folder_categories_parentId_idx";
DROP INDEX IF EXISTS public."email_logs_tenantId_idx";
DROP INDEX IF EXISTS public."email_logs_createdAt_idx";
DROP INDEX IF EXISTS public."documents_tenantId_idx";
DROP INDEX IF EXISTS public.documents_status_idx;
DROP INDEX IF EXISTS public."documents_requiresSignature_idx";
DROP INDEX IF EXISTS public."documents_folderId_idx";
DROP INDEX IF EXISTS public."documents_folderCategoryId_idx";
DROP INDEX IF EXISTS public.documents_checksum_idx;
DROP INDEX IF EXISTS public.document_tracking_status_idx;
DROP INDEX IF EXISTS public."document_tracking_signatureRequestId_key";
DROP INDEX IF EXISTS public."document_tracking_nextReminderAt_idx";
DROP INDEX IF EXISTS public."document_tracking_lrarTrackingNumber_key";
DROP INDEX IF EXISTS public."document_tracking_documentId_key";
DROP INDEX IF EXISTS public."document_requests_tenantId_idx";
DROP INDEX IF EXISTS public.document_requests_status_idx;
DROP INDEX IF EXISTS public."document_requests_folderId_idx";
DROP INDEX IF EXISTS public."deadlines_tenantId_idx";
DROP INDEX IF EXISTS public.deadlines_status_idx;
DROP INDEX IF EXISTS public."deadlines_folderId_idx";
DROP INDEX IF EXISTS public."deadlines_dueDate_idx";
DROP INDEX IF EXISTS public."deadlines_assignedToId_idx";
DROP INDEX IF EXISTS public."conversations_tenantId_idx";
DROP INDEX IF EXISTS public."conversations_lastMessageAt_idx";
DROP INDEX IF EXISTS public."conversations_folderId_idx";
DROP INDEX IF EXISTS public."conversation_participants_userId_idx";
DROP INDEX IF EXISTS public."conversation_participants_conversationId_userId_key";
DROP INDEX IF EXISTS public."clients_tenantId_idx";
DROP INDEX IF EXISTS public."clients_tenantId_email_idx";
DROP INDEX IF EXISTS public."clients_invitationToken_key";
DROP INDEX IF EXISTS public."clients_invitationToken_idx";
DROP INDEX IF EXISTS public.clients_email_idx;
DROP INDEX IF EXISTS public."client_consents_clientId_idx";
DROP INDEX IF EXISTS public."client_accesses_folderId_email_key";
DROP INDEX IF EXISTS public.client_accesses_email_idx;
DROP INDEX IF EXISTS public."client_accesses_activationToken_key";
DROP INDEX IF EXISTS public."client_accesses_activationToken_idx";
DROP INDEX IF EXISTS public."client_access_logs_createdAt_idx";
DROP INDEX IF EXISTS public."client_access_logs_accessId_idx";
DROP INDEX IF EXISTS public."builder_templates_tenantId_idx";
DROP INDEX IF EXISTS public."builder_templates_templateCategoryId_idx";
DROP INDEX IF EXISTS public."builder_templates_isSystem_idx";
DROP INDEX IF EXISTS public."builder_templates_documentType_idx";
DROP INDEX IF EXISTS public.builder_templates_category_idx;
DROP INDEX IF EXISTS public."builder_blocks_tenantId_idx";
DROP INDEX IF EXISTS public."builder_blocks_isSystem_idx";
DROP INDEX IF EXISTS public.builder_blocks_category_idx;
DROP INDEX IF EXISTS public."backup_logs_tenantId_idx";
DROP INDEX IF EXISTS public."backup_logs_startedAt_idx";
DROP INDEX IF EXISTS public."avocat_legal_info_tenantId_key";
DROP INDEX IF EXISTS public."audit_logs_userId_idx";
DROP INDEX IF EXISTS public."audit_logs_tenantId_idx";
DROP INDEX IF EXISTS public."audit_logs_entityType_entityId_idx";
DROP INDEX IF EXISTS public."audit_logs_createdAt_idx";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.tenant_settings DROP CONSTRAINT IF EXISTS tenant_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.template_categories DROP CONSTRAINT IF EXISTS template_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.signatures DROP CONSTRAINT IF EXISTS signatures_pkey;
ALTER TABLE IF EXISTS ONLY public.signature_reminders DROP CONSTRAINT IF EXISTS signature_reminders_pkey;
ALTER TABLE IF EXISTS ONLY public.reminder_logs DROP CONSTRAINT IF EXISTS reminder_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.registered_mails DROP CONSTRAINT IF EXISTS registered_mails_pkey;
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS push_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.folders DROP CONSTRAINT IF EXISTS folders_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_templates DROP CONSTRAINT IF EXISTS folder_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_persons DROP CONSTRAINT IF EXISTS folder_persons_pkey;
ALTER TABLE IF EXISTS ONLY public.folder_categories DROP CONSTRAINT IF EXISTS folder_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.email_logs DROP CONSTRAINT IF EXISTS email_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_tracking DROP CONSTRAINT IF EXISTS document_tracking_pkey;
ALTER TABLE IF EXISTS ONLY public.document_requests DROP CONSTRAINT IF EXISTS document_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.deadlines DROP CONSTRAINT IF EXISTS deadlines_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_participants DROP CONSTRAINT IF EXISTS conversation_participants_pkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_pkey;
ALTER TABLE IF EXISTS ONLY public.client_consents DROP CONSTRAINT IF EXISTS client_consents_pkey;
ALTER TABLE IF EXISTS ONLY public.client_accesses DROP CONSTRAINT IF EXISTS client_accesses_pkey;
ALTER TABLE IF EXISTS ONLY public.client_access_logs DROP CONSTRAINT IF EXISTS client_access_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.builder_templates DROP CONSTRAINT IF EXISTS builder_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.builder_blocks DROP CONSTRAINT IF EXISTS builder_blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_logs DROP CONSTRAINT IF EXISTS backup_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.avocat_legal_info DROP CONSTRAINT IF EXISTS avocat_legal_info_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.tenants;
DROP TABLE IF EXISTS public.tenant_settings;
DROP TABLE IF EXISTS public.template_categories;
DROP TABLE IF EXISTS public.signatures;
DROP TABLE IF EXISTS public.signature_reminders;
DROP TABLE IF EXISTS public.reminder_logs;
DROP TABLE IF EXISTS public.registered_mails;
DROP TABLE IF EXISTS public.push_subscriptions;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.folders;
DROP TABLE IF EXISTS public.folder_templates;
DROP TABLE IF EXISTS public.folder_persons;
DROP TABLE IF EXISTS public.folder_categories;
DROP TABLE IF EXISTS public.email_logs;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_tracking;
DROP TABLE IF EXISTS public.document_requests;
DROP TABLE IF EXISTS public.deadlines;
DROP TABLE IF EXISTS public.conversations;
DROP TABLE IF EXISTS public.conversation_participants;
DROP TABLE IF EXISTS public.clients;
DROP TABLE IF EXISTS public.client_consents;
DROP TABLE IF EXISTS public.client_accesses;
DROP TABLE IF EXISTS public.client_access_logs;
DROP TABLE IF EXISTS public.builder_templates;
DROP TABLE IF EXISTS public.builder_blocks;
DROP TABLE IF EXISTS public.backup_logs;
DROP TABLE IF EXISTS public.avocat_legal_info;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."TrackingStatus";
DROP TYPE IF EXISTS public."SignerType";
DROP TYPE IF EXISTS public."SignatureStatus";
DROP TYPE IF EXISTS public."ReminderType";
DROP TYPE IF EXISTS public."ReminderStatus";
DROP TYPE IF EXISTS public."RegisteredMailStatus";
DROP TYPE IF EXISTS public."PersonType";
DROP TYPE IF EXISTS public."PersonRole";
DROP TYPE IF EXISTS public."OutputFormat";
DROP TYPE IF EXISTS public."NotificationType";
DROP TYPE IF EXISTS public."FolderType";
DROP TYPE IF EXISTS public."FolderStatus";
DROP TYPE IF EXISTS public."EmailStatus";
DROP TYPE IF EXISTS public."DocumentType";
DROP TYPE IF EXISTS public."DocumentStatus";
DROP TYPE IF EXISTS public."DocumentRequestStatus";
DROP TYPE IF EXISTS public."DocumentRequestPriority";
DROP TYPE IF EXISTS public."DeliveryMethod";
DROP TYPE IF EXISTS public."DeadlineType";
DROP TYPE IF EXISTS public."DeadlineStatus";
DROP TYPE IF EXISTS public."DeadlinePriority";
DROP TYPE IF EXISTS public."ConsentType";
DROP TYPE IF EXISTS public."ClientType";
DROP TYPE IF EXISTS public."BlockCategory";
DROP TYPE IF EXISTS public."BackupType";
DROP TYPE IF EXISTS public."BackupStatus";
--
-- Name: BackupStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."BackupStatus" AS ENUM (
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."BackupStatus" OWNER TO lexdoc_user;

--
-- Name: BackupType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."BackupType" AS ENUM (
    'DATABASE',
    'MINIO',
    'FULL'
);


ALTER TYPE public."BackupType" OWNER TO lexdoc_user;

--
-- Name: BlockCategory; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."BlockCategory" AS ENUM (
    'INTRO',
    'FAITS',
    'MOYENS',
    'DISPOSITIF',
    'SIGNATURE',
    'CLAUSE',
    'CUSTOM'
);


ALTER TYPE public."BlockCategory" OWNER TO lexdoc_user;

--
-- Name: ClientType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ClientType" AS ENUM (
    'INDIVIDUAL',
    'COMPANY',
    'ASSOCIATION'
);


ALTER TYPE public."ClientType" OWNER TO lexdoc_user;

--
-- Name: ConsentType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ConsentType" AS ENUM (
    'DATA_PROCESSING',
    'EMAIL_NOTIFICATIONS',
    'SMS_NOTIFICATIONS',
    'DOCUMENT_STORAGE',
    'DATA_RETENTION'
);


ALTER TYPE public."ConsentType" OWNER TO lexdoc_user;

--
-- Name: DeadlinePriority; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeadlinePriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."DeadlinePriority" OWNER TO lexdoc_user;

--
-- Name: DeadlineStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeadlineStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'OVERDUE'
);


ALTER TYPE public."DeadlineStatus" OWNER TO lexdoc_user;

--
-- Name: DeadlineType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeadlineType" AS ENUM (
    'DEADLINE',
    'HEARING',
    'MEETING',
    'REMINDER',
    'TASK',
    'OTHER'
);


ALTER TYPE public."DeadlineType" OWNER TO lexdoc_user;

--
-- Name: DeliveryMethod; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DeliveryMethod" AS ENUM (
    'SIGNATURE_ELECTRONIQUE',
    'LRAR',
    'EMAIL'
);


ALTER TYPE public."DeliveryMethod" OWNER TO lexdoc_user;

--
-- Name: DocumentRequestPriority; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentRequestPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."DocumentRequestPriority" OWNER TO lexdoc_user;

--
-- Name: DocumentRequestStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentRequestStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'CANCELLED',
    'EXPIRED'
);


ALTER TYPE public."DocumentRequestStatus" OWNER TO lexdoc_user;

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'DRAFT',
    'PENDING_REVIEW',
    'PENDING_SIGNATURE',
    'SIGNED',
    'SENT',
    'ARCHIVED',
    'CANCELLED'
);


ALTER TYPE public."DocumentStatus" OWNER TO lexdoc_user;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentType" AS ENUM (
    'CONTRACT',
    'DEED',
    'LETTER',
    'INVOICE',
    'RECEIPT',
    'CERTIFICATE',
    'REPORT',
    'MINUTES',
    'AMENDMENT',
    'MEMORANDUM',
    'POWER_OF_ATTORNEY',
    'OTHER'
);


ALTER TYPE public."DocumentType" OWNER TO lexdoc_user;

--
-- Name: EmailStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."EmailStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'BOUNCED'
);


ALTER TYPE public."EmailStatus" OWNER TO lexdoc_user;

--
-- Name: FolderStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."FolderStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'PENDING',
    'CLOSED',
    'ARCHIVED'
);


ALTER TYPE public."FolderStatus" OWNER TO lexdoc_user;

--
-- Name: FolderType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."FolderType" AS ENUM (
    'LITIGATION',
    'CONTRACT',
    'BUSINESS',
    'FAMILY',
    'REAL_ESTATE',
    'LABOR',
    'INTELLECTUAL',
    'ADMINISTRATIVE',
    'CRIMINAL',
    'OTHER'
);


ALTER TYPE public."FolderType" OWNER TO lexdoc_user;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."NotificationType" AS ENUM (
    'SIGNATURE_PENDING',
    'SIGNATURE_COMPLETED',
    'SIGNATURE_REMINDER',
    'DOCUMENT_UPLOADED',
    'DOCUMENT_SHARED',
    'DOCUMENT_REQUEST',
    'DOCUMENT_REQUEST_FULFILLED',
    'FOLDER_CREATED',
    'FOLDER_STATUS_CHANGED',
    'CLIENT_ACCESS_CREATED',
    'DEADLINE_APPROACHING',
    'DEADLINE_PASSED',
    'MESSAGE_RECEIVED',
    'SYSTEM'
);


ALTER TYPE public."NotificationType" OWNER TO lexdoc_user;

--
-- Name: OutputFormat; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."OutputFormat" AS ENUM (
    'DOCX',
    'PDF'
);


ALTER TYPE public."OutputFormat" OWNER TO lexdoc_user;

--
-- Name: PersonRole; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."PersonRole" AS ENUM (
    'PARTIE_ADVERSE',
    'AVOCAT_ADVERSE',
    'TEMOIN',
    'EXPERT',
    'NOTAIRE',
    'HUISSIER',
    'MEDIATEUR',
    'AUTRE'
);


ALTER TYPE public."PersonRole" OWNER TO lexdoc_user;

--
-- Name: PersonType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."PersonType" AS ENUM (
    'PHYSIQUE',
    'MORALE'
);


ALTER TYPE public."PersonType" OWNER TO lexdoc_user;

--
-- Name: RegisteredMailStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."RegisteredMailStatus" AS ENUM (
    'PREPARING',
    'SENT',
    'IN_TRANSIT',
    'DELIVERED',
    'RETURNED',
    'ERROR'
);


ALTER TYPE public."RegisteredMailStatus" OWNER TO lexdoc_user;

--
-- Name: ReminderStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ReminderStatus" AS ENUM (
    'SENT',
    'FAILED',
    'OPENED',
    'CLICKED'
);


ALTER TYPE public."ReminderStatus" OWNER TO lexdoc_user;

--
-- Name: ReminderType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ReminderType" AS ENUM (
    'FIRST_REMINDER',
    'SECOND_REMINDER',
    'THIRD_REMINDER',
    'FINAL_NOTICE'
);


ALTER TYPE public."ReminderType" OWNER TO lexdoc_user;

--
-- Name: SignatureStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."SignatureStatus" AS ENUM (
    'PENDING',
    'SIGNED',
    'REFUSED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."SignatureStatus" OWNER TO lexdoc_user;

--
-- Name: SignerType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."SignerType" AS ENUM (
    'CLIENT',
    'LAWYER',
    'THIRD_PARTY'
);


ALTER TYPE public."SignerType" OWNER TO lexdoc_user;

--
-- Name: TrackingStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."TrackingStatus" AS ENUM (
    'DRAFT',
    'PENDING_SIGNATURE',
    'SIGNED',
    'PENDING_DELIVERY',
    'DELIVERED',
    'EXPIRED'
);


ALTER TYPE public."TrackingStatus" OWNER TO lexdoc_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'LAWYER',
    'ASSISTANT',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO lexdoc_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO lexdoc_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    changes jsonb,
    metadata jsonb,
    "userId" text,
    "ipAddress" text,
    "userAgent" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO lexdoc_user;

--
-- Name: avocat_legal_info; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.avocat_legal_info (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    "numeroToque" text,
    barreau text,
    specialites text[] DEFAULT ARRAY[]::text[],
    rcs text,
    "tvaIntra" text,
    "assuranceRC" text,
    "numeroPolice" text,
    "signaturePath" text,
    "cachetPath" text,
    "mentionsLegales" jsonb
);


ALTER TABLE public.avocat_legal_info OWNER TO lexdoc_user;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.backup_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tenantId" text,
    type public."BackupType" NOT NULL,
    status public."BackupStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "fileSize" bigint,
    "googleDriveId" text,
    "errorMessage" text
);


ALTER TABLE public.backup_logs OWNER TO lexdoc_user;

--
-- Name: builder_blocks; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.builder_blocks (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    category public."BlockCategory" NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    variables jsonb,
    tags text[] DEFAULT ARRAY[]::text[],
    "isMandatory" boolean DEFAULT false NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "displayOrder" integer,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdById" text
);


ALTER TABLE public.builder_blocks OWNER TO lexdoc_user;

--
-- Name: builder_templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.builder_templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    description text,
    "documentType" text NOT NULL,
    juridiction text,
    category text,
    "blocksStructure" jsonb NOT NULL,
    "requiredVariables" jsonb,
    "outputFormat" public."OutputFormat" DEFAULT 'DOCX'::public."OutputFormat" NOT NULL,
    "workflowConfig" jsonb,
    "legalMentions" jsonb,
    "isSystem" boolean DEFAULT false NOT NULL,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdById" text,
    "templateCategoryId" text
);


ALTER TABLE public.builder_templates OWNER TO lexdoc_user;

--
-- Name: client_access_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_access_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accessId" text NOT NULL,
    action text NOT NULL,
    "ipAddress" text NOT NULL,
    "userAgent" text
);


ALTER TABLE public.client_access_logs OWNER TO lexdoc_user;

--
-- Name: client_accesses; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_accesses (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    email text NOT NULL,
    "passwordHash" text,
    "activationToken" text,
    "tokenExpiresAt" timestamp(3) without time zone,
    "isActivated" boolean DEFAULT false NOT NULL,
    "lastLoginAt" timestamp(3) without time zone
);


ALTER TABLE public.client_accesses OWNER TO lexdoc_user;

--
-- Name: client_consents; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_consents (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "clientId" text NOT NULL,
    type public."ConsentType" NOT NULL,
    granted boolean NOT NULL,
    "grantedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "userAgent" text
);


ALTER TABLE public.client_consents OWNER TO lexdoc_user;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.clients (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    type public."ClientType" DEFAULT 'INDIVIDUAL'::public."ClientType" NOT NULL,
    "firstName" text,
    "lastName" text,
    "birthDate" timestamp(3) without time zone,
    "companyName" text,
    siret text,
    "vatNumber" text,
    email text NOT NULL,
    phone text,
    mobile text,
    address text,
    "addressLine2" text,
    "postalCode" text,
    city text,
    country text DEFAULT 'FR'::text NOT NULL,
    "hasExternet" boolean DEFAULT false NOT NULL,
    "extranetPassword" text,
    "extranetActivatedAt" timestamp(3) without time zone,
    "extranetLastLoginAt" timestamp(3) without time zone,
    "invitationToken" text,
    "invitationSentAt" timestamp(3) without time zone,
    "invitationExpiresAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    notes text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.clients OWNER TO lexdoc_user;

--
-- Name: conversation_participants; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.conversation_participants (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "conversationId" text NOT NULL,
    "userId" text NOT NULL,
    "lastReadAt" timestamp(3) without time zone,
    "unreadCount" integer DEFAULT 0 NOT NULL,
    "notificationsEnabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.conversation_participants OWNER TO lexdoc_user;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    subject text,
    "folderId" text,
    "lastMessageAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL
);


ALTER TABLE public.conversations OWNER TO lexdoc_user;

--
-- Name: deadlines; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.deadlines (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    title text NOT NULL,
    description text,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "dueTime" text,
    type public."DeadlineType" DEFAULT 'DEADLINE'::public."DeadlineType" NOT NULL,
    priority public."DeadlinePriority" DEFAULT 'NORMAL'::public."DeadlinePriority" NOT NULL,
    status public."DeadlineStatus" DEFAULT 'PENDING'::public."DeadlineStatus" NOT NULL,
    reminders jsonb,
    "lastReminderSentAt" timestamp(3) without time zone,
    "folderId" text,
    "documentId" text,
    "assignedToId" text,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL,
    "isRecurring" boolean DEFAULT false NOT NULL,
    "recurrenceRule" text,
    "completedAt" timestamp(3) without time zone,
    "completedById" text
);


ALTER TABLE public.deadlines OWNER TO lexdoc_user;

--
-- Name: document_requests; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.document_requests (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."DocumentRequestStatus" DEFAULT 'PENDING'::public."DocumentRequestStatus" NOT NULL,
    priority public."DocumentRequestPriority" DEFAULT 'NORMAL'::public."DocumentRequestPriority" NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "responseDocumentId" text,
    "responseDate" timestamp(3) without time zone,
    "responseNotes" text,
    "reminderCount" integer DEFAULT 0 NOT NULL,
    "lastReminderAt" timestamp(3) without time zone,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.document_requests OWNER TO lexdoc_user;

--
-- Name: document_tracking; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.document_tracking (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    status public."TrackingStatus" DEFAULT 'DRAFT'::public."TrackingStatus" NOT NULL,
    "deliveryMethod" public."DeliveryMethod",
    "signatureRequestId" text,
    "signatureStatus" public."SignatureStatus",
    "signedAt" timestamp(3) without time zone,
    "signedBy" text[] DEFAULT ARRAY[]::text[],
    "lrarTrackingNumber" text,
    "lrarStatus" public."RegisteredMailStatus",
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "reminderCount" integer DEFAULT 0 NOT NULL,
    "lastReminderAt" timestamp(3) without time zone,
    "nextReminderAt" timestamp(3) without time zone,
    "autoRemindersEnabled" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.document_tracking OWNER TO lexdoc_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    type public."DocumentType" NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    size bigint NOT NULL,
    checksum text NOT NULL,
    "bucketName" text NOT NULL,
    "objectKey" text NOT NULL,
    "isEncrypted" boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "parentId" text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    "requiresSignature" boolean DEFAULT false NOT NULL,
    "signatureDeadline" timestamp(3) without time zone,
    "validFrom" timestamp(3) without time zone,
    "validUntil" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    "folderId" text NOT NULL,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL,
    "folderCategoryId" text
);


ALTER TABLE public.documents OWNER TO lexdoc_user;

--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.email_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "to" text NOT NULL,
    subject text NOT NULL,
    template text NOT NULL,
    status public."EmailStatus" DEFAULT 'SENT'::public."EmailStatus" NOT NULL,
    "errorMessage" text,
    "notificationId" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.email_logs OWNER TO lexdoc_user;

--
-- Name: folder_categories; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_categories (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    color text,
    icon text,
    "parentId" text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.folder_categories OWNER TO lexdoc_user;

--
-- Name: folder_persons; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_persons (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text NOT NULL,
    "tenantId" text NOT NULL,
    type public."PersonType" DEFAULT 'PHYSIQUE'::public."PersonType" NOT NULL,
    role public."PersonRole" NOT NULL,
    "firstName" text,
    "lastName" text NOT NULL,
    company text,
    email text,
    phone text,
    address text,
    notes text
);


ALTER TABLE public.folder_persons OWNER TO lexdoc_user;

--
-- Name: folder_templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    "folderType" public."FolderType" NOT NULL,
    structure jsonb NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.folder_templates OWNER TO lexdoc_user;

--
-- Name: folders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    reference text NOT NULL,
    title text NOT NULL,
    description text,
    type public."FolderType" NOT NULL,
    status public."FolderStatus" DEFAULT 'OPEN'::public."FolderStatus" NOT NULL,
    "openedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "clientId" text NOT NULL,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL,
    color text DEFAULT '#3B82F6'::text,
    "metadataCession" jsonb,
    "parentId" text
);


ALTER TABLE public.folders OWNER TO lexdoc_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.messages (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "conversationId" text NOT NULL,
    content text NOT NULL,
    attachments jsonb,
    "senderId" text NOT NULL,
    "isEdited" boolean DEFAULT false NOT NULL,
    "editedAt" timestamp(3) without time zone,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL
);


ALTER TABLE public.messages OWNER TO lexdoc_user;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.notification_preferences (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    "emailSignatures" boolean DEFAULT true NOT NULL,
    "emailDocuments" boolean DEFAULT true NOT NULL,
    "emailDeadlines" boolean DEFAULT true NOT NULL,
    "emailMessages" boolean DEFAULT true NOT NULL,
    "emailDigest" boolean DEFAULT false NOT NULL,
    "digestFrequency" text DEFAULT 'DAILY'::text NOT NULL,
    "pushEnabled" boolean DEFAULT true NOT NULL,
    "pushSignatures" boolean DEFAULT true NOT NULL,
    "pushDocuments" boolean DEFAULT true NOT NULL,
    "pushDeadlines" boolean DEFAULT true NOT NULL,
    "pushMessages" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO lexdoc_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "entityType" text,
    "entityId" text,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    "emailSent" boolean DEFAULT false NOT NULL,
    "emailSentAt" timestamp(3) without time zone,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.notifications OWNER TO lexdoc_user;

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.push_subscriptions (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accessId" text NOT NULL,
    endpoint text NOT NULL,
    keys jsonb NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO lexdoc_user;

--
-- Name: registered_mails; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.registered_mails (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    "recipientName" text NOT NULL,
    "recipientAddress" text NOT NULL,
    "recipientCity" text NOT NULL,
    "recipientPostalCode" text NOT NULL,
    "recipientCountry" text DEFAULT 'FR'::text NOT NULL,
    "sendingBoxId" text,
    "trackingNumber" text,
    status public."RegisteredMailStatus" DEFAULT 'PREPARING'::public."RegisteredMailStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "returnedAt" timestamp(3) without time zone,
    "proofUrl" text,
    cost numeric(10,2)
);


ALTER TABLE public.registered_mails OWNER TO lexdoc_user;

--
-- Name: reminder_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.reminder_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "trackingId" text NOT NULL,
    type public."ReminderType" NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "sentTo" text NOT NULL,
    "emailSubject" text,
    "emailBody" text,
    status public."ReminderStatus" DEFAULT 'SENT'::public."ReminderStatus" NOT NULL,
    "errorMessage" text
);


ALTER TABLE public.reminder_logs OWNER TO lexdoc_user;

--
-- Name: signature_reminders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signature_reminders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "signatureId" text NOT NULL,
    "reminderNumber" integer NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "emailSent" boolean DEFAULT true NOT NULL,
    "smsSent" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.signature_reminders OWNER TO lexdoc_user;

--
-- Name: signatures; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signatures (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    "signerEmail" text NOT NULL,
    "signerName" text NOT NULL,
    "signerType" public."SignerType" DEFAULT 'CLIENT'::public."SignerType" NOT NULL,
    "transactionId" text,
    "signatureUrl" text,
    status public."SignatureStatus" DEFAULT 'PENDING'::public."SignatureStatus" NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "signedAt" timestamp(3) without time zone,
    "refusedAt" timestamp(3) without time zone,
    "expiredAt" timestamp(3) without time zone,
    "certificateUrl" text
);


ALTER TABLE public.signatures OWNER TO lexdoc_user;

--
-- Name: template_categories; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.template_categories (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    color text,
    "displayOrder" integer DEFAULT 0 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.template_categories OWNER TO lexdoc_user;

--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.tenant_settings (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "enableReminders" boolean DEFAULT true NOT NULL,
    "reminderSchedule" text DEFAULT '1,3,5'::text NOT NULL,
    "maxReminders" integer DEFAULT 3 NOT NULL,
    "defaultSignatureDeadlineDays" integer DEFAULT 7 NOT NULL,
    "emailFromName" text,
    "emailReplyTo" text,
    "emailSignature" text,
    "lrarSenderName" text,
    "lrarSenderAddress" text,
    "documentRetentionYears" integer DEFAULT 10 NOT NULL,
    "autoArchiveClosedFolders" boolean DEFAULT false NOT NULL,
    "autoArchiveAfterDays" integer DEFAULT 365 NOT NULL,
    "enforceStrongPasswords" boolean DEFAULT true NOT NULL,
    "sessionTimeoutMinutes" integer DEFAULT 480 NOT NULL,
    "require2FA" boolean DEFAULT false NOT NULL,
    "allowClientUpload" boolean DEFAULT false NOT NULL,
    "clientUploadMaxSizeMB" integer DEFAULT 10 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.tenant_settings OWNER TO lexdoc_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "legalName" text,
    siret text,
    address text,
    "postalCode" text,
    city text,
    country text DEFAULT 'FR'::text NOT NULL,
    phone text,
    email text NOT NULL,
    website text,
    logo text,
    "primaryColor" text DEFAULT '#0066ff'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "subscriptionTier" text DEFAULT 'TRIAL'::text NOT NULL,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    "maxClients" integer DEFAULT 100 NOT NULL,
    "maxStorage" bigint DEFAULT '5368709120'::bigint NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "subscribedAt" timestamp(3) without time zone
);


ALTER TABLE public.tenants OWNER TO lexdoc_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    avatar text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    permissions jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "resetToken" text,
    "resetTokenExpiresAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL,
    "refreshTokens" text[] DEFAULT ARRAY[]::text[],
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text
);


ALTER TABLE public.users OWNER TO lexdoc_user;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
df614b84-63b5-4bb7-acb3-705677064d8c	c3975f490877fbbe544867ca743a67c9e6ee63f8c45786aab9149392fbc41cab	2026-02-03 17:36:28.361432+00	20260203173628_init	\N	\N	2026-02-03 17:36:28.169949+00	1
b53b932e-f567-43d5-9c46-769f20004240	7befaa95cbd2df3dc0b69296e0c81b9f33821247ab2e5b8a85c8d00a37733473	2026-02-04 09:03:32.753787+00	20260204090332_add_master_models	\N	\N	2026-02-04 09:03:32.608161+00	1
9224efd1-6eb4-4b35-8ff4-40d603b275f5	1bfa825f044421de547fb7894bea3757e55cc68bfb2076c920612bbddc819573	2026-02-05 11:08:37.496505+00	20260205110837_add_folder_persons	\N	\N	2026-02-05 11:08:37.466876+00	1
9f39542c-5bc6-4192-b2a6-3e8a3c6ec2ae	027a9a0dfca8757a2510ca81b5f2909f060cb4f3ffc7b9195d58273f39665fcd	2026-02-05 12:18:53.822141+00	20260205121846_add_categories_and_document_requests	\N	\N	2026-02-05 12:18:53.756947+00	1
57b95031-c718-4cf4-a8c9-3da482e50ee5	76e97876e0249e9f13b4593e35f5e30de2df7cf067e9ed204333f938ab9c60f8	2026-02-05 15:56:54.976369+00	20260205155654_add_notifications	\N	\N	2026-02-05 15:56:54.925674+00	1
45c6821e-9d78-4e40-be5d-c5937404a327	eae02a367e0a0fe05f26f30011d3eeca99215d7356139119b53925883631b21f	2026-02-05 16:05:43.698416+00	20260205160543_add_deadlines	\N	\N	2026-02-05 16:05:43.667612+00	1
0da97ed0-5060-4b0f-91ba-180168a3867b	3d72c771232e2d51625c0ffb809798730649b040fc2386f6398f9652a01f8b59	2026-02-05 16:17:51.515635+00	20260205161751_add_chat_messaging	\N	\N	2026-02-05 16:17:51.476935+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.audit_logs (id, "createdAt", action, "entityType", "entityId", changes, metadata, "userId", "ipAddress", "userAgent", "tenantId") FROM stdin;
cml9d6re0000310v131hgdvno	2026-02-05 11:19:45.193	FOLDER_PERSON_CREATED	FolderPerson	cml9d6rdu000110v1tusjcjkg	\N	{"role": "PARTIE_ADVERSE", "type": "PHYSIQUE", "folderId": "fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9d6yyd000710v1s2ytx2ou	2026-02-05 11:19:54.998	FOLDER_PERSON_CREATED	FolderPerson	cml9d6yya000510v135c0rzqq	\N	{"role": "AVOCAT_ADVERSE", "type": "MORALE", "folderId": "fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9dchns000910v1wak9ry48	2026-02-05 11:24:12.52	FOLDER_PERSON_UPDATED	FolderPerson	cml9d6rdu000110v1tusjcjkg	{"phone": "06 12 34 56 78"}	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9ded1o000b10v1j93e9zw7	2026-02-05 11:25:39.853	FOLDER_PERSON_DELETED	FolderPerson	cml9d6yya000510v135c0rzqq	\N	{"folderId": "fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6", "deletedPerson": {"role": "AVOCAT_ADVERSE", "type": "MORALE", "lastName": "Durand", "firstName": "Marie"}}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9kmiuy000111bil489a50p	2026-02-05 14:47:57.946	FOLDER_VIEWED	Folder	cml8feb1z000510pf9trmhfa2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9kmiwr000311bif9vuzeh2	2026-02-05 14:47:58.012	FOLDER_VIEWED	Folder	cml8feb1z000510pf9trmhfa2	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9kseay000l11bizy0ekhjm	2026-02-05 14:52:31.978	DOCUMENT_REQUEST_CREATED	DocumentRequest	cml9kseai000j11bi8qvvdh5f	\N	{"title": "Justificatif de domicile", "folderId": "fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9ksedt000p11biz4h33zcr	2026-02-05 14:52:32.081	DOCUMENT_REQUEST_CREATED	DocumentRequest	cml9ksedi000n11bicid4rupz	\N	{"title": "Pièce d'identité", "folderId": "fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379"}	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9m0r5a000114jc1n3cvdzx	2026-02-05 15:27:01.483	FOLDER_VIEWED	Folder	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9m1cse000314jc2sx4xjma	2026-02-05 15:27:29.534	FOLDER_VIEWED	Folder	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	\N	\N	cml6vykja0002jms2hhr4hfr3	127.0.0.1	curl/8.5.0	cml6vykdd0000jms2wwxl9s27
cml9mcqwi00017q3ncwjf1i93	2026-02-05 15:36:21.043	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mcqy300037q3nzwis0mn8	2026-02-05 15:36:21.1	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9md6l500057q3nmvyes1ro	2026-02-05 15:36:41.369	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9md6mv00077q3n29rc8uzk	2026-02-05 15:36:41.431	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mj7vl00097q3nw8gsexwy	2026-02-05 15:41:22.978	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mj7x5000b7q3ns4w8isw7	2026-02-05 15:41:23.033	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mn7i40001iauvrf1bq1eb	2026-02-05 15:44:29.116	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9moch20003iauv35nd41ud	2026-02-05 15:45:22.214	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9mocqc0005iauvhvfvpfn8	2026-02-05 15:45:22.549	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nqoeu000111z64186hkb9	2026-02-05 16:15:10.614	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nqohs000311z6iug2xrh2	2026-02-05 16:15:10.72	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nskok000511z6fpfbsuf1	2026-02-05 16:16:39.092	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
cml9nskqh000711z6kbn6ylrj	2026-02-05 16:16:39.161	FOLDER_VIEWED	Folder	cml6vyl0v000djms25rbug5x8	\N	\N	cml6vykja0002jms2hhr4hfr3	90.105.191.233	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: avocat_legal_info; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.avocat_legal_info (id, "createdAt", "updatedAt", "tenantId", "numeroToque", barreau, specialites, rcs, "tvaIntra", "assuranceRC", "numeroPolice", "signaturePath", "cachetPath", "mentionsLegales") FROM stdin;
cml7z1r4400018nc2oq2y4dwa	2026-02-04 11:56:10.754	2026-02-04 11:58:08.016	cml6vykdd0000jms2wwxl9s27	P0245	Angers	{"Droit des affaires","Droit des sociétés",Fusions-Acquisitions}	Angers B 123 456 789	FR12345678901	AXA Assurances	RC-2026-00123456	\N	\N	{"rcs": "Angers B 123 456 789", "ordre": "Ordre des Avocats du Barreau d'Angers", "siege": "123 Rue de la Paix, 49000 Angers", "capital": 10000, "denomination": "Cabinet Pragmavox", "forme_juridique": "SELARL"}
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.backup_logs (id, "createdAt", "tenantId", type, status, "startedAt", "completedAt", "fileSize", "googleDriveId", "errorMessage") FROM stdin;
cml8vc3840003nk90y6t6vu6u	2026-02-05 03:00:00.724	\N	DATABASE	FAILED	2026-02-05 03:00:00.724	2026-02-05 03:00:00.883	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-05T03-00-00-718Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
cml8vc3510001nk90jsvc1ntg	2026-02-05 03:00:00.442	\N	FULL	FAILED	2026-02-05 03:00:00.442	2026-02-05 03:00:00.909	\N	\N	Command failed: PGPASSWORD="lexdoc_dev_password_2026" pg_dump -h localhost -p 5434 -U lexdoc_user -d lexdoc_dev?schema=public -F c -f /tmp/lexdoc-backups/db-backup-2026-02-05T03-00-00-718Z.sql\npg_dump: error: invalid connection option "lexdoc_dev?schema"\n
\.


--
-- Data for Name: builder_blocks; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.builder_blocks (id, "createdAt", "updatedAt", "tenantId", category, title, content, variables, tags, "isMandatory", "isSystem", "displayOrder", "usageCount", "createdById") FROM stdin;
cml7z49iq0001b6vehzovx84s	2026-02-04 11:58:07.922	2026-02-04 11:58:07.922	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête assignation TJ	ASSIGNATION\n\nDevant le Tribunal Judiciaire de {{juridiction}}\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}, {{demandeur.qualite}}, demeurant {{demandeur.adresse}},\n\nAyant pour avocat constitué : Maître {{avocat.nom}}, avocat au barreau de {{avocat.barreau}}, Toque n°{{avocat.toque}}	\N	{assignation,TJ,"tribunal judiciaire"}	t	t	\N	0	\N
cml7z49iz0003b6vepujrnmuc	2026-02-04 11:58:07.931	2026-02-04 11:58:07.931	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête assignation TC	ASSIGNATION\n\nDevant le Tribunal de Commerce de {{juridiction}}\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}, {{demandeur.forme_juridique}}, au capital de {{demandeur.capital}} euros, immatriculée au RCS de {{demandeur.rcs}} sous le numéro {{demandeur.siret}}, dont le siège social est situé {{demandeur.siege}}	\N	{assignation,TC,"tribunal commerce"}	t	t	\N	0	\N
cml7z49j20005b6ve03t88bbo	2026-02-04 11:58:07.934	2026-02-04 11:58:07.934	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête conclusions	CONCLUSIONS\n\nPOUR :\n{{partie.nom}}, {{partie.qualite}}\nDemeurant {{partie.adresse}}\n\nAyant pour avocat constitué : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n{{avocat.adresse}}\nTél : {{avocat.telephone}} - Fax : {{avocat.fax}}\nToque n°{{avocat.toque}}	\N	{conclusions,en-tête}	f	t	\N	0	\N
cml7z49ji0007b6vetr147duw	2026-02-04 11:58:07.951	2026-02-04 11:58:07.951	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête mise en demeure	{{cabinet.nom}}\n{{cabinet.adresse}}\n{{cabinet.cp}} {{cabinet.ville}}\n\nLettre recommandée avec AR n°{{lrar.numero}}\n\n{{lieu}}, le {{date}}\n\nObjet : Mise en demeure\nRéf : {{reference_dossier}}\n\nMadame, Monsieur,	\N	{"mise en demeure",LRAR,courrier}	f	t	\N	0	\N
cml7z49jl0009b6veju45kles	2026-02-04 11:58:07.953	2026-02-04 11:58:07.953	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête convocation audience	CONVOCATION À L'AUDIENCE\n\nVeuillez vous présenter ou vous faire représenter le :\n\n{{date_audience}} à {{heure_audience}}\n\nDevant le {{juridiction}}\nSitué : {{adresse_juridiction}}\nSalle : {{salle_audience}}\n\nPour l'affaire :\n{{demandeur.nom}} c/ {{defendeur.nom}}\nRG n°{{numero_rg}}	\N	{convocation,audience}	f	t	\N	0	\N
cml7z49jo000bb6veyo49j1i5	2026-02-04 11:58:07.957	2026-02-04 11:58:07.957	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Cession entreprise	I. EXPOSÉ DES FAITS\n\nLa société {{cedant.nom}}, {{cedant.forme}}, a été constituée le {{cedant.date_constitution}}.\n\nSon capital social s'élève à {{cedant.capital}} euros, divisé en {{cedant.nombre_parts}} parts sociales de {{cedant.valeur_nominale}} euros chacune.\n\nPar acte sous seing privé en date du {{date_promesse}}, {{cedant.dirigeant}} a consenti à {{cessionnaire.nom}} une promesse de cession portant sur {{nombre_parts_cedees}} parts sociales, représentant {{pourcentage_cession}}% du capital social.	\N	{faits,cession,entreprise,"parts sociales"}	f	t	\N	0	\N
cml7z49jr000db6ve23qmqhl9	2026-02-04 11:58:07.959	2026-02-04 11:58:07.959	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Inexécution contrat	I. EXPOSÉ DES FAITS\n\nPar contrat en date du {{date_contrat}}, {{demandeur.nom}} et {{defendeur.nom}} ont conclu un accord portant sur {{objet_contrat}}.\n\nAux termes de ce contrat, {{defendeur.nom}} s'engageait à :\n{{#each obligations}}\n- {{this}}\n{{/each}}\n\nOr, force est de constater que {{defendeur.nom}} n'a pas respecté ses engagements contractuels.	\N	{faits,inexécution,contrat}	f	t	\N	0	\N
cml7z49jt000fb6vewht7g66x	2026-02-04 11:58:07.962	2026-02-04 11:58:07.962	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Litige commercial	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} exerce une activité de {{demandeur.activite}} depuis {{demandeur.date_creation}}.\n\nDans le cadre de son activité, {{demandeur.nom}} a passé commande auprès de {{defendeur.nom}} le {{date_commande}} pour un montant de {{montant_commande}} euros HT.\n\nMalgré le paiement intégral de la commande le {{date_paiement}}, {{defendeur.nom}} n'a toujours pas procédé à la livraison des marchandises commandées.	\N	{faits,litige,commercial}	f	t	\N	0	\N
cml7z49jv000hb6vecm701xa8	2026-02-04 11:58:07.964	2026-02-04 11:58:07.964	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1103 Code Civil	II. DISCUSSION EN DROIT\n\nA. Sur la force obligatoire du contrat\n\nAux termes de l'article 1103 du Code civil :\n« Les contrats légalement formés tiennent lieu de loi à ceux qui les ont faits. »\n\nEn l'espèce, le contrat conclu entre les parties est parfaitement valable et doit donc recevoir pleine et entière application.\n\n{{defendeur.nom}} ne saurait s'exonérer de ses obligations contractuelles sans engager sa responsabilité.	\N	{moyens,droit,contrat,1103}	f	t	\N	0	\N
cml7z49jx000jb6vevp0sqzbo	2026-02-04 11:58:07.966	2026-02-04 11:58:07.966	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1217 Code Civil	B. Sur les remèdes à l'inexécution\n\nL'article 1217 du Code civil dispose :\n« La partie envers laquelle l'engagement n'a pas été exécuté, ou l'a été imparfaitement, peut :\n- refuser d'exécuter ou suspendre l'exécution de sa propre obligation ;\n- poursuivre l'exécution forcée en nature de l'obligation ;\n- obtenir une réduction du prix ;\n- provoquer la résolution du contrat ;\n- demander réparation des conséquences de l'inexécution. »\n\nEn l'espèce, {{demandeur.nom}} est fondé à solliciter {{remede_choisi}}.	\N	{moyens,droit,inexécution,1217}	f	t	\N	0	\N
cml7z49jz000lb6vea2qby8gt	2026-02-04 11:58:07.968	2026-02-04 11:58:07.968	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Responsabilité contractuelle	C. Sur la responsabilité contractuelle\n\nLa responsabilité contractuelle de {{defendeur.nom}} est engagée dès lors que :\n\n1. Un contrat valable a été conclu entre les parties ;\n2. {{defendeur.nom}} n'a pas exécuté ses obligations contractuelles ;\n3. Cette inexécution a causé un préjudice à {{demandeur.nom}}.\n\nCes trois conditions sont réunies en l'espèce :\n- Le contrat du {{date_contrat}} est parfaitement valable ;\n- L'inexécution est caractérisée par {{description_inexecution}} ;\n- Le préjudice s'élève à la somme de {{montant_prejudice}} euros.	\N	{moyens,responsabilité,contractuelle}	f	t	\N	0	\N
cml7z49k1000nb6vem119olib	2026-02-04 11:58:07.969	2026-02-04 11:58:07.969	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Condamnation pécuniaire	PAR CES MOTIFS\n\nPlaise au Tribunal de :\n\n- DÉCLARER {{demandeur.nom}} recevable et bien fondé en ses demandes ;\n\n- CONDAMNER {{defendeur.nom}} à payer à {{demandeur.nom}} la somme de {{montant_principal}} euros à titre de dommages et intérêts ;\n\n- CONDAMNER {{defendeur.nom}} à payer à {{demandeur.nom}} la somme de {{montant_article_700}} euros au titre de l'article 700 du Code de procédure civile ;\n\n- CONDAMNER {{defendeur.nom}} aux entiers dépens ;	\N	{dispositif,condamnation,dommages-intérêts}	t	t	\N	0	\N
cml85wbxr0005m3wj01sxwyyw	2026-02-04 15:07:55.119	2026-02-04 15:07:55.119	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête déclaration de créance	DÉCLARATION DE CRÉANCE\n\nProcédure collective n°{{numero_procedure}}\nOuverte à l'encontre de : {{debiteur.nom}}\nJugement d'ouverture du {{date_jugement}}\n\nCRÉANCIER DÉCLARANT :\n{{creancier.nom}}\n{{creancier.adresse}}\nSIRET : {{creancier.siret}}\n\nÀ l'attention de :\nMaître {{mandataire.nom}}, {{mandataire.qualite}}\n{{mandataire.adresse}}	\N	{déclaration,créance,"procédure collective",redressement}	f	t	\N	0	\N
cml7z49k3000pb6vep28zt8bp	2026-02-04 11:58:07.972	2026-02-04 11:58:07.972	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Exécution forcée	PAR CES MOTIFS\n\nPlaise au Tribunal de :\n\n- ORDONNER l'exécution forcée du contrat conclu le {{date_contrat}} ;\n\n- CONDAMNER {{defendeur.nom}} à exécuter son obligation de {{obligation}} sous astreinte de {{montant_astreinte}} euros par jour de retard à compter de la signification du présent jugement ;\n\n- CONDAMNER {{defendeur.nom}} aux dépens ainsi qu'à payer à {{demandeur.nom}} la somme de {{montant_article_700}} euros sur le fondement de l'article 700 du CPC ;	\N	{dispositif,"exécution forcée",astreinte}	f	t	\N	0	\N
cml7z49k6000rb6vesj4lazij	2026-02-04 11:58:07.974	2026-02-04 11:58:07.974	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Résolution contrat	PAR CES MOTIFS\n\nPlaise au Tribunal de :\n\n- PRONONCER la résolution du contrat conclu le {{date_contrat}} aux torts exclusifs de {{defendeur.nom}} ;\n\n- CONDAMNER {{defendeur.nom}} à restituer à {{demandeur.nom}} la somme de {{montant_restitution}} euros versée en exécution du contrat ;\n\n- CONDAMNER {{defendeur.nom}} à payer à {{demandeur.nom}} la somme de {{montant_prejudice}} euros à titre de dommages et intérêts ;	\N	{dispositif,résolution,contrat}	f	t	\N	0	\N
cml7z49k8000tb6vez4ps44yj	2026-02-04 11:58:07.976	2026-02-04 11:58:07.976	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Formule signature avocat	Sous toutes réserves et ce ne sera que justice.\n\nFait à {{lieu}}, le {{date}}\n\nMaître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}	\N	{signature,avocat}	t	t	\N	0	\N
cml7z49ka000vb6ve9qef0mu2	2026-02-04 11:58:07.978	2026-02-04 11:58:07.978	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Bordereau de pièces	BORDEREAU DE COMMUNICATION DE PIÈCES\n\n{{#each pieces}}\nPièce n°{{@index}} : {{this.titre}}\n{{/each}}	\N	{bordereau,pièces}	f	t	\N	0	\N
cml7z49kc000xb6vezg7hxujk	2026-02-04 11:58:07.98	2026-02-04 11:58:07.98	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de non-concurrence	ARTICLE {{numero}} - NON-CONCURRENCE\n\nLe Cédant s'engage à ne pas exercer, directement ou indirectement, une activité concurrente de celle de la Société pendant une durée de {{duree}} ans à compter de la Date de Réalisation, sur le territoire de {{territoire}}.\n\nEn cas de violation de cette obligation, le Cédant sera redevable envers le Cessionnaire d'une indemnité forfaitaire de {{montant_penalite}} euros, sans préjudice du droit du Cessionnaire de demander l'indemnisation de son préjudice réel.	\N	{clause,non-concurrence,cession}	f	t	\N	0	\N
cml7z49ke000zb6ve9lefic9i	2026-02-04 11:58:07.982	2026-02-04 11:58:07.982	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de garantie d'actif et passif	ARTICLE {{numero}} - GARANTIE D'ACTIF ET DE PASSIF\n\n{{numero}}.1 - Le Cédant garantit le Cessionnaire contre toute diminution d'actif ou augmentation de passif de la Société qui résulterait :\n- d'événements, faits ou circonstances antérieurs à la Date de Réalisation ;\n- de la non-conformité des déclarations figurant à l'Annexe {{annexe_declarations}}.\n\n{{numero}}.2 - Cette garantie est consentie pour une durée de {{duree_garantie}} mois à compter de la Date de Réalisation.\n\n{{numero}}.3 - La garantie ne pourra être mise en œuvre que si le montant unitaire d'une Réclamation excède {{seuil_declenchement}} euros et si le montant cumulé des Réclamations excède {{franchise}} euros.	\N	{clause,GAP,garantie,cession}	f	t	\N	0	\N
cml7z49kg0011b6verddbio78	2026-02-04 11:58:07.985	2026-02-04 11:58:07.985	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'earn-out	ARTICLE {{numero}} - COMPLÉMENT DE PRIX (EARN-OUT)\n\n{{numero}}.1 - En sus du Prix de Cession, le Cessionnaire versera au Cédant un complément de prix calculé comme suit :\n\n- Si l'EBITDA de l'exercice {{exercice_reference}} est supérieur à {{seuil_ebitda}} euros, le Cessionnaire versera au Cédant {{pourcentage_earnout}}% de l'excédent.\n\n{{numero}}.2 - Le complément de prix sera plafonné à {{plafond_earnout}} euros.\n\n{{numero}}.3 - Le paiement interviendra dans les {{delai_paiement}} jours suivant l'approbation des comptes de l'exercice {{exercice_reference}}.	\N	{clause,earn-out,"complément prix",cession}	f	t	\N	0	\N
cml7z49ki0013b6veiobgn2vk	2026-02-04 11:58:07.987	2026-02-04 11:58:07.987	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de confidentialité	ARTICLE {{numero}} - CONFIDENTIALITÉ\n\nLes Parties s'engagent à considérer comme strictement confidentielles et à ne pas divulguer les informations échangées dans le cadre de la présente opération.\n\nCette obligation de confidentialité restera en vigueur pendant une durée de {{duree}} ans à compter de la signature des présentes.\n\nLa violation de cette obligation pourra donner lieu à l'allocation de dommages et intérêts.	\N	{clause,confidentialité}	f	t	\N	0	\N
cml7z49kk0015b6ve43fsawdl	2026-02-04 11:58:07.989	2026-02-04 11:58:07.989	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de sortie conjointe (tag-along)	ARTICLE {{numero}} - DROIT DE SORTIE CONJOINTE (TAG-ALONG)\n\nEn cas de projet de cession par un Associé Majoritaire de tout ou partie de ses parts sociales à un tiers, les Associés Minoritaires bénéficieront d'un droit de sortie conjointe leur permettant de céder leurs parts au même prix et aux mêmes conditions.\n\nL'Associé Majoritaire devra notifier son projet de cession aux Associés Minoritaires par lettre recommandée avec accusé de réception {{delai_notification}} jours avant la date envisagée de cession.	\N	{clause,tag-along,"sortie conjointe","pacte associés"}	f	t	\N	0	\N
cml7z49km0017b6vepg1sr0ia	2026-02-04 11:58:07.99	2026-02-04 11:58:07.99	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'entraînement (drag-along)	ARTICLE {{numero}} - OBLIGATION DE SORTIE CONJOINTE (DRAG-ALONG)\n\nEn cas de projet de cession par les Associés Majoritaires représentant au moins {{seuil_majoritaires}}% du capital social à un tiers acquéreur offrant d'acquérir 100% du capital, les Associés Minoritaires seront tenus de céder leurs parts au même prix et aux mêmes conditions.\n\nLe droit d'entraînement ne pourra être exercé que si le prix de cession est au moins égal à {{prix_minimum}} euros par part sociale.	\N	{clause,drag-along,entraînement,"pacte associés"}	f	t	\N	0	\N
cml82hb9y0001hqsdzc8ou44s	2026-02-04 13:32:15.573	2026-02-04 13:32:15.573	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête lettre simple	{{cabinet.nom}}\n{{cabinet.adresse}}\n{{cabinet.cp}} {{cabinet.ville}}\nTél : {{cabinet.telephone}}\nEmail : {{cabinet.email}}\n\n{{lieu}}, le {{date}}\n\n{{destinataire.civilite}} {{destinataire.nom}}\n{{destinataire.adresse}}\n{{destinataire.cp}} {{destinataire.ville}}\n\nObjet : {{objet_lettre}}\nRéf. dossier : {{reference_dossier}}\n\n{{destinataire.civilite}},	\N	{lettre,courrier,simple,en-tête}	f	t	\N	0	\N
cml82hbaa0003hqsdwuxv29te	2026-02-04 13:32:15.587	2026-02-04 13:32:15.587	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête requête	REQUÊTE\n\nPrésentée à {{juridiction}}\n\nPAR :\n{{requerant.nom}}, {{requerant.qualite}}\nDemeurant : {{requerant.adresse}}\n\nAyant pour avocat : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\nToque n°{{avocat.toque}}\n\nTendant à voir ordonner {{objet_requete}}	\N	{requête,en-tête,ordonnance}	f	t	\N	0	\N
cml88g72z000m521vpjyagym7	2026-02-04 16:19:21.18	2026-02-04 16:19:21.18	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Rétractation	CONCLUSIONS AUX FINS DE RÉTRACTATION\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nDemande la rétractation de l'ordonnance rendue le {{date_ordonnance}} par le Président du Tribunal Judiciaire.	{}	{retractation,intro}	f	t	11	0	\N
cml82hbad0005hqsdm9m7x2qy	2026-02-04 13:32:15.59	2026-02-04 13:32:15.59	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête assignation en référé	ASSIGNATION EN RÉFÉRÉ\n\nDevant {{juridiction}}, statuant en référé\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}, {{demandeur.qualite}}, demeurant {{demandeur.adresse}},\n\nAyant pour avocat constitué : Maître {{avocat.nom}}, avocat au barreau de {{avocat.barreau}}, Toque n°{{avocat.toque}},\n\nJ'ai, {{huissier.nom}}, Huissier de Justice associé près le Tribunal Judiciaire de {{huissier.ressort}},\n\nDONNÉ ASSIGNATION À :\n\n{{defendeur.nom}}, demeurant {{defendeur.adresse}},\n\nD'avoir à comparaître le {{date_audience}} à {{heure_audience}}\nDevant {{juridiction}}, statuant en référé,\nSis {{adresse_juridiction}}	\N	{assignation,référé,urgence,en-tête}	f	t	\N	0	\N
cml82hbag0007hqsdfp1cgad6	2026-02-04 13:32:15.592	2026-02-04 13:32:15.592	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête sommation interpellative	SOMMATION INTERPELLATIVE\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{requerant.nom}}, {{requerant.qualite}}, demeurant {{requerant.adresse}},\n\nJ'ai, {{huissier.nom}}, Huissier de Justice,\n\nSOMMÉ {{somme.nom}}, demeurant {{somme.adresse}},\n\nDE RÉPONDRE AUX QUESTIONS SUIVANTES :\n\n{{#each questions}}\n{{@index}}. {{this}}\n{{/each}}\n\nEt lui ai déclaré que ses réponses seront consignées dans le présent acte et pourront être utilisées en justice.	\N	{sommation,interpellative,huissier,preuve}	f	t	\N	0	\N
cml82hbai0009hqsd511u2gf2	2026-02-04 13:32:15.594	2026-02-04 13:32:15.594	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête protocole d'accord	PROTOCOLE D'ACCORD TRANSACTIONNEL\n\nENTRE LES SOUSSIGNÉS :\n\n{{partie1.nom}}, {{partie1.forme_juridique}}, au capital de {{partie1.capital}} euros,\nimmatriculée au RCS de {{partie1.rcs}} sous le numéro {{partie1.siret}},\ndont le siège social est situé {{partie1.siege}},\nreprésentée par {{partie1.representant}}, en sa qualité de {{partie1.qualite_representant}},\n\nCi-après dénommée « {{partie1.denomination}} »,\n\nD'UNE PART,\n\nET :\n\n{{partie2.nom}}, {{partie2.forme_juridique}}, au capital de {{partie2.capital}} euros,\nimmatriculée au RCS de {{partie2.rcs}} sous le numéro {{partie2.siret}},\ndont le siège social est situé {{partie2.siege}},\nreprésentée par {{partie2.representant}}, en sa qualité de {{partie2.qualite_representant}},\n\nCi-après dénommée « {{partie2.denomination}} »,\n\nD'AUTRE PART,\n\nEnsemble désignées « les Parties »,\n\nIL A ÉTÉ PRÉALABLEMENT EXPOSÉ CE QUI SUIT :	\N	{protocole,accord,transaction,en-tête}	f	t	\N	0	\N
cml82hbak000bhqsd3pqyllng	2026-02-04 13:32:15.597	2026-02-04 13:32:15.597	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Rupture contrat de travail	I. EXPOSÉ DES FAITS\n\n{{salarie.nom}} a été embauché par la société {{employeur.nom}} le {{date_embauche}} en qualité de {{poste}} selon contrat de travail à durée {{type_contrat}}.\n\nSa rémunération mensuelle brute s'élevait à {{salaire_brut}} euros.\n\nLe {{date_rupture}}, {{employeur.nom}} a procédé à {{type_rupture}} du contrat de travail de {{salarie.nom}} dans les circonstances suivantes :\n\n{{circonstances_rupture}}\n\nCette rupture est intervenue sans que {{motifs_contestation}}.	\N	{faits,travail,rupture,licenciement,"contrat travail"}	f	t	\N	0	\N
cml82hbam000dhqsdq2kziiy7	2026-02-04 13:32:15.599	2026-02-04 13:32:15.599	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Vice caché	I. EXPOSÉ DES FAITS\n\nPar acte {{type_acte}} en date du {{date_vente}}, {{vendeur.nom}} a vendu à {{acheteur.nom}} {{bien_vendu}} moyennant le prix de {{prix_vente}} euros.\n\nPostérieurement à la vente, {{acheteur.nom}} a découvert l'existence des vices suivants :\n\n{{#each vices}}\n- {{this.description}} (constaté le {{this.date_decouverte}})\n{{/each}}\n\nCes vices, antérieurs à la vente et cachés lors de celle-ci, rendent le bien impropre à l'usage auquel il était destiné, à savoir {{usage_prevu}}.\n\nUne expertise {{type_expertise}} réalisée par {{expert.nom}} le {{date_expertise}} a confirmé l'existence et la gravité de ces vices.	\N	{faits,"vice caché",vente,garantie}	f	t	\N	0	\N
cml82hbao000fhqsd8dikwudd	2026-02-04 13:32:15.601	2026-02-04 13:32:15.601	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Concurrence déloyale	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} exerce une activité de {{activite}} depuis {{date_creation}} et jouit d'une notoriété établie dans ce secteur.\n\n{{defendeur.nom}}, ancien {{relation_anterieure}} de {{demandeur.nom}} jusqu'au {{date_fin_relation}}, a créé la société {{societe_concurrente.nom}} le {{date_creation_concurrent}}.\n\nDepuis lors, {{defendeur.nom}} se livre à des actes de concurrence déloyale caractérisés par :\n\n{{#each actes_deloyaux}}\n- {{this.description}}\n{{/each}}\n\nCes agissements ont causé à {{demandeur.nom}} un préjudice commercial considérable, se traduisant par {{description_prejudice}}.	\N	{faits,"concurrence déloyale",commercial,préjudice}	f	t	\N	0	\N
cml82hbar000hhqsdu663xnr8	2026-02-04 13:32:15.603	2026-02-04 13:32:15.603	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Recouvrement impayés	I. EXPOSÉ DES FAITS\n\n{{creancier.nom}} a fourni à {{debiteur.nom}} les prestations/marchandises suivantes :\n\n{{#each factures}}\n- Facture n°{{this.numero}} du {{this.date}} d'un montant de {{this.montant}} euros HT (échéance : {{this.echeance}})\n{{/each}}\n\nLe montant total des sommes dues s'élève à {{montant_total}} euros TTC.\n\nMalgré plusieurs relances amiables en date des {{dates_relances}}, {{debiteur.nom}} n'a procédé à aucun règlement.\n\nUne mise en demeure lui a été adressée par lettre recommandée avec accusé de réception le {{date_mise_en_demeure}}, restée sans effet à ce jour.	\N	{faits,impayés,recouvrement,créance,facture}	f	t	\N	0	\N
cml82hbat000jhqsdw54powdy	2026-02-04 13:32:15.605	2026-02-04 13:32:15.605	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Responsabilité civile	I. EXPOSÉ DES FAITS\n\nLe {{date_fait_dommageable}}, {{victime.nom}} a subi un dommage dans les circonstances suivantes :\n\n{{description_circonstances}}\n\nCe dommage est directement imputable à {{responsable.nom}} qui {{description_fait_generateur}}.\n\n{{victime.nom}} a subi les préjudices suivants :\n\n{{#each prejudices}}\n- {{this.nature}} : {{this.description}} (évaluation provisoire : {{this.montant}} euros)\n{{/each}}\n\nUn rapport d'expertise établi par {{expert.nom}} le {{date_expertise}} confirme l'imputabilité du dommage et évalue le préjudice définitif à {{montant_total_prejudice}} euros.	\N	{faits,responsabilité,dommage,préjudice,indemnisation}	f	t	\N	0	\N
cml82hbav000lhqsdc5gl3nv8	2026-02-04 13:32:15.607	2026-02-04 13:32:15.607	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1231-1 Code Civil (Dommages-intérêts)	II. DISCUSSION EN DROIT\n\nA. Sur les dommages-intérêts pour inexécution\n\nL'article 1231-1 du Code civil dispose :\n« Le débiteur est condamné, s'il y a lieu, au paiement de dommages et intérêts soit à raison de l'inexécution de l'obligation, soit à raison du retard dans l'exécution, s'il ne justifie pas que l'exécution a été empêchée par la force majeure. »\n\nEn l'espèce, {{defendeur.nom}} n'a pas exécuté son obligation de {{obligation_inexecutee}}.\n\nCette inexécution a causé à {{demandeur.nom}} un préjudice direct et certain s'élevant à {{montant_prejudice}} euros, correspondant à {{nature_prejudice}}.	\N	{moyens,droit,dommages-intérêts,1231-1,inexécution}	f	t	\N	0	\N
cml82hbax000nhqsd3bt19pud	2026-02-04 13:32:15.61	2026-02-04 13:32:15.61	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1240 Code Civil (Responsabilité délictuelle)	II. DISCUSSION EN DROIT\n\nA. Sur la responsabilité délictuelle\n\nL'article 1240 du Code civil dispose :\n« Tout fait quelconque de l'homme, qui cause à autrui un dommage, oblige celui par la faute duquel il est arrivé à le réparer. »\n\nTrois conditions doivent être réunies :\n1. Une faute : {{defendeur.nom}} a commis une faute en {{description_faute}} ;\n2. Un dommage : {{demandeur.nom}} a subi un préjudice de {{montant_prejudice}} euros ;\n3. Un lien de causalité : le dommage est la conséquence directe et certaine de la faute commise.\n\nLa responsabilité de {{defendeur.nom}} est donc engagée sur le fondement de l'article 1240 du Code civil.	\N	{moyens,droit,"responsabilité délictuelle",1240,faute}	f	t	\N	0	\N
cml82hbb2000phqsdj4lt2c0r	2026-02-04 13:32:15.615	2026-02-04 13:32:15.615	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1641 Code Civil (Garantie des vices cachés)	II. DISCUSSION EN DROIT\n\nA. Sur la garantie des vices cachés\n\nL'article 1641 du Code civil dispose :\n« Le vendeur est tenu de la garantie à raison des défauts cachés de la chose vendue qui la rendent impropre à l'usage auquel on la destine, ou qui diminuent tellement cet usage que l'acheteur ne l'aurait pas acquise, ou n'en aurait donné qu'un moindre prix, s'il les avait connus. »\n\nLe vice est caractérisé lorsque :\n- Il est antérieur à la vente : en l'espèce, {{preuve_anteriorite}} ;\n- Il est caché : {{demandeur.nom}} ne pouvait le déceler lors de la vente ;\n- Il est grave : le bien est impropre à {{usage_prevu}}.\n\n{{demandeur.nom}} est donc fondé à exercer l'action rédhibitoire ou estimatoire prévue à l'article 1644 du Code civil.	\N	{moyens,droit,"vice caché",1641,vente,garantie}	f	t	\N	0	\N
cml82hbb5000rhqsdizu9noiu	2026-02-04 13:32:15.618	2026-02-04 13:32:15.618	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1792 Code Civil (Responsabilité décennale)	II. DISCUSSION EN DROIT\n\nA. Sur la responsabilité décennale des constructeurs\n\nL'article 1792 du Code civil dispose :\n« Tout constructeur d'un ouvrage est responsable de plein droit, envers le maître ou l'acquéreur de l'ouvrage, des dommages, même résultant d'un vice du sol, qui compromettent la solidité de l'ouvrage ou qui, l'affectant dans l'un de ses éléments constitutifs ou l'un de ses éléments d'équipement, le rendent impropre à sa destination. »\n\nEn l'espèce :\n- La réception des travaux est intervenue le {{date_reception}} ;\n- Les désordres sont apparus le {{date_apparition_desordres}}, soit dans le délai décennal ;\n- Ces désordres {{nature_desordres}} compromettent la solidité de l'ouvrage / rendent l'ouvrage impropre à sa destination.\n\nLa responsabilité de {{constructeur.nom}} est donc engagée de plein droit.	\N	{moyens,droit,construction,1792,décennale,constructeur}	f	t	\N	0	\N
cml82hbb8000thqsd4lhrxxa1	2026-02-04 13:32:15.62	2026-02-04 13:32:15.62	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article L.442-1 Code de Commerce (Pratiques restrictives)	II. DISCUSSION EN DROIT\n\nA. Sur les pratiques restrictives de concurrence\n\nL'article L.442-1 du Code de commerce dispose :\n« I. - Engage la responsabilité de son auteur et l'oblige à réparer le préjudice causé le fait, dans le cadre de la négociation commerciale, de la conclusion ou de l'exécution d'un contrat, par toute personne exerçant des activités de production, de distribution ou de services :\n1° D'obtenir ou de tenter d'obtenir de l'autre partie un avantage ne correspondant à aucune contrepartie ou manifestement disproportionné au regard de la valeur de la contrepartie consentie ;\n2° De soumettre ou de tenter de soumettre l'autre partie à des obligations créant un déséquilibre significatif dans les droits et obligations des parties. »\n\nEn l'espèce, {{defendeur.nom}} a {{description_pratique_restrictive}}.	\N	{moyens,droit,commerce,L442-1,"pratiques restrictives",déséquilibre}	f	t	\N	0	\N
cml82hbba000vhqsd7qh9gqta	2026-02-04 13:32:15.622	2026-02-04 13:32:15.622	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article L.1235-1 Code du Travail (Licenciement sans cause)	II. DISCUSSION EN DROIT\n\nA. Sur le licenciement sans cause réelle et sérieuse\n\nL'article L.1235-1 du Code du travail dispose :\n« En cas de litige, le juge, à qui il appartient d'apprécier la régularité de la procédure suivie et le caractère réel et sérieux des motifs invoqués par l'employeur, forme sa conviction au vu des éléments fournis par les parties après avoir ordonné, au besoin, toutes les mesures d'instruction qu'il estime utiles. »\n\nLe licenciement de {{salarie.nom}} est dépourvu de cause réelle et sérieuse car :\n\n{{#each motifs_contestation}}\n- {{this}}\n{{/each}}\n\n{{salarie.nom}} est donc fondé à solliciter les indemnités prévues à l'article L.1235-3 du Code du travail.	\N	{moyens,droit,travail,L1235-1,licenciement,"cause réelle sérieuse"}	f	t	\N	0	\N
cml82hbbc000xhqsdc203njz0	2026-02-04 13:32:15.624	2026-02-04 13:32:15.624	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Jurisprudence concurrence déloyale	B. Sur la concurrence déloyale - Jurisprudence constante\n\nIl est de jurisprudence constante que constitue un acte de concurrence déloyale le fait de :\n\n- Détourner la clientèle d'un concurrent par des moyens déloyaux (Com., 12 février 2020, n°18-17.731) ;\n- Débaucher massivement les salariés d'un concurrent (Com., 24 janvier 2018, n°16-22.325) ;\n- Créer une confusion dans l'esprit de la clientèle (Com., 10 septembre 2013, n°12-19.588) ;\n- Dénigrer les produits ou services d'un concurrent (Com., 24 septembre 2013, n°12-19.790).\n\nEn l'espèce, {{defendeur.nom}} s'est rendu coupable de {{actes_concurrence_deloyale}}.\n\nLa jurisprudence admet que le préjudice résultant d'actes de concurrence déloyale peut être évalué en fonction du trouble commercial subi (Com., 12 février 2020, n°18-17.731).	\N	{moyens,jurisprudence,"concurrence déloyale",cassation}	f	t	\N	0	\N
cml82hbbe000zhqsd72co8vev	2026-02-04 13:32:15.626	2026-02-04 13:32:15.626	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Jurisprudence responsabilité contractuelle	B. Sur la responsabilité contractuelle - Rappel jurisprudentiel\n\nLa Cour de cassation rappelle de manière constante que :\n\n« Le créancier d'une obligation contractuelle inexécutée a le choix de poursuivre l'exécution forcée de l'obligation ou la résolution du contrat avec dommages et intérêts » (Civ. 1ère, 2 avril 2014, n°13-14.287).\n\n« L'inexécution d'une obligation contractuelle est en elle-même constitutive d'une faute, sans qu'il soit nécessaire de caractériser un comportement fautif distinct » (Civ. 3ème, 6 juillet 2017, n°16-17.151).\n\n« Le préjudice né de l'inexécution d'un contrat consiste dans la perte éprouvée et le gain manqué » (Com., 14 juin 2016, n°15-12.576).\n\nEn l'espèce, l'inexécution contractuelle de {{defendeur.nom}} justifie {{remede_sollicite}}.	\N	{moyens,jurisprudence,"responsabilité contractuelle",cassation,inexécution}	f	t	\N	0	\N
cml85wbxt0007m3wj5vqqkalb	2026-02-04 15:07:55.122	2026-02-04 15:07:55.122	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête saisine conseil prud'hommes	SAISINE DU CONSEIL DE PRUD'HOMMES DE {{juridiction}}\n\nDEMANDEUR :\n{{salarie.civilite}} {{salarie.nom}} {{salarie.prenom}}\nDemeurant : {{salarie.adresse}}\nN° Sécurité Sociale : {{salarie.nss}}\n\nDÉFENDEUR :\n{{employeur.nom}}\nSIRET : {{employeur.siret}}\nSiège social : {{employeur.adresse}}\nReprésenté par : {{employeur.representant}}	\N	{prud'hommes,travail,saisine,en-tête}	f	t	\N	0	\N
cml82hbbg0011hqsd1x2ts9fx	2026-02-04 13:32:15.628	2026-02-04 13:32:15.628	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 700 CPC et dépens	C. Sur l'article 700 du Code de procédure civile et les dépens\n\nL'article 700 du Code de procédure civile dispose :\n« Le juge condamne la partie tenue aux dépens ou qui perd son procès à payer à l'autre partie la somme qu'il détermine, au titre des frais exposés et non compris dans les dépens. »\n\nIl serait particulièrement inéquitable de laisser à la charge de {{demandeur.nom}} les frais irrépétibles engagés pour la défense de ses droits.\n\nEn conséquence, {{defendeur.nom}} devra être condamné à verser à {{demandeur.nom}} la somme de {{montant_article_700}} euros au titre de l'article 700 du CPC.\n\n{{defendeur.nom}} supportera en outre les entiers dépens de l'instance, en application de l'article 696 du Code de procédure civile.	\N	{moyens,droit,"article 700",dépens,frais}	f	t	\N	0	\N
cml82hbbj0013hqsd97vmunzc	2026-02-04 13:32:15.631	2026-02-04 13:32:15.631	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Exécution provisoire	D. Sur l'exécution provisoire\n\nConformément aux articles 514 et suivants du Code de procédure civile, l'exécution provisoire est de droit pour les décisions de première instance.\n\nEn tout état de cause, la situation justifie que l'exécution provisoire soit ordonnée :\n\n- L'ancienneté de la créance ({{anciennete_creance}}) ;\n- L'urgence de la situation ({{description_urgence}}) ;\n- L'absence de risque de conséquences manifestement excessives.\n\nIl est en effet de jurisprudence constante que « l'exécution provisoire peut être ordonnée lorsque le juge l'estime nécessaire et compatible avec la nature de l'affaire » (Civ. 2ème, 10 mars 2016, n°15-12.876).\n\nEn conséquence, il est demandé au Tribunal d'ordonner l'exécution provisoire du jugement à intervenir.	\N	{moyens,"exécution provisoire",procédure,urgence}	f	t	\N	0	\N
cml82hbbl0015hqsduxi7pcsj	2026-02-04 13:32:15.633	2026-02-04 13:32:15.633	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause pénale	ARTICLE {{numero}} - CLAUSE PÉNALE\n\n{{numero}}.1 - En cas de manquement par l'une des Parties à l'une quelconque de ses obligations au titre du présent contrat, la Partie défaillante sera redevable de plein droit, après mise en demeure restée infructueuse pendant un délai de {{delai_mise_en_demeure}} jours, d'une indemnité forfaitaire de {{montant_penalite}} euros, sans préjudice de tous dommages et intérêts complémentaires.\n\n{{numero}}.2 - Cette clause pénale est stipulée à titre de dommages et intérêts forfaitaires et définitifs, les Parties renonçant expressément à solliciter du juge la révision de son montant en application de l'article 1231-5 du Code civil.\n\n{{numero}}.3 - Le paiement de cette indemnité n'aura pas pour effet de libérer la Partie défaillante de son obligation d'exécuter le contrat.	\N	{clause,pénale,sanction,"indemnité forfaitaire"}	f	t	\N	0	\N
cml82hbbn0017hqsd4tnmrxd1	2026-02-04 13:32:15.635	2026-02-04 13:32:15.635	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause résolutoire	ARTICLE {{numero}} - CLAUSE RÉSOLUTOIRE\n\n{{numero}}.1 - En cas de manquement grave par l'une des Parties à ses obligations essentielles au titre du présent contrat, et notamment :\n{{#each obligations_essentielles}}\n- {{this}}\n{{/each}}\n\nle contrat sera résolu de plein droit {{delai_resolution}} jours après l'envoi d'une mise en demeure par lettre recommandée avec accusé de réception restée sans effet, sans qu'il soit besoin d'aucune formalité judiciaire.\n\n{{numero}}.2 - La résolution sera acquise sans préjudice de tous dommages et intérêts que pourrait réclamer la Partie non défaillante.\n\n{{numero}}.3 - La présente clause résolutoire ne fait pas obstacle à la faculté pour la Partie non défaillante de solliciter l'exécution forcée du contrat plutôt que sa résolution.	\N	{clause,résolutoire,résolution,contrat}	f	t	\N	0	\N
cml82hbbp0019hqsdbdawi33h	2026-02-04 13:32:15.638	2026-02-04 13:32:15.638	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de réserve de propriété	ARTICLE {{numero}} - RÉSERVE DE PROPRIÉTÉ\n\n{{numero}}.1 - Le transfert de propriété des {{biens_vises}} est suspendu jusqu'au paiement intégral du prix, en principal et accessoires. Le défaut de paiement pourra entraîner la revendication des biens.\n\n{{numero}}.2 - Toutefois, les risques de perte et de détérioration des biens seront transférés à l'Acheteur dès la livraison.\n\n{{numero}}.3 - L'Acheteur s'engage à :\n- Conserver les biens sous réserve de propriété dans des conditions propres à en assurer l'identification ;\n- Les assurer contre tous risques, la police devant mentionner l'existence de la clause de réserve de propriété ;\n- Informer immédiatement le Vendeur de toute saisie pratiquée par un tiers.\n\n{{numero}}.4 - En cas de revente des biens avant complet paiement du prix, l'Acheteur s'engage à mentionner la présente clause au sous-acquéreur et à informer le Vendeur de cette revente.	\N	{clause,"réserve de propriété",transfert,paiement}	f	t	\N	0	\N
cml82hbbt001bhqsd6uylvrm6	2026-02-04 13:32:15.641	2026-02-04 13:32:15.641	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause attributive de juridiction	ARTICLE {{numero}} - ATTRIBUTION DE JURIDICTION\n\n{{numero}}.1 - TOUS LES LITIGES AUXQUELS LE PRÉSENT CONTRAT POURRAIT DONNER LIEU, CONCERNANT TANT SA VALIDITÉ, SON INTERPRÉTATION, SON EXÉCUTION, SA RÉSOLUTION, LEURS CONSÉQUENCES ET LEURS SUITES, SERONT SOUMIS AU {{juridiction_competente}}.\n\n{{numero}}.2 - Cette clause attributive de juridiction s'applique même en cas de pluralité de défendeurs, d'appel en garantie ou de référé.\n\n{{numero}}.3 - Les Parties déclarent avoir la qualité de commerçants et reconnaissent que le présent contrat a été conclu pour les besoins de leur activité professionnelle.	\N	{clause,attributive,juridiction,compétence,tribunal}	f	t	\N	0	\N
cml82hbbv001dhqsdxk1j9t6t	2026-02-04 13:32:15.644	2026-02-04 13:32:15.644	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause compromissoire	ARTICLE {{numero}} - CLAUSE COMPROMISSOIRE\n\n{{numero}}.1 - Tous différends découlant du présent contrat ou en relation avec celui-ci seront tranchés définitivement suivant le Règlement d'arbitrage de {{institution_arbitrage}}, par {{nombre_arbitres}} arbitre(s) nommé(s) conformément à ce Règlement.\n\n{{numero}}.2 - Le siège de l'arbitrage sera {{siege_arbitrage}}.\n\n{{numero}}.3 - La langue de l'arbitrage sera {{langue_arbitrage}}.\n\n{{numero}}.4 - Le droit applicable au fond du litige sera {{droit_applicable}}.\n\n{{numero}}.5 - La sentence arbitrale sera définitive et s'imposera aux Parties, qui s'engagent à l'exécuter de bonne foi. Les Parties renoncent expressément à tout recours en annulation, sauf pour les motifs prévus par les articles 1520 et suivants du Code de procédure civile.	\N	{clause,compromissoire,arbitrage,litige}	f	t	\N	0	\N
cml85wbxw0009m3wjin7n6sih	2026-02-04 15:07:55.125	2026-02-04 15:07:55.125	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête acte de signification	ACTE DE SIGNIFICATION\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de {{requerant.nom}}, {{requerant.qualite}},\nDemeurant {{requerant.adresse}},\n\nJ'ai, {{huissier.nom}}, Commissaire de Justice,\ndemeurant {{huissier.adresse}},\n\nSIGNIFIÉ À :\n\n{{destinataire.nom}}\n{{destinataire.adresse}}\n\nLe document suivant :	\N	{signification,huissier,"commissaire justice"}	f	t	\N	0	\N
cml82hbby001fhqsd3ov9sylk	2026-02-04 13:32:15.646	2026-02-04 13:32:15.646	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de médiation préalable	ARTICLE {{numero}} - MÉDIATION PRÉALABLE OBLIGATOIRE\n\n{{numero}}.1 - Préalablement à toute action judiciaire ou arbitrale, les Parties s'engagent à soumettre tout différend relatif à la validité, l'interprétation ou l'exécution du présent contrat à une procédure de médiation.\n\n{{numero}}.2 - La médiation sera conduite selon le règlement de {{organisme_mediation}}, par un médiateur choisi d'un commun accord ou, à défaut, désigné par cet organisme.\n\n{{numero}}.3 - La médiation se déroulera à {{lieu_mediation}} en langue {{langue_mediation}}.\n\n{{numero}}.4 - Les Parties s'engagent à participer de bonne foi à la médiation pendant une durée minimale de {{duree_mediation}} avant de pouvoir saisir toute juridiction.\n\n{{numero}}.5 - Les frais de médiation seront partagés par moitié entre les Parties, sauf accord contraire. Les communications intervenues lors de la médiation resteront confidentielles.	\N	{clause,médiation,préalable,amiable,MARD}	f	t	\N	0	\N
cml82hbc0001hhqsd8q6mo10d	2026-02-04 13:32:15.648	2026-02-04 13:32:15.648	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de hardship (Imprévision)	ARTICLE {{numero}} - CLAUSE DE HARDSHIP (IMPRÉVISION)\n\n{{numero}}.1 - Si, postérieurement à la conclusion du présent contrat, survient un changement de circonstances imprévisible lors de la conclusion du contrat et rendant l'exécution excessivement onéreuse pour une Partie, celle-ci peut demander une renégociation du contrat à l'autre Partie.\n\n{{numero}}.2 - Les circonstances visées incluent notamment :\n- Les modifications substantielles des conditions économiques ;\n- Les évolutions législatives ou réglementaires ;\n- Les événements affectant significativement l'équilibre contractuel.\n\n{{numero}}.3 - La Partie invoquant la clause doit notifier à l'autre Partie, par lettre recommandée avec accusé de réception :\n- La nature du changement de circonstances ;\n- Son impact sur l'équilibre du contrat ;\n- Les modifications qu'elle propose.\n\n{{numero}}.4 - Les Parties s'engagent à négocier de bonne foi pendant {{duree_negociation}} jours. À défaut d'accord, les Parties pourront saisir {{instance_competente}} aux fins de révision ou de résiliation du contrat.	\N	{clause,hardship,imprévision,renégociation,1195}	f	t	\N	0	\N
cml82hbc2001jhqsdijhfqtm9	2026-02-04 13:32:15.65	2026-02-04 13:32:15.65	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause MAC (Material Adverse Change)	ARTICLE {{numero}} - CLAUSE MAC (CHANGEMENT DÉFAVORABLE SIGNIFICATIF)\n\n{{numero}}.1 - Un « Changement Défavorable Significatif » (« MAC ») désigne tout événement, circonstance ou changement qui, individuellement ou conjointement avec d'autres, a ou est raisonnablement susceptible d'avoir un effet défavorable significatif sur :\n- L'activité, les actifs, la situation financière ou les résultats de la Société ;\n- La capacité du Vendeur à exécuter ses obligations au titre du présent contrat.\n\n{{numero}}.2 - Ne constituent pas un MAC :\n- Les changements affectant l'économie ou les marchés financiers en général ;\n- Les changements affectant le secteur d'activité de la Société dans son ensemble ;\n- Les changements résultant de l'annonce ou de la réalisation de l'Opération.\n\n{{numero}}.3 - En cas de survenance d'un MAC entre la date de signature et la Date de Réalisation, le Cessionnaire pourra :\n- Soit renoncer à l'Opération sans indemnité ;\n- Soit demander une réduction du Prix de Cession proportionnelle à l'impact du MAC.	\N	{clause,MAC,"changement défavorable",cession,M&A}	f	t	\N	0	\N
cml82hbc4001lhqsdl1jfn633	2026-02-04 13:32:15.652	2026-02-04 13:32:15.652	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de représentations et garanties	ARTICLE {{numero}} - REPRÉSENTATIONS ET GARANTIES DU CÉDANT\n\n{{numero}}.1 - Le Cédant déclare et garantit au Cessionnaire que les déclarations suivantes sont exactes et complètes à la date des présentes et le resteront à la Date de Réalisation :\n\na) Capacité et pouvoirs : Le Cédant a la pleine capacité et tous les pouvoirs nécessaires pour conclure et exécuter le présent contrat.\n\nb) Propriété des titres : Le Cédant est propriétaire des Parts cédées, libres de tout nantissement, gage ou sûreté.\n\nc) Comptes sociaux : Les comptes annuels de la Société pour l'exercice clos le {{date_cloture}} donnent une image fidèle du patrimoine, de la situation financière et des résultats de la Société.\n\nd) Litiges : Il n'existe aucun litige, procédure ou enquête en cours ou, à la connaissance du Cédant, menaçant, susceptible d'avoir un effet défavorable significatif sur la Société.\n\ne) Conformité : La Société exerce ses activités en conformité avec toutes les lois et réglementations applicables.	\N	{clause,représentations,garanties,déclarations,cession,M&A}	f	t	\N	0	\N
cml82hbc6001nhqsd875u0g7u	2026-02-04 13:32:15.655	2026-02-04 13:32:15.655	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'ajustement de prix	ARTICLE {{numero}} - AJUSTEMENT DU PRIX DE CESSION\n\n{{numero}}.1 - Le Prix de Cession sera ajusté à la hausse ou à la baisse en fonction de la variation de la Situation Nette Comptable de la Société entre la Date de Référence ({{date_reference}}) et la Date de Réalisation.\n\n{{numero}}.2 - Définitions :\n- « Situation Nette de Référence » : {{montant_snr}} euros, telle qu'elle ressort du bilan au {{date_reference}}.\n- « Situation Nette de Réalisation » : la situation nette comptable de la Société à la Date de Réalisation, déterminée selon les mêmes méthodes comptables.\n\n{{numero}}.3 - Modalités d'ajustement :\n- Si la Situation Nette de Réalisation est supérieure à la Situation Nette de Référence, le Prix de Cession sera majoré de la différence ;\n- Si la Situation Nette de Réalisation est inférieure à la Situation Nette de Référence, le Prix de Cession sera réduit de la différence.\n\n{{numero}}.4 - Les comptes de Réalisation seront établis par {{expert_comptable}} dans les {{delai_etablissement}} jours suivant la Date de Réalisation et soumis à l'approbation des Parties.	\N	{clause,"ajustement prix","locked box","completion accounts",cession,M&A}	f	t	\N	0	\N
cml85wbxc0001m3wj2igcwn0l	2026-02-04 15:07:55.104	2026-02-04 15:07:55.104	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête conclusions d'appel	CONCLUSIONS D'APPEL\n\nPOUR :\n{{appelant.nom}}, {{appelant.qualite}}\nDemeurant {{appelant.adresse}}\n\nAPPELANT\n\nAyant pour avocat : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\nToque n°{{avocat.toque}}\n\nCONTRE :\n\n{{intime.nom}}, {{intime.qualite}}\nDemeurant {{intime.adresse}}\n\nINTIMÉ	\N	{conclusions,appel,en-tête}	f	t	\N	0	\N
cml85wbxn0003m3wjej8s8518	2026-02-04 15:07:55.116	2026-02-04 15:07:55.116	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête requête JAF	REQUÊTE AUX FINS DE {{objet_requete}}\n\nÀ Monsieur/Madame le Juge aux Affaires Familiales\nprès le Tribunal Judiciaire de {{juridiction}}\n\nLe requérant :\n{{requerant.civilite}} {{requerant.nom}} {{requerant.prenom}}\nNé(e) le {{requerant.date_naissance}} à {{requerant.lieu_naissance}}\nDe nationalité {{requerant.nationalite}}\nProfession : {{requerant.profession}}\nDemeurant : {{requerant.adresse}}	\N	{requête,JAF,famille,divorce}	f	t	\N	0	\N
cml88g72w000i521viuoi7gl9	2026-02-04 16:19:21.176	2026-02-04 16:19:21.176	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Récusation	CONCLUSIONS AUX FINS DE RÉCUSATION\n\nPour : {{client.nom}}\n\nDemande la récusation de Monsieur/Madame {{juge.nom}}, juge au Tribunal Judiciaire de {{juridiction}}.	{}	{recusation,intro}	f	t	9	0	\N
cml85wbxz000bm3wje41ifut0	2026-02-04 15:07:55.127	2026-02-04 15:07:55.127	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête opposition ordonnance injonction payer	OPPOSITION À ORDONNANCE PORTANT INJONCTION DE PAYER\n\nJe soussigné(e) {{opposant.nom}},\nDemeurant {{opposant.adresse}},\n\nFais opposition à l'ordonnance portant injonction de payer rendue le {{date_ordonnance}}\npar le {{juridiction}}\nà la requête de {{creancier.nom}}\npour un montant principal de {{montant}} euros.\n\nNuméro de minute : {{numero_minute}}\nNuméro RG : {{numero_rg}}	\N	{opposition,"injonction de payer",procédure}	f	t	\N	0	\N
cml85wby3000dm3wjdgisx09c	2026-02-04 15:07:55.131	2026-02-04 15:07:55.131	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête QPC	QUESTION PRIORITAIRE DE CONSTITUTIONNALITÉ\n\nMÉMOIRE DISTINCT ET MOTIVÉ\nprésenté en application de l'article 23-1 de l'ordonnance n°58-1067 du 7 novembre 1958\n\nDevant : {{juridiction}}\n\nPar : {{partie.nom}}\nReprésenté par : Maître {{avocat.nom}}\n\nSur la constitutionnalité des dispositions de l'article {{article_conteste}} du {{code_vise}}\nau regard des droits et libertés garantis par la Constitution	\N	{QPC,constitutionnel,en-tête}	f	t	\N	0	\N
cml85wby5000fm3wj7kjjs2uj	2026-02-04 15:07:55.133	2026-02-04 15:07:55.133	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête référé expertise	ASSIGNATION EN RÉFÉRÉ-EXPERTISE\nArticle 145 du Code de procédure civile\n\nDevant le Président du {{juridiction}}, statuant en référé\n\nL'an deux mille {{annee}}, le {{date_acte}},\n\nÀ la requête de : {{demandeur.nom}}\nDemeurant {{demandeur.adresse}}\n\nAyant pour avocat : Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}	\N	{référé,expertise,"145 CPC",en-tête}	f	t	\N	0	\N
cml85wby7000hm3wjqx0vmllx	2026-02-04 15:07:55.136	2026-02-04 15:07:55.136	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête lettre de résiliation	{{expediteur.nom}}\n{{expediteur.adresse}}\n{{expediteur.cp}} {{expediteur.ville}}\n\nLettre Recommandée avec AR\n\n{{lieu}}, le {{date}}\n\n{{destinataire.nom}}\n{{destinataire.adresse}}\n{{destinataire.cp}} {{destinataire.ville}}\n\nObjet : Résiliation du contrat {{reference_contrat}}\nRéf : {{reference_dossier}}\n\nMadame, Monsieur,\n\nPar la présente, je vous notifie ma décision de résilier le contrat {{type_contrat}} conclu le {{date_contrat}} entre nos parties.	\N	{résiliation,contrat,lettre,LRAR}	f	t	\N	0	\N
cml85wby9000jm3wj9dm2300e	2026-02-04 15:07:55.138	2026-02-04 15:07:55.138	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête contrat de travail CDI	CONTRAT DE TRAVAIL À DURÉE INDÉTERMINÉE\n\nENTRE LES SOUSSIGNÉS :\n\n{{employeur.nom}}, {{employeur.forme}}\nSIRET : {{employeur.siret}}\nSiège social : {{employeur.adresse}}\nReprésentée par {{employeur.representant}}, en qualité de {{employeur.qualite}}\n\nCi-après dénommée « l'Employeur »\n\nD'une part,\n\nET :\n\n{{salarie.civilite}} {{salarie.nom}} {{salarie.prenom}}\nNé(e) le {{salarie.date_naissance}} à {{salarie.lieu_naissance}}\nDe nationalité {{salarie.nationalite}}\nN° Sécurité Sociale : {{salarie.nss}}\nDemeurant : {{salarie.adresse}}\n\nCi-après dénommé(e) « le Salarié »\n\nD'autre part,\n\nIL A ÉTÉ CONVENU CE QUI SUIT :	\N	{"contrat travail",CDI,embauche,en-tête}	f	t	\N	0	\N
cml85wbye000lm3wj8wk4bjba	2026-02-04 15:07:55.142	2026-02-04 15:07:55.142	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête bail commercial	BAIL COMMERCIAL\nArticles L.145-1 et suivants du Code de commerce\n\nENTRE LES SOUSSIGNÉS :\n\nLE BAILLEUR :\n{{bailleur.nom}}, {{bailleur.qualite}}\nDemeurant/Siège : {{bailleur.adresse}}\n{{bailleur.rcs}}\n\nLE PRENEUR :\n{{preneur.nom}}, {{preneur.forme}}\nSIRET : {{preneur.siret}}\nSiège social : {{preneur.siege}}\nReprésenté par {{preneur.representant}}\n\nIL A ÉTÉ CONVENU CE QUI SUIT :\n\nDESIGNATION DES LOCAUX :\nLe Bailleur donne à bail au Preneur qui accepte les locaux situés :\n{{adresse_locaux}}\nD'une superficie de {{superficie}} m²	\N	{bail,commercial,location,en-tête}	f	t	\N	0	\N
cml85wbyh000nm3wj8z1ppedt	2026-02-04 15:07:55.145	2026-02-04 15:07:55.145	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête statuts SAS	STATUTS\n\nSOCIÉTÉ PAR ACTIONS SIMPLIFIÉE\n\n{{societe.denomination}}\n\nSociété par Actions Simplifiée\nau capital de {{societe.capital}} euros\nSiège social : {{societe.siege}}\n\n\nTITRE I - FORME - OBJET - DÉNOMINATION - SIÈGE - DURÉE\n\nArticle 1 - Forme\nIl est formé entre les propriétaires des actions ci-après créées et de celles qui pourront l'être ultérieurement, une société par actions simplifiée régie par les articles L.227-1 et suivants du Code de commerce.	\N	{statuts,SAS,constitution,société}	f	t	\N	0	\N
cml85wbyj000pm3wj1gvz7w4h	2026-02-04 15:07:55.147	2026-02-04 15:07:55.147	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête PV AG ordinaire	PROCÈS-VERBAL DE L'ASSEMBLÉE GÉNÉRALE ORDINAIRE\ndu {{date_ag}}\n\n{{societe.denomination}}\n{{societe.forme}} au capital de {{societe.capital}} euros\nSiège social : {{societe.siege}}\n{{societe.rcs}}\n\nL'an deux mille {{annee}}, le {{date_ag}},\nà {{heure_ag}}, les associés de la société {{societe.denomination}}\nse sont réunis en Assemblée Générale Ordinaire au siège social,\nsur convocation du {{convocateur}}.\n\nÉTAIENT PRÉSENTS OU REPRÉSENTÉS :	\N	{PV,"assemblée générale",AGO,société}	f	t	\N	0	\N
cml85wbyl000rm3wjwsgf8xqw	2026-02-04 15:07:55.149	2026-02-04 15:07:55.149	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête testament olographe	CECI EST MON TESTAMENT\n\nJe soussigné(e) {{testateur.nom}} {{testateur.prenom}},\nNé(e) le {{testateur.date_naissance}} à {{testateur.lieu_naissance}},\nDemeurant {{testateur.adresse}},\nSain(e) d'esprit et de corps,\n\nRévoque tous testaments antérieurs et exprime mes dernières volontés comme suit :	\N	{testament,olographe,succession,en-tête}	f	t	\N	0	\N
cml85wbyn000tm3wj0kdmcxgs	2026-02-04 15:07:55.151	2026-02-04 15:07:55.151	cml6vykdd0000jms2wwxl9s27	INTRO	En-tête donation	ACTE DE DONATION\n\nENTRE LES SOUSSIGNÉS :\n\nLE DONATEUR :\n{{donateur.civilite}} {{donateur.nom}} {{donateur.prenom}}\nNé(e) le {{donateur.date_naissance}} à {{donateur.lieu_naissance}}\nDemeurant {{donateur.adresse}}\n\nLE DONATAIRE :\n{{donataire.civilite}} {{donataire.nom}} {{donataire.prenom}}\nNé(e) le {{donataire.date_naissance}} à {{donataire.lieu_naissance}}\nDemeurant {{donataire.adresse}}\n\nIL A ÉTÉ EXPOSÉ ET CONVENU CE QUI SUIT :	\N	{donation,libéralité,succession,en-tête}	f	t	\N	0	\N
cml85wbyp000vm3wjh354kq1h	2026-02-04 15:07:55.154	2026-02-04 15:07:55.154	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Divorce contentieux	I. EXPOSÉ DES FAITS\n\n{{epoux1.civilite}} {{epoux1.nom}} et {{epoux2.civilite}} {{epoux2.nom}} se sont mariés le {{date_mariage}} à {{lieu_mariage}}.\n\nDe cette union sont issus {{nombre_enfants}} enfant(s) :\n{{#each enfants}}\n- {{this.prenom}}, né(e) le {{this.date_naissance}}\n{{/each}}\n\nLes époux sont séparés de fait depuis le {{date_separation}}.\n\nLa vie commune est devenue impossible en raison de {{motifs_divorce}}.	\N	{faits,divorce,famille,séparation}	f	t	\N	0	\N
cml85wbyr000xm3wjgdqa549l	2026-02-04 15:07:55.155	2026-02-04 15:07:55.155	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Accident du travail	I. EXPOSÉ DES FAITS\n\nLe {{date_accident}}, {{victime.nom}}, salarié de {{employeur.nom}} en qualité de {{poste}}, a été victime d'un accident du travail.\n\nCirconstances de l'accident :\n{{description_accident}}\n\nConséquences médicales :\n- ITT initiale : {{duree_itt}} jours\n- Consolidation le {{date_consolidation}}\n- Taux d'IPP : {{taux_ipp}}%\n\nL'accident a été reconnu comme accident du travail par la CPAM le {{date_reconnaissance}}.	\N	{faits,"accident travail",AT,indemnisation}	f	t	\N	0	\N
cml85wbyt000zm3wj5c7sewwf	2026-02-04 15:07:55.157	2026-02-04 15:07:55.157	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Contrefaçon marque	I. EXPOSÉ DES FAITS\n\n{{titulaire.nom}} est titulaire de la marque « {{marque.denomination}} » enregistrée sous le n°{{marque.numero}} le {{marque.date_depot}} en classes {{marque.classes}}.\n\nOr, {{contrefacteur.nom}} commercialise depuis le {{date_debut_contrefacon}} des produits portant un signe identique/similaire à cette marque, à savoir {{description_signe_litigieux}}.\n\nCes actes de contrefaçon ont été constatés par :\n{{#each preuves}}\n- {{this.description}} ({{this.date}})\n{{/each}}	\N	{faits,contrefaçon,marque,"propriété intellectuelle"}	f	t	\N	0	\N
cml85wbyv0011m3wjhlt92yds	2026-02-04 15:07:55.16	2026-02-04 15:07:55.16	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Malfaçons construction	I. EXPOSÉ DES FAITS\n\n{{maitre_ouvrage.nom}} a confié à {{constructeur.nom}} la réalisation de {{nature_travaux}} par contrat du {{date_contrat}}.\n\nLes travaux ont été réceptionnés le {{date_reception}}, avec les réserves suivantes :\n{{#each reserves}}\n- {{this}}\n{{/each}}\n\nPostérieurement à la réception, les désordres suivants sont apparus :\n{{#each desordres}}\n- {{this.description}} (constaté le {{this.date}})\n{{/each}}\n\nUne expertise judiciaire ordonnée le {{date_ordonnance_expertise}} et réalisée par {{expert.nom}} a conclu que ces désordres engagent la responsabilité de {{constructeur.nom}}.	\N	{faits,construction,malfaçons,désordres}	f	t	\N	0	\N
cml85wbyx0013m3wj2mr55uvo	2026-02-04 15:07:55.162	2026-02-04 15:07:55.162	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Trouble de voisinage	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} est propriétaire/locataire du bien situé {{demandeur.adresse}} depuis le {{date_occupation}}.\n\n{{defendeur.nom}}, occupant le bien situé {{defendeur.adresse}}, cause depuis le {{date_debut_troubles}} des troubles anormaux de voisinage caractérisés par :\n{{#each troubles}}\n- {{this.nature}} : {{this.description}}\n{{/each}}\n\nCes nuisances excèdent les inconvénients normaux du voisinage et causent un préjudice à {{demandeur.nom}} consistant en {{description_prejudice}}.	\N	{faits,voisinage,troubles,nuisances}	f	t	\N	0	\N
cml85wbyz0015m3wjbepauh55	2026-02-04 15:07:55.163	2026-02-04 15:07:55.163	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Harcèlement moral travail	I. EXPOSÉ DES FAITS\n\n{{salarie.nom}} a été embauché(e) par {{employeur.nom}} le {{date_embauche}} en qualité de {{poste}}.\n\nDepuis le {{date_debut_harcelement}}, {{salarie.nom}} est victime d'agissements répétés de harcèlement moral de la part de {{harceleur.nom}}, {{harceleur.qualite}}, caractérisés par :\n{{#each agissements}}\n- Le {{this.date}} : {{this.description}}\n{{/each}}\n\nCes agissements ont entraîné une dégradation de la santé de {{salarie.nom}}, attestée par {{preuves_medicales}}.	\N	{faits,harcèlement,moral,travail}	f	t	\N	0	\N
cml85wbz10017m3wjhufyg3c0	2026-02-04 15:07:55.165	2026-02-04 15:07:55.165	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Rupture brutale relations commerciales	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} et {{defendeur.nom}} entretenaient des relations commerciales établies depuis {{duree_relation}} ans, portant sur {{objet_relation}}.\n\nLe chiffre d'affaires annuel réalisé avec {{defendeur.nom}} représentait en moyenne {{pourcentage_ca}}% du chiffre d'affaires de {{demandeur.nom}}.\n\nPar courrier du {{date_rupture}}, {{defendeur.nom}} a notifié à {{demandeur.nom}} la cessation de leurs relations commerciales avec un préavis de seulement {{duree_preavis_accorde}}, alors que la durée de préavis raisonnablement attendue était de {{duree_preavis_attendue}}.	\N	{faits,rupture,"relations commerciales",L442-1}	f	t	\N	0	\N
cml85wbz60019m3wjq6nfn3nr	2026-02-04 15:07:55.17	2026-02-04 15:07:55.17	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Abus de biens sociaux	I. EXPOSÉ DES FAITS\n\n{{dirigeant.nom}} a exercé les fonctions de {{dirigeant.qualite}} de la société {{societe.nom}} du {{date_debut_mandat}} au {{date_fin_mandat}}.\n\nDurant cette période, il a commis les actes suivants constitutifs d'abus de biens sociaux :\n{{#each abus}}\n- {{this.date}} : {{this.description}} pour un montant de {{this.montant}} euros\n{{/each}}\n\nCes détournements ont été découverts le {{date_decouverte}} à l'occasion de {{circonstances_decouverte}}.	\N	{faits,"abus biens sociaux",pénal,société}	f	t	\N	0	\N
cml85wbz8001bm3wj3cni580h	2026-02-04 15:07:55.172	2026-02-04 15:07:55.172	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Refus de vente	I. EXPOSÉ DES FAITS\n\n{{demandeur.nom}} exerce une activité de {{activite}} et est un client régulier de {{defendeur.nom}} depuis {{duree_relation}}.\n\nLe {{date_refus}}, {{demandeur.nom}} a passé commande auprès de {{defendeur.nom}} pour {{description_commande}}.\n\nCette commande a été refusée par {{defendeur.nom}} au motif suivant : {{motif_invoque}}.\n\nCe refus constitue une pratique discriminatoire car {{justification_discrimination}}.	\N	{faits,"refus de vente",discrimination,commercial}	f	t	\N	0	\N
cml85wbza001dm3wj1jzkt3hd	2026-02-04 15:07:55.174	2026-02-04 15:07:55.174	cml6vykdd0000jms2wwxl9s27	FAITS	Exposé des faits - Liquidation judiciaire	I. EXPOSÉ DES FAITS\n\nLa société {{societe.nom}}, {{societe.forme}} au capital de {{societe.capital}} euros, immatriculée sous le numéro {{societe.siret}}, exerçait une activité de {{societe.activite}}.\n\nPar jugement du {{date_jugement_lj}}, le Tribunal de Commerce de {{juridiction}} a prononcé la liquidation judiciaire de la société.\n\nMaître {{liquidateur.nom}} a été désigné en qualité de liquidateur judiciaire.\n\nLa date de cessation des paiements a été fixée au {{date_cessation_paiements}}.	\N	{faits,"liquidation judiciaire","procédure collective"}	f	t	\N	0	\N
cml85wbzc001fm3wj3v2pm8j2	2026-02-04 15:07:55.176	2026-02-04 15:07:55.176	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article L.1232-1 Code du Travail (Licenciement)	II. DISCUSSION EN DROIT\n\nA. Sur la cause réelle et sérieuse du licenciement\n\nL'article L.1232-1 du Code du travail dispose :\n« Tout licenciement pour motif personnel est motivé dans les conditions définies par le présent chapitre. Il est justifié par une cause réelle et sérieuse. »\n\nLa cause doit être :\n- Réelle : existante, exacte et objective ;\n- Sérieuse : d'une gravité suffisante rendant impossible la poursuite du contrat.\n\nEn l'espèce, le licenciement de {{salarie.nom}} ne repose sur aucune cause réelle et sérieuse car {{motifs_contestation}}.	\N	{moyens,droit,licenciement,L1232-1,travail}	f	t	\N	0	\N
cml85wbze001hm3wj5tsfupwu	2026-02-04 15:07:55.179	2026-02-04 15:07:55.179	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1343-2 Code Civil (Intérêts)	B. Sur les intérêts moratoires\n\nL'article 1343-2 du Code civil dispose :\n« Les intérêts échus, dus au moins pour une année entière, produisent intérêt si le contrat l'a prévu ou si une décision de justice le précise. »\n\nL'article 1231-6 prévoit que les dommages et intérêts dus à raison du retard dans le paiement d'une obligation de somme d'argent consistent dans l'intérêt au taux légal.\n\nEn conséquence, la condamnation devra être assortie des intérêts au taux légal à compter de {{date_mise_en_demeure}} pour les sommes réclamées à titre principal, et à compter du prononcé de la décision pour les sommes allouées à titre de dommages et intérêts.	\N	{moyens,droit,intérêts,1343-2,anatocisme}	f	t	\N	0	\N
cml85wbzg001jm3wjpwdulrgn	2026-02-04 15:07:55.181	2026-02-04 15:07:55.181	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1195 Code Civil (Imprévision)	C. Sur l'imprévision\n\nL'article 1195 du Code civil dispose :\n« Si un changement de circonstances imprévisible lors de la conclusion du contrat rend l'exécution excessivement onéreuse pour une partie qui n'avait pas accepté d'en assumer le risque, celle-ci peut demander une renégociation du contrat à son cocontractant. »\n\nEn l'espèce, {{description_changement_circonstances}} constitue un changement imprévisible qui :\n- N'était pas prévisible lors de la conclusion du contrat le {{date_contrat}} ;\n- Rend l'exécution excessivement onéreuse pour {{partie.nom}} ;\n- N'avait pas été assumé contractuellement par {{partie.nom}}.\n\n{{partie.nom}} est donc fondé(e) à solliciter la révision judiciaire du contrat.	\N	{moyens,droit,imprévision,1195,révision}	f	t	\N	0	\N
cml85wbzj001lm3wjnrjjzqqq	2026-02-04 15:07:55.183	2026-02-04 15:07:55.183	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Article 1104 Code Civil (Bonne foi)	D. Sur l'obligation de bonne foi\n\nL'article 1104 du Code civil dispose :\n« Les contrats doivent être négociés, formés et exécutés de bonne foi. Cette disposition est d'ordre public. »\n\nLa jurisprudence sanctionne notamment :\n- Le comportement déloyal dans l'exécution du contrat (Com., 10 juillet 2007) ;\n- L'usage abusif d'une prérogative contractuelle (Civ. 1ère, 16 février 1999) ;\n- Le refus de renégociation abusif (Com., 3 octobre 2006).\n\nEn l'espèce, {{defendeur.nom}} a manqué à son obligation de bonne foi en {{description_manquement}}.	\N	{moyens,droit,"bonne foi",1104,loyauté}	f	t	\N	0	\N
cml85wbzl001nm3wjiggn6wga	2026-02-04 15:07:55.186	2026-02-04 15:07:55.186	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Vice du consentement (Erreur)	E. Sur l'erreur\n\nL'article 1132 du Code civil dispose :\n« L'erreur de droit ou de fait, à moins qu'elle ne soit inexcusable, est une cause de nullité du contrat lorsqu'elle porte sur les qualités essentielles de la prestation due ou sur celles du cocontractant. »\n\nL'erreur commise par {{partie.nom}} porte sur {{objet_erreur}}, qui constitue une qualité essentielle car {{justification_qualite_essentielle}}.\n\nCette erreur est excusable car {{justification_excusabilite}}.\n\nEn conséquence, la nullité du contrat doit être prononcée.	\N	{moyens,droit,erreur,"vice consentement",nullité}	f	t	\N	0	\N
cml85wbzn001pm3wj24dhzbos	2026-02-04 15:07:55.188	2026-02-04 15:07:55.188	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Vice du consentement (Dol)	F. Sur le dol\n\nL'article 1137 du Code civil dispose :\n« Le dol est le fait pour un contractant d'obtenir le consentement de l'autre par des manœuvres ou des mensonges. Constitue également un dol la dissimulation intentionnelle par l'un des contractants d'une information dont il sait le caractère déterminant pour l'autre partie. »\n\n{{defendeur.nom}} a commis un dol en {{description_dol}}.\n\nCette manœuvre/réticence était déterminante du consentement de {{demandeur.nom}}, qui n'aurait pas contracté ou aurait contracté à des conditions différentes s'il avait connu {{information_dissimilee}}.\n\nLa nullité du contrat doit être prononcée avec allocation de dommages et intérêts.	\N	{moyens,droit,dol,"vice consentement",nullité}	f	t	\N	0	\N
cml85wbzp001rm3wj6gkiryb9	2026-02-04 15:07:55.19	2026-02-04 15:07:55.19	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Prescription biennale travail	G. Sur la prescription\n\nL'article L.1471-1 du Code du travail dispose :\n« Toute action portant sur l'exécution du contrat de travail se prescrit par deux ans à compter du jour où celui qui l'exerce a connu ou aurait dû connaître les faits lui permettant d'exercer son droit. »\n\nEn l'espèce, l'action de {{partie.nom}} est recevable car :\n- Le point de départ de la prescription est le {{date_connaissance_faits}} ;\n- La saisine du Conseil de Prud'hommes est intervenue le {{date_saisine}} ;\n- L'action a donc été introduite dans le délai de deux ans.	\N	{moyens,droit,prescription,travail,L1471-1}	f	t	\N	0	\N
cml85wbzs001tm3wj1kfe29ua	2026-02-04 15:07:55.192	2026-02-04 15:07:55.192	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Prescription quinquennale	H. Sur la prescription quinquennale\n\nL'article 2224 du Code civil dispose :\n« Les actions personnelles ou mobilières se prescrivent par cinq ans à compter du jour où le titulaire d'un droit a connu ou aurait dû connaître les faits lui permettant de l'exercer. »\n\nLe point de départ du délai de prescription est fixé au {{date_point_depart}} car c'est à cette date que {{demandeur.nom}} a eu connaissance de {{faits_permettant_agir}}.\n\nL'action ayant été introduite le {{date_action}}, elle est recevable.	\N	{moyens,droit,prescription,2224,quinquennale}	f	t	\N	0	\N
cml85wbzu001vm3wj1krfc2tx	2026-02-04 15:07:55.194	2026-02-04 15:07:55.194	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Préjudice économique	I. Sur le préjudice économique\n\nLe préjudice économique subi par {{demandeur.nom}} comprend :\n\n1. La perte éprouvée :\n{{#each pertes}}\n- {{this.description}} : {{this.montant}} euros\n{{/each}}\nSous-total pertes : {{total_pertes}} euros\n\n2. Le gain manqué :\n{{#each gains_manques}}\n- {{this.description}} : {{this.montant}} euros\n{{/each}}\nSous-total gains manqués : {{total_gains_manques}} euros\n\nTOTAL PRÉJUDICE ÉCONOMIQUE : {{total_prejudice}} euros	\N	{moyens,préjudice,économique,dommages-intérêts}	f	t	\N	0	\N
cml85wbzy001xm3wjrwc0dxif	2026-02-04 15:07:55.199	2026-02-04 15:07:55.199	cml6vykdd0000jms2wwxl9s27	MOYENS	Moyen - Préjudice moral	J. Sur le préjudice moral\n\n{{demandeur.nom}} a subi un préjudice moral résultant de {{source_prejudice}}.\n\nCe préjudice se manifeste par :\n{{#each manifestations}}\n- {{this}}\n{{/each}}\n\nIl est attesté par {{preuves_prejudice_moral}}.\n\nEu égard à la gravité des faits et à leurs conséquences sur {{demandeur.nom}}, le préjudice moral sera justement réparé par l'allocation d'une somme de {{montant_moral}} euros à titre de dommages et intérêts.	\N	{moyens,préjudice,moral,dommages-intérêts}	f	t	\N	0	\N
cml85wc01001zm3wj6bkvbnsp	2026-02-04 15:07:55.201	2026-02-04 15:07:55.201	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Référé expertise	PAR CES MOTIFS\n\nPlaise au Président statuant en référé :\n\n- ORDONNER une mesure d'expertise judiciaire ;\n\n- DESIGNER tel expert qu'il plaira au Président de nommer avec pour mission de :\n  * Se rendre sur les lieux situés {{adresse_lieux}} ;\n  * Décrire les désordres constatés ;\n  * Rechercher les causes des désordres ;\n  * Déterminer les responsabilités ;\n  * Évaluer les travaux de reprise ;\n  * Chiffrer les préjudices ;\n\n- FIXER la consignation à la somme de {{montant_consignation}} euros ;\n\n- RÉSERVER les dépens.	\N	{dispositif,référé,expertise,"145 CPC"}	f	t	\N	0	\N
cml85wc030021m3wjwpzxxfhg	2026-02-04 15:07:55.203	2026-02-04 15:07:55.203	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Référé provision	PAR CES MOTIFS\n\nPlaise au Président statuant en référé :\n\n- CONSTATER que l'obligation de {{defendeur.nom}} n'est pas sérieusement contestable ;\n\n- CONDAMNER {{defendeur.nom}} à verser à {{demandeur.nom}} une provision de {{montant_provision}} euros à valoir sur l'indemnisation de son préjudice ;\n\n- ORDONNER l'exécution provisoire de droit ;\n\n- CONDAMNER {{defendeur.nom}} aux dépens ainsi qu'à verser à {{demandeur.nom}} la somme de {{montant_article_700}} euros sur le fondement de l'article 700 du CPC.	\N	{dispositif,référé,provision,"835 CPC"}	f	t	\N	0	\N
cml85wc050023m3wj18u5glks	2026-02-04 15:07:55.205	2026-02-04 15:07:55.205	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Nullité contrat	PAR CES MOTIFS\n\nPlaise au Tribunal :\n\n- PRONONCER la nullité du contrat conclu le {{date_contrat}} entre {{partie1.nom}} et {{partie2.nom}} pour cause de {{motif_nullite}} ;\n\n- ORDONNER les restitutions réciproques ;\n\n- CONDAMNER {{partie_fautive.nom}} à verser à {{partie_victime.nom}} la somme de {{montant_dommages}} euros à titre de dommages et intérêts ;\n\n- CONDAMNER {{partie_fautive.nom}} aux entiers dépens.	\N	{dispositif,nullité,contrat,restitutions}	f	t	\N	0	\N
cml85wc070025m3wjgmbew5u0	2026-02-04 15:07:55.207	2026-02-04 15:07:55.207	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Prud'hommes licenciement	PAR CES MOTIFS\n\nPlaise au Conseil de Prud'hommes :\n\n- DIRE ET JUGER que le licenciement de {{salarie.nom}} est dépourvu de cause réelle et sérieuse ;\n\n- CONDAMNER {{employeur.nom}} à verser à {{salarie.nom}} les sommes suivantes :\n  * {{montant_indemnite_licenciement}} euros à titre d'indemnité pour licenciement sans cause réelle et sérieuse (article L.1235-3 du Code du travail) ;\n  * {{montant_preavis}} euros au titre de l'indemnité compensatrice de préavis ;\n  * {{montant_cp_preavis}} euros au titre des congés payés afférents ;\n  * {{montant_article_700}} euros au titre de l'article 700 du CPC ;\n\n- ORDONNER la remise des documents de fin de contrat rectifiés ;\n\n- CONDAMNER {{employeur.nom}} aux dépens.	\N	{dispositif,prud'hommes,licenciement,travail}	f	t	\N	0	\N
cml85wc090027m3wj95bxsm0s	2026-02-04 15:07:55.209	2026-02-04 15:07:55.209	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Divorce par consentement mutuel	PAR CES MOTIFS\n\nPlaise au Juge aux Affaires Familiales :\n\n- HOMOLOGUER la convention de divorce par consentement mutuel ;\n\n- PRONONCER le divorce de {{epoux1.nom}} et {{epoux2.nom}} ;\n\n- ORDONNER la mention du divorce en marge de l'acte de mariage ;\n\n- DIRE que chaque partie conservera la charge de ses propres dépens.	\N	{dispositif,divorce,"consentement mutuel",famille}	f	t	\N	0	\N
cml85wc0b0029m3wjgju4qsif	2026-02-04 15:07:55.212	2026-02-04 15:07:55.212	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Injonction de faire	PAR CES MOTIFS\n\nPlaise au Tribunal :\n\n- ENJOINDRE {{defendeur.nom}} de {{obligation_a_executer}} dans un délai de {{delai}} à compter de la signification du présent jugement ;\n\n- DIRE que passé ce délai, {{defendeur.nom}} sera redevable d'une astreinte de {{montant_astreinte}} euros par jour de retard ;\n\n- SE RÉSERVER la liquidation de l'astreinte ;\n\n- CONDAMNER {{defendeur.nom}} aux dépens.	\N	{dispositif,injonction,faire,astreinte}	f	t	\N	0	\N
cml85wc0e002bm3wjyr6v68p2	2026-02-04 15:07:55.214	2026-02-04 15:07:55.214	cml6vykdd0000jms2wwxl9s27	DISPOSITIF	Dispositif - Interdiction et cessation	PAR CES MOTIFS\n\nPlaise au Tribunal :\n\n- INTERDIRE à {{defendeur.nom}} de {{comportement_interdit}} sous astreinte de {{montant_astreinte}} euros par infraction constatée ;\n\n- ORDONNER la cessation de {{actes_litigieux}} ;\n\n- ORDONNER la publication du présent jugement dans {{support_publication}} aux frais de {{defendeur.nom}} ;\n\n- CONDAMNER {{defendeur.nom}} à verser à {{demandeur.nom}} la somme de {{montant_dommages}} euros à titre de dommages et intérêts.	\N	{dispositif,interdiction,cessation,astreinte,concurrence}	f	t	\N	0	\N
cml85wc0g002dm3wjaramyz2p	2026-02-04 15:07:55.216	2026-02-04 15:07:55.216	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Formule signature client	Fait à {{lieu}}, le {{date}}\nEn {{nombre_exemplaires}} exemplaires originaux.\n\n{{client.nom}}\n(signature précédée de la mention « Lu et approuvé »)\n\n{{client.signature}}	\N	{signature,client,formule}	f	t	\N	0	\N
cml85wc0i002fm3wjhtf3ttp6	2026-02-04 15:07:55.218	2026-02-04 15:07:55.218	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Formule signature électronique	Le présent document a été signé électroniquement conformément aux dispositions du Règlement (UE) n°910/2014 du 23 juillet 2014 (eIDAS).\n\nSignatures électroniques qualifiées :\n\n{{#each signataires}}\n- {{this.nom}} : Certificat n°{{this.numero_certificat}}\n  Date de signature : {{this.date_signature}}\n  Autorité de certification : {{this.autorite_certification}}\n{{/each}}	\N	{signature,électronique,eIDAS}	f	t	\N	0	\N
cml85wc0k002hm3wjc8ydz3vt	2026-02-04 15:07:55.22	2026-02-04 15:07:55.22	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Mentions légales pied de page	---\n{{cabinet.denomination}} - {{cabinet.forme}}\nSiège social : {{cabinet.adresse}}\nTél : {{cabinet.telephone}} - Email : {{cabinet.email}}\nBarreau de {{avocat.barreau}} - Toque n°{{avocat.toque}}\n{{#if cabinet.rcs}}RCS {{cabinet.rcs}} - {{/if}}{{#if cabinet.tva}}TVA {{cabinet.tva}}{{/if}}\n\nDocument confidentiel - Toute reproduction interdite	\N	{"mentions légales","pied de page",footer}	f	t	\N	0	\N
cml85wc0l002jm3wjep9cjbzh	2026-02-04 15:07:55.222	2026-02-04 15:07:55.222	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Clause de confidentialité fin de document	Le présent document et les informations qu'il contient sont strictement confidentiels et destinés à l'usage exclusif de leur(s) destinataire(s). Toute utilisation, divulgation ou reproduction, même partielle, non autorisée est interdite.\n\nSi vous avez reçu ce document par erreur, merci de le détruire et d'en informer immédiatement l'expéditeur.	\N	{confidentialité,clause,"fin document"}	f	t	\N	0	\N
cml85wc0o002lm3wjivpjc0c3	2026-02-04 15:07:55.224	2026-02-04 15:07:55.224	cml6vykdd0000jms2wwxl9s27	SIGNATURE	Annexes et pièces jointes	LISTE DES ANNEXES\n\n{{#each annexes}}\nAnnexe {{@index}} : {{this.titre}}\n{{#if this.description}}    {{this.description}}{{/if}}\n{{/each}}\n\nLes annexes font partie intégrante du présent {{type_document}}.	\N	{annexes,"pièces jointes",liste}	f	t	\N	0	\N
cml85wc0q002nm3wj9mlq2nfi	2026-02-04 15:07:55.226	2026-02-04 15:07:55.226	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de force majeure	ARTICLE {{numero}} - FORCE MAJEURE\n\n{{numero}}.1 - Aucune des Parties ne sera tenue responsable vis-à-vis de l'autre Partie d'un manquement à ses obligations contractuelles si ce manquement résulte d'un événement de force majeure au sens de l'article 1218 du Code civil.\n\n{{numero}}.2 - Sont notamment considérés comme cas de force majeure : les catastrophes naturelles, guerres, actes de terrorisme, grèves générales, décisions gouvernementales, épidémies ou pandémies.\n\n{{numero}}.3 - La Partie invoquant la force majeure devra en informer l'autre Partie dans un délai de {{delai_notification}} jours.\n\n{{numero}}.4 - Si l'événement de force majeure se prolonge au-delà de {{duree_suspension}} mois, chaque Partie pourra résilier le contrat sans indemnité.	\N	{clause,"force majeure",1218,exonération}	f	t	\N	0	\N
cml85wc0t002pm3wj9irwxw1d	2026-02-04 15:07:55.229	2026-02-04 15:07:55.229	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de non-sollicitation de personnel	ARTICLE {{numero}} - NON-SOLLICITATION DE PERSONNEL\n\nChacune des Parties s'engage à ne pas solliciter, embaucher ou faire embaucher, directement ou indirectement, tout salarié ou collaborateur de l'autre Partie, pendant toute la durée du présent contrat et pendant une période de {{duree}} mois suivant son terme.\n\nEn cas de violation de cette obligation, la Partie défaillante versera à l'autre une indemnité forfaitaire de {{montant}} euros par salarié ou collaborateur concerné.	\N	{clause,non-sollicitation,personnel,salarié}	f	t	\N	0	\N
cml85wc0v002rm3wjcxm0ck2x	2026-02-04 15:07:55.231	2026-02-04 15:07:55.231	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de propriété intellectuelle	ARTICLE {{numero}} - PROPRIÉTÉ INTELLECTUELLE\n\n{{numero}}.1 - Les droits de propriété intellectuelle sur les {{objets_pi}} créés dans le cadre du présent contrat sont cédés à {{cessionnaire}} dès leur création, pour le monde entier et pour toute la durée légale de protection.\n\n{{numero}}.2 - Cette cession comprend les droits de reproduction, représentation, adaptation, traduction et commercialisation.\n\n{{numero}}.3 - Le Créateur garantit que les {{objets_pi}} ne portent pas atteinte aux droits des tiers et s'engage à indemniser {{cessionnaire}} de toute réclamation à ce titre.\n\n{{numero}}.4 - Le prix convenu inclut la rémunération de cette cession de droits.	\N	{clause,"propriété intellectuelle","cession droits",PI}	f	t	\N	0	\N
cml85wc0y002tm3wjsznnwexx	2026-02-04 15:07:55.234	2026-02-04 15:07:55.234	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de données personnelles (RGPD)	ARTICLE {{numero}} - PROTECTION DES DONNÉES PERSONNELLES\n\n{{numero}}.1 - Dans le cadre de l'exécution du présent contrat, les Parties s'engagent à respecter la réglementation applicable en matière de protection des données personnelles, notamment le Règlement (UE) 2016/679 du 27 avril 2016 (RGPD).\n\n{{numero}}.2 - {{partie_RT}} agit en qualité de responsable de traitement.\n\n{{numero}}.3 - {{partie_ST}} agit en qualité de sous-traitant et s'engage notamment à :\n- Traiter les données uniquement sur instruction documentée du responsable de traitement ;\n- Garantir la confidentialité des données ;\n- Mettre en œuvre les mesures de sécurité appropriées ;\n- Assister le responsable de traitement pour répondre aux demandes des personnes concernées.	\N	{clause,RGPD,"données personnelles",sous-traitance}	f	t	\N	0	\N
cml85wc0z002vm3wjmhyxnsgj	2026-02-04 15:07:55.236	2026-02-04 15:07:55.236	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de limitation de responsabilité	ARTICLE {{numero}} - LIMITATION DE RESPONSABILITÉ\n\n{{numero}}.1 - La responsabilité totale de {{partie_limitee}} au titre du présent contrat ne pourra excéder {{plafond}} euros.\n\n{{numero}}.2 - En aucun cas, {{partie_limitee}} ne sera responsable des dommages indirects, notamment le manque à gagner, la perte de clientèle, la perte de données ou l'atteinte à l'image.\n\n{{numero}}.3 - Ces limitations ne s'appliquent pas en cas de faute lourde ou intentionnelle, ou en cas d'atteinte à l'intégrité physique des personnes.\n\n{{numero}}.4 - Les Parties reconnaissent que ces limitations sont équilibrées et reflètent l'économie du contrat.	\N	{clause,"limitation responsabilité",plafond,exclusion}	f	t	\N	0	\N
cml85wc11002xm3wjbwryjxqs	2026-02-04 15:07:55.237	2026-02-04 15:07:55.237	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de divisibilité	ARTICLE {{numero}} - DIVISIBILITÉ\n\nSi l'une quelconque des stipulations du présent contrat était déclarée nulle ou inopposable en application d'une loi, d'un règlement ou à la suite d'une décision de justice devenue définitive, elle serait réputée non écrite, sans que cela n'affecte la validité des autres stipulations qui demeureront pleinement applicables.\n\nLes Parties s'engagent à négocier de bonne foi pour remplacer la stipulation nulle ou inopposable par une stipulation valide ayant un effet économique aussi proche que possible.	\N	{clause,divisibilité,"nullité partielle",validité}	f	t	\N	0	\N
cml85wc13002zm3wj7l1nsakb	2026-02-04 15:07:55.239	2026-02-04 15:07:55.239	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'intégralité	ARTICLE {{numero}} - INTÉGRALITÉ DE L'ACCORD\n\nLe présent contrat et ses annexes constituent l'intégralité de l'accord entre les Parties sur son objet.\n\nIl annule et remplace tous accords, lettres d'intention, pourparlers et documents antérieurs ayant le même objet.\n\nAucune modification du présent contrat ne sera valable sans un avenant écrit signé par les deux Parties.	\N	{clause,intégralité,"accord complet",modification}	f	t	\N	0	\N
cml85wc140031m3wjznmzffp3	2026-02-04 15:07:55.241	2026-02-04 15:07:55.241	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de renonciation	ARTICLE {{numero}} - NON-RENONCIATION\n\nLe fait pour l'une des Parties de ne pas se prévaloir d'un manquement de l'autre Partie à l'une quelconque des obligations visées au présent contrat ne saurait être interprété comme une renonciation à se prévaloir dans l'avenir d'un tel manquement.\n\nToute renonciation à l'application du présent contrat devra faire l'objet d'un accord exprès et écrit des Parties.	\N	{clause,renonciation,tolérance,droits}	f	t	\N	0	\N
cml85wc160033m3wjchqiv9d2	2026-02-04 15:07:55.243	2026-02-04 15:07:55.243	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de cession de contrat	ARTICLE {{numero}} - CESSION\n\n{{numero}}.1 - Le présent contrat est conclu intuitu personae et ne pourra être cédé ou transféré par l'une des Parties sans l'accord préalable écrit de l'autre Partie.\n\n{{numero}}.2 - Par exception, {{partie}} pourra librement céder le présent contrat à toute société de son groupe (au sens de l'article L.233-3 du Code de commerce) ou à tout cessionnaire de tout ou partie de ses activités.\n\n{{numero}}.3 - En cas de cession autorisée, le cessionnaire sera tenu de toutes les obligations du cédant au titre du présent contrat.	\N	{clause,"cession contrat","intuitu personae",transfert}	f	t	\N	0	\N
cml85wc180035m3wjrhwngual	2026-02-04 15:07:55.244	2026-02-04 15:07:55.244	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de révision de prix	ARTICLE {{numero}} - RÉVISION DU PRIX\n\n{{numero}}.1 - Le prix sera révisé {{periodicite}} en fonction de l'évolution de l'indice {{indice_reference}} publié par {{organisme_publication}}.\n\n{{numero}}.2 - La formule de révision est la suivante :\nP1 = P0 x (I1/I0)\nOù :\n- P1 = prix révisé\n- P0 = prix initial ({{prix_initial}} euros)\n- I1 = dernier indice connu à la date de révision\n- I0 = indice à la date de conclusion ({{indice_initial}})\n\n{{numero}}.3 - La révision ne pourra conduire à une augmentation supérieure à {{plafond_augmentation}}% par an.	\N	{clause,"révision prix",indexation,indice}	f	t	\N	0	\N
cml85wc1a0037m3wjrkjo1kqn	2026-02-04 15:07:55.246	2026-02-04 15:07:55.246	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de pénalités de retard	ARTICLE {{numero}} - PÉNALITÉS DE RETARD\n\nEn cas de retard de paiement, le débiteur sera de plein droit redevable :\n\n{{numero}}.1 - D'intérêts de retard calculés au taux de {{taux_interet}}% l'an (ou au taux prévu à l'article L.441-10 du Code de commerce pour les relations commerciales entre professionnels), à compter de la date d'échéance ;\n\n{{numero}}.2 - D'une indemnité forfaitaire pour frais de recouvrement de {{indemnite_forfaitaire}} euros, conformément à l'article D.441-5 du Code de commerce ;\n\n{{numero}}.3 - Des frais de recouvrement effectivement exposés si ceux-ci excèdent l'indemnité forfaitaire.	\N	{clause,pénalités,retard,intérêts,paiement}	f	t	\N	0	\N
cml88g72y000k521vhls1iakg	2026-02-04 16:19:21.178	2026-02-04 16:19:21.178	cml88g71z0000521vp3t710u4	INTRO	Intro Requête Ordonnance sur Requête	REQUÊTE AUX FINS D'ORDONNANCE SUR REQUÊTE\n\nPrésentée par :\n{{client.nom}}\n\nÀ Monsieur le Président du Tribunal Judiciaire de {{juridiction}},\n\nLa présente requête est présentée sur le fondement de l'article 493 du Code de procédure civile.	{}	{ordonnance,requete,intro}	f	t	10	0	\N
cml85wc1b0039m3wj65o78j36	2026-02-04 15:07:55.248	2026-02-04 15:07:55.248	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de notification	ARTICLE {{numero}} - NOTIFICATIONS\n\nToute notification ou communication au titre du présent contrat devra être faite par écrit et sera réputée valablement effectuée si elle est adressée :\n\n- Pour {{partie1.nom}} : {{partie1.adresse_notification}}\n- Pour {{partie2.nom}} : {{partie2.adresse_notification}}\n\nToute notification sera réputée reçue :\n- En cas de lettre recommandée avec AR : à la date de première présentation ;\n- En cas d'email avec accusé de réception : à la date d'envoi ;\n- En cas de remise en main propre : à la date de remise.\n\nToute modification d'adresse devra être notifiée à l'autre Partie dans les meilleurs délais.	\N	{clause,notification,communication,adresse}	f	t	\N	0	\N
cml85wc1d003bm3wjfb5nfy0p	2026-02-04 15:07:55.25	2026-02-04 15:07:55.25	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de durée et renouvellement	ARTICLE {{numero}} - DURÉE\n\n{{numero}}.1 - Le présent contrat est conclu pour une durée de {{duree_initiale}} à compter de {{date_effet}}.\n\n{{numero}}.2 - À l'issue de cette période initiale, le contrat sera renouvelé par tacite reconduction pour des périodes successives de {{duree_renouvellement}}, sauf dénonciation par l'une des Parties moyennant un préavis de {{preavis}} adressé par lettre recommandée avec accusé de réception.\n\n{{numero}}.3 - Le nombre de renouvellements n'est pas limité / Le contrat ne pourra être renouvelé plus de {{nombre_max_renouvellements}} fois.	\N	{clause,durée,renouvellement,"tacite reconduction"}	f	t	\N	0	\N
cml85wc1f003dm3wj9hsxtos5	2026-02-04 15:07:55.252	2026-02-04 15:07:55.252	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause de résiliation anticipée	ARTICLE {{numero}} - RÉSILIATION ANTICIPÉE\n\n{{numero}}.1 - Chaque Partie pourra résilier le présent contrat par anticipation :\n- En cas de manquement grave de l'autre Partie à ses obligations, non remédié dans un délai de {{delai_remediation}} jours suivant mise en demeure ;\n- En cas d'ouverture d'une procédure collective à l'encontre de l'autre Partie ;\n- En cas de changement de contrôle de l'autre Partie.\n\n{{numero}}.2 - La résiliation prendra effet {{delai_effet}} jours après notification par lettre recommandée avec AR.\n\n{{numero}}.3 - La résiliation est sans préjudice des dommages et intérêts éventuellement dus à la Partie non défaillante.	\N	{clause,résiliation,anticipée,manquement}	f	t	\N	0	\N
cml85wc1h003fm3wjdzcszs28	2026-02-04 15:07:55.253	2026-02-04 15:07:55.253	cml6vykdd0000jms2wwxl9s27	CLAUSE	Clause d'audit	ARTICLE {{numero}} - DROIT D'AUDIT\n\n{{numero}}.1 - {{partie_beneficiaire}} se réserve le droit de procéder ou faire procéder, à ses frais, à tout audit destiné à vérifier le respect par {{partie_auditee}} de ses obligations au titre du présent contrat.\n\n{{numero}}.2 - L'audit sera réalisé pendant les heures ouvrables, moyennant un préavis de {{preavis_audit}} jours ouvrés.\n\n{{numero}}.3 - {{partie_auditee}} s'engage à coopérer pleinement à l'audit et à donner accès à tous documents et informations utiles.\n\n{{numero}}.4 - Les résultats de l'audit seront confidentiels.	\N	{clause,audit,vérification,contrôle}	f	t	\N	0	\N
cml88g72e0002521vd4ncnwe7	2026-02-04 16:19:21.158	2026-02-04 16:19:21.158	cml88g71z0000521vp3t710u4	INTRO	Intro Assignation Tribunal Judiciaire	L'AN DEUX MILLE VINGT-SIX\nEt le {{date_assignation}}\n\nÀ la requête de :\n{{client.civilite}} {{client.nom}} {{client.prenom}}\nDemeurant {{client.adresse}}\n{{client.code_postal}} {{client.ville}}\n\nReprésenté par Maître {{avocat.nom}} {{avocat.prenom}}\nAvocat au Barreau de {{avocat.barreau}}\n{{cabinet.adresse}}\n\nJ'ai, {{huissier.nom}} {{huissier.prenom}}, Huissier de Justice associé de la SCP {{huissier.scp}}, demeurant {{huissier.adresse}}, et exerçant en cette ville,\n\nDONNÉ ASSIGNATION À :\n\n{{adversaire.civilite}} {{adversaire.nom}} {{adversaire.prenom}}\nDemeurant {{adversaire.adresse}}\n{{adversaire.code_postal}} {{adversaire.ville}}\n\nÀ COMPARAÎTRE devant le Tribunal Judiciaire de {{juridiction}}, Palais de Justice {{juridiction.adresse}}, le {{date_audience}} à {{heure_audience}}.	{}	{assignation,tribunal-judiciaire,intro}	f	t	1	0	\N
cml88g72l0004521v67f38gmg	2026-02-04 16:19:21.165	2026-02-04 16:19:21.165	cml88g71z0000521vp3t710u4	INTRO	Intro Assignation Référé Urgence	L'AN DEUX MILLE VINGT-SIX\nEt le {{date_assignation}}\n\nEN RÉFÉRÉ D'HEURE À HEURE\n\nÀ la requête de :\n{{client.nom}}\nAgissant en qualité de {{client.qualite}}\n\nAyant pour avocat :\nMaître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nJ'ai {{huissier.nom}}, Huissier de Justice,\n\nDONNÉ ASSIGNATION EN RÉFÉRÉ D'HEURE À HEURE À :\n\n{{adversaire.nom}}\n\nPour voir statuer par le Président du Tribunal Judiciaire statuant en référé le {{date_audience}} à {{heure_audience}}.\n\nIL Y A URGENCE car {{motif_urgence}}.	{}	{refere,urgence,intro}	f	t	2	0	\N
cml88g72m0006521vrm2xxfs7	2026-02-04 16:19:21.167	2026-02-04 16:19:21.167	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions en Défense	TRIBUNAL JUDICIAIRE DE {{juridiction}}\n\nCONCLUSIONS EN DÉFENSE\n\nPour :\n{{client.civilite}} {{client.nom}} {{client.prenom}}\nDemeurant {{client.adresse}}\n\nReprésenté par :\nMaître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nCONTRE :\n\n{{adversaire.nom}}\n\nAffaire RG nº {{numero_rg}}\n\nPLAISE AU TRIBUNAL,	{}	{conclusions,defense,intro}	f	t	3	0	\N
cml88g72o0008521v6l79d856	2026-02-04 16:19:21.168	2026-02-04 16:19:21.168	cml88g71z0000521vp3t710u4	INTRO	Intro Requête en Référé	REQUÊTE EN RÉFÉRÉ\n\nPrésentée par :\n{{client.nom}}\n{{client.adresse}}\n\nReprésenté par Maître {{avocat.nom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nCONTRE :\n\n{{adversaire.nom}}\n{{adversaire.adresse}}\n\nMonsieur le Président du Tribunal Judiciaire de {{juridiction}},	{}	{requete,refere,intro}	f	t	4	0	\N
cml88g72p000a521vt2ugqmlk	2026-02-04 16:19:21.17	2026-02-04 16:19:21.17	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Incident	CONCLUSIONS SUR INCIDENT\n\nAffaire RG nº {{numero_rg}}\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nPLAISE AU TRIBUNAL,\n\nSur l'incident soulevé par la partie adverse,	{}	{conclusions,incident,intro}	f	t	5	0	\N
cml88g72r000c521vlxm2tbb5	2026-02-04 16:19:21.171	2026-02-04 16:19:21.171	cml88g71z0000521vp3t710u4	INTRO	Intro Mémoire en Réplique	MÉMOIRE EN RÉPLIQUE\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nAffaire : {{numero_rg}}\n\nEn réponse aux conclusions déposées par la partie adverse le {{date_conclusions_adversaire}},	{}	{replique,memoire,intro}	f	t	6	0	\N
cml88g72s000e521vgrroa0zf	2026-02-04 16:19:21.173	2026-02-04 16:19:21.173	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Appel	COUR D'APPEL DE {{juridiction}}\n\nCONCLUSIONS D'APPELANT\n\nPour : {{client.nom}}\nAPPELANT\n\nContre : {{adversaire.nom}}\nINTIMÉ\n\nAffaire nº {{numero_rg}}\n\nPLAISE À LA COUR,	{}	{appel,conclusions,intro}	f	t	7	0	\N
cml88g72t000g521vgtu9w5zz	2026-02-04 16:19:21.174	2026-02-04 16:19:21.174	cml88g71z0000521vp3t710u4	INTRO	Intro Contredit	CONTREDIT\n\nAffaire RG nº {{numero_rg}}\n\nPour : {{client.nom}}\n\nCONTESTE LA COMPÉTENCE DU TRIBUNAL\n\nAu visa de l'article 75 du Code de procédure civile,	{}	{contredit,competence,intro}	f	t	8	0	\N
cml88g731000o521vamlkkqum	2026-02-04 16:19:21.181	2026-02-04 16:19:21.181	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Référé-Provision	CONCLUSIONS EN RÉFÉRÉ-PROVISION\n\nPour : {{client.nom}}\n\nContre : {{adversaire.nom}}\n\nSur le fondement de l'article 835 alinéa 2 du Code de procédure civile,\n\nPLAISE AU PRÉSIDENT,	{}	{refere,provision,intro}	f	t	12	0	\N
cml88g733000q521v59duxkoq	2026-02-04 16:19:21.183	2026-02-04 16:19:21.183	cml88g71z0000521vp3t710u4	INTRO	Intro Assignation Jour Fixe	ASSIGNATION À JOUR FIXE\n\nL'AN DEUX MILLE VINGT-SIX\nLe {{date_assignation}}\n\nÀ la requête de : {{client.nom}}\n\nMuni d'une ordonnance rendue le {{date_ordonnance}} par le Président du Tribunal Judiciaire de {{juridiction}} autorisant l'assignation à jour fixe,\n\nJ'ai assigné : {{adversaire.nom}}\n\nÀ comparaître le {{date_audience}} à {{heure_audience}}.	{}	{jour-fixe,assignation,intro}	f	t	13	0	\N
cml88g734000s521vlmw8r7ax	2026-02-04 16:19:21.184	2026-02-04 16:19:21.184	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Intervention Volontaire	CONCLUSIONS D'INTERVENTION VOLONTAIRE\n\nPour : {{client.nom}}\nINTERVENANT\n\nDans l'instance opposant :\n\n{{demandeur.nom}}\nDEMANDEUR\n\nÀ\n\n{{defendeur.nom}}\nDÉFENDEUR\n\nAffaire RG nº {{numero_rg}}\n\nPLAISE AU TRIBUNAL recevoir l'intervention de {{client.nom}},	{}	{intervention,volontaire,intro}	f	t	14	0	\N
cml88g735000u521vsg18vhsw	2026-02-04 16:19:21.185	2026-02-04 16:19:21.185	cml88g71z0000521vp3t710u4	INTRO	Intro Conclusions Appel en Garantie	CONCLUSIONS D'APPEL EN GARANTIE\n\nPour : {{client.nom}}\nDÉFENDEUR ET DEMANDEUR À L'APPEL EN GARANTIE\n\nAppelle en garantie :\n\n{{garant.nom}}\n\nEn vue d'être relevé et garanti de toute condamnation qui pourrait être prononcée à son encontre.	{}	{garantie,appel-garantie,intro}	f	t	15	0	\N
cml88g736000w521vv9dwdvqy	2026-02-04 16:19:21.186	2026-02-04 16:19:21.186	cml88g71z0000521vp3t710u4	FAITS	Chronologie Relation Contractuelle	EXPOSÉ DES FAITS\n\nLa relation contractuelle entre les parties s'est établie selon la chronologie suivante :\n\n- Le {{date_1}} : {{evenement_1}}\n- Le {{date_2}} : {{evenement_2}}\n- Le {{date_3}} : {{evenement_3}}\n- Le {{date_4}} : {{evenement_4}}\n\nForce est de constater que {{constatation_principale}}.	{}	{chronologie,contrat,faits}	f	t	1	0	\N
cml88g737000y521v0sp6dmjv	2026-02-04 16:19:21.188	2026-02-04 16:19:21.188	cml88g71z0000521vp3t710u4	FAITS	Rappel Contrat Commercial	Par contrat en date du {{date_contrat}}, la société {{client.nom}} et la société {{adversaire.nom}} ont conclu un accord commercial portant sur {{objet_contrat}}.\n\nAux termes de ce contrat, il était notamment prévu que :\n- {{clause_1}}\n- {{clause_2}}\n- {{clause_3}}\n\nLe contrat prévoyait une durée de {{duree_contrat}} et un montant total de {{montant_contrat}} euros.	{}	{contrat,commercial,faits}	f	t	2	0	\N
cml88g7380010521v8v0pf884	2026-02-04 16:19:21.189	2026-02-04 16:19:21.189	cml88g71z0000521vp3t710u4	FAITS	Inexécution Contractuelle Détaillée	Or, {{adversaire.nom}} n'a pas respecté ses obligations contractuelles, et ce à plusieurs égards :\n\n1. {{manquement_1}} alors que le contrat prévoyait {{obligation_contractuelle_1}}\n\n2. {{manquement_2}} en violation de l'article {{article_contrat_2}} du contrat\n\n3. {{manquement_3}}\n\nMalgré une mise en demeure adressée par lettre recommandée avec accusé de réception en date du {{date_mise_en_demeure}}, restée sans réponse, {{adversaire.nom}} persiste dans son inexécution.	{}	{inexecution,manquements,faits}	f	t	3	0	\N
cml88g73a0012521vfng0ohzi	2026-02-04 16:19:21.19	2026-02-04 16:19:21.19	cml88g71z0000521vp3t710u4	FAITS	Contexte Cession Parts Sociales	La société {{societe_cible}} est une société {{forme_juridique}} au capital de {{capital}} euros, immatriculée au RCS de {{ville_rcs}} sous le numéro {{numero_rcs}}.\n\nMonsieur/Madame {{cedant.nom}} détenait {{nombre_parts}} parts sociales de la société {{societe_cible}}, représentant {{pourcentage}}% du capital social.\n\nPar protocole de cession en date du {{date_protocole}}, Monsieur/Madame {{cedant.nom}} a cédé l'intégralité de ses parts sociales à Monsieur/Madame {{cessionnaire.nom}} pour un prix de {{prix_cession}} euros.	{}	{cession,parts-sociales,faits}	f	t	4	0	\N
cml88g73b0014521v1mmtupxt	2026-02-04 16:19:21.191	2026-02-04 16:19:21.191	cml88g71z0000521vp3t710u4	FAITS	Litige Livraison Marchandises	Le {{date_commande}}, {{client.nom}} a passé commande auprès de {{adversaire.nom}} pour l'achat de {{description_marchandises}}, pour un montant total de {{montant}} euros TTC.\n\nLa livraison devait intervenir le {{date_livraison_prevue}}.\n\nOr, à ce jour, {{adversaire.nom}} n'a toujours pas procédé à la livraison des marchandises commandées, malgré le paiement intégral effectué par {{client.nom}} le {{date_paiement}}.	{}	{livraison,marchandises,vente,faits}	f	t	5	0	\N
cml88g73c0016521vpptdo7n1	2026-02-04 16:19:21.192	2026-02-04 16:19:21.192	cml88g71z0000521vp3t710u4	FAITS	Accident Circulation Détaillé	Le {{date_accident}} à {{heure_accident}}, un accident de la circulation s'est produit {{lieu_accident}}.\n\n{{client.nom}}, qui circulait à bord du véhicule {{marque_vehicule_client}} immatriculé {{immatriculation_client}}, a été heurté par le véhicule conduit par {{adversaire.nom}}, de marque {{marque_vehicule_adversaire}} immatriculé {{immatriculation_adversaire}}.\n\nLes circonstances de l'accident sont les suivantes : {{circonstances_detaillees}}.\n\nUn constat amiable d'accident a été établi sur place.	{}	{accident,circulation,faits}	f	t	6	0	\N
cml88g73d0018521v8nv8mlww	2026-02-04 16:19:21.193	2026-02-04 16:19:21.193	cml88g71z0000521vp3t710u4	FAITS	Rupture Abusive Contrat Travail	{{client.nom}} a été embauché(e) par la société {{employeur}} en qualité de {{poste}} par contrat de travail à durée {{type_contrat}} en date du {{date_embauche}}.\n\nLe {{date_licenciement}}, {{client.nom}} a été convoqué(e) à un entretien préalable au licenciement.\n\nPar lettre recommandée en date du {{date_lettre_licenciement}}, {{employeur}} a notifié à {{client.nom}} son licenciement pour {{motif_licenciement}}.\n\nOr, ce licenciement est dépourvu de cause réelle et sérieuse pour les raisons suivantes : {{arguments}}.	{}	{travail,licenciement,faits}	f	t	7	0	\N
cml88g73e001a521vr9lcyh1r	2026-02-04 16:19:21.194	2026-02-04 16:19:21.194	cml88g71z0000521vp3t710u4	FAITS	Troubles Voisinage	{{client.nom}} est propriétaire d'un bien immobilier situé {{adresse_client}}, dont il/elle a fait l'acquisition le {{date_acquisition}}.\n\nDepuis le {{date_debut_troubles}}, {{client.nom}} subit des troubles anormaux de voisinage causés par {{adversaire.nom}}, propriétaire du bien situé {{adresse_adversaire}}.\n\nCes troubles se manifestent notamment par : {{description_troubles}}.\n\nMalgré plusieurs courriers de réclamation, dont le dernier en date du {{date_dernier_courrier}}, {{adversaire.nom}} n'a pris aucune mesure pour faire cesser ces nuisances.	{}	{voisinage,troubles,immobilier,faits}	f	t	8	0	\N
cml88g76q005u521vuxf591dk	2026-02-04 16:19:21.314	2026-02-04 16:19:21.314	cml88g71z0000521vp3t710u4	DISPOSITIF	Désistement	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDONNER ACTE à {{client.nom}} de son désistement d'instance et d'action,\n\nCONSTATER l'extinction de l'instance,\n\nDIRE que chaque partie conservera la charge de ses propres dépens.	{}	{desistement,procedure,dispositif}	f	t	25	0	\N
cml88g73f001c521vcqqf772a	2026-02-04 16:19:21.196	2026-02-04 16:19:21.196	cml88g71z0000521vp3t710u4	FAITS	Vice Caché Vente Immobilière	Par acte authentique en date du {{date_vente}}, {{client.nom}} a acquis auprès de {{vendeur}} un bien immobilier situé {{adresse_bien}} pour un prix de {{prix_vente}} euros.\n\nPostérieurement à la vente, {{client.nom}} a découvert que le bien était affecté des vices suivants : {{description_vices}}.\n\nCes vices, qui existaient au jour de la vente et qui n'étaient pas apparents lors de la visite, rendent le bien impropre à l'usage auquel il est destiné.\n\nUn rapport d'expertise établi le {{date_expertise}} par {{expert}} confirme l'existence et la gravité de ces vices.	{}	{vice-cache,vente,immobilier,faits}	f	t	9	0	\N
cml88g73g001e521vo5wrzbou	2026-02-04 16:19:21.197	2026-02-04 16:19:21.197	cml88g71z0000521vp3t710u4	FAITS	Impayés Loyers Commercial	Par bail commercial en date du {{date_bail}}, {{bailleur}} a donné à bail à {{preneur}} des locaux à usage commercial situés {{adresse_locaux}}, moyennant un loyer mensuel de {{montant_loyer}} euros HT.\n\nÀ compter du mois de {{mois_premier_impaye}}, {{preneur}} a cessé de régler les loyers et charges.\n\nÀ ce jour, le montant total des impayés s'élève à {{montant_total_impaye}} euros, correspondant à {{nombre_mois}} mois de loyers impayés.\n\nMalgré une mise en demeure par acte d'huissier en date du {{date_commandement}}, {{preneur}} n'a procédé à aucun règlement.	{}	{bail,commercial,impaye,faits}	f	t	10	0	\N
cml88g73h001g521vo3tl0upg	2026-02-04 16:19:21.198	2026-02-04 16:19:21.198	cml88g71z0000521vp3t710u4	FAITS	Défaut Conformité Produit	Le {{date_achat}}, {{client.nom}} a fait l'acquisition auprès de {{vendeur}} d'un {{produit}} pour un prix de {{prix}} euros.\n\nDès la première utilisation, {{client.nom}} a constaté que le produit ne présentait pas les caractéristiques annoncées, à savoir : {{non_conformites}}.\n\nLe produit livré ne correspond donc pas à la description qui en avait été faite et ne possède pas les qualités essentielles attendues.	{}	{conformite,produit,consommation,faits}	f	t	11	0	\N
cml88g73j001i521vgm37bhcw	2026-02-04 16:19:21.199	2026-02-04 16:19:21.199	cml88g71z0000521vp3t710u4	FAITS	Diffamation Publique	Le {{date_publication}}, {{adversaire.nom}} a publié sur {{support_publication}} les propos suivants :\n\n"{{propos_litigieux}}"\n\nCes propos, qui imputent à {{client.nom}} des faits précis portant atteinte à son honneur et à sa considération, constituent une diffamation publique au sens de l'article 29 de la loi du 29 juillet 1881.	{}	{diffamation,presse,faits}	f	t	12	0	\N
cml88g73k001k521v3b82sqhs	2026-02-04 16:19:21.2	2026-02-04 16:19:21.2	cml88g71z0000521vp3t710u4	FAITS	Concurrence Déloyale	{{client.nom}} exerce l'activité de {{activite}} depuis {{date_creation}}.\n\nOr, {{adversaire.nom}}, ancien {{relation_anterieure}}, a commis les actes de concurrence déloyale suivants :\n\n1. {{acte_deloyal_1}}\n2. {{acte_deloyal_2}}\n3. {{acte_deloyal_3}}\n\nCes agissements ont causé à {{client.nom}} un préjudice commercial considérable.	{}	{concurrence,deloyale,commercial,faits}	f	t	13	0	\N
cml88g73n001m521v1d8iib8a	2026-02-04 16:19:21.203	2026-02-04 16:19:21.203	cml88g71z0000521vp3t710u4	FAITS	Divorce Contexte Familial	{{client.nom}} et {{conjoint.nom}} se sont mariés le {{date_mariage}} à la mairie de {{lieu_mariage}}, sous le régime de {{regime_matrimonial}}.\n\nDe cette union sont issus {{nombre_enfants}} enfant(s) :\n{{liste_enfants}}\n\nLa vie commune a cessé le {{date_separation}}, date à laquelle {{circonstances_separation}}.\n\nLe divorce est demandé pour {{motif_divorce}}.	{}	{divorce,famille,faits}	f	t	14	0	\N
cml88g73o001o521vpfloyyiv	2026-02-04 16:19:21.205	2026-02-04 16:19:21.205	cml88g71z0000521vp3t710u4	FAITS	Succession Litigieuse	{{defunt.nom}} est décédé(e) le {{date_deces}} à {{lieu_deces}}, laissant pour lui/elle succéder :\n{{liste_heritiers}}\n\nLe patrimoine successoral comprend notamment :\n{{liste_biens}}\n\nUn désaccord est survenu entre les héritiers concernant {{objet_litige}}.	{}	{succession,heritage,faits}	f	t	15	0	\N
cml88g73p001q521v9sde8oa5	2026-02-04 16:19:21.206	2026-02-04 16:19:21.206	cml88g71z0000521vp3t710u4	FAITS	Prêt Non Remboursé	Par acte sous seing privé en date du {{date_pret}}, {{client.nom}} a consenti à {{emprunteur}} un prêt d'un montant de {{montant_pret}} euros.\n\nCe prêt devait être remboursé selon les modalités suivantes : {{modalites_remboursement}}.\n\nOr, {{emprunteur}} n'a effectué que {{nombre_echeances}} échéances sur les {{total_echeances}} prévues.\n\nLe solde restant dû s'élève à {{solde_du}} euros, outre les intérêts.	{}	{pret,creance,faits}	f	t	16	0	\N
cml88g73q001s521vsmd3yssd	2026-02-04 16:19:21.207	2026-02-04 16:19:21.207	cml88g71z0000521vp3t710u4	FAITS	Malfaçons Construction	{{client.nom}} a confié à {{constructeur}} la réalisation de {{travaux}} pour un montant de {{montant_travaux}} euros, selon devis accepté le {{date_devis}}.\n\nLa réception des travaux est intervenue le {{date_reception}}, avec les réserves suivantes : {{reserves}}.\n\nPostérieurement à la réception, les désordres suivants sont apparus : {{desordres}}.\n\nUne expertise judiciaire ordonnée le {{date_ordonnance_expertise}} a confirmé les malfaçons.	{}	{construction,malfacons,faits}	f	t	17	0	\N
cml88g73r001u521v5bympfqg	2026-02-04 16:19:21.208	2026-02-04 16:19:21.208	cml88g71z0000521vp3t710u4	FAITS	Contrefaçon Marque	{{client.nom}} est titulaire de la marque "{{nom_marque}}" enregistrée à l'INPI sous le numéro {{numero_depot}} le {{date_depot}}, pour désigner les produits et services suivants : {{classes}}.\n\nOr, {{adversaire.nom}} commercialise des produits/services sous le signe "{{signe_litigieux}}", reproduisant de manière identique/similaire la marque de {{client.nom}}.\n\nCes actes de contrefaçon portent gravement atteinte aux droits de propriété intellectuelle de {{client.nom}}.	{}	{contrefacon,marque,propriete-intellectuelle,faits}	f	t	18	0	\N
cml88g73s001w521vqeqj5k5d	2026-02-04 16:19:21.209	2026-02-04 16:19:21.209	cml88g71z0000521vp3t710u4	FAITS	Harcèlement Moral Travail	{{client.nom}} occupe le poste de {{poste}} au sein de {{employeur}} depuis le {{date_embauche}}.\n\nDepuis le {{date_debut_harcelement}}, {{client.nom}} est victime d'agissements répétés de harcèlement moral de la part de {{harceleur}}, se manifestant par :\n{{agissements}}\n\nCes agissements ont eu pour effet une dégradation des conditions de travail et de l'état de santé de {{client.nom}}, ainsi qu'en attestent {{preuves}}.	{}	{harcelement,travail,faits}	f	t	19	0	\N
cml88g73t001y521vaxtg9lb6	2026-02-04 16:19:21.21	2026-02-04 16:19:21.21	cml88g71z0000521vp3t710u4	FAITS	Rupture Brutale Relations Commerciales	{{client.nom}} et {{adversaire.nom}} entretenaient des relations commerciales établies depuis {{duree_relation}}.\n\nLe chiffre d'affaires annuel moyen réalisé avec {{adversaire.nom}} s'élevait à {{ca_moyen}} euros, représentant {{pourcentage}}% du chiffre d'affaires total de {{client.nom}}.\n\nPar courrier du {{date_rupture}}, {{adversaire.nom}} a notifié la cessation des relations commerciales avec effet au {{date_effet}}, soit un préavis de {{duree_preavis}} seulement.\n\nCe préavis est manifestement insuffisant au regard de la durée de la relation commerciale.	{}	{rupture,commercial,L442-1,faits}	f	t	20	0	\N
cml88g73v0020521va0x0yhy2	2026-02-04 16:19:21.211	2026-02-04 16:19:21.211	cml88g71z0000521vp3t710u4	FAITS	Accident Médical	Le {{date_intervention}}, {{client.nom}} a subi une intervention chirurgicale {{type_intervention}} pratiquée par le Docteur {{medecin}} au sein de {{etablissement}}.\n\nSuite à cette intervention, {{client.nom}} a présenté les complications suivantes : {{complications}}.\n\nL'expertise médicale diligentée par {{expert}} a mis en évidence {{conclusions_expertise}}.\n\nLe taux d'IPP a été évalué à {{taux_ipp}}%.	{}	{medical,responsabilite,faits}	f	t	21	0	\N
cml88g73w0022521v5z26q0mc	2026-02-04 16:19:21.212	2026-02-04 16:19:21.212	cml88g71z0000521vp3t710u4	FAITS	Non-paiement Factures	Dans le cadre de relations commerciales habituelles, {{client.nom}} a établi les factures suivantes à l'attention de {{adversaire.nom}} :\n\n{{liste_factures}}\n\nMalgré plusieurs relances amiables, dont la dernière en date du {{date_derniere_relance}}, ces factures demeurent impayées.\n\nLe montant total de la créance s'élève à {{montant_total}} euros TTC, outre les pénalités de retard.	{}	{factures,impaye,commercial,faits}	f	t	22	0	\N
cml88g73x0024521v2k2abwby	2026-02-04 16:19:21.214	2026-02-04 16:19:21.214	cml88g71z0000521vp3t710u4	FAITS	Expulsion Locataire	Par bail d'habitation en date du {{date_bail}}, {{bailleur}} a donné à bail à {{locataire}} un logement situé {{adresse_logement}}.\n\n{{locataire}} ne s'est pas acquitté de ses obligations locatives depuis le {{date_premier_impaye}}.\n\nUn commandement de payer visant la clause résolutoire a été délivré le {{date_commandement}}.\n\nDeux mois s'étant écoulés sans régularisation, le bail est résilié de plein droit.	{}	{expulsion,bail,habitation,faits}	f	t	23	0	\N
cml88g73y0026521v9zj1ktmx	2026-02-04 16:19:21.215	2026-02-04 16:19:21.215	cml88g71z0000521vp3t710u4	FAITS	Garantie Décennale	{{client.nom}} a fait construire {{ouvrage}} par {{constructeur}}, la réception étant intervenue le {{date_reception}}.\n\nDans le délai de la garantie décennale, des désordres sont apparus, rendant l'ouvrage impropre à sa destination :\n{{description_desordres}}\n\nCes désordres compromettent la solidité de l'ouvrage et/ou le rendent impropre à sa destination, engageant la responsabilité décennale du constructeur.	{}	{decennale,construction,faits}	f	t	24	0	\N
cml88g7400028521vqjlu9adz	2026-02-04 16:19:21.216	2026-02-04 16:19:21.216	cml88g71z0000521vp3t710u4	FAITS	Abus de Confiance	{{client.nom}} a remis à {{adversaire.nom}} la somme de {{montant}} euros / les biens suivants : {{biens}}, à charge pour ce dernier de {{mission}}.\n\nOr, {{adversaire.nom}} a détourné ces fonds/biens en les utilisant à des fins personnelles, à savoir : {{utilisation_frauduleuse}}.\n\nMalgré mise en demeure, {{adversaire.nom}} refuse de restituer les sommes/biens détournés.	{}	{abus-confiance,penal,faits}	f	t	25	0	\N
cml88g742002a521vzg1sjbol	2026-02-04 16:19:21.218	2026-02-04 16:19:21.218	cml88g71z0000521vp3t710u4	MOYENS	Article 1103 Code Civil - Force Obligatoire	SUR LE FONDEMENT DE L'ARTICLE 1103 DU CODE CIVIL\n\nAux termes de l'article 1103 du Code civil, "les contrats légalement formés tiennent lieu de loi à ceux qui les ont faits".\n\nEn l'espèce, le contrat liant les parties, conclu le {{date_contrat}}, est parfaitement valide et produit tous ses effets.\n\n{{adversaire.nom}} ne peut donc se soustraire unilatéralement à ses obligations contractuelles, sous peine de voir sa responsabilité contractuelle engagée.	{}	{article-1103,pacta-sunt-servanda,moyens}	f	t	1	0	\N
cml88g743002c521vosmq5vyc	2026-02-04 16:19:21.22	2026-02-04 16:19:21.22	cml88g71z0000521vp3t710u4	MOYENS	Article 1217 Code Civil - Inexécution	SUR L'INEXÉCUTION CONTRACTUELLE\n\nL'article 1217 du Code civil dispose que "la partie envers laquelle l'engagement n'a pas été exécuté, ou l'a été imparfaitement, peut :\n- refuser d'exécuter ou suspendre l'exécution de sa propre obligation ;\n- poursuivre l'exécution forcée en nature de l'obligation ;\n- obtenir une réduction du prix ;\n- provoquer la résolution du contrat ;\n- demander réparation des conséquences de l'inexécution".\n\nEn l'espèce, l'inexécution par {{adversaire.nom}} de ses obligations contractuelles justifie que {{client.nom}} sollicite {{option_choisie}}.	{}	{article-1217,inexecution,moyens}	f	t	2	0	\N
cml88g744002e521v7p8k1pgt	2026-02-04 16:19:21.221	2026-02-04 16:19:21.221	cml88g71z0000521vp3t710u4	MOYENS	Article 1231-1 Code Civil - Dommages-Intérêts	SUR LES DOMMAGES-INTÉRÊTS\n\nAux termes de l'article 1231-1 du Code civil, "le débiteur est condamné, s'il y a lieu, au paiement de dommages et intérêts soit à raison de l'inexécution de l'obligation, soit à raison du retard dans l'exécution, s'il ne justifie pas que l'exécution a été empêchée par la force majeure".\n\nEn l'espèce, {{client.nom}} a subi un préjudice direct et certain du fait de l'inexécution par {{adversaire.nom}}, préjudice qu'il convient d'évaluer à {{montant_prejudice}} euros.	{}	{article-1231-1,dommages-interets,moyens}	f	t	3	0	\N
cml88g745002g521vybf7v9b1	2026-02-04 16:19:21.222	2026-02-04 16:19:21.222	cml88g71z0000521vp3t710u4	MOYENS	Article 1240 Code Civil - Responsabilité Délictuelle	SUR LA RESPONSABILITÉ DÉLICTUELLE\n\nL'article 1240 du Code civil dispose que "tout fait quelconque de l'homme, qui cause à autrui un dommage, oblige celui par la faute duquel il est arrivé à le réparer".\n\nEn l'espèce, la responsabilité de {{adversaire.nom}} est engagée dès lors que sont réunies les trois conditions :\n\n1. Une faute : {{description_faute}}\n2. Un dommage : {{description_dommage}}\n3. Un lien de causalité : {{lien_causalite}}	{}	{article-1240,responsabilite,delictuelle,moyens}	f	t	4	0	\N
cml88g746002i521vhodfo31h	2026-02-04 16:19:21.223	2026-02-04 16:19:21.223	cml88g71z0000521vp3t710u4	MOYENS	Article 1245 Code Civil - Produits Défectueux	SUR LA RESPONSABILITÉ DU FAIT DES PRODUITS DÉFECTUEUX\n\nAux termes de l'article 1245 du Code civil, "le producteur est responsable du dommage causé par un défaut de son produit, qu'il soit ou non lié par un contrat avec la victime".\n\nEn l'espèce, le produit {{description_produit}} fabriqué par {{producteur}} présente un défaut de {{nature_defaut}} qui a causé {{dommage}}.\n\nLa responsabilité de {{producteur}} est donc engagée, sans qu'il soit besoin de prouver une faute de sa part.	{}	{article-1245,produits-defectueux,moyens}	f	t	5	0	\N
cml88g748002k521vacuh2a39	2026-02-04 16:19:21.224	2026-02-04 16:19:21.224	cml88g71z0000521vp3t710u4	MOYENS	Article 1641 Code Civil - Garantie Vices Cachés	SUR LA GARANTIE DES VICES CACHÉS\n\nAux termes de l'article 1641 du Code civil, "le vendeur est tenu de la garantie à raison des défauts cachés de la chose vendue qui la rendent impropre à l'usage auquel on la destine, ou qui diminuent tellement cet usage que l'acheteur ne l'aurait pas acquise, ou n'en aurait donné qu'un moindre prix, s'il les avait connus".\n\nLe vice invoqué remplit les conditions légales :\n- Il est caché : {{demonstration_caractere_cache}}\n- Il est antérieur à la vente : {{demonstration_anteriorite}}\n- Il est grave : {{demonstration_gravite}}	{}	{article-1641,vice-cache,moyens}	f	t	6	0	\N
cml88g749002m521vhxya4cte	2026-02-04 16:19:21.225	2026-02-04 16:19:21.225	cml88g71z0000521vp3t710u4	MOYENS	Article 1792 Code Civil - Responsabilité Décennale	SUR LA RESPONSABILITÉ DÉCENNALE\n\nL'article 1792 du Code civil dispose que "tout constructeur d'un ouvrage est responsable de plein droit, envers le maître ou l'acquéreur de l'ouvrage, des dommages, même résultant d'un vice du sol, qui compromettent la solidité de l'ouvrage ou qui, l'affectant dans l'un de ses éléments constitutifs ou l'un de ses éléments d'équipement, le rendent impropre à sa destination".\n\nLes désordres constatés compromettent la solidité de l'ouvrage / rendent l'ouvrage impropre à sa destination, engageant ainsi la responsabilité décennale de {{constructeur}}.	{}	{article-1792,decennale,construction,moyens}	f	t	7	0	\N
cml88g74a002o521vw2vqw2x8	2026-02-04 16:19:21.227	2026-02-04 16:19:21.227	cml88g71z0000521vp3t710u4	MOYENS	Article L.442-1 Code Commerce - Rupture Brutale	SUR LA RUPTURE BRUTALE DES RELATIONS COMMERCIALES\n\nL'article L.442-1 II du Code de commerce sanctionne "le fait, par toute personne exerçant des activités de production, de distribution ou de services de rompre brutalement, même partiellement, une relation commerciale établie, en l'absence d'un préavis écrit qui tienne compte notamment de la durée de la relation commerciale".\n\nEn l'espèce, la relation commerciale était établie depuis {{duree_relation}}, justifiant un préavis d'au moins {{duree_preavis_necessaire}}.\n\nLe préavis accordé de {{duree_preavis_accorde}} est manifestement insuffisant.	{}	{L442-1,rupture-brutale,commercial,moyens}	f	t	8	0	\N
cml88g74b002q521va73e2tzo	2026-02-04 16:19:21.228	2026-02-04 16:19:21.228	cml88g71z0000521vp3t710u4	MOYENS	Article L.1232-1 Code Travail - Licenciement	SUR L'ABSENCE DE CAUSE RÉELLE ET SÉRIEUSE\n\nAux termes de l'article L.1232-1 du Code du travail, "tout licenciement pour motif personnel est motivé" et doit reposer sur "une cause réelle et sérieuse".\n\nEn l'espèce, le motif invoqué par l'employeur ne constitue pas une cause réelle et sérieuse de licenciement car {{argumentation}}.\n\nLe licenciement de {{client.nom}} est donc dépourvu de cause réelle et sérieuse.	{}	{L1232-1,licenciement,travail,moyens}	f	t	9	0	\N
cml88g74e002s521v7a2unise	2026-02-04 16:19:21.23	2026-02-04 16:19:21.23	cml88g71z0000521vp3t710u4	MOYENS	Article 835 CPC - Référé Provision	SUR LA PROVISION\n\nL'article 835 alinéa 2 du Code de procédure civile dispose que "le président du tribunal judiciaire peut accorder une provision au créancier dans le cas où l'obligation n'est pas sérieusement contestable".\n\nEn l'espèce, l'obligation de {{adversaire.nom}} n'est pas sérieusement contestable dès lors que :\n{{argumentation}}\n\nIl y a donc lieu d'accorder à {{client.nom}} une provision de {{montant}} euros.	{}	{article-835,refere,provision,moyens}	f	t	10	0	\N
cml88g74f002u521vpioir7p9	2026-02-04 16:19:21.232	2026-02-04 16:19:21.232	cml88g71z0000521vp3t710u4	MOYENS	Article 834 CPC - Référé Trouble Illicite	SUR LE TROUBLE MANIFESTEMENT ILLICITE\n\nL'article 834 du Code de procédure civile dispose que "le président du tribunal judiciaire peut toujours, même en présence d'une contestation sérieuse, prescrire en référé les mesures conservatoires ou de remise en état qui s'imposent, soit pour prévenir un dommage imminent, soit pour faire cesser un trouble manifestement illicite".\n\nEn l'espèce, {{adversaire.nom}} commet un trouble manifestement illicite en {{description_trouble}}.\n\nIl y a lieu d'ordonner {{mesure_sollicitee}}.	{}	{article-834,refere,trouble-illicite,moyens}	f	t	11	0	\N
cml88g74h002w521vdyx94cqg	2026-02-04 16:19:21.233	2026-02-04 16:19:21.233	cml88g71z0000521vp3t710u4	MOYENS	Article 1195 Code Civil - Imprévision	SUR L'IMPRÉVISION\n\nAux termes de l'article 1195 du Code civil, "si un changement de circonstances imprévisible lors de la conclusion du contrat rend l'exécution excessivement onéreuse pour une partie qui n'avait pas accepté d'en assumer le risque, celle-ci peut demander une renégociation du contrat à son cocontractant".\n\nEn l'espèce, {{evenement_imprevisible}} constitue un changement de circonstances imprévisible rendant l'exécution du contrat excessivement onéreuse pour {{client.nom}}.	{}	{article-1195,imprevision,moyens}	f	t	12	0	\N
cml88g74i002y521vv4nx38ek	2026-02-04 16:19:21.234	2026-02-04 16:19:21.234	cml88g71z0000521vp3t710u4	MOYENS	Article 1178 Code Civil - Nullité Contrat	SUR LA NULLITÉ DU CONTRAT\n\nL'article 1178 du Code civil dispose qu'"un contrat qui ne remplit pas les conditions requises pour sa validité est nul".\n\nEn l'espèce, le contrat est nul pour {{cause_nullite}} :\n{{argumentation}}\n\nLa nullité doit être prononcée avec toutes conséquences de droit.	{}	{article-1178,nullite,moyens}	f	t	13	0	\N
cml88g74j0030521vk54lrhrw	2026-02-04 16:19:21.236	2026-02-04 16:19:21.236	cml88g71z0000521vp3t710u4	MOYENS	Article 1143 Code Civil - Violence Économique	SUR LA VIOLENCE ÉCONOMIQUE\n\nL'article 1143 du Code civil dispose qu'"il y a également violence lorsqu'une partie, abusant de l'état de dépendance dans lequel se trouve son cocontractant à son égard, obtient de lui un engagement qu'il n'aurait pas souscrit en l'absence d'une telle contrainte et en tire un avantage manifestement excessif".\n\nEn l'espèce, {{adversaire.nom}} a abusé de l'état de dépendance de {{client.nom}} pour obtenir {{avantage_excessif}}.	{}	{article-1143,violence-economique,moyens}	f	t	14	0	\N
cml88g74k0032521v4qldymfa	2026-02-04 16:19:21.237	2026-02-04 16:19:21.237	cml88g71z0000521vp3t710u4	MOYENS	Article 1137 Code Civil - Dol	SUR LE DOL\n\nAux termes de l'article 1137 du Code civil, "le dol est le fait pour un contractant d'obtenir le consentement de l'autre par des manœuvres ou des mensonges" ou par "la dissimulation intentionnelle par l'un des contractants d'une information dont il sait le caractère déterminant pour l'autre partie".\n\nEn l'espèce, {{adversaire.nom}} a volontairement dissimulé/menti sur {{element_dolosif}}, information déterminante du consentement de {{client.nom}}.	{}	{article-1137,dol,moyens}	f	t	15	0	\N
cml88g74m0034521v22yipkfj	2026-02-04 16:19:21.238	2026-02-04 16:19:21.238	cml88g71z0000521vp3t710u4	MOYENS	Article 1104 Code Civil - Bonne Foi	SUR L'OBLIGATION DE BONNE FOI\n\nL'article 1104 du Code civil dispose que "les contrats doivent être négociés, formés et exécutés de bonne foi. Cette disposition est d'ordre public".\n\nEn l'espèce, {{adversaire.nom}} a manqué à son obligation de bonne foi en {{comportement_deloyal}}.\n\nCe comportement engage sa responsabilité contractuelle.	{}	{article-1104,bonne-foi,moyens}	f	t	16	0	\N
cml88g74n0036521vxi4yiay9	2026-02-04 16:19:21.239	2026-02-04 16:19:21.239	cml88g71z0000521vp3t710u4	MOYENS	Article 1112-1 Code Civil - Devoir Information	SUR LE DEVOIR D'INFORMATION PRÉCONTRACTUEL\n\nL'article 1112-1 du Code civil dispose que "celle des parties qui connaît une information dont l'importance est déterminante pour le consentement de l'autre doit l'en informer dès lors que, légitimement, cette dernière ignore cette information ou fait confiance à son cocontractant".\n\n{{adversaire.nom}} connaissait {{information_dissimilee}}, information déterminante, et n'en a pas informé {{client.nom}}.	{}	{article-1112-1,information,precontractuel,moyens}	f	t	17	0	\N
cml88g74o0038521valcanlgp	2026-02-04 16:19:21.24	2026-02-04 16:19:21.24	cml88g71z0000521vp3t710u4	MOYENS	Article L.217-4 Code Consommation - Conformité	SUR LE DÉFAUT DE CONFORMITÉ\n\nL'article L.217-4 du Code de la consommation impose au vendeur de "livrer un bien conforme au contrat et répond des défauts de conformité existant lors de la délivrance".\n\nLe produit livré n'est pas conforme car {{description_non_conformite}}.\n\n{{client.nom}} est en droit de demander {{option_consommateur}}.	{}	{L217-4,conformite,consommation,moyens}	f	t	18	0	\N
cml88g74r003a521vug41zhdp	2026-02-04 16:19:21.243	2026-02-04 16:19:21.243	cml88g71z0000521vp3t710u4	MOYENS	Article L.121-16 Code Consommation - Rétractation	SUR LE DROIT DE RÉTRACTATION\n\nL'article L.221-18 du Code de la consommation dispose que "le consommateur dispose d'un délai de quatorze jours pour exercer son droit de rétractation d'un contrat conclu à distance".\n\nEn l'espèce, {{client.nom}} a exercé son droit de rétractation dans le délai légal par {{moyen_retractation}} en date du {{date_retractation}}.\n\n{{adversaire.nom}} est tenu de rembourser l'intégralité des sommes versées.	{}	{L221-18,retractation,consommation,moyens}	f	t	19	0	\N
cml88g74s003c521vm7wva7mx	2026-02-04 16:19:21.245	2026-02-04 16:19:21.245	cml88g71z0000521vp3t710u4	MOYENS	Article 544 Code Civil - Droit Propriété	SUR L'ATTEINTE AU DROIT DE PROPRIÉTÉ\n\nL'article 544 du Code civil dispose que "la propriété est le droit de jouir et disposer des choses de la manière la plus absolue, pourvu qu'on n'en fasse pas un usage prohibé par les lois ou par les règlements".\n\nLes agissements de {{adversaire.nom}} constituent une atteinte au droit de propriété de {{client.nom}} en ce que {{atteinte}}.\n\nIl y a lieu d'ordonner la cessation de ces atteintes sous astreinte.	{}	{article-544,propriete,moyens}	f	t	20	0	\N
cml88g74t003e521vnn5tr2m6	2026-02-04 16:19:21.246	2026-02-04 16:19:21.246	cml88g71z0000521vp3t710u4	MOYENS	Trouble Anormal de Voisinage	SUR LE TROUBLE ANORMAL DE VOISINAGE\n\nLe principe selon lequel "nul ne doit causer à autrui un trouble anormal de voisinage" est un principe général du droit consacré par la jurisprudence.\n\nLa responsabilité fondée sur les troubles de voisinage est une responsabilité objective, indépendante de toute faute.\n\nEn l'espèce, les nuisances causées par {{adversaire.nom}} excèdent les inconvénients normaux du voisinage en raison de {{caractere_anormal}}.	{}	{voisinage,trouble-anormal,moyens}	f	t	21	0	\N
cml88g74u003g521vqo08divo	2026-02-04 16:19:21.247	2026-02-04 16:19:21.247	cml88g71z0000521vp3t710u4	MOYENS	Article L.713-2 CPI - Contrefaçon Marque	SUR LA CONTREFAÇON DE MARQUE\n\nL'article L.713-2 du Code de la propriété intellectuelle dispose que "sont interdits, sauf autorisation du titulaire de la marque, la reproduction, l'usage ou l'apposition d'une marque [...] pour des produits ou services identiques à ceux désignés dans l'enregistrement".\n\nEn l'espèce, {{adversaire.nom}} reproduit/imite la marque {{marque}} de {{client.nom}} sans autorisation, ce qui constitue un acte de contrefaçon.	{}	{L713-2,contrefacon,marque,moyens}	f	t	22	0	\N
cml88g74v003i521vmmpmjuzi	2026-02-04 16:19:21.248	2026-02-04 16:19:21.248	cml88g71z0000521vp3t710u4	MOYENS	Article L.122-4 CPI - Contrefaçon Droit Auteur	SUR LA CONTREFAÇON DE DROIT D'AUTEUR\n\nL'article L.122-4 du Code de la propriété intellectuelle dispose que "toute représentation ou reproduction intégrale ou partielle faite sans le consentement de l'auteur ou de ses ayants droit ou ayants cause est illicite".\n\nEn l'espèce, {{adversaire.nom}} a reproduit/représenté l'œuvre {{oeuvre}} de {{client.nom}} sans autorisation, ce qui constitue une contrefaçon.	{}	{L122-4,contrefacon,droit-auteur,moyens}	f	t	23	0	\N
cml88g74w003k521vqnwxh6jx	2026-02-04 16:19:21.249	2026-02-04 16:19:21.249	cml88g71z0000521vp3t710u4	MOYENS	Article 1242 alinéa 1 Code Civil - Responsabilité Fait Choses	SUR LA RESPONSABILITÉ DU FAIT DES CHOSES\n\nL'article 1242 alinéa 1 du Code civil dispose qu'"on est responsable non seulement du dommage que l'on cause par son propre fait, mais encore de celui qui est causé par le fait [...] des choses que l'on a sous sa garde".\n\n{{adversaire.nom}} était gardien de {{chose}} au moment des faits.\n\nCette chose a été l'instrument du dommage, ce qui engage la responsabilité de plein droit de son gardien.	{}	{article-1242,fait-des-choses,garde,moyens}	f	t	24	0	\N
cml88g74y003m521vrda4vsql	2026-02-04 16:19:21.25	2026-02-04 16:19:21.25	cml88g71z0000521vp3t710u4	MOYENS	Article 1242 alinéa 4 Code Civil - Responsabilité Employeur	SUR LA RESPONSABILITÉ DE L'EMPLOYEUR DU FAIT DE SES PRÉPOSÉS\n\nL'article 1242 alinéa 5 du Code civil dispose que "les maîtres et les commettants sont responsables du dommage causé par leurs domestiques et préposés dans les fonctions auxquelles ils les ont employés".\n\nLe dommage a été causé par {{prepose}}, salarié de {{commettant}}, dans l'exercice de ses fonctions.\n\n{{commettant}} est donc responsable de ce dommage.	{}	{article-1242,prepose,employeur,moyens}	f	t	25	0	\N
cml88g74z003o521vkcuy8rjx	2026-02-04 16:19:21.251	2026-02-04 16:19:21.251	cml88g71z0000521vp3t710u4	MOYENS	Article 145 CPC - Mesures Instruction In Futurum	SUR LA MESURE D'INSTRUCTION IN FUTURUM\n\nL'article 145 du Code de procédure civile dispose que "s'il existe un motif légitime de conserver ou d'établir avant tout procès la preuve de faits dont pourrait dépendre la solution d'un litige, les mesures d'instruction légalement admissibles peuvent être ordonnées à la demande de tout intéressé".\n\nEn l'espèce, {{client.nom}} justifie d'un motif légitime tenant à {{motif}}.\n\nLa mesure sollicitée est nécessaire pour préserver la preuve de {{elements}}.	{}	{article-145,instruction,in-futurum,moyens}	f	t	26	0	\N
cml88g750003q521v7mqyu8ii	2026-02-04 16:19:21.252	2026-02-04 16:19:21.252	cml88g71z0000521vp3t710u4	MOYENS	Article 700 CPC - Frais Irrépétibles	SUR LES FRAIS IRRÉPÉTIBLES\n\nL'article 700 du Code de procédure civile dispose que "le juge condamne la partie tenue aux dépens ou qui perd son procès à payer à l'autre partie la somme qu'il détermine, au titre des frais exposés et non compris dans les dépens".\n\nEn l'espèce, il serait inéquitable de laisser à la charge de {{client.nom}} les frais qu'il/elle a dû exposer pour assurer la défense de ses intérêts.\n\nIl est demandé la somme de {{montant}} euros à ce titre.	{}	{article-700,frais,moyens}	f	t	27	0	\N
cml88g751003s521v6xxyv3sd	2026-02-04 16:19:21.253	2026-02-04 16:19:21.253	cml88g71z0000521vp3t710u4	MOYENS	Article 514 CPC - Exécution Provisoire	SUR L'EXÉCUTION PROVISOIRE\n\nL'article 514 du Code de procédure civile dispose que "les décisions de première instance sont de droit exécutoires à titre provisoire".\n\nL'exécution provisoire de droit est pleinement justifiée en l'espèce au regard de {{motifs}}.\n\nIl n'y a pas lieu d'en écarter l'application.	{}	{article-514,execution-provisoire,moyens}	f	t	28	0	\N
cml88g752003u521vjtqs2ofo	2026-02-04 16:19:21.255	2026-02-04 16:19:21.255	cml88g71z0000521vp3t710u4	MOYENS	Astreinte	SUR L'ASTREINTE\n\nIl est demandé au Tribunal d'assortir la condamnation d'une astreinte de {{montant_astreinte}} euros par jour de retard à compter de la signification de la décision à intervenir.\n\nEn effet, il y a lieu de craindre que {{adversaire.nom}} n'exécute pas spontanément la décision, compte tenu de {{motifs_crainte}}.\n\nL'astreinte sollicitée est proportionnée à l'enjeu du litige.	{}	{astreinte,execution,moyens}	f	t	29	0	\N
cml88g754003w521vxofp30s6	2026-02-04 16:19:21.256	2026-02-04 16:19:21.256	cml88g71z0000521vp3t710u4	MOYENS	Article L.1152-1 Code Travail - Harcèlement Moral	SUR LE HARCÈLEMENT MORAL\n\nL'article L.1152-1 du Code du travail dispose qu'"aucun salarié ne doit subir les agissements répétés de harcèlement moral qui ont pour objet ou pour effet une dégradation de ses conditions de travail susceptible de porter atteinte à ses droits et à sa dignité, d'altérer sa santé physique ou mentale ou de compromettre son avenir professionnel".\n\n{{client.nom}} produit des éléments laissant supposer l'existence d'un harcèlement : {{elements_presumes}}.\n\nIl appartient à l'employeur de prouver que ces agissements ne sont pas constitutifs d'un tel harcèlement.	{}	{L1152-1,harcelement,travail,moyens}	f	t	30	0	\N
cml88g755003y521vm2oe88z5	2026-02-04 16:19:21.258	2026-02-04 16:19:21.258	cml88g71z0000521vp3t710u4	MOYENS	Article 1224 Code Civil - Résolution	SUR LA RÉSOLUTION DU CONTRAT\n\nL'article 1224 du Code civil dispose que "la résolution résulte soit de l'application d'une clause résolutoire soit, en cas d'inexécution suffisamment grave, d'une notification du créancier au débiteur ou d'une décision de justice".\n\nL'inexécution de {{adversaire.nom}} est suffisamment grave pour justifier la résolution judiciaire du contrat.\n\nEn effet, {{gravite_inexecution}}.	{}	{article-1224,resolution,moyens}	f	t	31	0	\N
cml88g7570040521vrlzlzzif	2026-02-04 16:19:21.259	2026-02-04 16:19:21.259	cml88g71z0000521vp3t710u4	MOYENS	Article 1347 Code Civil - Compensation	SUR LA COMPENSATION\n\nL'article 1347 du Code civil dispose que "la compensation est l'extinction simultanée d'obligations réciproques entre deux personnes".\n\nEn l'espèce, {{client.nom}} détient sur {{adversaire.nom}} une créance de {{montant_creance}} euros.\n\nPar ailleurs, {{adversaire.nom}} prétend détenir sur {{client.nom}} une créance de {{montant_dette}} euros.\n\nLa compensation légale s'opère de plein droit.	{}	{article-1347,compensation,moyens}	f	t	32	0	\N
cml88g75a0042521vqernntuk	2026-02-04 16:19:21.262	2026-02-04 16:19:21.262	cml88g71z0000521vp3t710u4	MOYENS	Prescription Acquisitive Immobilière	SUR LA PRESCRIPTION ACQUISITIVE\n\nAux termes de l'article 2258 du Code civil, "la prescription acquisitive est un moyen d'acquérir un bien ou un droit par l'effet de la possession sans que celui qui l'allègue soit obligé d'en rapporter un titre".\n\n{{client.nom}} possède le bien litigieux de manière continue, paisible, publique, non équivoque et à titre de propriétaire depuis plus de {{duree}} ans.\n\nLes conditions de la prescription acquisitive sont donc réunies.	{}	{prescription,acquisitive,immobilier,moyens}	f	t	33	0	\N
cml88g75c0044521vvmqcyp0a	2026-02-04 16:19:21.265	2026-02-04 16:19:21.265	cml88g71z0000521vp3t710u4	MOYENS	Article 2224 Code Civil - Prescription Extinctive	SUR LA PRESCRIPTION\n\nL'article 2224 du Code civil dispose que "les actions personnelles ou mobilières se prescrivent par cinq ans à compter du jour où le titulaire d'un droit a connu ou aurait dû connaître les faits lui permettant de l'exercer".\n\nEn l'espèce, l'action de {{adversaire.nom}} est prescrite dès lors que {{argumentation_prescription}}.\n\nL'action doit donc être déclarée irrecevable comme prescrite.	{}	{article-2224,prescription,extinctive,moyens}	f	t	34	0	\N
cml88g75d0046521vgatx1i7d	2026-02-04 16:19:21.266	2026-02-04 16:19:21.266	cml88g71z0000521vp3t710u4	MOYENS	Force Majeure	SUR LA FORCE MAJEURE\n\nL'article 1218 du Code civil dispose qu'"il y a force majeure en matière contractuelle lorsqu'un événement échappant au contrôle du débiteur, qui ne pouvait être raisonnablement prévu lors de la conclusion du contrat et dont les effets ne peuvent être évités par des mesures appropriées, empêche l'exécution de son obligation par le débiteur".\n\nEn l'espèce, {{evenement}} constitue un cas de force majeure car :\n- Il était imprévisible : {{demonstration_imprevisibilite}}\n- Il était irrésistible : {{demonstration_irresistibilite}}\n- Il était extérieur : {{demonstration_exteriorite}}	{}	{force-majeure,exoneration,moyens}	f	t	35	0	\N
cml88g75f0048521vwtm4gpmt	2026-02-04 16:19:21.267	2026-02-04 16:19:21.267	cml88g71z0000521vp3t710u4	MOYENS	Exception Inexécution	SUR L'EXCEPTION D'INEXÉCUTION\n\nL'article 1219 du Code civil dispose qu'"une partie peut refuser d'exécuter son obligation, alors même que celle-ci est exigible, si l'autre n'exécute pas la sienne et si cette inexécution est suffisamment grave".\n\nEn l'espèce, {{adversaire.nom}} n'a pas exécuté son obligation de {{obligation_adverse}}.\n\nCette inexécution est suffisamment grave pour justifier que {{client.nom}} suspende l'exécution de sa propre obligation.	{}	{exception-inexecution,moyens}	f	t	36	0	\N
cml88g75h004a521vw2uona5k	2026-02-04 16:19:21.269	2026-02-04 16:19:21.269	cml88g71z0000521vp3t710u4	MOYENS	Défaut Qualité Agir	SUR LE DÉFAUT DE QUALITÉ À AGIR\n\nL'article 31 du Code de procédure civile dispose que "l'action est ouverte à tous ceux qui ont un intérêt légitime au succès ou au rejet d'une prétention, sous réserve des cas dans lesquels la loi attribue le droit d'agir aux seules personnes qu'elle qualifie pour élever ou combattre une prétention".\n\nEn l'espèce, {{adversaire.nom}} n'a pas qualité à agir car {{argumentation}}.\n\nL'action doit être déclarée irrecevable.	{}	{qualite,recevabilite,moyens}	f	t	37	0	\N
cml88g75j004c521vng92fane	2026-02-04 16:19:21.271	2026-02-04 16:19:21.271	cml88g71z0000521vp3t710u4	MOYENS	Défaut Intérêt Agir	SUR LE DÉFAUT D'INTÉRÊT À AGIR\n\nL'article 31 du Code de procédure civile subordonne la recevabilité de l'action à l'existence d'un "intérêt légitime au succès ou au rejet d'une prétention".\n\nL'intérêt à agir doit être né, actuel, direct et personnel.\n\nEn l'espèce, {{adversaire.nom}} ne justifie d'aucun intérêt à agir car {{argumentation}}.	{}	{interet,recevabilite,moyens}	f	t	38	0	\N
cml88g75k004e521veylava8y	2026-02-04 16:19:21.272	2026-02-04 16:19:21.272	cml88g71z0000521vp3t710u4	MOYENS	Chose Jugée	SUR L'AUTORITÉ DE LA CHOSE JUGÉE\n\nL'article 1355 du Code civil dispose que "l'autorité de la chose jugée n'a lieu qu'à l'égard de ce qui a fait l'objet du jugement".\n\nIl faut identité de parties, de cause et d'objet.\n\nEn l'espèce, le litige a déjà été tranché par {{decision_anterieure}} rendue le {{date_decision}}.\n\nLes demandes de {{adversaire.nom}} se heurtent donc à l'autorité de la chose jugée.	{}	{chose-jugee,recevabilite,moyens}	f	t	39	0	\N
cml88g75m004g521vzxvig8n4	2026-02-04 16:19:21.274	2026-02-04 16:19:21.274	cml88g71z0000521vp3t710u4	MOYENS	Incompétence Territoriale	SUR L'INCOMPÉTENCE TERRITORIALE\n\nL'article 42 du Code de procédure civile dispose que "la juridiction territorialement compétente est, sauf disposition contraire, celle du lieu où demeure le défendeur".\n\nEn l'espèce, {{adversaire.nom}} a saisi le Tribunal Judiciaire de {{juridiction_saisie}} alors que le Tribunal compétent est celui de {{juridiction_competente}}.\n\nLe Tribunal devra se déclarer incompétent.	{}	{competence,territoriale,moyens}	f	t	40	0	\N
cml88g75o004i521vnxhpva0r	2026-02-04 16:19:21.276	2026-02-04 16:19:21.276	cml88g71z0000521vp3t710u4	DISPOSITIF	Condamnation Paiement Somme	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_principal}} € au titre de {{nature_creance}},\n\nASSORTIE des intérêts au taux légal à compter du {{date_interets}},\n\nCONDAMNER {{adversaire.nom}} aux dépens de l'instance,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_451}} € au titre de l'article 700 du Code de procédure civile.	{}	{condamnation,paiement,dispositif}	f	t	1	0	\N
cml88g75p004k521v49dd03ec	2026-02-04 16:19:21.278	2026-02-04 16:19:21.278	cml88g71z0000521vp3t710u4	DISPOSITIF	Résolution Contrat + Dommages-Intérêts	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nPRONONCER la résolution du contrat conclu le {{date_contrat}} entre les parties aux torts exclusifs de {{adversaire.nom}},\n\nCONDAMNER {{adversaire.nom}} à restituer à {{client.nom}} toutes les sommes perçues, soit {{montant_restitution}} €,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{resolution,dommages,dispositif}	f	t	2	0	\N
cml88g75r004m521v6u4xygzy	2026-02-04 16:19:21.279	2026-02-04 16:19:21.279	cml88g71z0000521vp3t710u4	DISPOSITIF	Nullité Contrat	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nPRONONCER la nullité du contrat conclu le {{date_contrat}} entre {{client.nom}} et {{adversaire.nom}},\n\nORDONNER les restitutions réciproques,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nCONDAMNER {{adversaire.nom}} aux dépens et aux frais irrépétibles.	{}	{nullite,dispositif}	f	t	3	0	\N
cml88g75s004o521vv8w12rz1	2026-02-04 16:19:21.281	2026-02-04 16:19:21.281	cml88g71z0000521vp3t710u4	DISPOSITIF	Exécution Forcée Obligation	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONDAMNER {{adversaire.nom}} à exécuter son obligation de {{obligation}} sous astreinte de {{montant_astreinte}} € par jour de retard à compter de la signification de la décision,\n\nSe réserver la liquidation de l'astreinte,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{execution-forcee,astreinte,dispositif}	f	t	4	0	\N
cml88g75u004q521vl5xdobqa	2026-02-04 16:19:21.282	2026-02-04 16:19:21.282	cml88g71z0000521vp3t710u4	DISPOSITIF	Référé Provision	PAR CES MOTIFS\n\nLe Président est prié de :\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} une provision de {{montant_provision}} € à valoir sur l'indemnisation de son préjudice,\n\nDIRE n'y avoir lieu à référé pour le surplus,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC,\n\nDIRE la présente ordonnance exécutoire de droit à titre provisoire.	{}	{refere,provision,dispositif}	f	t	5	0	\N
cml88g75w004s521vloj2amve	2026-02-04 16:19:21.284	2026-02-04 16:19:21.284	cml88g71z0000521vp3t710u4	DISPOSITIF	Référé Injonction	PAR CES MOTIFS\n\nLe Président est prié de :\n\nORDONNER à {{adversaire.nom}} de {{injonction}} sous astreinte de {{montant_astreinte}} € par jour de retard,\n\nDIRE que l'astreinte commencera à courir à l'expiration d'un délai de {{delai}} jours à compter de la signification de la présente ordonnance,\n\nSe réserver la liquidation de l'astreinte,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{refere,injonction,dispositif}	f	t	6	0	\N
cml88g75x004u521vu0n8ti2x	2026-02-04 16:19:21.286	2026-02-04 16:19:21.286	cml88g71z0000521vp3t710u4	DISPOSITIF	Expulsion + Arriérés	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONSTATER l'acquisition de la clause résolutoire,\n\nORDONNER l'expulsion de {{locataire}} et de tous occupants de son chef des locaux situés {{adresse}} avec le concours de la force publique si nécessaire,\n\nCONDAMNER {{locataire}} au paiement des arriérés de loyers et charges, soit {{montant_arrieres}} €,\n\nCONDAMNER {{locataire}} à une indemnité d'occupation égale au montant du loyer et des charges jusqu'à libération effective des lieux,\n\nCONDAMNER {{locataire}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{expulsion,bail,dispositif}	f	t	7	0	\N
cml88g75z004w521vg4ib6c8i	2026-02-04 16:19:21.288	2026-02-04 16:19:21.288	cml88g71z0000521vp3t710u4	DISPOSITIF	Licenciement Sans Cause	PAR CES MOTIFS\n\nLe Conseil de prud'hommes est prié de :\n\nDIRE ET JUGER le licenciement de {{client.nom}} sans cause réelle et sérieuse,\n\nCONDAMNER {{employeur}} à verser à {{client.nom}} les sommes suivantes :\n- {{montant_indemnite}} € à titre d'indemnité pour licenciement sans cause réelle et sérieuse,\n- {{montant_preavis}} € à titre d'indemnité compensatrice de préavis, outre {{montant_cp_preavis}} € au titre des congés payés afférents,\n- {{montant_licenciement}} € à titre d'indemnité légale/conventionnelle de licenciement,\n\nORDONNER la remise des documents de fin de contrat rectifiés sous astreinte,\n\nCONDAMNER {{employeur}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{licenciement,prudhommes,dispositif}	f	t	8	0	\N
cml88g761004y521v6sjjp8u8	2026-02-04 16:19:21.29	2026-02-04 16:19:21.29	cml88g71z0000521vp3t710u4	DISPOSITIF	Contrefaçon Marque	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDIRE ET JUGER que {{adversaire.nom}} s'est rendu coupable de contrefaçon de la marque {{marque}},\n\nINTERDIRE à {{adversaire.nom}} de fabriquer, importer, exporter, commercialiser tout produit portant cette marque, sous astreinte de {{montant_astreinte}} € par infraction constatée,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nORDONNER la publication de la décision dans {{publications}} aux frais de {{adversaire.nom}},\n\nCONDAMNER {{adversaire.nom}} aux dépens.	{}	{contrefacon,marque,dispositif}	f	t	9	0	\N
cml88g7620050521vb43702qf	2026-02-04 16:19:21.291	2026-02-04 16:19:21.291	cml88g71z0000521vp3t710u4	DISPOSITIF	Vice Caché Rédhibitoire	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nÀ titre principal :\nPRONONCER la résolution de la vente intervenue le {{date_vente}},\nCONDAMNER {{vendeur}} à restituer le prix de vente de {{prix}} €,\n\nÀ titre subsidiaire :\nCONDAMNER {{vendeur}} à verser une réduction de prix de {{montant_reduction}} €,\n\nEn tout état de cause :\nCONDAMNER {{vendeur}} à payer {{montant_di}} € de dommages-intérêts,\nCONDAMNER {{vendeur}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{vice-cache,vente,dispositif}	f	t	10	0	\N
cml88g7640052521vvh2mk93d	2026-02-04 16:19:21.292	2026-02-04 16:19:21.292	cml88g71z0000521vp3t710u4	DISPOSITIF	Responsabilité Décennale	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDÉCLARER {{constructeur}} responsable des désordres affectant l'ouvrage sur le fondement de l'article 1792 du Code civil,\n\nCONDAMNER {{constructeur}} et son assureur {{assureur}} in solidum à payer à {{client.nom}} :\n- {{montant_travaux}} € au titre des travaux de reprise,\n- {{montant_prejudice}} € au titre du préjudice de jouissance,\n\nCONDAMNER {{constructeur}} aux dépens incluant les frais d'expertise.	{}	{decennale,construction,dispositif}	f	t	11	0	\N
cml88g7660054521v46czgzp0	2026-02-04 16:19:21.295	2026-02-04 16:19:21.295	cml88g71z0000521vp3t710u4	DISPOSITIF	Troubles Voisinage	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONSTATER l'existence de troubles anormaux de voisinage,\n\nCONDAMNER {{adversaire.nom}} à faire cesser les troubles sous astreinte de {{montant_astreinte}} € par jour de retard,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € en réparation du préjudice subi,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{voisinage,troubles,dispositif}	f	t	12	0	\N
cml88g7680056521vngkypdpd	2026-02-04 16:19:21.296	2026-02-04 16:19:21.296	cml88g71z0000521vp3t710u4	DISPOSITIF	Divorce Consentement Mutuel	PAR CES MOTIFS\n\nLe Juge aux affaires familiales est prié de :\n\nHOMOLOGUER la convention de divorce réglant les conséquences du divorce,\n\nPRONONCER le divorce aux torts partagés / pour altération définitive du lien conjugal,\n\nCONSTATER l'accord des époux sur {{points_accord}},\n\nDIRE que chaque partie conservera la charge de ses propres dépens.	{}	{divorce,famille,dispositif}	f	t	13	0	\N
cml88g7690058521vzphzl4s0	2026-02-04 16:19:21.297	2026-02-04 16:19:21.297	cml88g71z0000521vp3t710u4	DISPOSITIF	Garde Enfants	PAR CES MOTIFS\n\nLe Juge aux affaires familiales est prié de :\n\nFIXER la résidence habituelle de l'enfant {{enfant.nom}} au domicile de {{parent_gardien}},\n\nFIXER le droit de visite et d'hébergement de {{autre_parent}} comme suit : {{modalites_dvh}},\n\nFIXER la contribution à l'entretien et à l'éducation de l'enfant à la somme de {{montant_pension}} € par mois,\n\nDIRE que cette contribution sera indexée sur l'indice des prix à la consommation.	{}	{garde,enfants,famille,dispositif}	f	t	14	0	\N
cml88g76a005a521v98d71u0x	2026-02-04 16:19:21.299	2026-02-04 16:19:21.299	cml88g71z0000521vp3t710u4	DISPOSITIF	Rupture Brutale Relations Commerciales	PAR CES MOTIFS\n\nLe Tribunal de commerce est prié de :\n\nDIRE ET JUGER que {{adversaire.nom}} a rompu brutalement les relations commerciales établies avec {{client.nom}},\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} :\n- {{montant_marge}} € au titre de la perte de marge brute sur la durée du préavis insuffisant,\n- {{montant_frais}} € au titre des frais de reconversion,\n\nCONDAMNER {{adversaire.nom}} aux dépens et à payer {{montant_451}} € au titre de l'article 700 CPC.	{}	{rupture-brutale,commercial,dispositif}	f	t	15	0	\N
cml88g76c005c521vv9uuxa1g	2026-02-04 16:19:21.3	2026-02-04 16:19:21.3	cml88g71z0000521vp3t710u4	DISPOSITIF	Mesures Conservatoires	PAR CES MOTIFS\n\nLe Juge de l'exécution est prié de :\n\nAUTORISER {{client.nom}} à pratiquer une saisie conservatoire sur les comptes bancaires de {{adversaire.nom}}, jusqu'à concurrence de {{montant}} €,\n\nDIRE que la présente ordonnance sera caduque si l'assignation au fond n'est pas délivrée dans le mois de son exécution,\n\nDISPENSER le requérant de la signification préalable de la présente ordonnance.	{}	{saisie,conservatoire,dispositif}	f	t	16	0	\N
cml88g76d005e521vh5p6crja	2026-02-04 16:19:21.302	2026-02-04 16:19:21.302	cml88g71z0000521vp3t710u4	DISPOSITIF	Mesure Expertise	PAR CES MOTIFS\n\nLe Président / Le Tribunal est prié de :\n\nORDONNER une mesure d'expertise judiciaire,\n\nDÉSIGNER tel expert qu'il plaira avec mission de :\n{{missions_expert}}\n\nFIXER la provision à consigner à la somme de {{provision}} €,\n\nDIRE que l'expert déposera son rapport dans un délai de {{delai}} mois.	{}	{expertise,judiciaire,dispositif}	f	t	17	0	\N
cml88g76f005g521vdzx22fub	2026-02-04 16:19:21.304	2026-02-04 16:19:21.304	cml88g71z0000521vp3t710u4	DISPOSITIF	Concurrence Déloyale	PAR CES MOTIFS\n\nLe Tribunal de commerce est prié de :\n\nDIRE ET JUGER que {{adversaire.nom}} a commis des actes de concurrence déloyale au préjudice de {{client.nom}},\n\nCONDAMNER {{adversaire.nom}} à cesser ses agissements sous astreinte,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_di}} € à titre de dommages-intérêts,\n\nORDONNER la publication de la décision aux frais de {{adversaire.nom}}.	{}	{concurrence,deloyale,dispositif}	f	t	18	0	\N
cml88g76h005i521v6w4l3u8n	2026-02-04 16:19:21.305	2026-02-04 16:19:21.305	cml88g71z0000521vp3t710u4	DISPOSITIF	Débouté	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDÉCLARER {{adversaire.nom}} mal fondé en l'ensemble de ses demandes,\n\nL'EN DÉBOUTER purement et simplement,\n\nCONDAMNER {{adversaire.nom}} aux dépens de l'instance,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_451}} € au titre de l'article 700 du Code de procédure civile.	{}	{debout,defense,dispositif}	f	t	19	0	\N
cml88g76i005k521v9uj0qoec	2026-02-04 16:19:21.307	2026-02-04 16:19:21.307	cml88g71z0000521vp3t710u4	DISPOSITIF	Sursis à Statuer	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nORDONNER le sursis à statuer dans l'attente de {{evenement_attendu}},\n\nRENVOYER l'affaire à une audience de mise en état ultérieure,\n\nRÉSERVER les dépens.	{}	{sursis,procedure,dispositif}	f	t	20	0	\N
cml88g76k005m521vth4y5cgb	2026-02-04 16:19:21.308	2026-02-04 16:19:21.308	cml88g71z0000521vp3t710u4	DISPOSITIF	Jonction Instances	PAR CES MOTIFS\n\nLe Juge de la mise en état est prié de :\n\nORDONNER la jonction des instances RG nº {{rg_1}} et RG nº {{rg_2}},\n\nDIRE que l'affaire se poursuivra sous le numéro RG {{rg_principal}}.	{}	{jonction,procedure,dispositif}	f	t	21	0	\N
cml88g76l005o521va5a3suh9	2026-02-04 16:19:21.309	2026-02-04 16:19:21.309	cml88g71z0000521vp3t710u4	DISPOSITIF	Irrecevabilité	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nDÉCLARER l'action de {{adversaire.nom}} irrecevable pour {{motif_irrecevabilite}},\n\nCONDAMNER {{adversaire.nom}} aux dépens de l'instance,\n\nCONDAMNER {{adversaire.nom}} à payer à {{client.nom}} la somme de {{montant_451}} € au titre de l'article 700 du Code de procédure civile.	{}	{irrecevabilite,fin-non-recevoir,dispositif}	f	t	22	0	\N
cml88g76n005q521vkfmxy3ur	2026-02-04 16:19:21.311	2026-02-04 16:19:21.311	cml88g71z0000521vp3t710u4	DISPOSITIF	Radiation	PAR CES MOTIFS\n\nLe Juge de la mise en état est prié de :\n\nCONSTATER que {{partie_defaillante}} n'a pas accompli les diligences mises à sa charge,\n\nORDONNER la radiation de l'affaire du rôle,\n\nRÉSERVER les dépens.	{}	{radiation,procedure,dispositif}	f	t	23	0	\N
cml88g76o005s521va9wne6nq	2026-02-04 16:19:21.313	2026-02-04 16:19:21.313	cml88g71z0000521vp3t710u4	DISPOSITIF	Caducité Citation	PAR CES MOTIFS\n\nLe Tribunal est prié de :\n\nCONSTATER la caducité de la citation délivrée le {{date_citation}},\n\nCONSTATER en conséquence l'extinction de l'instance,\n\nCONDAMNER {{demandeur}} aux dépens.	{}	{caducite,procedure,dispositif}	f	t	24	0	\N
cml88g76r005w521vt9s0x3d0	2026-02-04 16:19:21.316	2026-02-04 16:19:21.316	cml88g71z0000521vp3t710u4	CLAUSE	Clause Résolutoire Standard	CLAUSE RÉSOLUTOIRE\n\nLe présent contrat sera résilié de plein droit, un mois après mise en demeure restée sans effet, en cas de manquement par l'une des parties à l'une quelconque de ses obligations.\n\nLa résiliation prendra effet à la date indiquée dans la mise en demeure.\n\nCette résiliation s'effectuera sans préjudice de tous dommages et intérêts auxquels la partie lésée pourrait prétendre.	{}	{clause,resolutoire,contrat}	f	t	1	0	\N
cml88g76t005y521v8gj9u0yc	2026-02-04 16:19:21.318	2026-02-04 16:19:21.318	cml88g71z0000521vp3t710u4	CLAUSE	Clause Attributive de Juridiction	ATTRIBUTION DE JURIDICTION\n\nTout litige relatif à la formation, l'exécution ou l'interprétation du présent contrat sera soumis à la compétence exclusive du Tribunal de Commerce / Tribunal Judiciaire de {{ville}}.\n\nCette clause s'applique même en cas de référé, de pluralité de défendeurs ou d'appel en garantie.	{}	{clause,competence,juridiction}	f	t	2	0	\N
cml88g76v0060521vx13ab0zi	2026-02-04 16:19:21.319	2026-02-04 16:19:21.319	cml88g71z0000521vp3t710u4	CLAUSE	Clause Compromissoire Arbitrage	CLAUSE COMPROMISSOIRE\n\nTous les litiges auxquels le présent contrat pourrait donner lieu, concernant tant sa validité, son interprétation, son exécution, sa résolution, leurs conséquences et leurs suites, seront soumis à arbitrage conformément au Règlement d'arbitrage de {{organisme_arbitrage}}.\n\nL'arbitrage sera conduit par {{nombre}} arbitre(s) désigné(s) conformément au Règlement.\n\nLe siège de l'arbitrage sera fixé à {{ville}}.\n\nLa langue de l'arbitrage sera le français.	{}	{clause,arbitrage,compromissoire}	f	t	3	0	\N
cml88g76w0062521v8vd848jy	2026-02-04 16:19:21.32	2026-02-04 16:19:21.32	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Confidentialité	CONFIDENTIALITÉ\n\nLes parties s'engagent à considérer comme strictement confidentielles et à ne pas divulguer à des tiers, pendant la durée du contrat et pendant une période de {{duree}} ans après son terme, les informations de toute nature, commerciales, industrielles, techniques, financières, nominatives, dont elles pourraient avoir connaissance dans le cadre du présent contrat.\n\nCette obligation de confidentialité ne s'applique pas aux informations qui :\n- sont ou deviennent publiques sans faute de la partie réceptrice ;\n- sont reçues licitement d'un tiers autorisé à les divulguer ;\n- doivent être divulguées en vertu de la loi ou d'une décision de justice.	{}	{clause,confidentialite,contrat}	f	t	4	0	\N
cml88g76y0064521vhcbw3dwv	2026-02-04 16:19:21.322	2026-02-04 16:19:21.322	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Non-Concurrence	NON-CONCURRENCE\n\n{{partie_obligee}} s'engage à ne pas exercer, directement ou indirectement, une activité concurrente de celle de {{beneficiaire}} pendant une durée de {{duree}} à compter de la fin du présent contrat.\n\nCette interdiction s'applique dans le secteur géographique suivant : {{zone_geographique}}.\n\nEn contrepartie de cette obligation, {{beneficiaire}} versera à {{partie_obligee}} une indemnité de {{montant}} €.\n\nToute violation de cette clause entraînera le versement d'une indemnité forfaitaire de {{penalite}} € par infraction constatée, sans préjudice de tous dommages et intérêts.	{}	{clause,non-concurrence,contrat}	f	t	5	0	\N
cml88g7700066521vu500prh2	2026-02-04 16:19:21.324	2026-02-04 16:19:21.324	cml88g71z0000521vp3t710u4	CLAUSE	Clause Pénale	CLAUSE PÉNALE\n\nEn cas d'inexécution par l'une des parties de l'une quelconque de ses obligations au titre du présent contrat, cette partie sera redevable de plein droit, après mise en demeure restée infructueuse pendant {{delai}} jours, d'une pénalité forfaitaire de {{montant}} €, sans préjudice de tous dommages et intérêts complémentaires que pourrait réclamer la partie lésée.\n\nCette pénalité est due sans qu'il soit nécessaire de prouver l'existence ou l'étendue d'un quelconque préjudice.	{}	{clause,penale,contrat}	f	t	6	0	\N
cml88g7710068521vba2az4lz	2026-02-04 16:19:21.326	2026-02-04 16:19:21.326	cml88g71z0000521vp3t710u4	CLAUSE	Clause Limitative Responsabilité	LIMITATION DE RESPONSABILITÉ\n\nLa responsabilité de {{partie}} au titre du présent contrat ne pourra excéder {{montant_ou_pourcentage}}.\n\nCette limitation de responsabilité ne s'applique pas :\n- en cas de faute lourde ou dolosive ;\n- en cas de décès ou de dommage corporel ;\n- aux obligations essentielles du contrat.\n\nEn aucun cas {{partie}} ne pourra être tenu responsable des dommages indirects, tels que perte de données, perte d'exploitation, manque à gagner ou atteinte à l'image.	{}	{clause,responsabilite,limitation}	f	t	7	0	\N
cml88g773006a521vosb3jek6	2026-02-04 16:19:21.327	2026-02-04 16:19:21.327	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Force Majeure	FORCE MAJEURE\n\nAucune partie ne sera responsable d'un retard ou d'une inexécution de ses obligations résultant d'un cas de force majeure au sens de l'article 1218 du Code civil.\n\nSont notamment considérés comme cas de force majeure : les catastrophes naturelles, les guerres, les grèves, les pannes d'électricité ou de télécommunications, les épidémies, les décisions gouvernementales.\n\nLa partie affectée devra notifier l'autre partie dans un délai de {{delai}} jours et prendre toutes mesures pour limiter les effets de la force majeure.\n\nSi la force majeure persiste au-delà de {{duree}}, chaque partie pourra résilier le contrat sans indemnité.	{}	{clause,force-majeure,contrat}	f	t	8	0	\N
cml88g774006c521v4xmlpe5t	2026-02-04 16:19:21.328	2026-02-04 16:19:21.328	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Propriété Intellectuelle	PROPRIÉTÉ INTELLECTUELLE\n\nSauf stipulation expresse contraire, les droits de propriété intellectuelle relatifs aux {{creations}} créés dans le cadre du présent contrat sont et demeurent la propriété exclusive de {{titulaire}}.\n\n{{autre_partie}} ne pourra utiliser ces créations que dans le cadre strict de l'exécution du présent contrat.\n\nToute utilisation non autorisée constituerait une contrefaçon engageant la responsabilité de {{autre_partie}}.	{}	{clause,propriete-intellectuelle,contrat}	f	t	9	0	\N
cml88g775006e521vekwesynh	2026-02-04 16:19:21.33	2026-02-04 16:19:21.33	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Cession Droits Auteur	CESSION DE DROITS D'AUTEUR\n\n{{cedant}} cède à {{cessionnaire}}, à titre {{exclusif_non_exclusif}}, l'ensemble des droits patrimoniaux d'auteur portant sur {{oeuvre}}, à savoir :\n\n- le droit de reproduction sur tout support connu ou inconnu à ce jour ;\n- le droit de représentation par tout moyen connu ou inconnu à ce jour ;\n- le droit de modification, adaptation, traduction ;\n- le droit de commercialisation et d'exploitation.\n\nCette cession est consentie pour le monde entier et pour la durée légale de protection du droit d'auteur.\n\nEn contrepartie de cette cession, {{cessionnaire}} versera à {{cedant}} la somme de {{montant}} €.	{}	{clause,droit-auteur,cession}	f	t	10	0	\N
cml88g776006g521vczih4opl	2026-02-04 16:19:21.331	2026-02-04 16:19:21.331	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Prix	PRIX ET MODALITÉS DE PAIEMENT\n\nLe prix de {{prestation_bien}} est fixé à {{montant}} € HT, soit {{montant_ttc}} € TTC au taux de TVA de {{taux_tva}}%.\n\nCe prix sera payable selon les modalités suivantes : {{modalites_paiement}}.\n\nTout retard de paiement entraînera de plein droit :\n- l'exigibilité d'intérêts de retard au taux de {{taux}}% ;\n- une indemnité forfaitaire pour frais de recouvrement de {{indemnite}} €.	{}	{clause,prix,paiement}	f	t	11	0	\N
cml88g778006i521vhwofeyni	2026-02-04 16:19:21.332	2026-02-04 16:19:21.332	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Révision Prix	RÉVISION DE PRIX\n\nLe prix sera révisé annuellement à la date anniversaire du contrat selon la formule suivante :\n\nP1 = P0 x (I1/I0)\n\nOù :\n- P0 est le prix initial\n- P1 est le prix révisé\n- I0 est l'indice {{indice}} publié à la date de signature\n- I1 est le dernier indice {{indice}} connu à la date de révision\n\nEn cas de disparition de l'indice de référence, les parties conviendront d'un nouvel indice de remplacement.	{}	{clause,revision,prix}	f	t	12	0	\N
cml88g779006k521v24zbwjjd	2026-02-04 16:19:21.334	2026-02-04 16:19:21.334	cml88g71z0000521vp3t710u4	CLAUSE	Clause Réserve Propriété	RÉSERVE DE PROPRIÉTÉ\n\n{{vendeur}} se réserve la propriété des biens vendus jusqu'au paiement intégral du prix, en principal et accessoires.\n\nÀ défaut de paiement à l'échéance, {{vendeur}} pourra revendiquer les biens vendus et en reprendre possession.\n\n{{acheteur}} s'engage à :\n- assurer les biens contre tous risques ;\n- permettre l'accès à ses locaux pour la reprise des biens ;\n- ne pas céder ou nantir les biens.	{}	{clause,reserve-propriete,vente}	f	t	13	0	\N
cml88g77c006m521v0nboakt3	2026-02-04 16:19:21.336	2026-02-04 16:19:21.336	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Garantie	GARANTIE\n\n{{garant}} garantit {{beneficiaire}} contre tout défaut de {{objet_garantie}} pendant une durée de {{duree}} à compter de {{point_depart}}.\n\nCette garantie couvre {{etendue_garantie}}.\n\nPour bénéficier de cette garantie, {{beneficiaire}} devra notifier le défaut par écrit dans un délai de {{delai}} jours suivant sa découverte.\n\n{{garant}} s'engage à remédier au défaut par {{modalites_reparation}} dans un délai de {{delai_reparation}}.	{}	{clause,garantie,contrat}	f	t	14	0	\N
cml88g77d006o521vnpxcsbqw	2026-02-04 16:19:21.337	2026-02-04 16:19:21.337	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Non-Sollicitation	NON-SOLLICITATION\n\nPendant la durée du contrat et pendant une période de {{duree}} suivant son terme, chaque partie s'interdit de solliciter, embaucher ou faire travailler, directement ou indirectement, tout collaborateur de l'autre partie ayant participé à l'exécution du présent contrat.\n\nEn cas de manquement à cette obligation, la partie défaillante sera redevable d'une indemnité forfaitaire de {{montant}} €.	{}	{clause,non-sollicitation,personnel}	f	t	15	0	\N
cml88g77e006q521vasv633sj	2026-02-04 16:19:21.338	2026-02-04 16:19:21.338	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Médiation Préalable	MÉDIATION PRÉALABLE\n\nEn cas de différend relatif au présent contrat, les parties s'engagent à tenter de résoudre leur litige à l'amiable par voie de médiation avant toute action judiciaire.\n\nLa médiation sera confiée à {{mediateur_ou_organisme}}.\n\nLe processus de médiation ne pourra excéder {{duree}}.\n\nLes frais de médiation seront partagés par moitié entre les parties.\n\nÀ défaut d'accord dans ce délai, les parties retrouveront leur liberté de saisir les tribunaux compétents.	{}	{clause,mediation,reglement-litiges}	f	t	16	0	\N
cml88g77f006s521vbajjdscw	2026-02-04 16:19:21.339	2026-02-04 16:19:21.339	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Intuitu Personae	INTUITU PERSONAE\n\nLe présent contrat est conclu en considération de la personne de {{partie}}, en raison de {{qualites}}.\n\nEn conséquence, {{partie}} ne pourra céder ou transférer le bénéfice du présent contrat à un tiers sans l'accord préalable et écrit de {{autre_partie}}.\n\nTout changement de contrôle de {{partie}} devra être notifié à {{autre_partie}} qui pourra résilier le contrat de plein droit dans un délai de {{delai}} jours suivant cette notification.	{}	{clause,intuitu-personae,contrat}	f	t	17	0	\N
cml88g77h006u521vpb2903gs	2026-02-04 16:19:21.341	2026-02-04 16:19:21.341	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Divisibilité	DIVISIBILITÉ\n\nSi l'une quelconque des dispositions du présent contrat était déclarée nulle ou inapplicable, cette nullité ou inapplicabilité n'affecterait pas les autres dispositions qui demeureront en vigueur.\n\nLes parties s'efforceront, dans la mesure du possible, de remplacer la disposition nulle ou inapplicable par une disposition valide et applicable ayant un effet économique aussi proche que possible de la disposition initiale.	{}	{clause,divisibilite,nullite}	f	t	18	0	\N
cml88g77j006w521vw7jp2ffd	2026-02-04 16:19:21.343	2026-02-04 16:19:21.343	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Renonciation	RENONCIATION\n\nLe fait pour l'une des parties de ne pas se prévaloir d'un manquement par l'autre partie à l'une quelconque des obligations visées dans le présent contrat ne saurait être interprété comme une renonciation à l'obligation en cause.\n\nUne telle tolérance ne pourra en aucun cas créer un droit acquis au profit de la partie défaillante.	{}	{clause,renonciation,tolerance}	f	t	19	0	\N
cml88g77l006y521vxmfs9mwk	2026-02-04 16:19:21.345	2026-02-04 16:19:21.345	cml88g71z0000521vp3t710u4	CLAUSE	Clause Entire Agreement	INTÉGRALITÉ DE L'ACCORD\n\nLe présent contrat constitue l'intégralité de l'accord entre les parties et annule et remplace tous accords, propositions ou déclarations antérieurs, écrits ou verbaux, relatifs à son objet.\n\nAucune modification du présent contrat ne sera valable si elle n'est pas établie par écrit et signée par les deux parties.	{}	{clause,integralite,accord}	f	t	20	0	\N
cml88g77m0070521vf650ciug	2026-02-04 16:19:21.347	2026-02-04 16:19:21.347	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Durée et Reconduction	DURÉE - RECONDUCTION\n\nLe présent contrat est conclu pour une durée de {{duree_initiale}} à compter de sa signature.\n\nÀ l'issue de cette période initiale, le contrat sera reconduit tacitement pour des périodes successives de {{duree_reconduction}}, sauf dénonciation par l'une des parties notifiée par lettre recommandée avec accusé de réception {{delai_preavis}} avant le terme de la période en cours.	{}	{clause,duree,reconduction}	f	t	21	0	\N
cml88g77o0072521vj2000jc9	2026-02-04 16:19:21.348	2026-02-04 16:19:21.348	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Résiliation pour Convenance	RÉSILIATION POUR CONVENANCE\n\nChaque partie pourra résilier le présent contrat à tout moment et sans avoir à justifier d'aucun motif, moyennant un préavis de {{duree_preavis}} notifié par lettre recommandée avec accusé de réception.\n\nEn cas de résiliation, {{prestataire}} aura droit au paiement des prestations déjà réalisées et des frais engagés.	{}	{clause,resiliation,convenance}	f	t	22	0	\N
cml88g77q0074521vtn13uxbe	2026-02-04 16:19:21.35	2026-02-04 16:19:21.35	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Assurance	ASSURANCE\n\n{{partie}} s'engage à souscrire et à maintenir en vigueur pendant toute la durée du contrat une assurance responsabilité civile professionnelle auprès d'une compagnie notoirement solvable couvrant les conséquences de sa responsabilité civile pour un montant minimum de {{montant}} € par sinistre.\n\n{{partie}} s'engage à fournir à première demande une attestation d'assurance justifiant de cette couverture.	{}	{clause,assurance,rc-pro}	f	t	23	0	\N
cml88g77t0076521vln3abr3d	2026-02-04 16:19:21.354	2026-02-04 16:19:21.354	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Données Personnelles RGPD	DONNÉES PERSONNELLES\n\nLes parties s'engagent à respecter la réglementation applicable en matière de protection des données personnelles, notamment le Règlement (UE) 2016/679 (RGPD).\n\n{{responsable_traitement}} agit en qualité de responsable du traitement pour les données collectées dans le cadre du présent contrat.\n\n{{sous_traitant}} s'engage à :\n- ne traiter les données que sur instruction documentée ;\n- garantir la confidentialité des données ;\n- assister {{responsable_traitement}} pour répondre aux demandes d'exercice des droits ;\n- notifier toute violation de données dans un délai de 72 heures ;\n- supprimer ou restituer les données au terme du contrat.	{}	{clause,rgpd,donnees-personnelles}	f	t	24	0	\N
cml88g77v0078521vzljfizp7	2026-02-04 16:19:21.355	2026-02-04 16:19:21.355	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Sous-Traitance	SOUS-TRAITANCE\n\n{{prestataire}} pourra faire appel à des sous-traitants pour l'exécution du présent contrat.\n\n{{prestataire}} restera seul responsable de la bonne exécution du contrat vis-à-vis de {{client}}.\n\n{{prestataire}} s'engage à ce que ses sous-traitants respectent les mêmes obligations que celles auxquelles il est lui-même soumis.\n\n{{mention_eventuelle_autorisation}}.	{}	{clause,sous-traitance,prestation}	f	t	25	0	\N
cml88g77w007a521vc1kn77nq	2026-02-04 16:19:21.357	2026-02-04 16:19:21.357	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Notification	NOTIFICATIONS\n\nToute notification entre les parties devra être faite par écrit et sera considérée comme valablement effectuée :\n- si elle est remise en main propre, à la date de remise ;\n- si elle est envoyée par lettre recommandée avec accusé de réception, à la date de première présentation ;\n- si elle est envoyée par email, à la date d'envoi avec confirmation de réception.\n\nLes notifications seront adressées aux coordonnées suivantes :\n{{coordonnees_parties}}	{}	{clause,notification,formalisme}	f	t	26	0	\N
cml88g77x007c521vkiqqh47f	2026-02-04 16:19:21.358	2026-02-04 16:19:21.358	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Audit	DROIT D'AUDIT\n\n{{beneficiaire}} aura le droit, à ses frais et moyennant un préavis de {{delai}} jours ouvrables, de procéder ou de faire procéder par un tiers de son choix à un audit des registres, documents et systèmes de {{partie_auditee}} relatifs à l'exécution du présent contrat.\n\n{{partie_auditee}} s'engage à coopérer pleinement à tout audit et à fournir toutes les informations nécessaires.\n\nL'audit sera réalisé pendant les heures ouvrables et dans le respect de la confidentialité.	{}	{clause,audit,controle}	f	t	27	0	\N
cml88g77z007e521vpcr0f7xf	2026-02-04 16:19:21.359	2026-02-04 16:19:21.359	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Compliance	CONFORMITÉ RÉGLEMENTAIRE\n\nChaque partie s'engage à respecter l'ensemble des dispositions légales et réglementaires applicables à son activité, notamment en matière de :\n- lutte contre la corruption (Loi Sapin II) ;\n- devoir de vigilance ;\n- droit de la concurrence ;\n- réglementation environnementale.\n\nChaque partie garantit l'autre contre toute réclamation qui pourrait résulter d'un manquement à ces obligations.	{}	{clause,compliance,conformite}	f	t	28	0	\N
cml88g780007g521vxoj1jk9a	2026-02-04 16:19:21.36	2026-02-04 16:19:21.36	cml88g71z0000521vp3t710u4	CLAUSE	Clause Anti-Corruption	ANTI-CORRUPTION\n\nLes parties déclarent avoir pris connaissance de et s'engagent à respecter la réglementation anti-corruption applicable, notamment la loi nº 2016-1691 du 9 décembre 2016 dite "Sapin II".\n\nChaque partie s'interdit de proposer, promettre, accorder ou solliciter, directement ou indirectement, tout avantage indu à un agent public ou à toute personne privée en vue d'obtenir ou conserver un marché ou tout autre avantage.\n\nTout manquement à cette obligation constituera une cause de résiliation immédiate du contrat aux torts exclusifs de la partie défaillante.	{}	{clause,anti-corruption,sapin-2}	f	t	29	0	\N
cml88g781007i521v2qw1dvop	2026-02-04 16:19:21.362	2026-02-04 16:19:21.362	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Non-Débauchage	NON-DÉBAUCHAGE\n\nPendant la durée du contrat et pendant une période de {{duree}} ans suivant son terme, chaque partie s'interdit de :\n\n- débaucher tout salarié de l'autre partie ayant participé à l'exécution du présent contrat ;\n- embaucher un tel salarié dans un délai de {{delai}} mois suivant son départ de l'autre partie.\n\nEn cas de manquement, la partie défaillante versera à l'autre une indemnité forfaitaire égale à {{mois}} mois de la rémunération brute du salarié concerné.	{}	{clause,non-debauchage,personnel}	f	t	30	0	\N
cml88g782007k521v6y7ysft3	2026-02-04 16:19:21.363	2026-02-04 16:19:21.363	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Sortie Associé	CLAUSE DE SORTIE\n\nEn cas de désaccord persistant entre les associés sur {{sujets}}, chaque associé pourra proposer d'acquérir les parts de l'autre associé ou de lui céder les siennes.\n\nL'associé destinataire de l'offre disposera d'un délai de {{delai}} pour accepter soit de vendre ses parts, soit d'acquérir les parts de l'autre aux mêmes conditions.\n\nÀ défaut de réponse dans ce délai, l'offre sera caduque.	{}	{clause,sortie,associes}	f	t	31	0	\N
cml88g784007m521vjnok7juu	2026-02-04 16:19:21.364	2026-02-04 16:19:21.364	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Drag-Along	CLAUSE D'ENTRAÎNEMENT (DRAG-ALONG)\n\nEn cas de cession par les Associés Majoritaires (détenant au moins {{pourcentage}}% du capital) de l'intégralité de leurs parts à un tiers, les Associés Minoritaires s'engagent irrévocablement à céder l'intégralité de leurs parts au même cessionnaire, dans les mêmes conditions de prix et de modalités.\n\nLes Associés Majoritaires notifieront leur intention aux Associés Minoritaires au moins {{delai}} jours avant la cession envisagée.	{}	{clause,drag-along,cession}	f	t	32	0	\N
cml88g785007o521vqvw57n1a	2026-02-04 16:19:21.365	2026-02-04 16:19:21.365	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Tag-Along	CLAUSE DE SORTIE CONJOINTE (TAG-ALONG)\n\nEn cas de cession par un Associé de ses parts à un tiers, les autres Associés auront la faculté de céder au même cessionnaire tout ou partie de leurs parts, au même prix et aux mêmes conditions.\n\nL'Associé cédant devra notifier aux autres Associés les conditions de la cession envisagée.\n\nLes autres Associés disposeront d'un délai de {{delai}} jours pour exercer leur droit de sortie conjointe.	{}	{clause,tag-along,cession}	f	t	33	0	\N
cml88g786007q521vbvvav36z	2026-02-04 16:19:21.366	2026-02-04 16:19:21.366	cml88g71z0000521vp3t710u4	CLAUSE	Clause d'Agrément	CLAUSE D'AGRÉMENT\n\nToute cession de parts sociales à un tiers non associé est soumise à l'agrément préalable de la collectivité des associés statuant à la majorité de {{majorite}}.\n\nLe projet de cession devra être notifié à la société et aux associés par lettre recommandée avec accusé de réception.\n\nLa décision d'agrément devra intervenir dans un délai de {{delai}} jours à compter de la notification. À défaut de réponse dans ce délai, l'agrément sera réputé acquis.	{}	{clause,agrement,cession}	f	t	34	0	\N
cml88g788007s521vbug3368y	2026-02-04 16:19:21.368	2026-02-04 16:19:21.368	cml88g71z0000521vp3t710u4	CLAUSE	Clause de Préemption	DROIT DE PRÉEMPTION\n\nEn cas de projet de cession de parts par un associé, les autres associés bénéficieront d'un droit de préemption.\n\nL'associé cédant devra notifier aux autres associés les conditions de la cession envisagée, notamment l'identité de l'acquéreur, le nombre de parts, le prix et les modalités de paiement.\n\nLes associés disposeront d'un délai de {{delai}} jours pour exercer leur droit de préemption, au prorata de leur participation.	{}	{clause,preemption,cession}	f	t	35	0	\N
cml88g789007u521vfgrnbvd0	2026-02-04 16:19:21.369	2026-02-04 16:19:21.369	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Standard Avocat	Fait à {{ville}}, le {{date_jour}}\n\nPour {{client.nom}},\nSon conseil,\n\nMaître {{avocat.nom}} {{avocat.prenom}}\nAvocat au Barreau de {{avocat.barreau}}\n{{cabinet.adresse}}\n{{cabinet.telephone}}\n{{cabinet.email}}	{}	{signature,avocat}	f	t	1	0	\N
cml88g78a007w521v0682o7of	2026-02-04 16:19:21.37	2026-02-04 16:19:21.37	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Assignation Huissier	DONT ACTE\n\nCoût de l'acte : {{cout_acte}} €\n\n{{huissier.nom}} {{huissier.prenom}}\nHuissier de Justice\nSCP {{huissier.scp}}\n{{huissier.adresse}}	{}	{signature,huissier,assignation}	f	t	2	0	\N
cml88g78b007y521vew68ol1k	2026-02-04 16:19:21.371	2026-02-04 16:19:21.371	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Conclusions Avocat Postulant	Sous toutes réserves,\n\nPour {{client.nom}},\nMaître {{avocat_postulant.nom}}, avocat postulant\nMaître {{avocat_plaidant.nom}}, avocat plaidant\n\nLe {{date_jour}}	{}	{signature,avocat,postulant}	f	t	3	0	\N
cml88g78c0080521vmvdhp864	2026-02-04 16:19:21.373	2026-02-04 16:19:21.373	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Contrat Deux Parties	Fait en deux exemplaires originaux,\nà {{ville}}, le {{date_jour}}\n\nPour {{partie_1.nom}}                     Pour {{partie_2.nom}}\nReprésenté par : {{partie_1.representant}}   Représenté par : {{partie_2.representant}}\nFonction : {{partie_1.fonction}}            Fonction : {{partie_2.fonction}}\n\n\n_____________________                    _____________________\n(Signature précédée de la mention       (Signature précédée de la mention\n"Lu et approuvé")                       "Lu et approuvé")	{}	{signature,contrat,deux-parties}	f	t	4	0	\N
cml88g78e0082521vumkeaawx	2026-02-04 16:19:21.374	2026-02-04 16:19:21.374	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Contrat Trois Parties	Fait en trois exemplaires originaux,\nà {{ville}}, le {{date_jour}}\n\nPour {{partie_1.nom}}          Pour {{partie_2.nom}}          Pour {{partie_3.nom}}\n\n\n\n_________________              _________________              _________________	{}	{signature,contrat,trois-parties}	f	t	5	0	\N
cml88g78f0084521vsq1hq5gm	2026-02-04 16:19:21.376	2026-02-04 16:19:21.376	cml88g71z0000521vp3t710u4	SIGNATURE	Signature avec Paraphes	Le présent contrat, composé de {{nombre_pages}} pages, a été paraphé par les parties.\n\nFait à {{ville}}, le {{date_jour}}\nEn {{nombre_exemplaires}} exemplaires originaux\n\n{{partie_1.nom}}                              {{partie_2.nom}}\n\n\nSignature :                                   Signature :\n_________________________                     _________________________\nParaphe sur chaque page : ___                Paraphe sur chaque page : ___	{}	{signature,paraphes,contrat}	f	t	6	0	\N
cml88g78g0086521vgxea0dvr	2026-02-04 16:19:21.377	2026-02-04 16:19:21.377	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Protocole Accord	Ainsi convenu entre les parties,\n\nFait à {{ville}}, le {{date_jour}}\n\nEn {{nombre}} exemplaires, un pour chaque partie\n\nLes Parties déclarent avoir lu et approuvé l'ensemble du présent protocole d'accord.\n\n\nPour {{partie_1}} :                           Pour {{partie_2}} :\n\n\n_____________________                         _____________________	{}	{signature,protocole,accord}	f	t	7	0	\N
cml88g78j0088521vlybba19z	2026-02-04 16:19:21.379	2026-02-04 16:19:21.379	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Procès-Verbal AG	De tout ce que dessus, il a été dressé le présent procès-verbal qui a été signé, après lecture, par les membres du bureau.\n\nFait à {{ville}}, le {{date_jour}}\n\nLe Président de séance :                      Le Secrétaire de séance :\n\n\n_____________________                         _____________________\n{{president.nom}}                             {{secretaire.nom}}	{}	{signature,pv,ag}	f	t	8	0	\N
cml88g78k008a521vu0tn3dzz	2026-02-04 16:19:21.38	2026-02-04 16:19:21.38	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Rapport Expert	En foi de quoi, j'ai établi le présent rapport.\n\nFait à {{ville}}, le {{date_jour}}\n\n{{expert.titre}} {{expert.nom}}\nExpert {{expert.specialite}}\nAgréé par la Cour d'appel de {{expert.cour}}\n\n\n_____________________	{}	{signature,expert,rapport}	f	t	9	0	\N
cml88g78l008c521vwczg2jq3	2026-02-04 16:19:21.381	2026-02-04 16:19:21.381	cml88g71z0000521vp3t710u4	SIGNATURE	Signature Courrier Avocat	Je vous prie d'agréer, {{formule_politesse}}, l'expression de mes salutations distinguées.\n\nMaître {{avocat.nom}} {{avocat.prenom}}\nAvocat au Barreau de {{avocat.barreau}}\n\nP.J. : {{pieces_jointes}}	{}	{signature,courrier,avocat}	f	t	10	0	\N
\.


--
-- Data for Name: builder_templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.builder_templates (id, "createdAt", "updatedAt", "tenantId", name, description, "documentType", juridiction, category, "blocksStructure", "requiredVariables", "outputFormat", "workflowConfig", "legalMentions", "isSystem", "usageCount", "createdById", "templateCategoryId") FROM stdin;
cml7z49kp0019b6ve8k82awgq	2026-02-04 11:58:07.994	2026-02-04 11:58:07.994	cml6vykdd0000jms2wwxl9s27	Assignation devant le Tribunal Judiciaire	Modèle d'assignation pour les litiges civils devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TJ"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml7z49kw001bb6ves1nms473	2026-02-04 11:58:08	2026-02-04 11:58:08	cml6vykdd0000jms2wwxl9s27	Assignation devant le Tribunal de Commerce	Modèle d'assignation pour les litiges commerciaux	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TC"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits - Litige commercial"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif - Condamnation pécuniaire"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml7z49kz001db6veejh2kl6a	2026-02-04 11:58:08.003	2026-02-04 11:58:08.003	cml6vykdd0000jms2wwxl9s27	Conclusions en défense	Modèle de conclusions pour la partie défenderesse	CONCLUSIONS	\N	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête conclusions"}, {"order": 2, "mandatory": true, "blockTitle": "Rappel des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml7z49l2001fb6vet4n3hx1w	2026-02-04 11:58:08.006	2026-02-04 11:58:08.006	cml6vykdd0000jms2wwxl9s27	Mise en demeure simple	Modèle de mise en demeure pour inexécution contractuelle	MISE_EN_DEMEURE	\N	Courriers	[{"order": 1, "mandatory": true, "blockTitle": "En-tête mise en demeure"}, {"order": 2, "mandatory": true, "blockTitle": "Corps mise en demeure"}, {"order": 3, "mandatory": true, "blockTitle": "Signature"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml7z49l4001hb6vepx7md3qy	2026-02-04 11:58:08.008	2026-02-04 11:58:08.008	cml6vykdd0000jms2wwxl9s27	Protocole de cession de parts sociales	Modèle complet pour cession de parts sociales SARL/SAS	PROTOCOLE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule cession"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Clause de non-concurrence"}, {"order": 4, "mandatory": true, "blockTitle": "Signatures parties"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml7z49l6001jb6ves3273zfw	2026-02-04 11:58:08.01	2026-02-04 11:58:08.01	cml6vykdd0000jms2wwxl9s27	Pacte d'associés SAS	Modèle de pacte d'associés pour SAS	PACTE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule pacte"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de sortie conjointe (tag-along)"}, {"order": 3, "mandatory": true, "blockTitle": "Clause d'entraînement (drag-along)"}, {"order": 4, "mandatory": true, "blockTitle": "Clause de confidentialité"}, {"order": 5, "mandatory": true, "blockTitle": "Signatures"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml7z49l8001lb6veuyll3l06	2026-02-04 11:58:08.013	2026-02-04 11:58:08.013	cml6vykdd0000jms2wwxl9s27	Garantie d'actif et passif (GAP)	Convention de garantie d'actif et passif autonome	GARANTIE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule GAP"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Signatures"}]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc1l003hm3wj39n2jc86	2026-02-04 15:07:55.257	2026-02-04 15:07:55.257	cml6vykdd0000jms2wwxl9s27	Assignation en référé expertise (145 CPC)	Pour obtenir une expertise judiciaire avant tout procès	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc1q003jm3wjwtdwmbed	2026-02-04 15:07:55.262	2026-02-04 15:07:55.262	cml6vykdd0000jms2wwxl9s27	Assignation en référé provision	Pour obtenir une provision sur créance non contestable	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc1s003lm3wjjbb6k188	2026-02-04 15:07:55.265	2026-02-04 15:07:55.265	cml6vykdd0000jms2wwxl9s27	Conclusions en réplique (demandeur)	Conclusions du demandeur en réponse aux conclusions adverses	CONCLUSIONS	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc1u003nm3wjm8r4abvv	2026-02-04 15:07:55.267	2026-02-04 15:07:55.267	cml6vykdd0000jms2wwxl9s27	Conclusions récapitulatives	Conclusions finales récapitulant l'ensemble des demandes	CONCLUSIONS	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc1w003pm3wjck7k16li	2026-02-04 15:07:55.269	2026-02-04 15:07:55.269	cml6vykdd0000jms2wwxl9s27	Opposition à ordonnance d'injonction de payer	Modèle d'opposition à une injonction de payer	OPPOSITION	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc1z003rm3wjy99rw0i3	2026-02-04 15:07:55.271	2026-02-04 15:07:55.271	cml6vykdd0000jms2wwxl9s27	Requête en rectification d'erreur matérielle	Pour corriger une erreur dans une décision de justice	REQUETE	\N	Procédure civile	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc20003tm3wj99o8k652	2026-02-04 15:07:55.273	2026-02-04 15:07:55.273	cml6vykdd0000jms2wwxl9s27	Assignation en contrefaçon de marque	Action en contrefaçon devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Propriété intellectuelle	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc22003vm3wjmg3ro57k	2026-02-04 15:07:55.275	2026-02-04 15:07:55.275	cml6vykdd0000jms2wwxl9s27	Assignation en concurrence déloyale	Action pour actes de concurrence déloyale	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc24003xm3wjldy6fglg	2026-02-04 15:07:55.277	2026-02-04 15:07:55.277	cml6vykdd0000jms2wwxl9s27	Assignation en rupture brutale	Action L.442-1 II pour rupture brutale de relations commerciales	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc26003zm3wjyrsa14r1	2026-02-04 15:07:55.279	2026-02-04 15:07:55.279	cml6vykdd0000jms2wwxl9s27	Déclaration de créance (procédure collective)	Déclaration au passif d'une procédure collective	DECLARATION	\N	Procédures collectives	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc280041m3wjssew9rzx	2026-02-04 15:07:55.281	2026-02-04 15:07:55.281	cml6vykdd0000jms2wwxl9s27	Revendication de marchandises	Action en revendication de biens vendus avec réserve de propriété	REQUETE	\N	Procédures collectives	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2a0043m3wjbxwu74sv	2026-02-04 15:07:55.282	2026-02-04 15:07:55.282	cml6vykdd0000jms2wwxl9s27	Saisine Conseil de Prud'hommes - Licenciement	Contestation d'un licenciement devant le CPH	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2c0045m3wjgeu64ato	2026-02-04 15:07:55.284	2026-02-04 15:07:55.284	cml6vykdd0000jms2wwxl9s27	Saisine CPH - Harcèlement moral	Action pour harcèlement moral au travail	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2e0047m3wj06pij6ko	2026-02-04 15:07:55.286	2026-02-04 15:07:55.286	cml6vykdd0000jms2wwxl9s27	Saisine CPH - Rappel de salaires	Action en rappel de salaires et accessoires	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2g0049m3wjhfnlw25t	2026-02-04 15:07:55.288	2026-02-04 15:07:55.288	cml6vykdd0000jms2wwxl9s27	Conclusions prud'homales (défense employeur)	Conclusions pour l'employeur en défense	CONCLUSIONS	\N	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2l004bm3wj7w4t2rpm	2026-02-04 15:07:55.294	2026-02-04 15:07:55.294	cml6vykdd0000jms2wwxl9s27	Transaction rupture contrat de travail	Protocole transactionnel suite à rupture du contrat	PROTOCOLE	\N	Droit du travail	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2o004dm3wjs45npz8g	2026-02-04 15:07:55.296	2026-02-04 15:07:55.296	cml6vykdd0000jms2wwxl9s27	Requête divorce par consentement mutuel (notaire)	Convention de divorce par consentement mutuel	REQUETE	\N	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2q004fm3wjs205yrei	2026-02-04 15:07:55.298	2026-02-04 15:07:55.298	cml6vykdd0000jms2wwxl9s27	Requête divorce contentieux	Requête en divorce pour altération définitive du lien conjugal	REQUETE	JAF	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2r004hm3wj2wdk55vc	2026-02-04 15:07:55.3	2026-02-04 15:07:55.3	cml6vykdd0000jms2wwxl9s27	Requête modification pension alimentaire	Modification de la contribution à l'entretien des enfants	REQUETE	JAF	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2t004jm3wjwgiouwtf	2026-02-04 15:07:55.302	2026-02-04 15:07:55.302	cml6vykdd0000jms2wwxl9s27	Requête droits de visite et d'hébergement	Fixation ou modification du droit de visite	REQUETE	JAF	Droit de la famille	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2w004lm3wjf3hqr2xd	2026-02-04 15:07:55.304	2026-02-04 15:07:55.304	cml6vykdd0000jms2wwxl9s27	Assignation en garantie décennale	Action contre le constructeur au titre de l'article 1792 CC	ASSIGNATION	Tribunal Judiciaire	Construction	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2x004nm3wjfl8dqbb5	2026-02-04 15:07:55.306	2026-02-04 15:07:55.306	cml6vykdd0000jms2wwxl9s27	Assignation en garantie biennale	Action en garantie de bon fonctionnement	ASSIGNATION	\N	Construction	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc2z004pm3wj5woryjur	2026-02-04 15:07:55.307	2026-02-04 15:07:55.307	cml6vykdd0000jms2wwxl9s27	Assignation troubles de voisinage	Action pour troubles anormaux de voisinage	ASSIGNATION	\N	Immobilier	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc31004rm3wj3neqpnry	2026-02-04 15:07:55.309	2026-02-04 15:07:55.309	cml6vykdd0000jms2wwxl9s27	Assignation vice caché immobilier	Action rédhibitoire ou estimatoire	ASSIGNATION	\N	Immobilier	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc32004tm3wjhfxt4b15	2026-02-04 15:07:55.311	2026-02-04 15:07:55.311	cml6vykdd0000jms2wwxl9s27	Bail commercial 3-6-9	Modèle complet de bail commercial	CONTRAT	\N	Immobilier	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc34004vm3wj2ljsxir7	2026-02-04 15:07:55.313	2026-02-04 15:07:55.313	cml6vykdd0000jms2wwxl9s27	Contrat de cession de parts SARL	Cession de parts sociales de SARL	CONTRAT	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc36004xm3wjcvkgxpym	2026-02-04 15:07:55.314	2026-02-04 15:07:55.314	cml6vykdd0000jms2wwxl9s27	Contrat de cession d'actions SAS	Cession d'actions de SAS	CONTRAT	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc38004zm3wjtizfs2qd	2026-02-04 15:07:55.316	2026-02-04 15:07:55.316	cml6vykdd0000jms2wwxl9s27	Pacte d'associés SARL	Pacte d'associés pour SARL	PACTE	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3a0051m3wjfjce6k30	2026-02-04 15:07:55.318	2026-02-04 15:07:55.318	cml6vykdd0000jms2wwxl9s27	Lettre d'intention (LOI)	Lettre d'intention non engageante M&A	LETTRE	\N	M&A	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3c0053m3wjz2eta9ux	2026-02-04 15:07:55.32	2026-02-04 15:07:55.32	cml6vykdd0000jms2wwxl9s27	Protocole d'accord M&A	Protocole de cession complet avec GAP	PROTOCOLE	\N	M&A	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3d0055m3wjzo84driz	2026-02-04 15:07:55.322	2026-02-04 15:07:55.322	cml6vykdd0000jms2wwxl9s27	Contrat de franchise	Contrat de franchise commerciale	CONTRAT	\N	Distribution	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3f0057m3wjizfhwwr5	2026-02-04 15:07:55.324	2026-02-04 15:07:55.324	cml6vykdd0000jms2wwxl9s27	Contrat d'agent commercial	Contrat d'agence commerciale	CONTRAT	\N	Distribution	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3i0059m3wjaho36q4p	2026-02-04 15:07:55.326	2026-02-04 15:07:55.326	cml6vykdd0000jms2wwxl9s27	Contrat de prestation de services	Contrat B2B de prestation de services	CONTRAT	\N	Contrats commerciaux	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3k005bm3wjf23utuph	2026-02-04 15:07:55.328	2026-02-04 15:07:55.328	cml6vykdd0000jms2wwxl9s27	CGV B2B	Conditions générales de vente professionnels	CGV	\N	Contrats commerciaux	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3m005dm3wjysdg2s9z	2026-02-04 15:07:55.33	2026-02-04 15:07:55.33	cml6vykdd0000jms2wwxl9s27	NDA bilatéral	Accord de confidentialité bilatéral	CONTRAT	\N	Contrats commerciaux	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3o005fm3wj3tkrcl5f	2026-02-04 15:07:55.332	2026-02-04 15:07:55.332	cml6vykdd0000jms2wwxl9s27	Mise en demeure paiement facture	Mise en demeure précontentieuse pour impayé	MISE_EN_DEMEURE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3q005hm3wjb7zc0s7i	2026-02-04 15:07:55.334	2026-02-04 15:07:55.334	cml6vykdd0000jms2wwxl9s27	Mise en demeure exécution obligation	Mise en demeure d'exécuter une obligation contractuelle	MISE_EN_DEMEURE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3s005jm3wjtuocuvy5	2026-02-04 15:07:55.336	2026-02-04 15:07:55.336	cml6vykdd0000jms2wwxl9s27	Mise en demeure cessation agissements	Mise en demeure de cesser des agissements illicites	MISE_EN_DEMEURE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3u005lm3wj6cysq4w1	2026-02-04 15:07:55.338	2026-02-04 15:07:55.338	cml6vykdd0000jms2wwxl9s27	Lettre de résiliation	Résiliation de contrat avec préavis	LETTRE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3v005nm3wjv80g76f2	2026-02-04 15:07:55.34	2026-02-04 15:07:55.34	cml6vykdd0000jms2wwxl9s27	Lettre de réclamation	Réclamation amiable précontentieuse	LETTRE	\N	Courriers	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3x005pm3wj5l6553z6	2026-02-04 15:07:55.342	2026-02-04 15:07:55.342	cml6vykdd0000jms2wwxl9s27	Statuts SAS	Statuts complets de SAS	STATUTS	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc3z005rm3wj0yno3mfq	2026-02-04 15:07:55.343	2026-02-04 15:07:55.343	cml6vykdd0000jms2wwxl9s27	Statuts SARL	Statuts complets de SARL	STATUTS	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc41005tm3wjgjxt8iex	2026-02-04 15:07:55.345	2026-02-04 15:07:55.345	cml6vykdd0000jms2wwxl9s27	PV AG Ordinaire Annuelle	PV d'approbation des comptes annuels	PV	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc43005vm3wjt91bvnip	2026-02-04 15:07:55.347	2026-02-04 15:07:55.347	cml6vykdd0000jms2wwxl9s27	PV AG Extraordinaire	PV de modification des statuts	PV	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml85wc45005xm3wjfp8ibdmm	2026-02-04 15:07:55.349	2026-02-04 15:07:55.349	cml6vykdd0000jms2wwxl9s27	PV nomination dirigeant	Décision de nomination d'un dirigeant	PV	\N	Droit des sociétés	[]	\N	DOCX	\N	\N	t	0	\N	\N
cml88mpuc000d12k16kzbgu86	2026-02-04 16:24:25.429	2026-02-04 16:24:25.429	cml88g71z0000521vp3t710u4	Assignation à Jour Fixe	Assignation à jour fixe avec ordonnance préalable du président	ASSIGNATION	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Assignation Jour Fixe", "blockId": "cml88g733000q521v59duxkoq", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "client.nom", "adversaire.nom", "date_ordonnance", "juridiction", "date_audience", "heure_audience"]	DOCX	{"category": "PROCEDURE", "description": "Assignation à jour fixe avec ordonnance préalable du président"}	\N	t	0	\N	\N
cml88mptw000112k135d9x19m	2026-02-04 16:24:25.412	2026-02-04 16:24:25.412	cml88g71z0000521vp3t710u4	Assignation en Paiement - Tribunal Judiciaire	Assignation devant le Tribunal Judiciaire pour demande de condamnation au paiement d'une somme	ASSIGNATION	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 4, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 5, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 6, "title": "Article 1231-1 Code Civil - Dommages-Intérêts", "blockId": "cml88g744002e521v7p8k1pgt", "isOptional": true}, {"order": 7, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 8, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "client.nom", "adversaire.nom", "date_contrat", "objet_contrat", "montant_principal", "date_interets", "montant_451", "avocat.nom", "avocat.barreau", "huissier.nom", "juridiction", "date_audience"]	DOCX	{"category": "PROCEDURE", "description": "Assignation devant le Tribunal Judiciaire pour demande de condamnation au paiement d'une somme"}	\N	t	0	\N	\N
cml88mpu2000312k167yyw784	2026-02-04 16:24:25.419	2026-02-04 16:24:25.419	cml88g71z0000521vp3t710u4	Assignation en Référé d'Heure à Heure	Assignation en référé d'urgence pour troubles manifestement illicites	ASSIGNATION	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Assignation Référé Urgence", "blockId": "cml88g72l0004521v67f38gmg", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "client.nom", "adversaire.nom", "motif_urgence", "date_audience", "heure_audience", "montant_principal"]	DOCX	{"category": "PROCEDURE", "description": "Assignation en référé d'urgence pour troubles manifestement illicites"}	\N	t	0	\N	\N
cml88mpu4000512k1ymvr4jdp	2026-02-04 16:24:25.42	2026-02-04 16:24:25.42	cml88g71z0000521vp3t710u4	Conclusions en Défense - Tribunal Judiciaire	Conclusions en défense pour répondre à une assignation	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions en Défense", "blockId": "cml88g72m0006521vrm2xxfs7", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Résolution Contrat + Dommages-Intérêts", "blockId": "cml88g75p004k521v49dd03ec", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg", "juridiction", "date_contrat", "avocat.nom", "avocat.barreau"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions en défense pour répondre à une assignation"}	\N	t	0	\N	\N
cml88mpu6000712k1peo4vyst	2026-02-04 16:24:25.422	2026-02-04 16:24:25.422	cml88g71z0000521vp3t710u4	Requête en Référé - Mesures Conservatoires	Requête en référé pour obtenir des mesures conservatoires	REQUETE	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Requête en Référé", "blockId": "cml88g72o0008521v6l79d856", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "juridiction", "avocat.nom"]	DOCX	{"category": "PROCEDURE", "description": "Requête en référé pour obtenir des mesures conservatoires"}	\N	t	0	\N	\N
cml88mpu8000912k15aehazvd	2026-02-04 16:24:25.424	2026-02-04 16:24:25.424	cml88g71z0000521vp3t710u4	Conclusions d'Appel - Cour d'Appel	Conclusions d'appelant devant la Cour d'Appel	CONCLUSIONS	Cour d'Appel	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Appel", "blockId": "cml88g72s000e521vgrroa0zf", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions d'appelant devant la Cour d'Appel"}	\N	t	0	\N	\N
cml88mpua000b12k1u7ju0n7q	2026-02-04 16:24:25.427	2026-02-04 16:24:25.427	cml88g71z0000521vp3t710u4	Contredit - Déclinatoire de Compétence	Contredit contestant la compétence du tribunal	CONTREDIT	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Contredit", "blockId": "cml88g72t000g521vgtu9w5zz", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "numero_rg", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Contredit contestant la compétence du tribunal"}	\N	t	0	\N	\N
cml88mpvx002112k1b34hqknm	2026-02-04 16:24:25.485	2026-02-04 16:24:25.485	cml88g71z0000521vp3t710u4	Mise en Demeure d'Exécuter	Mise en demeure d'exécuter une obligation contractuelle	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "obligation", "delai"]	DOCX	{"category": "COURRIER", "description": "Mise en demeure d'exécuter une obligation contractuelle"}	\N	t	0	\N	\N
cml88mpuf000f12k1bcaxrmz8	2026-02-04 16:24:25.432	2026-02-04 16:24:25.432	cml88g71z0000521vp3t710u4	Conclusions Référé-Provision	Conclusions en référé-provision pour créance non sérieusement contestable	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Référé-Provision", "blockId": "cml88g731000o521vamlkkqum", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "montant_principal"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions en référé-provision pour créance non sérieusement contestable"}	\N	t	0	\N	\N
cml88mpui000h12k1zezpwvb2	2026-02-04 16:24:25.434	2026-02-04 16:24:25.434	cml88g71z0000521vp3t710u4	Conclusions Intervention Volontaire	Conclusions d'intervention volontaire dans une instance en cours	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Intervention Volontaire", "blockId": "cml88g734000s521vlmw8r7ax", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "demandeur.nom", "defendeur.nom", "numero_rg"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions d'intervention volontaire dans une instance en cours"}	\N	t	0	\N	\N
cml88mpuk000j12k1h86oj7er	2026-02-04 16:24:25.436	2026-02-04 16:24:25.436	cml88g71z0000521vp3t710u4	Conclusions Appel en Garantie	Conclusions pour appeler un tiers en garantie	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Appel en Garantie", "blockId": "cml88g735000u521vsg18vhsw", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "garant.nom"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions pour appeler un tiers en garantie"}	\N	t	0	\N	\N
cml88mpum000l12k1g5eod8l0	2026-02-04 16:24:25.438	2026-02-04 16:24:25.438	cml88g71z0000521vp3t710u4	Ordonnance sur Requête - Saisie Conservatoire	Requête aux fins d'ordonnance sur requête pour saisie conservatoire	REQUETE	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Requête Ordonnance sur Requête", "blockId": "cml88g72y000k521vhls1iakg", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Requête aux fins d'ordonnance sur requête pour saisie conservatoire"}	\N	t	0	\N	\N
cml88mpuo000n12k1g9bgpisd	2026-02-04 16:24:25.44	2026-02-04 16:24:25.44	cml88g71z0000521vp3t710u4	Conclusions Rétractation Ordonnance	Conclusions aux fins de rétractation d'une ordonnance sur requête	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Rétractation", "blockId": "cml88g72z000m521vpjyagym7", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "date_ordonnance"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions aux fins de rétractation d'une ordonnance sur requête"}	\N	t	0	\N	\N
cml88mpuq000p12k1ucin9uib	2026-02-04 16:24:25.442	2026-02-04 16:24:25.442	cml88g71z0000521vp3t710u4	Conclusions Récusation Juge	Conclusions aux fins de récusation d'un magistrat	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Récusation", "blockId": "cml88g72w000i521viuoi7gl9", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "juge.nom", "juridiction"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions aux fins de récusation d'un magistrat"}	\N	t	0	\N	\N
cml88mpus000r12k1t3dd44of	2026-02-04 16:24:25.444	2026-02-04 16:24:25.444	cml88g71z0000521vp3t710u4	Mémoire en Réplique	Mémoire en réplique suite aux conclusions adverses	MEMOIRE	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Mémoire en Réplique", "blockId": "cml88g72r000c521vlxm2tbb5", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg", "date_conclusions_adversaire"]	DOCX	{"category": "PROCEDURE", "description": "Mémoire en réplique suite aux conclusions adverses"}	\N	t	0	\N	\N
cml88mput000t12k1saehw1k0	2026-02-04 16:24:25.446	2026-02-04 16:24:25.446	cml88g71z0000521vp3t710u4	Conclusions sur Incident	Conclusions sur incident soulevé en cours d'instance	CONCLUSIONS	Tribunal Judiciaire	PROCEDURE	[{"order": 1, "title": "Intro Conclusions Incident", "blockId": "cml88g72p000a521vt2ugqmlk", "isOptional": false}, {"order": 2, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["client.nom", "adversaire.nom", "numero_rg"]	DOCX	{"category": "PROCEDURE", "description": "Conclusions sur incident soulevé en cours d'instance"}	\N	t	0	\N	\N
cml9o7kws000lf0egi5diqzx0	2026-02-05 16:28:19.229	2026-02-05 16:28:19.229	cml6vyl1v0017jms2uzfefv85	Conclusions récapitulatives	Conclusions finales récapitulant l'ensemble des demandes	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kx1000nf0ege9jd9ozc	2026-02-05 16:28:19.237	2026-02-05 16:28:19.237	cml6vyl1v0017jms2uzfefv85	Opposition à ordonnance d'injonction de payer	Modèle d'opposition à une injonction de payer	OPPOSITION	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml88mpuw000v12k1k6u63joa	2026-02-04 16:24:25.448	2026-02-04 16:24:25.448	cml88g71z0000521vp3t710u4	Contrat de Vente - Bien Mobilier	Contrat de vente d'un bien mobilier corporel	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 3, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 4, "title": "Clause Pénale", "blockId": "cml88g7700066521vu500prh2", "isOptional": true}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["vendeur.nom", "acquereur.nom", "prix_vente", "description_bien"]	DOCX	{"category": "CONTRAT", "description": "Contrat de vente d'un bien mobilier corporel"}	\N	t	0	\N	\N
cml88mpuy000x12k127lmedir	2026-02-04 16:24:25.45	2026-02-04 16:24:25.45	cml88g71z0000521vp3t710u4	Contrat de Prestation de Services	Contrat de prestation de services entre professionnels	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Clause Pénale", "blockId": "cml88g7700066521vu500prh2", "isOptional": true}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["prestataire.nom", "client.nom", "objet_prestation", "prix"]	DOCX	{"category": "CONTRAT", "description": "Contrat de prestation de services entre professionnels"}	\N	t	0	\N	\N
cml88mpuz000z12k1r03qci24	2026-02-04 16:24:25.452	2026-02-04 16:24:25.452	cml88g71z0000521vp3t710u4	Bail Commercial	Bail commercial 3-6-9 pour locaux professionnels	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["bailleur.nom", "preneur.nom", "adresse_locaux", "montant_loyer"]	DOCX	{"category": "CONTRAT", "description": "Bail commercial 3-6-9 pour locaux professionnels"}	\N	t	0	\N	\N
cml88mpv1001112k17z2yeizu	2026-02-04 16:24:25.454	2026-02-04 16:24:25.454	cml88g71z0000521vp3t710u4	Contrat de Mandat	Contrat de mandat général ou spécial	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["mandant.nom", "mandataire.nom", "objet_mandat"]	DOCX	{"category": "CONTRAT", "description": "Contrat de mandat général ou spécial"}	\N	t	0	\N	\N
cml88mpv3001312k169gypi5i	2026-02-04 16:24:25.455	2026-02-04 16:24:25.455	cml88g71z0000521vp3t710u4	Contrat de Sous-Traitance	Contrat de sous-traitance industrielle ou commerciale	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Clause Pénale", "blockId": "cml88g7700066521vu500prh2", "isOptional": true}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["entrepreneur.nom", "soustraitant.nom", "objet"]	DOCX	{"category": "CONTRAT", "description": "Contrat de sous-traitance industrielle ou commerciale"}	\N	t	0	\N	\N
cml88mpv5001512k171mymog5	2026-02-04 16:24:25.457	2026-02-04 16:24:25.457	cml88g71z0000521vp3t710u4	Contrat de Distribution	Contrat de distribution exclusive ou sélective	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["fournisseur.nom", "distributeur.nom", "territoire"]	DOCX	{"category": "CONTRAT", "description": "Contrat de distribution exclusive ou sélective"}	\N	t	0	\N	\N
cml88mpv7001712k1hbg1iho6	2026-02-04 16:24:25.46	2026-02-04 16:24:25.46	cml88g71z0000521vp3t710u4	Contrat de Franchise	Contrat de franchise commerciale	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["franchiseur.nom", "franchise.nom", "redevance"]	DOCX	{"category": "CONTRAT", "description": "Contrat de franchise commerciale"}	\N	t	0	\N	\N
cml88mpv9001912k1v7zqvkt3	2026-02-04 16:24:25.461	2026-02-04 16:24:25.461	cml88g71z0000521vp3t710u4	Promesse Unilatérale de Vente	Promesse unilatérale de vente immobilière	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["promettant.nom", "beneficiaire.nom", "prix", "delai_option"]	DOCX	{"category": "CONTRAT", "description": "Promesse unilatérale de vente immobilière"}	\N	t	0	\N	\N
cml88mpvb001b12k1iquwjhvc	2026-02-04 16:24:25.463	2026-02-04 16:24:25.463	cml88g71z0000521vp3t710u4	Compromis de Vente Immobilier	Compromis de vente pour bien immobilier	CONTRAT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["vendeur.nom", "acquereur.nom", "adresse_bien", "prix"]	DOCX	{"category": "CONTRAT", "description": "Compromis de vente pour bien immobilier"}	\N	t	0	\N	\N
cml88mpvc001d12k1b2wqi41p	2026-02-04 16:24:25.465	2026-02-04 16:24:25.465	cml88g71z0000521vp3t710u4	Avenant Contrat Commercial	Avenant modificatif à un contrat commercial existant	AVENANT	\N	CONTRAT	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["partie1.nom", "partie2.nom", "date_contrat_initial", "modifications"]	DOCX	{"category": "CONTRAT", "description": "Avenant modificatif à un contrat commercial existant"}	\N	t	0	\N	\N
cml88mpve001f12k1nhvmamez	2026-02-04 16:24:25.467	2026-02-04 16:24:25.467	cml88g71z0000521vp3t710u4	Protocole de Cession de Parts Sociales	Protocole de cession de parts sociales avec garantie d'actif et de passif	PROTOCOLE	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Contexte Cession Parts Sociales", "blockId": "cml88g73a0012521vfng0ohzi", "isOptional": false}, {"order": 3, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["cedant.nom", "cessionnaire.nom", "societe_cible", "prix_cession", "nombre_parts", "pourcentage", "montant_gap", "duree_gap"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Protocole de cession de parts sociales avec garantie d'actif et de passif"}	\N	t	0	\N	\N
cml88mpvg001h12k1s4nk6wgc	2026-02-04 16:24:25.469	2026-02-04 16:24:25.469	cml88g71z0000521vp3t710u4	Statuts SARL	Statuts constitutifs d'une SARL	STATUTS	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["denomination", "siege", "objet", "capital", "associes"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Statuts constitutifs d'une SARL"}	\N	t	0	\N	\N
cml88mpvi001j12k1pcjpm7r2	2026-02-04 16:24:25.47	2026-02-04 16:24:25.47	cml88g71z0000521vp3t710u4	Statuts SAS	Statuts constitutifs d'une SAS	STATUTS	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["denomination", "siege", "objet", "capital", "president.nom"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Statuts constitutifs d'une SAS"}	\N	t	0	\N	\N
cml88mpvj001l12k18tj4h3qy	2026-02-04 16:24:25.472	2026-02-04 16:24:25.472	cml88g71z0000521vp3t710u4	Pacte d'Associés	Pacte d'associés extra-statutaire	PACTE	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "associes", "date_statuts"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Pacte d'associés extra-statutaire"}	\N	t	0	\N	\N
cml88mpvl001n12k1petslibj	2026-02-04 16:24:25.473	2026-02-04 16:24:25.473	cml88g71z0000521vp3t710u4	PV Assemblée Générale Ordinaire	Procès-verbal d'assemblée générale ordinaire annuelle	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "date_ag", "president_seance", "resolutions"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Procès-verbal d'assemblée générale ordinaire annuelle"}	\N	t	0	\N	\N
cml88mpvm001p12k1woiocgu6	2026-02-04 16:24:25.475	2026-02-04 16:24:25.475	cml88g71z0000521vp3t710u4	PV Assemblée Générale Extraordinaire	Procès-verbal d'AGE pour modification statutaire	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "date_age", "modifications_statutaires"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Procès-verbal d'AGE pour modification statutaire"}	\N	t	0	\N	\N
cml88mpvo001r12k15isi85dp	2026-02-04 16:24:25.477	2026-02-04 16:24:25.477	cml88g71z0000521vp3t710u4	Augmentation de Capital	Résolution d'augmentation de capital social	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "capital_actuel", "montant_augmentation", "modalites"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Résolution d'augmentation de capital social"}	\N	t	0	\N	\N
cml88mpvq001t12k1l64apbu5	2026-02-04 16:24:25.478	2026-02-04 16:24:25.478	cml88g71z0000521vp3t710u4	Dissolution Anticipée	Résolution de dissolution anticipée de société	PV_AG	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "motif_dissolution", "liquidateur.nom"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Résolution de dissolution anticipée de société"}	\N	t	0	\N	\N
cml88mpvr001v12k13yae3ioo	2026-02-04 16:24:25.48	2026-02-04 16:24:25.48	cml88g71z0000521vp3t710u4	Cession de Fonds de Commerce	Acte de cession de fonds de commerce	ACTE	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["vendeur.nom", "acquereur.nom", "fonds", "prix"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Acte de cession de fonds de commerce"}	\N	t	0	\N	\N
cml88mpvt001x12k1njss3r9t	2026-02-04 16:24:25.481	2026-02-04 16:24:25.481	cml88g71z0000521vp3t710u4	Fusion-Absorption	Projet de fusion par absorption entre deux sociétés	PROJET	\N	DROIT_AFFAIRES	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe_absorbante", "societe_absorbee", "parite_echange"]	DOCX	{"category": "DROIT_AFFAIRES", "description": "Projet de fusion par absorption entre deux sociétés"}	\N	t	0	\N	\N
cml88mpvv001z12k1arfkfwwo	2026-02-04 16:24:25.483	2026-02-04 16:24:25.483	cml88g71z0000521vp3t710u4	Mise en Demeure de Payer	Lettre de mise en demeure pour impayés	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "client.nom", "montant_du", "delai_paiement"]	DOCX	{"category": "COURRIER", "description": "Lettre de mise en demeure pour impayés"}	\N	t	0	\N	\N
cml9o7kxf000pf0egtefnkskn	2026-02-05 16:28:19.251	2026-02-05 16:28:19.251	cml6vyl1v0017jms2uzfefv85	Requête en rectification d'erreur matérielle	Pour corriger une erreur dans une décision de justice	REQUETE	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml88mpvy002312k1s8ptsyll	2026-02-04 16:24:25.487	2026-02-04 16:24:25.487	cml88g71z0000521vp3t710u4	Notification de Résiliation	Courrier de notification de résiliation de contrat	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Inexécution Contractuelle Détaillée", "blockId": "cml88g7380010521v8v0pf884", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "date_contrat", "motif_resiliation", "date_effet"]	DOCX	{"category": "COURRIER", "description": "Courrier de notification de résiliation de contrat"}	\N	t	0	\N	\N
cml88mpw0002512k1p7tmryk1	2026-02-04 16:24:25.488	2026-02-04 16:24:25.488	cml88g71z0000521vp3t710u4	Convocation Assemblée Générale	Convocation à une assemblée générale d'associés	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["societe", "date_ag", "lieu", "ordre_du_jour"]	DOCX	{"category": "COURRIER", "description": "Convocation à une assemblée générale d'associés"}	\N	t	0	\N	\N
cml88mpw1002712k1iaduikvr	2026-02-04 16:24:25.489	2026-02-04 16:24:25.489	cml88g71z0000521vp3t710u4	Réclamation Livraison Non-Conforme	Réclamation pour livraison non conforme à la commande	COURRIER	\N	COURRIER	[{"order": 1, "title": "Litige Livraison Marchandises", "blockId": "cml88g73b0014521v1mmtupxt", "isOptional": false}, {"order": 2, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "numero_commande", "date_livraison", "non_conformites"]	DOCX	{"category": "COURRIER", "description": "Réclamation pour livraison non conforme à la commande"}	\N	t	0	\N	\N
cml88mpw2002912k1295utjpo	2026-02-04 16:24:25.491	2026-02-04 16:24:25.491	cml88g71z0000521vp3t710u4	Protestation Refus de Livraison	Protestation suite à un refus de livraison	COURRIER	\N	COURRIER	[{"order": 1, "title": "Litige Livraison Marchandises", "blockId": "cml88g73b0014521v1mmtupxt", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "date_refus", "motif_refus"]	DOCX	{"category": "COURRIER", "description": "Protestation suite à un refus de livraison"}	\N	t	0	\N	\N
cml88mpw4002b12k12yq1jyv8	2026-02-04 16:24:25.493	2026-02-04 16:24:25.493	cml88g71z0000521vp3t710u4	Demande d'Indemnisation Assurance	Demande d'indemnisation auprès d'une compagnie d'assurance	COURRIER	\N	COURRIER	[{"order": 1, "title": "Accident Circulation Détaillé", "blockId": "cml88g73c0016521vpptdo7n1", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["compagnie", "numero_police", "date_sinistre", "montant_demande"]	DOCX	{"category": "COURRIER", "description": "Demande d'indemnisation auprès d'une compagnie d'assurance"}	\N	t	0	\N	\N
cml88mpw6002d12k17uoco3da	2026-02-04 16:24:25.494	2026-02-04 16:24:25.494	cml88g71z0000521vp3t710u4	Contestation Licenciement	Courrier de contestation d'un licenciement	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rupture Abusive Contrat Travail", "blockId": "cml88g73d0018521v8nv8mlww", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["employeur", "date_licenciement", "arguments_contestation"]	DOCX	{"category": "COURRIER", "description": "Courrier de contestation d'un licenciement"}	\N	t	0	\N	\N
cml88mpw7002f12k1p0knfwlp	2026-02-04 16:24:25.495	2026-02-04 16:24:25.495	cml88g71z0000521vp3t710u4	Demande de Documents	Demande de communication de documents ou pièces	COURRIER	\N	COURRIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "documents_demandes", "delai"]	DOCX	{"category": "COURRIER", "description": "Demande de communication de documents ou pièces"}	\N	t	0	\N	\N
cml88mpw8002h12k1t3ngd8a7	2026-02-04 16:24:25.497	2026-02-04 16:24:25.497	cml88g71z0000521vp3t710u4	Réponse à Mise en Demeure	Réponse à une mise en demeure reçue	COURRIER	\N	COURRIER	[{"order": 1, "title": "Chronologie Relation Contractuelle", "blockId": "cml88g736000w521vv9dwdvqy", "isOptional": false}, {"order": 2, "title": "Article 1103 Code Civil - Force Obligatoire", "blockId": "cml88g742002a521vzg1sjbol", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["destinataire.nom", "date_mise_en_demeure", "reponse"]	DOCX	{"category": "COURRIER", "description": "Réponse à une mise en demeure reçue"}	\N	t	0	\N	\N
cml88mpwa002j12k1rck7u7hm	2026-02-04 16:24:25.498	2026-02-04 16:24:25.498	cml88g71z0000521vp3t710u4	Assignation Vice Caché Immobilier	Assignation en garantie des vices cachés suite à une vente immobilière	ASSIGNATION	Tribunal Judiciaire	IMMOBILIER	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Vice Caché Vente Immobilière", "blockId": "cml88g73f001c521vcqqf772a", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Résolution Contrat + Dommages-Intérêts", "blockId": "cml88g75p004k521v49dd03ec", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["date_assignation", "acquereur.nom", "vendeur.nom", "adresse_bien", "date_vente", "prix_vente", "description_vices", "expert.nom"]	DOCX	{"category": "IMMOBILIER", "description": "Assignation en garantie des vices cachés suite à une vente immobilière"}	\N	t	0	\N	\N
cml88mpwb002l12k12jwfeg6w	2026-02-04 16:24:25.5	2026-02-04 16:24:25.5	cml88g71z0000521vp3t710u4	Assignation Troubles de Voisinage	Assignation pour troubles anormaux de voisinage	ASSIGNATION	Tribunal Judiciaire	IMMOBILIER	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Troubles Voisinage", "blockId": "cml88g73e001a521vr9lcyh1r", "isOptional": false}, {"order": 3, "title": "Article 1240 Code Civil - Responsabilité Délictuelle", "blockId": "cml88g745002g521vybf7v9b1", "isOptional": false}, {"order": 4, "title": "Condamnation Paiement Somme", "blockId": "cml88g75o004i521vnxhpva0r", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["demandeur.nom", "defendeur.nom", "adresse_demandeur", "adresse_defendeur", "description_troubles", "date_debut_troubles"]	DOCX	{"category": "IMMOBILIER", "description": "Assignation pour troubles anormaux de voisinage"}	\N	t	0	\N	\N
cml88mpwd002n12k1gss7i695	2026-02-04 16:24:25.501	2026-02-04 16:24:25.501	cml88g71z0000521vp3t710u4	Assignation Expulsion Impayés Loyers	Assignation en expulsion pour impayés de loyers avec clause résolutoire	ASSIGNATION	Tribunal Judiciaire	IMMOBILIER	[{"order": 1, "title": "Intro Assignation Tribunal Judiciaire", "blockId": "cml88g72e0002521vd4ncnwe7", "isOptional": false}, {"order": 2, "title": "Impayés Loyers Commercial", "blockId": "cml88g73g001e521vo5wrzbou", "isOptional": false}, {"order": 3, "title": "Article 1217 Code Civil - Inexécution", "blockId": "cml88g743002c521vosmq5vyc", "isOptional": false}, {"order": 4, "title": "Résolution Contrat + Dommages-Intérêts", "blockId": "cml88g75p004k521v49dd03ec", "isOptional": false}, {"order": 5, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["bailleur.nom", "preneur.nom", "adresse_locaux", "montant_loyer", "montant_total_impaye", "nombre_mois", "date_commandement"]	DOCX	{"category": "IMMOBILIER", "description": "Assignation en expulsion pour impayés de loyers avec clause résolutoire"}	\N	t	0	\N	\N
cml88mpwf002p12k11j0ye95m	2026-02-04 16:24:25.503	2026-02-04 16:24:25.503	cml88g71z0000521vp3t710u4	Bail d'Habitation	Contrat de bail d'habitation meublée ou non meublée	CONTRAT	\N	IMMOBILIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Clause Résolutoire Standard", "blockId": "cml88g76r005w521vt9s0x3d0", "isOptional": false}, {"order": 3, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["bailleur.nom", "locataire.nom", "adresse_logement", "loyer", "charges", "depot_garantie"]	DOCX	{"category": "IMMOBILIER", "description": "Contrat de bail d'habitation meublée ou non meublée"}	\N	t	0	\N	\N
cml88mpwg002r12k1qnf0c5kw	2026-02-04 16:24:25.504	2026-02-04 16:24:25.504	cml88g71z0000521vp3t710u4	État des Lieux Contradictoire	État des lieux d'entrée ou de sortie de location	ETAT_LIEUX	\N	IMMOBILIER	[{"order": 1, "title": "Rappel Contrat Commercial", "blockId": "cml88g737000y521v0sp6dmjv", "isOptional": false}, {"order": 2, "title": "Signature Standard Avocat", "blockId": "cml88g789007u521vfgrnbvd0", "isOptional": false}]	["type_etat_lieux", "date", "adresse_logement", "bailleur.nom", "locataire.nom"]	DOCX	{"category": "IMMOBILIER", "description": "État des lieux d'entrée ou de sortie de location"}	\N	t	0	\N	\N
cml9o7ksu0001f0ege4hmsa8z	2026-02-05 16:28:19.086	2026-02-05 16:28:19.086	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal Judiciaire	Modèle d'assignation pour les litiges civils devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TJ"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7ktf0003f0egitlznk83	2026-02-05 16:28:19.106	2026-02-05 16:28:19.106	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal de Commerce	Modèle d'assignation pour les litiges commerciaux	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TC"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits - Litige commercial"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif - Condamnation pécuniaire"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7ktt0005f0egl6qj0i0i	2026-02-05 16:28:19.122	2026-02-05 16:28:19.122	cml6vyl1v0017jms2uzfefv85	Conclusions en défense	Modèle de conclusions pour la partie défenderesse	CONCLUSIONS	\N	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête conclusions"}, {"order": 2, "mandatory": true, "blockTitle": "Rappel des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7kud0007f0egvn772xx9	2026-02-05 16:28:19.14	2026-02-05 16:28:19.14	cml6vyl1v0017jms2uzfefv85	Mise en demeure simple	Modèle de mise en demeure pour inexécution contractuelle	MISE_EN_DEMEURE	\N	Courriers	[{"order": 1, "mandatory": true, "blockTitle": "En-tête mise en demeure"}, {"order": 2, "mandatory": true, "blockTitle": "Corps mise en demeure"}, {"order": 3, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7kuq0009f0egcliicez3	2026-02-05 16:28:19.154	2026-02-05 16:28:19.154	cml6vyl1v0017jms2uzfefv85	Protocole de cession de parts sociales	Modèle complet pour cession de parts sociales SARL/SAS	PROTOCOLE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule cession"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Clause de non-concurrence"}, {"order": 4, "mandatory": true, "blockTitle": "Signatures parties"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7kvb000bf0eg47nsteek	2026-02-05 16:28:19.173	2026-02-05 16:28:19.173	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SAS	Modèle de pacte d'associés pour SAS	PACTE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule pacte"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de sortie conjointe (tag-along)"}, {"order": 3, "mandatory": true, "blockTitle": "Clause d'entraînement (drag-along)"}, {"order": 4, "mandatory": true, "blockTitle": "Clause de confidentialité"}, {"order": 5, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7kvo000df0egoz81b00t	2026-02-05 16:28:19.188	2026-02-05 16:28:19.188	cml6vyl1v0017jms2uzfefv85	Garantie d'actif et passif (GAP)	Convention de garantie d'actif et passif autonome	GARANTIE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule GAP"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7kw3000ff0eguhg1ps1l	2026-02-05 16:28:19.203	2026-02-05 16:28:19.203	cml6vyl1v0017jms2uzfefv85	Assignation en référé expertise (145 CPC)	Pour obtenir une expertise judiciaire avant tout procès	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kwb000hf0eg4orvsl66	2026-02-05 16:28:19.211	2026-02-05 16:28:19.211	cml6vyl1v0017jms2uzfefv85	Assignation en référé provision	Pour obtenir une provision sur créance non contestable	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kwm000jf0egwrigk9vp	2026-02-05 16:28:19.222	2026-02-05 16:28:19.222	cml6vyl1v0017jms2uzfefv85	Conclusions en réplique (demandeur)	Conclusions du demandeur en réponse aux conclusions adverses	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kxk000rf0egody62ckq	2026-02-05 16:28:19.257	2026-02-05 16:28:19.257	cml6vyl1v0017jms2uzfefv85	Assignation en contrefaçon de marque	Action en contrefaçon devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Propriété intellectuelle	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7ky5000tf0egrxk1tkef	2026-02-05 16:28:19.276	2026-02-05 16:28:19.276	cml6vyl1v0017jms2uzfefv85	Assignation en concurrence déloyale	Action pour actes de concurrence déloyale	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kym000vf0eg1t273ykx	2026-02-05 16:28:19.294	2026-02-05 16:28:19.294	cml6vyl1v0017jms2uzfefv85	Assignation en rupture brutale	Action L.442-1 II pour rupture brutale de relations commerciales	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kyt000xf0egiyb5k4rl	2026-02-05 16:28:19.301	2026-02-05 16:28:19.301	cml6vyl1v0017jms2uzfefv85	Déclaration de créance (procédure collective)	Déclaration au passif d'une procédure collective	DECLARATION	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kz4000zf0egjk4w9404	2026-02-05 16:28:19.312	2026-02-05 16:28:19.312	cml6vyl1v0017jms2uzfefv85	Revendication de marchandises	Action en revendication de biens vendus avec réserve de propriété	REQUETE	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kzh0011f0eglo4m3y21	2026-02-05 16:28:19.323	2026-02-05 16:28:19.323	cml6vyl1v0017jms2uzfefv85	Saisine Conseil de Prud'hommes - Licenciement	Contestation d'un licenciement devant le CPH	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7kzw0013f0eghrn4bklj	2026-02-05 16:28:19.34	2026-02-05 16:28:19.34	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Harcèlement moral	Action pour harcèlement moral au travail	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l0k0015f0egm3qfqp4b	2026-02-05 16:28:19.361	2026-02-05 16:28:19.361	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Rappel de salaires	Action en rappel de salaires et accessoires	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l0s0017f0egnwojbkum	2026-02-05 16:28:19.372	2026-02-05 16:28:19.372	cml6vyl1v0017jms2uzfefv85	Conclusions prud'homales (défense employeur)	Conclusions pour l'employeur en défense	CONCLUSIONS	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l100019f0egsubmvnxe	2026-02-05 16:28:19.38	2026-02-05 16:28:19.38	cml6vyl1v0017jms2uzfefv85	Transaction rupture contrat de travail	Protocole transactionnel suite à rupture du contrat	PROTOCOLE	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l17001bf0egivs1kl1s	2026-02-05 16:28:19.387	2026-02-05 16:28:19.387	cml6vyl1v0017jms2uzfefv85	Requête divorce par consentement mutuel (notaire)	Convention de divorce par consentement mutuel	REQUETE	\N	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l1d001df0egd9zvskdw	2026-02-05 16:28:19.394	2026-02-05 16:28:19.394	cml6vyl1v0017jms2uzfefv85	Requête divorce contentieux	Requête en divorce pour altération définitive du lien conjugal	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l1i001ff0egrbe33wdu	2026-02-05 16:28:19.398	2026-02-05 16:28:19.398	cml6vyl1v0017jms2uzfefv85	Requête modification pension alimentaire	Modification de la contribution à l'entretien des enfants	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l1o001hf0egn0v06kch	2026-02-05 16:28:19.404	2026-02-05 16:28:19.404	cml6vyl1v0017jms2uzfefv85	Requête droits de visite et d'hébergement	Fixation ou modification du droit de visite	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l1u001jf0eg63e3u0o6	2026-02-05 16:28:19.41	2026-02-05 16:28:19.41	cml6vyl1v0017jms2uzfefv85	Assignation en garantie décennale	Action contre le constructeur au titre de l'article 1792 CC	ASSIGNATION	Tribunal Judiciaire	Construction	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l1y001lf0eg001o8z22	2026-02-05 16:28:19.414	2026-02-05 16:28:19.414	cml6vyl1v0017jms2uzfefv85	Assignation en garantie biennale	Action en garantie de bon fonctionnement	ASSIGNATION	\N	Construction	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l27001nf0egpynqkypu	2026-02-05 16:28:19.423	2026-02-05 16:28:19.423	cml6vyl1v0017jms2uzfefv85	Assignation troubles de voisinage	Action pour troubles anormaux de voisinage	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l2d001pf0eg6zl89r8g	2026-02-05 16:28:19.429	2026-02-05 16:28:19.429	cml6vyl1v0017jms2uzfefv85	Assignation vice caché immobilier	Action rédhibitoire ou estimatoire	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l2i001rf0egbd3db474	2026-02-05 16:28:19.434	2026-02-05 16:28:19.434	cml6vyl1v0017jms2uzfefv85	Bail commercial 3-6-9	Modèle complet de bail commercial	CONTRAT	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l2p001tf0eg20e8tdat	2026-02-05 16:28:19.441	2026-02-05 16:28:19.441	cml6vyl1v0017jms2uzfefv85	Contrat de cession de parts SARL	Cession de parts sociales de SARL	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l2y001vf0eggk71yvlm	2026-02-05 16:28:19.45	2026-02-05 16:28:19.45	cml6vyl1v0017jms2uzfefv85	Contrat de cession d'actions SAS	Cession d'actions de SAS	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l33001xf0eghwjo92mk	2026-02-05 16:28:19.455	2026-02-05 16:28:19.455	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SARL	Pacte d'associés pour SARL	PACTE	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l3b001zf0eg1xzjaik0	2026-02-05 16:28:19.464	2026-02-05 16:28:19.464	cml6vyl1v0017jms2uzfefv85	Lettre d'intention (LOI)	Lettre d'intention non engageante M&A	LETTRE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l3p0021f0egdvq9lqi8	2026-02-05 16:28:19.477	2026-02-05 16:28:19.477	cml6vyl1v0017jms2uzfefv85	Protocole d'accord M&A	Protocole de cession complet avec GAP	PROTOCOLE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l3x0023f0egcvuudf6p	2026-02-05 16:28:19.485	2026-02-05 16:28:19.485	cml6vyl1v0017jms2uzfefv85	Contrat de franchise	Contrat de franchise commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l4d0025f0ege8f2cnsl	2026-02-05 16:28:19.501	2026-02-05 16:28:19.501	cml6vyl1v0017jms2uzfefv85	Contrat d'agent commercial	Contrat d'agence commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l4i0027f0egwpdqtpw9	2026-02-05 16:28:19.507	2026-02-05 16:28:19.507	cml6vyl1v0017jms2uzfefv85	Contrat de prestation de services	Contrat B2B de prestation de services	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l4v0029f0egu30f0xpp	2026-02-05 16:28:19.519	2026-02-05 16:28:19.519	cml6vyl1v0017jms2uzfefv85	CGV B2B	Conditions générales de vente professionnels	CGV	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l51002bf0egh15wja6r	2026-02-05 16:28:19.525	2026-02-05 16:28:19.525	cml6vyl1v0017jms2uzfefv85	NDA bilatéral	Accord de confidentialité bilatéral	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l5i002ff0eg5yy72jiq	2026-02-05 16:28:19.543	2026-02-05 16:28:19.543	cml6vyl1v0017jms2uzfefv85	Mise en demeure exécution obligation	Mise en demeure d'exécuter une obligation contractuelle	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l5q002hf0egvty8f982	2026-02-05 16:28:19.551	2026-02-05 16:28:19.551	cml6vyl1v0017jms2uzfefv85	Mise en demeure cessation agissements	Mise en demeure de cesser des agissements illicites	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l5w002jf0egasoroqze	2026-02-05 16:28:19.556	2026-02-05 16:28:19.556	cml6vyl1v0017jms2uzfefv85	Lettre de résiliation	Résiliation de contrat avec préavis	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l5z002lf0egy91noxxm	2026-02-05 16:28:19.56	2026-02-05 16:28:19.56	cml6vyl1v0017jms2uzfefv85	Lettre de réclamation	Réclamation amiable précontentieuse	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l65002nf0eg6ijyuh7b	2026-02-05 16:28:19.565	2026-02-05 16:28:19.565	cml6vyl1v0017jms2uzfefv85	Statuts SAS	Statuts complets de SAS	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l68002pf0eg1heywuhd	2026-02-05 16:28:19.568	2026-02-05 16:28:19.568	cml6vyl1v0017jms2uzfefv85	Statuts SARL	Statuts complets de SARL	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l6c002rf0eg30if16h4	2026-02-05 16:28:19.572	2026-02-05 16:28:19.572	cml6vyl1v0017jms2uzfefv85	PV AG Ordinaire Annuelle	PV d'approbation des comptes annuels	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l6f002tf0eg4ewsn602	2026-02-05 16:28:19.575	2026-02-05 16:28:19.575	cml6vyl1v0017jms2uzfefv85	PV AG Extraordinaire	PV de modification des statuts	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l6s002vf0egopmqxapw	2026-02-05 16:28:19.588	2026-02-05 16:28:19.588	cml6vyl1v0017jms2uzfefv85	PV nomination dirigeant	Décision de nomination d'un dirigeant	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rtg0001hcc1j2gcszbz	2026-02-05 16:28:28.18	2026-02-05 16:28:28.18	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal Judiciaire	Modèle d'assignation pour les litiges civils devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TJ"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7rto0003hcc1muis1xyj	2026-02-05 16:28:28.188	2026-02-05 16:28:28.188	cml6vyl1v0017jms2uzfefv85	Assignation devant le Tribunal de Commerce	Modèle d'assignation pour les litiges commerciaux	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[{"order": 1, "mandatory": true, "blockTitle": "En-tête assignation TC"}, {"order": 2, "mandatory": true, "blockTitle": "Exposé des faits - Litige commercial"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif - Condamnation pécuniaire"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7ru10005hcc1ju0pumbr	2026-02-05 16:28:28.202	2026-02-05 16:28:28.202	cml6vyl1v0017jms2uzfefv85	Conclusions en défense	Modèle de conclusions pour la partie défenderesse	CONCLUSIONS	\N	Procédure civile	[{"order": 1, "mandatory": true, "blockTitle": "En-tête conclusions"}, {"order": 2, "mandatory": true, "blockTitle": "Rappel des faits"}, {"order": 3, "mandatory": true, "blockTitle": "Discussion en droit"}, {"order": 4, "mandatory": true, "blockTitle": "Dispositif"}, {"order": 5, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7ru90007hcc1f2gyd95z	2026-02-05 16:28:28.209	2026-02-05 16:28:28.209	cml6vyl1v0017jms2uzfefv85	Mise en demeure simple	Modèle de mise en demeure pour inexécution contractuelle	MISE_EN_DEMEURE	\N	Courriers	[{"order": 1, "mandatory": true, "blockTitle": "En-tête mise en demeure"}, {"order": 2, "mandatory": true, "blockTitle": "Corps mise en demeure"}, {"order": 3, "mandatory": true, "blockTitle": "Signature"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7ruf0009hcc1a187moa4	2026-02-05 16:28:28.215	2026-02-05 16:28:28.215	cml6vyl1v0017jms2uzfefv85	Protocole de cession de parts sociales	Modèle complet pour cession de parts sociales SARL/SAS	PROTOCOLE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule cession"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Clause de non-concurrence"}, {"order": 4, "mandatory": true, "blockTitle": "Signatures parties"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7ruz000bhcc1o7u0lb58	2026-02-05 16:28:28.235	2026-02-05 16:28:28.235	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SAS	Modèle de pacte d'associés pour SAS	PACTE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule pacte"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de sortie conjointe (tag-along)"}, {"order": 3, "mandatory": true, "blockTitle": "Clause d'entraînement (drag-along)"}, {"order": 4, "mandatory": true, "blockTitle": "Clause de confidentialité"}, {"order": 5, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7rva000dhcc1npk3tkkn	2026-02-05 16:28:28.246	2026-02-05 16:28:28.246	cml6vyl1v0017jms2uzfefv85	Garantie d'actif et passif (GAP)	Convention de garantie d'actif et passif autonome	GARANTIE	\N	Droit des affaires	[{"order": 1, "mandatory": true, "blockTitle": "Préambule GAP"}, {"order": 2, "mandatory": true, "blockTitle": "Clause de garantie d'actif et passif"}, {"order": 3, "mandatory": true, "blockTitle": "Signatures"}]	null	DOCX	null	null	t	0	\N	\N
cml9o7rve000fhcc16bdc1il8	2026-02-05 16:28:28.25	2026-02-05 16:28:28.25	cml6vyl1v0017jms2uzfefv85	Assignation en référé expertise (145 CPC)	Pour obtenir une expertise judiciaire avant tout procès	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rvw000hhcc1p42q6bea	2026-02-05 16:28:28.268	2026-02-05 16:28:28.268	cml6vyl1v0017jms2uzfefv85	Assignation en référé provision	Pour obtenir une provision sur créance non contestable	ASSIGNATION	Tribunal Judiciaire	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rw3000jhcc1dfdxg0ck	2026-02-05 16:28:28.275	2026-02-05 16:28:28.275	cml6vyl1v0017jms2uzfefv85	Conclusions en réplique (demandeur)	Conclusions du demandeur en réponse aux conclusions adverses	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rwb000lhcc1whnaa851	2026-02-05 16:28:28.283	2026-02-05 16:28:28.283	cml6vyl1v0017jms2uzfefv85	Conclusions récapitulatives	Conclusions finales récapitulant l'ensemble des demandes	CONCLUSIONS	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rwi000nhcc1dfofsw9f	2026-02-05 16:28:28.29	2026-02-05 16:28:28.29	cml6vyl1v0017jms2uzfefv85	Opposition à ordonnance d'injonction de payer	Modèle d'opposition à une injonction de payer	OPPOSITION	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rwr000phcc1gitq1ftm	2026-02-05 16:28:28.3	2026-02-05 16:28:28.3	cml6vyl1v0017jms2uzfefv85	Requête en rectification d'erreur matérielle	Pour corriger une erreur dans une décision de justice	REQUETE	\N	Procédure civile	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rwz000rhcc1imo7sh2m	2026-02-05 16:28:28.307	2026-02-05 16:28:28.307	cml6vyl1v0017jms2uzfefv85	Assignation en contrefaçon de marque	Action en contrefaçon devant le Tribunal Judiciaire	ASSIGNATION	Tribunal Judiciaire	Propriété intellectuelle	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rxa000thcc1nx4gs6c5	2026-02-05 16:28:28.319	2026-02-05 16:28:28.319	cml6vyl1v0017jms2uzfefv85	Assignation en concurrence déloyale	Action pour actes de concurrence déloyale	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rxe000vhcc1gfuckdud	2026-02-05 16:28:28.323	2026-02-05 16:28:28.323	cml6vyl1v0017jms2uzfefv85	Assignation en rupture brutale	Action L.442-1 II pour rupture brutale de relations commerciales	ASSIGNATION	Tribunal de Commerce	Procédure commerciale	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rxs000xhcc12364stg4	2026-02-05 16:28:28.337	2026-02-05 16:28:28.337	cml6vyl1v0017jms2uzfefv85	Déclaration de créance (procédure collective)	Déclaration au passif d'une procédure collective	DECLARATION	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rxx000zhcc1h02p32n8	2026-02-05 16:28:28.341	2026-02-05 16:28:28.341	cml6vyl1v0017jms2uzfefv85	Revendication de marchandises	Action en revendication de biens vendus avec réserve de propriété	REQUETE	\N	Procédures collectives	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7ry70011hcc170kr2dfl	2026-02-05 16:28:28.351	2026-02-05 16:28:28.351	cml6vyl1v0017jms2uzfefv85	Saisine Conseil de Prud'hommes - Licenciement	Contestation d'un licenciement devant le CPH	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7ryg0013hcc17arz99wg	2026-02-05 16:28:28.36	2026-02-05 16:28:28.36	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Harcèlement moral	Action pour harcèlement moral au travail	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7ryk0015hcc11tm7tlpn	2026-02-05 16:28:28.364	2026-02-05 16:28:28.364	cml6vyl1v0017jms2uzfefv85	Saisine CPH - Rappel de salaires	Action en rappel de salaires et accessoires	SAISINE	Conseil de Prud'hommes	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7ryw0017hcc18zpzh7jq	2026-02-05 16:28:28.377	2026-02-05 16:28:28.377	cml6vyl1v0017jms2uzfefv85	Conclusions prud'homales (défense employeur)	Conclusions pour l'employeur en défense	CONCLUSIONS	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rz70019hcc1cij9a7nt	2026-02-05 16:28:28.388	2026-02-05 16:28:28.388	cml6vyl1v0017jms2uzfefv85	Transaction rupture contrat de travail	Protocole transactionnel suite à rupture du contrat	PROTOCOLE	\N	Droit du travail	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rzd001bhcc1pxzq40zd	2026-02-05 16:28:28.394	2026-02-05 16:28:28.394	cml6vyl1v0017jms2uzfefv85	Requête divorce par consentement mutuel (notaire)	Convention de divorce par consentement mutuel	REQUETE	\N	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rzq001dhcc1y2ar6ydj	2026-02-05 16:28:28.406	2026-02-05 16:28:28.406	cml6vyl1v0017jms2uzfefv85	Requête divorce contentieux	Requête en divorce pour altération définitive du lien conjugal	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rzv001fhcc17axo9ad4	2026-02-05 16:28:28.412	2026-02-05 16:28:28.412	cml6vyl1v0017jms2uzfefv85	Requête modification pension alimentaire	Modification de la contribution à l'entretien des enfants	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7rzy001hhcc1srnfr4g0	2026-02-05 16:28:28.415	2026-02-05 16:28:28.415	cml6vyl1v0017jms2uzfefv85	Requête droits de visite et d'hébergement	Fixation ou modification du droit de visite	REQUETE	JAF	Droit de la famille	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s02001jhcc1rup3yupb	2026-02-05 16:28:28.418	2026-02-05 16:28:28.418	cml6vyl1v0017jms2uzfefv85	Assignation en garantie décennale	Action contre le constructeur au titre de l'article 1792 CC	ASSIGNATION	Tribunal Judiciaire	Construction	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s06001lhcc1v6rol6t8	2026-02-05 16:28:28.422	2026-02-05 16:28:28.422	cml6vyl1v0017jms2uzfefv85	Assignation en garantie biennale	Action en garantie de bon fonctionnement	ASSIGNATION	\N	Construction	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s0d001nhcc1tdfcjheo	2026-02-05 16:28:28.429	2026-02-05 16:28:28.429	cml6vyl1v0017jms2uzfefv85	Assignation troubles de voisinage	Action pour troubles anormaux de voisinage	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s0m001phcc1a3eai8df	2026-02-05 16:28:28.437	2026-02-05 16:28:28.437	cml6vyl1v0017jms2uzfefv85	Assignation vice caché immobilier	Action rédhibitoire ou estimatoire	ASSIGNATION	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s0w001rhcc11ylqim9y	2026-02-05 16:28:28.448	2026-02-05 16:28:28.448	cml6vyl1v0017jms2uzfefv85	Bail commercial 3-6-9	Modèle complet de bail commercial	CONTRAT	\N	Immobilier	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s12001thcc15bk0gfh5	2026-02-05 16:28:28.455	2026-02-05 16:28:28.455	cml6vyl1v0017jms2uzfefv85	Contrat de cession de parts SARL	Cession de parts sociales de SARL	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s17001vhcc12gvhq572	2026-02-05 16:28:28.459	2026-02-05 16:28:28.459	cml6vyl1v0017jms2uzfefv85	Contrat de cession d'actions SAS	Cession d'actions de SAS	CONTRAT	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s1a001xhcc1fc5ut87t	2026-02-05 16:28:28.463	2026-02-05 16:28:28.463	cml6vyl1v0017jms2uzfefv85	Pacte d'associés SARL	Pacte d'associés pour SARL	PACTE	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s1d001zhcc1c78istur	2026-02-05 16:28:28.466	2026-02-05 16:28:28.466	cml6vyl1v0017jms2uzfefv85	Lettre d'intention (LOI)	Lettre d'intention non engageante M&A	LETTRE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s1m0021hcc1mgmhwtlg	2026-02-05 16:28:28.474	2026-02-05 16:28:28.474	cml6vyl1v0017jms2uzfefv85	Protocole d'accord M&A	Protocole de cession complet avec GAP	PROTOCOLE	\N	M&A	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s1s0023hcc11omc13l9	2026-02-05 16:28:28.48	2026-02-05 16:28:28.48	cml6vyl1v0017jms2uzfefv85	Contrat de franchise	Contrat de franchise commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s1z0025hcc13muo4xml	2026-02-05 16:28:28.487	2026-02-05 16:28:28.487	cml6vyl1v0017jms2uzfefv85	Contrat d'agent commercial	Contrat d'agence commerciale	CONTRAT	\N	Distribution	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s270027hcc1kep2ovgz	2026-02-05 16:28:28.495	2026-02-05 16:28:28.495	cml6vyl1v0017jms2uzfefv85	Contrat de prestation de services	Contrat B2B de prestation de services	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s2b0029hcc15y08fmfn	2026-02-05 16:28:28.5	2026-02-05 16:28:28.5	cml6vyl1v0017jms2uzfefv85	CGV B2B	Conditions générales de vente professionnels	CGV	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s2j002bhcc13c0ed112	2026-02-05 16:28:28.507	2026-02-05 16:28:28.507	cml6vyl1v0017jms2uzfefv85	NDA bilatéral	Accord de confidentialité bilatéral	CONTRAT	\N	Contrats commerciaux	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s2o002dhcc1gu57n9ct	2026-02-05 16:28:28.512	2026-02-05 16:28:28.512	cml6vyl1v0017jms2uzfefv85	Mise en demeure paiement facture	Mise en demeure précontentieuse pour impayé	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s2y002fhcc1wzsveqkm	2026-02-05 16:28:28.522	2026-02-05 16:28:28.522	cml6vyl1v0017jms2uzfefv85	Mise en demeure exécution obligation	Mise en demeure d'exécuter une obligation contractuelle	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s33002hhcc1553dza5c	2026-02-05 16:28:28.528	2026-02-05 16:28:28.528	cml6vyl1v0017jms2uzfefv85	Mise en demeure cessation agissements	Mise en demeure de cesser des agissements illicites	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s3d002jhcc1r20hwlop	2026-02-05 16:28:28.538	2026-02-05 16:28:28.538	cml6vyl1v0017jms2uzfefv85	Lettre de résiliation	Résiliation de contrat avec préavis	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s3k002lhcc1dnaiva14	2026-02-05 16:28:28.544	2026-02-05 16:28:28.544	cml6vyl1v0017jms2uzfefv85	Lettre de réclamation	Réclamation amiable précontentieuse	LETTRE	\N	Courriers	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s3p002nhcc15yqeflzw	2026-02-05 16:28:28.549	2026-02-05 16:28:28.549	cml6vyl1v0017jms2uzfefv85	Statuts SAS	Statuts complets de SAS	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s40002phcc1sloaupfm	2026-02-05 16:28:28.561	2026-02-05 16:28:28.561	cml6vyl1v0017jms2uzfefv85	Statuts SARL	Statuts complets de SARL	STATUTS	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s4b002rhcc1krlznqx2	2026-02-05 16:28:28.571	2026-02-05 16:28:28.571	cml6vyl1v0017jms2uzfefv85	PV AG Ordinaire Annuelle	PV d'approbation des comptes annuels	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s4d002thcc1bdoo3j73	2026-02-05 16:28:28.574	2026-02-05 16:28:28.574	cml6vyl1v0017jms2uzfefv85	PV AG Extraordinaire	PV de modification des statuts	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7s4j002vhcc1n267ujdw	2026-02-05 16:28:28.579	2026-02-05 16:28:28.579	cml6vyl1v0017jms2uzfefv85	PV nomination dirigeant	Décision de nomination d'un dirigeant	PV	\N	Droit des sociétés	[]	null	DOCX	null	null	t	0	\N	\N
cml9o7l5a002df0egw7yndkbt	2026-02-05 16:28:19.533	2026-02-05 16:44:11.922	cml6vyl1v0017jms2uzfefv85	Mise en demeure paiement facture	Mise en demeure précontentieuse pour impayé	MISE_EN_DEMEURE	\N	Courriers	[]	null	DOCX	null	null	t	1	\N	\N
\.


--
-- Data for Name: client_access_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_access_logs (id, "createdAt", "accessId", action, "ipAddress", "userAgent") FROM stdin;
cml9krpwn000711bi27rzlbwe	2026-02-05 14:52:00.359	cml9kquol000511bis5jf9ebt	ACCOUNT_ACTIVATED	127.0.0.1	curl/8.5.0
cml9krwah000911biu0wbnj9v	2026-02-05 14:52:08.634	cml9kquol000511bis5jf9ebt	LOGIN	127.0.0.1	curl/8.5.0
cml9krwcm000b11bijsmtpetv	2026-02-05 14:52:08.71	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9ks4x7000d11bi9fh2njoa	2026-02-05 14:52:19.819	cml9kquol000511bis5jf9ebt	LOGIN	127.0.0.1	curl/8.5.0
cml9ks4y1000f11birbdbugcd	2026-02-05 14:52:19.849	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9ks4zc000h11bi1cflp194	2026-02-05 14:52:19.896	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9kskvu000r11bihu9vt38w	2026-02-05 14:52:40.506	cml9kquol000511bis5jf9ebt	LOGIN	127.0.0.1	curl/8.5.0
cml9kskww000t11bimijkihyo	2026-02-05 14:52:40.544	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
cml9kskyv000v11biejtp5pop	2026-02-05 14:52:40.616	cml9kquol000511bis5jf9ebt	API_REQUEST	127.0.0.1	curl/8.5.0
\.


--
-- Data for Name: client_accesses; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_accesses (id, "createdAt", "updatedAt", "folderId", email, "passwordHash", "activationToken", "tokenExpiresAt", "isActivated", "lastLoginAt") FROM stdin;
cml9kquol000511bis5jf9ebt	2026-02-05 14:51:19.893	2026-02-05 14:52:40.502	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	jean.dupont@techcorp.fr	$2b$10$Xu3UCnjrutRuXs/J4bo6huQvCPY7n/s8O4V3tfvWw77wEEHeBx9qm	\N	\N	t	2026-02-05 14:52:40.501
\.


--
-- Data for Name: client_consents; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_consents (id, "createdAt", "clientId", type, granted, "grantedAt", "ipAddress", "userAgent") FROM stdin;
cml6vyl0r0009jms2v73bxbzx	2026-02-03 17:41:57.868	cml6vykuw0006jms2difazkpa	DATA_PROCESSING	t	2026-02-03 17:41:57.868	192.168.1.100	\N
cml6vyl0r000ajms2e0pu8hwu	2026-02-03 17:41:57.868	cml6vykuw0006jms2difazkpa	EMAIL_NOTIFICATIONS	t	2026-02-03 17:41:57.868	192.168.1.100	\N
cml6vyl0r000bjms2rvuggnqr	2026-02-03 17:41:57.868	cml6vyl0p0008jms2dt1u0gp1	DATA_PROCESSING	t	2026-02-03 17:41:57.868	192.168.1.101	\N
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.clients (id, "createdAt", "updatedAt", type, "firstName", "lastName", "birthDate", "companyName", siret, "vatNumber", email, phone, mobile, address, "addressLine2", "postalCode", city, country, "hasExternet", "extranetPassword", "extranetActivatedAt", "extranetLastLoginAt", "invitationToken", "invitationSentAt", "invitationExpiresAt", "isActive", notes, "tenantId") FROM stdin;
cml6vykuw0006jms2difazkpa	2026-02-03 17:41:57.657	2026-02-03 17:41:57.657	COMPANY	\N	\N	\N	Tech Corp SAS	98765432100012	\N	jean.dupont@techcorp.fr	01 23 45 67 89	\N	456 Avenue de la Tech	\N	75001	Paris	FR	t	$2b$12$sR8AP6dslrQvCMFA60H5NePCJ7KenwISMAs9W58Y1LXRKyQcagv3q	2026-02-03 17:41:57.656	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27
cml6vyl0p0008jms2dt1u0gp1	2026-02-03 17:41:57.865	2026-02-03 17:41:57.865	INDIVIDUAL	Marie	Durand	\N	\N	\N	\N	marie.durand@email.fr	06 12 34 56 78	\N	789 Rue des Fleurs	\N	49100	Angers	FR	t	$2b$12$UTgWyiWCdi4/nw4xSO5cv.E.dhLPpMwNd5915A8JAh6vCzSdoCb0q	2026-02-03 17:41:57.864	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27
cml8feb1j000110pf02s3lt88	2026-02-04 19:33:50.311	2026-02-04 19:33:50.311	COMPANY	\N	\N	\N	StartupX SARL	\N	\N	hello@startupx.fr	\N	\N	\N	\N	\N	\N	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27
cml8feb1q000310pfqjw2w14v	2026-02-04 19:33:50.319	2026-02-04 19:33:50.319	COMPANY	\N	\N	\N	InnovCo SAS	\N	\N	contact@innovco.fr	\N	\N	\N	\N	\N	\N	FR	f	\N	\N	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: conversation_participants; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.conversation_participants (id, "createdAt", "conversationId", "userId", "lastReadAt", "unreadCount", "notificationsEnabled") FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.conversations (id, "createdAt", "updatedAt", subject, "folderId", "lastMessageAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: deadlines; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.deadlines (id, "createdAt", "updatedAt", title, description, "dueDate", "dueTime", type, priority, status, reminders, "lastReminderSentAt", "folderId", "documentId", "assignedToId", "createdById", "tenantId", "isRecurring", "recurrenceRule", "completedAt", "completedById") FROM stdin;
\.


--
-- Data for Name: document_requests; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.document_requests (id, "createdAt", "updatedAt", "folderId", title, description, status, priority, "dueDate", "responseDocumentId", "responseDate", "responseNotes", "reminderCount", "lastReminderAt", "createdById", "tenantId") FROM stdin;
cml9fca98000rh7vhvlhli82s	2026-02-05 12:20:02.156	2026-02-05 12:20:02.156	cml6vyl0v000djms25rbug5x8	Kbis de moins de 3 mois	Merci de fournir un extrait Kbis de votre société datant de moins de 3 mois pour la constitution du dossier.	PENDING	HIGH	2026-02-12 12:20:02.155	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9fca9u000th7vhiks61p0e	2026-02-05 12:20:02.178	2026-02-05 12:20:02.178	cml6vyl0v000djms25rbug5x8	Pièce d'identité	Copie recto-verso de votre pièce d'identité en cours de validité.	PENDING	NORMAL	2026-02-19 12:20:02.177	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9fcaa8000vh7vhu6bquse0	2026-02-05 12:20:02.192	2026-02-05 12:20:02.192	cml6vyl0v000djms25rbug5x8	Derniers bilans comptables	Les 3 derniers bilans comptables certifiés par votre expert-comptable.	PENDING	URGENT	2026-02-08 12:20:02.189	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9kseai000j11bi8qvvdh5f	2026-02-05 14:52:31.963	2026-02-05 14:52:31.963	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	Justificatif de domicile	Merci de fournir un justificatif de domicile de moins de 3 mois (facture EDF, quittance de loyer, etc.)	PENDING	HIGH	2026-02-20 00:00:00	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml9ksedi000n11bicid4rupz	2026-02-05 14:52:32.07	2026-02-05 14:52:32.07	fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	Pièce d'identité	Veuillez fournir une copie de votre carte d'identité ou passeport en cours de validité.	PENDING	URGENT	2026-02-10 00:00:00	\N	\N	\N	0	\N	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: document_tracking; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.document_tracking (id, "createdAt", "updatedAt", "documentId", status, "deliveryMethod", "signatureRequestId", "signatureStatus", "signedAt", "signedBy", "lrarTrackingNumber", "lrarStatus", "sentAt", "deliveredAt", "reminderCount", "lastReminderAt", "nextReminderAt", "autoRemindersEnabled") FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.documents (id, "createdAt", "updatedAt", name, description, type, tags, filename, "originalName", "mimeType", size, checksum, "bucketName", "objectKey", "isEncrypted", version, "parentId", status, "requiresSignature", "signatureDeadline", "validFrom", "validUntil", "archivedAt", "deletedAt", "folderId", "createdById", "tenantId", "folderCategoryId") FROM stdin;
cml6vyl13000jjms232792l1y	2026-02-03 17:41:57.879	2026-02-03 17:41:57.879	Protocole de cession - Tech Corp	\N	CONTRACT	{}	protocole-cession-techcorp.pdf	Protocole de cession.pdf	application/pdf	2516582	abc123def456	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/protocole-cession-techcorp.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-08 17:41:57.878	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N
cml6vyl17000ljms2xfzrqdbk	2026-02-03 17:41:57.883	2026-02-03 17:41:57.883	Acte de garantie d'actif et de passif	\N	DEED	{}	acte-garantie-gap.pdf	GAP.pdf	application/pdf	1874329	def789ghi012	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/acte-garantie-gap.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-10 17:41:57.883	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N
cml6vyl19000njms2iu9iuwvv	2026-02-03 17:41:57.885	2026-02-03 17:41:57.885	Contrat de conseil juridique 2026	\N	CONTRACT	{}	contrat-conseil-2026.pdf	Contrat conseil.pdf	application/pdf	987654	ghi345jkl678	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/contrat-conseil-2026.pdf	t	1	\N	SIGNED	t	\N	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N
cml6vyl1b000pjms2707bomdj	2026-02-03 17:41:57.887	2026-02-03 17:41:57.887	Attestation de livraison - Matériel informatique	\N	CERTIFICATE	{}	attestation-livraison.pdf	Attestation.pdf	application/pdf	654321	jkl901mno234	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/attestation-livraison.pdf	t	1	\N	SENT	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N
cml6vyl1d000rjms21ti62wqk	2026-02-03 17:41:57.889	2026-02-03 17:41:57.889	Avenant contrat commercial n°3	\N	AMENDMENT	{}	avenant-3.pdf	Avenant 3.pdf	application/pdf	456789	mno567pqr890	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/avenant-3.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-04 17:41:57.888	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	\N
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.email_logs (id, "createdAt", "to", subject, template, status, "errorMessage", "notificationId", "tenantId") FROM stdin;
\.


--
-- Data for Name: folder_categories; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_categories (id, "createdAt", "updatedAt", name, description, color, icon, "parentId", "displayOrder", "tenantId") FROM stdin;
cml9fca4d0001h7vhsvoms05d	2026-02-05 12:20:01.981	2026-02-05 12:20:01.981	Contentieux	Documents relatifs aux procédures contentieuses	#EF4444	Scale	\N	1	cml6vykdd0000jms2wwxl9s27
cml9fca4q0003h7vhssckybk0	2026-02-05 12:20:01.995	2026-02-05 12:20:01.995	Corporate	Documents de droit des sociétés	#3B82F6	Building	\N	2	cml6vykdd0000jms2wwxl9s27
cml9fca520005h7vhc62fheha	2026-02-05 12:20:02.005	2026-02-05 12:20:02.005	Contrats	Contrats et conventions	#10B981	FileSignature	\N	3	cml6vykdd0000jms2wwxl9s27
cml9fca5g0007h7vh661fe38w	2026-02-05 12:20:02.021	2026-02-05 12:20:02.021	Pièces Client	Documents fournis par le client	#F59E0B	Upload	\N	4	cml6vykdd0000jms2wwxl9s27
cml9fca5m0008h7vhoq20gqbn	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Assignations	Actes d'assignation	#F87171	FileText	cml9fca4d0001h7vhsvoms05d	1	cml6vykdd0000jms2wwxl9s27
cml9fca5m0009h7vhfqu69v0o	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Conclusions	Conclusions et mémoires	#FB923C	FileText	cml9fca4d0001h7vhsvoms05d	2	cml6vykdd0000jms2wwxl9s27
cml9fca5m000ah7vhf8jyhsof	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Pièces	Pièces du dossier	#FBBF24	Paperclip	cml9fca4d0001h7vhsvoms05d	3	cml6vykdd0000jms2wwxl9s27
cml9fca5m000bh7vhrsa2s3c0	2026-02-05 12:20:02.027	2026-02-05 12:20:02.027	Jugements	Décisions de justice	#A78BFA	Gavel	cml9fca4d0001h7vhsvoms05d	4	cml6vykdd0000jms2wwxl9s27
cml9fca6u000ch7vhoejhtoui	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	Statuts	Statuts et modifications	#60A5FA	FileText	cml9fca4q0003h7vhssckybk0	1	cml6vykdd0000jms2wwxl9s27
cml9fca6u000dh7vhcktfw9sk	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	PV Assemblées	Procès-verbaux d'assemblées	#34D399	Users	cml9fca4q0003h7vhssckybk0	2	cml6vykdd0000jms2wwxl9s27
cml9fca6u000eh7vh9dx3l6pk	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	Cessions	Documents de cession	#818CF8	ArrowRightLeft	cml9fca4q0003h7vhssckybk0	3	cml6vykdd0000jms2wwxl9s27
cml9fca6u000fh7vhstat1869	2026-02-05 12:20:02.07	2026-02-05 12:20:02.07	Garanties	Garanties d'actif et passif	#F472B6	Shield	cml9fca4q0003h7vhssckybk0	4	cml6vykdd0000jms2wwxl9s27
cml9fca7l000gh7vhrbmskz0b	2026-02-05 12:20:02.097	2026-02-05 12:20:02.097	Contrats de travail	CDI, CDD, avenants	#2DD4BF	Briefcase	cml9fca520005h7vhc62fheha	1	cml6vykdd0000jms2wwxl9s27
cml9fca7l000hh7vhef7wy2sn	2026-02-05 12:20:02.097	2026-02-05 12:20:02.097	Contrats commerciaux	Vente, distribution, partenariat	#A3E635	Handshake	cml9fca520005h7vhc62fheha	2	cml6vykdd0000jms2wwxl9s27
cml9fca7l000ih7vhplroctgk	2026-02-05 12:20:02.097	2026-02-05 12:20:02.097	Baux	Baux commerciaux et professionnels	#FB7185	Home	cml9fca520005h7vhc62fheha	3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: folder_persons; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_persons (id, "createdAt", "updatedAt", "folderId", "tenantId", type, role, "firstName", "lastName", company, email, phone, address, notes) FROM stdin;
cml9d6rdu000110v1tusjcjkg	2026-02-05 11:19:45.186	2026-02-05 11:24:12.516	fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	cml6vykdd0000jms2wwxl9s27	PHYSIQUE	PARTIE_ADVERSE	Jean	Dupont	\N	jean.dupont@example.com	06 12 34 56 78	123 rue de Paris, 75001 Paris	Client principal dans le litige
\.


--
-- Data for Name: folder_templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_templates (id, "createdAt", "updatedAt", name, description, "folderType", structure, "tenantId") FROM stdin;
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folders (id, "createdAt", "updatedAt", reference, title, description, type, status, "openedAt", "closedAt", "archivedAt", "clientId", "createdById", "tenantId", color, "metadataCession", "parentId") FROM stdin;
cml6vyl0v000djms25rbug5x8	2026-02-03 17:41:57.872	2026-02-03 17:41:57.872	2026-001	Cession entreprise Tech Corp	Dossier de cession de parts sociales Tech Corp SAS	BUSINESS	IN_PROGRESS	2026-02-03 17:41:57.872	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N
cml6vyl0z000fjms24ukfhi3k	2026-02-03 17:41:57.876	2026-02-03 17:41:57.876	2026-002	Contrats commerciaux	Rédaction contrats fournisseurs	CONTRACT	OPEN	2026-02-03 17:41:57.876	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N
cml6vyl11000hjms2krxzvmzx	2026-02-03 17:41:57.877	2026-02-03 17:41:57.877	2026-003	Litige fournisseur	Contentieux livraison matériel informatique	LITIGATION	IN_PROGRESS	2026-02-03 17:41:57.877	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N
cml8feb1z000510pf9trmhfa2	2026-02-04 19:33:50.327	2026-02-04 19:33:50.327	DOS-2026-004	Tech Corp - Litige Commercial	Contentieux avec fournisseur	LITIGATION	OPEN	2026-02-04 19:33:50.327	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EF4444	\N	\N
cml8feb29000710pfjmjz3odz	2026-02-04 19:33:50.337	2026-02-04 19:33:50.337	DOS-2026-005	Tech Corp - Contrat Distribution	Négociation contrat de distribution	CONTRACT	OPEN	2026-02-04 19:33:50.337	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#10B981	\N	\N
cml8feb2e000910pfzh5ilxb7	2026-02-04 19:33:50.342	2026-02-04 19:33:50.342	DOS-2026-006	StartupX - Levée de Fonds	Série A - Documentation juridique	BUSINESS	OPEN	2026-02-04 19:33:50.342	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#8B5CF6	\N	\N
cml8feb2i000b10pfg17hbnxm	2026-02-04 19:33:50.346	2026-02-04 19:33:50.346	DOS-2026-007	StartupX - Pacte Associés	Rédaction pacte d'associés	BUSINESS	OPEN	2026-02-04 19:33:50.346	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#F59E0B	\N	\N
cml8feb2l000d10pfe8y2gtge	2026-02-04 19:33:50.35	2026-02-04 19:33:50.35	DOS-2026-008	InnovCo - Cession Parts Sociales	Cession de 30% des parts	BUSINESS	OPEN	2026-02-04 19:33:50.35	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EC4899	\N	\N
cml8feb2q000f10pfwi9qm0ph	2026-02-04 19:33:50.354	2026-02-04 19:33:50.354	DOS-2026-009	InnovCo - Propriété Intellectuelle	Dépôt de marque et brevets	INTELLECTUAL	OPEN	2026-02-04 19:33:50.354	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#06B6D4	\N	\N
cml8feb2t000h10pfy2cvm3la	2026-02-04 19:33:50.357	2026-02-04 19:33:50.357	DOS-2026-010	InnovCo - Contrat de Travail	Recrutement CTO	LABOR	OPEN	2026-02-04 19:33:50.357	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#14B8A6	\N	\N
fold_tech_restr_eacd9db5-a02a-48dd-9409-d3439c694379	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-101	Tech Corp - Restructuration 2026	Opération de restructuration complète	BUSINESS	OPEN	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#3B82F6	\N	\N
fold_tech_lit_e091ec9f-dfcf-4f8a-a054-61e0fe3d9730	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-102	Tech Corp - Contentieux Fournisseur Alpha	Litige commercial avec fournisseur	LITIGATION	IN_PROGRESS	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EF4444	\N	\N
fold_tech_dist_1f4ed02c-e37a-4606-be14-71360fb99e00	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-103	Tech Corp - Réseau Distribution	Mise en place réseau de distribution	CONTRACT	OPEN	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#10B981	\N	\N
fold_startup_lev_e8f7e2ec-2596-41e9-9c2c-bc9f8434e3d4	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-104	StartupX - Levée Série A	Documentation juridique levée de fonds	BUSINESS	IN_PROGRESS	2026-02-04 20:53:56.607	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#8B5CF6	\N	\N
fold_startup_pac_bb3f0f72-98b9-4ddd-a1de-e1abfb4822d6	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-105	StartupX - Pacte Associés	Rédaction et négociation pacte	BUSINESS	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#F59E0B	\N	\N
fold_startup_cto_158cb796-a1ca-4c54-966c-58bf6c3c534a	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-106	StartupX - Recrutement CTO	Contrat de travail directeur technique	LABOR	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1j000110pf02s3lt88	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#06B6D4	\N	\N
fold_innovco_ces_efa4a2b3-f8d8-4b74-81d7-b1acbf9cdee6	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-107	InnovCo - Cession 30% Parts	Cession parts sociales à investisseur	BUSINESS	IN_PROGRESS	2026-02-04 20:53:56.607	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#EC4899	\N	\N
fold_innovco_pi_99e1fdfc-e178-456a-8214-357acb846f80	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-108	InnovCo - Protection Marques	Dépôt et protection marques et brevets	INTELLECTUAL	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#14B8A6	\N	\N
fold_innovco_lic_75a54213-9d67-42fe-9725-a3d2ed3e2890	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-109	InnovCo - Licence Technologie	Contrat de licence technologique	CONTRACT	OPEN	2026-02-04 20:53:56.607	\N	\N	cml8feb1q000310pfqjw2w14v	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#0EA5E9	\N	\N
fold_tech_bail_a6618d0b-7990-412c-9ac5-5d68e250b04c	2026-02-04 20:53:56.607	2026-02-04 20:53:56.607	DOS-2026-110	Tech Corp - Nouveau Siège Social	Négociation bail commercial nouveaux locaux	CONTRACT	OPEN	2026-02-04 20:53:56.607	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27	#FBBF24	\N	\N
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.messages (id, "createdAt", "updatedAt", "conversationId", content, attachments, "senderId", "isEdited", "editedAt", "isDeleted", "deletedAt", "tenantId") FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.notification_preferences (id, "createdAt", "updatedAt", "userId", "emailSignatures", "emailDocuments", "emailDeadlines", "emailMessages", "emailDigest", "digestFrequency", "pushEnabled", "pushSignatures", "pushDocuments", "pushDeadlines", "pushMessages") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.notifications (id, "createdAt", type, title, message, "entityType", "entityId", link, "isRead", "readAt", "emailSent", "emailSentAt", "userId", "tenantId") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.push_subscriptions (id, "createdAt", "accessId", endpoint, keys) FROM stdin;
\.


--
-- Data for Name: registered_mails; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.registered_mails (id, "createdAt", "updatedAt", "documentId", "recipientName", "recipientAddress", "recipientCity", "recipientPostalCode", "recipientCountry", "sendingBoxId", "trackingNumber", status, "sentAt", "deliveredAt", "returnedAt", "proofUrl", cost) FROM stdin;
cml6vyl1p0014jms2af8xdbue	2026-02-03 17:41:57.902	2026-02-03 17:41:57.902	cml6vyl1b000pjms2707bomdj	Fournisseur Tech SARL	123 Rue du Commerce	Lyon	69001	FR	\N	FR123456789	IN_TRANSIT	2026-02-01 17:41:57.901	\N	\N	\N	\N
\.


--
-- Data for Name: reminder_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.reminder_logs (id, "createdAt", "trackingId", type, "sentAt", "sentTo", "emailSubject", "emailBody", status, "errorMessage") FROM stdin;
\.


--
-- Data for Name: signature_reminders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signature_reminders (id, "createdAt", "signatureId", "reminderNumber", "sentAt", "emailSent", "smsSent") FROM stdin;
cml6vyl1m0010jms2uk36e2zy	2026-02-03 17:41:57.898	cml6vyl1e000tjms2oi4th11h	1	2026-02-01 17:41:57.898	t	f
cml6vyl1m0011jms26zxu8vli	2026-02-03 17:41:57.898	cml6vyl1e000tjms2oi4th11h	2	2026-02-02 17:41:57.898	t	f
cml6vyl1m0012jms29qtoymzb	2026-02-03 17:41:57.898	cml6vyl1i000vjms2rmc6urqc	1	2026-02-02 17:41:57.898	t	f
cml7uwcpu0001rpkq0ilqjtk6	2026-02-04 10:00:00.354	cml6vyl1e000tjms2oi4th11h	3	2026-02-04 10:00:00.354	t	f
cml7uwcrr0003rpkqe7dxmqg6	2026-02-04 10:00:00.424	cml6vyl1i000vjms2rmc6urqc	2	2026-02-04 10:00:00.424	t	f
cml9ac89y0005nk90u2iydwi1	2026-02-05 10:00:01.509	cml6vyl1i000vjms2rmc6urqc	3	2026-02-05 10:00:01.509	t	f
cml9ac8dy0007nk90v7lklqbv	2026-02-05 10:00:01.653	cml6vyl1l000zjms2xq80j8mr	1	2026-02-05 10:00:01.653	t	f
\.


--
-- Data for Name: signatures; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signatures (id, "createdAt", "updatedAt", "documentId", "signerEmail", "signerName", "signerType", "transactionId", "signatureUrl", status, "invitedAt", "signedAt", "refusedAt", "expiredAt", "certificateUrl") FROM stdin;
cml6vyl1e000tjms2oi4th11h	2026-02-03 17:41:57.891	2026-02-03 17:41:57.891	cml6vyl13000jjms232792l1y	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-01-29 17:41:57.89	\N	\N	\N	\N
cml6vyl1i000vjms2rmc6urqc	2026-02-03 17:41:57.894	2026-02-03 17:41:57.894	cml6vyl17000ljms2xfzrqdbk	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-01-31 17:41:57.893	\N	\N	\N	\N
cml6vyl1j000xjms2aikx8iv1	2026-02-03 17:41:57.896	2026-02-03 17:41:57.896	cml6vyl19000njms2iu9iuwvv	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	SIGNED	2026-01-16 17:41:57.895	2026-01-19 17:41:57.895	\N	\N	\N
cml6vyl1l000zjms2xq80j8mr	2026-02-03 17:41:57.897	2026-02-03 17:41:57.897	cml6vyl1d000rjms21ti62wqk	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-02-03 11:41:57.896	\N	\N	\N	\N
\.


--
-- Data for Name: template_categories; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.template_categories (id, "createdAt", "updatedAt", name, description, icon, color, "displayOrder", "tenantId") FROM stdin;
cml9fca83000jh7vh4vzhpchi	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Contentieux	Templates pour les procédures contentieuses	Scale	#EF4444	1	cml6vykdd0000jms2wwxl9s27
cml9fca83000kh7vhuworsxey	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Corporate	Templates de droit des sociétés	Building	#3B82F6	2	cml6vykdd0000jms2wwxl9s27
cml9fca83000lh7vhzt8kzj8y	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Contrats	Templates de contrats	FileSignature	#10B981	3	cml6vykdd0000jms2wwxl9s27
cml9fca83000mh7vhqmbtni2v	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Courriers	Templates de courriers	Mail	#8B5CF6	4	cml6vykdd0000jms2wwxl9s27
cml9fca83000nh7vha6xyd4pm	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Immobilier	Templates immobilier	Home	#F59E0B	5	cml6vykdd0000jms2wwxl9s27
cml9fca83000oh7vhms0omora	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Social	Templates droit social	Users	#EC4899	6	cml6vykdd0000jms2wwxl9s27
cml9fca83000ph7vhiglst228	2026-02-05 12:20:02.115	2026-02-05 12:20:02.115	Propriété intellectuelle	Templates PI/Marques/Brevets	Lightbulb	#14B8A6	7	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.tenant_settings (id, "createdAt", "updatedAt", "enableReminders", "reminderSchedule", "maxReminders", "defaultSignatureDeadlineDays", "emailFromName", "emailReplyTo", "emailSignature", "lrarSenderName", "lrarSenderAddress", "documentRetentionYears", "autoArchiveClosedFolders", "autoArchiveAfterDays", "enforceStrongPasswords", "sessionTimeoutMinutes", "require2FA", "allowClientUpload", "clientUploadMaxSizeMB", "tenantId") FROM stdin;
cml6vyl1t0016jms240uih3kh	2026-02-03 17:41:57.905	2026-02-03 17:41:57.905	t	1,3,5	3	7	Cabinet Pragmavox	contact@pragmavox.fr	\N	\N	\N	10	f	365	t	480	f	f	10	cml6vykdd0000jms2wwxl9s27
cml6vyl7s001bjms2x4pqt7mo	2026-02-03 17:41:58.12	2026-02-03 17:41:58.12	t	1,3,5	3	7	\N	\N	\N	\N	\N	10	f	365	t	480	f	f	10	cml6vyl1v0017jms2uzfefv85
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.tenants (id, "createdAt", "updatedAt", name, "legalName", siret, address, "postalCode", city, country, phone, email, website, logo, "primaryColor", "isActive", "subscriptionTier", "maxUsers", "maxClients", "maxStorage", "trialEndsAt", "subscribedAt") FROM stdin;
cml6vykdd0000jms2wwxl9s27	2026-02-03 17:41:57.026	2026-02-03 17:41:57.026	Cabinet Pragmavox	Cabinet Pragmavox Avocat	12345678900011	123 Rue de la Paix	49000	Angers	FR	02 41 00 00 00	contact@pragmavox.fr	https://pragmavox.fr	\N	#0066ff	t	PRO	5	100	5368709120	\N	\N
cml6vyl1v0017jms2uzfefv85	2026-02-03 17:41:57.908	2026-02-03 17:41:57.908	Cabinet Juridicom	Cabinet Juridicom & Associés	98765432100013	\N	\N	\N	FR	\N	contact@juridicom.fr	\N	\N	#0066ff	t	BASIC	5	100	5368709120	\N	\N
cml88g71z0000521vp3t710u4	2026-02-04 16:19:21.143	2026-02-04 16:19:21.143	LexDoc Système	\N	\N	\N	\N	\N	FR	\N	system@lexdoc.fr	\N	\N	#0066ff	t	TRIAL	5	100	5368709120	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.users (id, "createdAt", "updatedAt", email, password, "firstName", "lastName", phone, avatar, role, permissions, "isActive", "isEmailVerified", "emailVerifiedAt", "lastLoginAt", "resetToken", "resetTokenExpiresAt", "tenantId", "refreshTokens", "twoFactorEnabled", "twoFactorSecret") FROM stdin;
cml6vykp40004jms2d2rnfrpm	2026-02-03 17:41:57.449	2026-02-03 17:41:57.449	assistant@pragmavox.fr	$2b$12$X04CXAF5kKlOVApw208cy.btG8k9PsUrTXUo1RUYdnytgEiAvLrf2	Sophie	Martin	\N	\N	ASSISTANT	\N	t	t	2026-02-03 17:41:57.448	\N	\N	\N	cml6vykdd0000jms2wwxl9s27	{}	f	\N
cml6vyl7q0019jms2mpbhvpm5	2026-02-03 17:41:58.118	2026-02-04 18:28:07.328	admin@juridicom.fr	$2b$12$oi3gWiJu07P.zzarhwQTX.V2Vu869ZzmqEeG2EyHXaGKaHtUXrfxy	Pierre	Legrand	\N	\N	ADMIN	\N	t	t	2026-02-03 17:41:58.117	2026-02-04 18:28:07.327	\N	\N	cml6vyl1v0017jms2uzfefv85	{}	f	\N
cml6vykja0002jms2hhr4hfr3	2026-02-03 17:41:57.238	2026-02-05 22:08:36.337	yves-marie.bienaime@pragmavox.fr	$2b$12$p1VevXVnTybDli3BCLSvGeslrpJw5/GqVeNZsog6jph447YHcDEou	Yves-Marie	Bienaimé	\N	\N	ADMIN	\N	t	t	2026-02-03 17:41:57.237	2026-02-05 22:08:36.336	\N	\N	cml6vykdd0000jms2wwxl9s27	{}	f	\N
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: avocat_legal_info avocat_legal_info_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.avocat_legal_info
    ADD CONSTRAINT avocat_legal_info_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: builder_blocks builder_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_blocks
    ADD CONSTRAINT builder_blocks_pkey PRIMARY KEY (id);


--
-- Name: builder_templates builder_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_templates
    ADD CONSTRAINT builder_templates_pkey PRIMARY KEY (id);


--
-- Name: client_access_logs client_access_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_access_logs
    ADD CONSTRAINT client_access_logs_pkey PRIMARY KEY (id);


--
-- Name: client_accesses client_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_accesses
    ADD CONSTRAINT client_accesses_pkey PRIMARY KEY (id);


--
-- Name: client_consents client_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_consents
    ADD CONSTRAINT client_consents_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: conversation_participants conversation_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: deadlines deadlines_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT deadlines_pkey PRIMARY KEY (id);


--
-- Name: document_requests document_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT document_requests_pkey PRIMARY KEY (id);


--
-- Name: document_tracking document_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_tracking
    ADD CONSTRAINT document_tracking_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: folder_categories folder_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_categories
    ADD CONSTRAINT folder_categories_pkey PRIMARY KEY (id);


--
-- Name: folder_persons folder_persons_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT folder_persons_pkey PRIMARY KEY (id);


--
-- Name: folder_templates folder_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_templates
    ADD CONSTRAINT folder_templates_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: registered_mails registered_mails_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.registered_mails
    ADD CONSTRAINT registered_mails_pkey PRIMARY KEY (id);


--
-- Name: reminder_logs reminder_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.reminder_logs
    ADD CONSTRAINT reminder_logs_pkey PRIMARY KEY (id);


--
-- Name: signature_reminders signature_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_reminders
    ADD CONSTRAINT signature_reminders_pkey PRIMARY KEY (id);


--
-- Name: signatures signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT signatures_pkey PRIMARY KEY (id);


--
-- Name: template_categories template_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.template_categories
    ADD CONSTRAINT template_categories_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_tenantId_idx" ON public.audit_logs USING btree ("tenantId");


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: avocat_legal_info_tenantId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "avocat_legal_info_tenantId_key" ON public.avocat_legal_info USING btree ("tenantId");


--
-- Name: backup_logs_startedAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "backup_logs_startedAt_idx" ON public.backup_logs USING btree ("startedAt");


--
-- Name: backup_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "backup_logs_tenantId_idx" ON public.backup_logs USING btree ("tenantId");


--
-- Name: builder_blocks_category_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX builder_blocks_category_idx ON public.builder_blocks USING btree (category);


--
-- Name: builder_blocks_isSystem_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_blocks_isSystem_idx" ON public.builder_blocks USING btree ("isSystem");


--
-- Name: builder_blocks_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_blocks_tenantId_idx" ON public.builder_blocks USING btree ("tenantId");


--
-- Name: builder_templates_category_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX builder_templates_category_idx ON public.builder_templates USING btree (category);


--
-- Name: builder_templates_documentType_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_documentType_idx" ON public.builder_templates USING btree ("documentType");


--
-- Name: builder_templates_isSystem_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_isSystem_idx" ON public.builder_templates USING btree ("isSystem");


--
-- Name: builder_templates_templateCategoryId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_templateCategoryId_idx" ON public.builder_templates USING btree ("templateCategoryId");


--
-- Name: builder_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "builder_templates_tenantId_idx" ON public.builder_templates USING btree ("tenantId");


--
-- Name: client_access_logs_accessId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_access_logs_accessId_idx" ON public.client_access_logs USING btree ("accessId");


--
-- Name: client_access_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_access_logs_createdAt_idx" ON public.client_access_logs USING btree ("createdAt");


--
-- Name: client_accesses_activationToken_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_accesses_activationToken_idx" ON public.client_accesses USING btree ("activationToken");


--
-- Name: client_accesses_activationToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "client_accesses_activationToken_key" ON public.client_accesses USING btree ("activationToken");


--
-- Name: client_accesses_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX client_accesses_email_idx ON public.client_accesses USING btree (email);


--
-- Name: client_accesses_folderId_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "client_accesses_folderId_email_key" ON public.client_accesses USING btree ("folderId", email);


--
-- Name: client_consents_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_consents_clientId_idx" ON public.client_consents USING btree ("clientId");


--
-- Name: clients_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX clients_email_idx ON public.clients USING btree (email);


--
-- Name: clients_invitationToken_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_invitationToken_idx" ON public.clients USING btree ("invitationToken");


--
-- Name: clients_invitationToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "clients_invitationToken_key" ON public.clients USING btree ("invitationToken");


--
-- Name: clients_tenantId_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_tenantId_email_idx" ON public.clients USING btree ("tenantId", email);


--
-- Name: clients_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_tenantId_idx" ON public.clients USING btree ("tenantId");


--
-- Name: conversation_participants_conversationId_userId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "conversation_participants_conversationId_userId_key" ON public.conversation_participants USING btree ("conversationId", "userId");


--
-- Name: conversation_participants_userId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversation_participants_userId_idx" ON public.conversation_participants USING btree ("userId");


--
-- Name: conversations_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversations_folderId_idx" ON public.conversations USING btree ("folderId");


--
-- Name: conversations_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversations_lastMessageAt_idx" ON public.conversations USING btree ("lastMessageAt");


--
-- Name: conversations_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "conversations_tenantId_idx" ON public.conversations USING btree ("tenantId");


--
-- Name: deadlines_assignedToId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_assignedToId_idx" ON public.deadlines USING btree ("assignedToId");


--
-- Name: deadlines_dueDate_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_dueDate_idx" ON public.deadlines USING btree ("dueDate");


--
-- Name: deadlines_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_folderId_idx" ON public.deadlines USING btree ("folderId");


--
-- Name: deadlines_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX deadlines_status_idx ON public.deadlines USING btree (status);


--
-- Name: deadlines_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "deadlines_tenantId_idx" ON public.deadlines USING btree ("tenantId");


--
-- Name: document_requests_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "document_requests_folderId_idx" ON public.document_requests USING btree ("folderId");


--
-- Name: document_requests_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX document_requests_status_idx ON public.document_requests USING btree (status);


--
-- Name: document_requests_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "document_requests_tenantId_idx" ON public.document_requests USING btree ("tenantId");


--
-- Name: document_tracking_documentId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "document_tracking_documentId_key" ON public.document_tracking USING btree ("documentId");


--
-- Name: document_tracking_lrarTrackingNumber_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "document_tracking_lrarTrackingNumber_key" ON public.document_tracking USING btree ("lrarTrackingNumber");


--
-- Name: document_tracking_nextReminderAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "document_tracking_nextReminderAt_idx" ON public.document_tracking USING btree ("nextReminderAt");


--
-- Name: document_tracking_signatureRequestId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "document_tracking_signatureRequestId_key" ON public.document_tracking USING btree ("signatureRequestId");


--
-- Name: document_tracking_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX document_tracking_status_idx ON public.document_tracking USING btree (status);


--
-- Name: documents_checksum_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX documents_checksum_idx ON public.documents USING btree (checksum);


--
-- Name: documents_folderCategoryId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_folderCategoryId_idx" ON public.documents USING btree ("folderCategoryId");


--
-- Name: documents_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_folderId_idx" ON public.documents USING btree ("folderId");


--
-- Name: documents_requiresSignature_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_requiresSignature_idx" ON public.documents USING btree ("requiresSignature");


--
-- Name: documents_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX documents_status_idx ON public.documents USING btree (status);


--
-- Name: documents_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_tenantId_idx" ON public.documents USING btree ("tenantId");


--
-- Name: email_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "email_logs_createdAt_idx" ON public.email_logs USING btree ("createdAt");


--
-- Name: email_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "email_logs_tenantId_idx" ON public.email_logs USING btree ("tenantId");


--
-- Name: folder_categories_parentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_categories_parentId_idx" ON public.folder_categories USING btree ("parentId");


--
-- Name: folder_categories_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_categories_tenantId_idx" ON public.folder_categories USING btree ("tenantId");


--
-- Name: folder_persons_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_persons_folderId_idx" ON public.folder_persons USING btree ("folderId");


--
-- Name: folder_persons_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_persons_tenantId_idx" ON public.folder_persons USING btree ("tenantId");


--
-- Name: folder_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_templates_tenantId_idx" ON public.folder_templates USING btree ("tenantId");


--
-- Name: folders_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_clientId_idx" ON public.folders USING btree ("clientId");


--
-- Name: folders_parentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_parentId_idx" ON public.folders USING btree ("parentId");


--
-- Name: folders_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX folders_status_idx ON public.folders USING btree (status);


--
-- Name: folders_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_tenantId_idx" ON public.folders USING btree ("tenantId");


--
-- Name: folders_tenantId_reference_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "folders_tenantId_reference_key" ON public.folders USING btree ("tenantId", reference);


--
-- Name: messages_conversationId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "messages_conversationId_idx" ON public.messages USING btree ("conversationId");


--
-- Name: messages_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "messages_createdAt_idx" ON public.messages USING btree ("createdAt");


--
-- Name: messages_senderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "messages_senderId_idx" ON public.messages USING btree ("senderId");


--
-- Name: notification_preferences_userId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "notification_preferences_userId_key" ON public.notification_preferences USING btree ("userId");


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "notifications_tenantId_idx" ON public.notifications USING btree ("tenantId");


--
-- Name: notifications_userId_isRead_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "notifications_userId_isRead_idx" ON public.notifications USING btree ("userId", "isRead");


--
-- Name: push_subscriptions_accessId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "push_subscriptions_accessId_idx" ON public.push_subscriptions USING btree ("accessId");


--
-- Name: push_subscriptions_endpoint_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX push_subscriptions_endpoint_key ON public.push_subscriptions USING btree (endpoint);


--
-- Name: registered_mails_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "registered_mails_documentId_idx" ON public.registered_mails USING btree ("documentId");


--
-- Name: registered_mails_sendingBoxId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "registered_mails_sendingBoxId_key" ON public.registered_mails USING btree ("sendingBoxId");


--
-- Name: registered_mails_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX registered_mails_status_idx ON public.registered_mails USING btree (status);


--
-- Name: registered_mails_trackingNumber_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "registered_mails_trackingNumber_idx" ON public.registered_mails USING btree ("trackingNumber");


--
-- Name: registered_mails_trackingNumber_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "registered_mails_trackingNumber_key" ON public.registered_mails USING btree ("trackingNumber");


--
-- Name: reminder_logs_sentAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "reminder_logs_sentAt_idx" ON public.reminder_logs USING btree ("sentAt");


--
-- Name: reminder_logs_trackingId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "reminder_logs_trackingId_idx" ON public.reminder_logs USING btree ("trackingId");


--
-- Name: signature_reminders_signatureId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signature_reminders_signatureId_idx" ON public.signature_reminders USING btree ("signatureId");


--
-- Name: signatures_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_documentId_idx" ON public.signatures USING btree ("documentId");


--
-- Name: signatures_signerEmail_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_signerEmail_idx" ON public.signatures USING btree ("signerEmail");


--
-- Name: signatures_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX signatures_status_idx ON public.signatures USING btree (status);


--
-- Name: signatures_transactionId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_transactionId_idx" ON public.signatures USING btree ("transactionId");


--
-- Name: signatures_transactionId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "signatures_transactionId_key" ON public.signatures USING btree ("transactionId");


--
-- Name: template_categories_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "template_categories_tenantId_idx" ON public.template_categories USING btree ("tenantId");


--
-- Name: tenant_settings_tenantId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "tenant_settings_tenantId_key" ON public.tenant_settings USING btree ("tenantId");


--
-- Name: tenants_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX tenants_email_idx ON public.tenants USING btree (email);


--
-- Name: tenants_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX tenants_email_key ON public.tenants USING btree (email);


--
-- Name: tenants_siret_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX tenants_siret_idx ON public.tenants USING btree (siret);


--
-- Name: tenants_siret_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX tenants_siret_key ON public.tenants USING btree (siret);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: users_tenantId_role_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "users_tenantId_role_idx" ON public.users USING btree ("tenantId", role);


--
-- Name: audit_logs audit_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: avocat_legal_info avocat_legal_info_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.avocat_legal_info
    ADD CONSTRAINT "avocat_legal_info_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_logs backup_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT "backup_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: builder_blocks builder_blocks_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_blocks
    ADD CONSTRAINT "builder_blocks_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: builder_templates builder_templates_templateCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_templates
    ADD CONSTRAINT "builder_templates_templateCategoryId_fkey" FOREIGN KEY ("templateCategoryId") REFERENCES public.template_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: builder_templates builder_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.builder_templates
    ADD CONSTRAINT "builder_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_access_logs client_access_logs_accessId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_access_logs
    ADD CONSTRAINT "client_access_logs_accessId_fkey" FOREIGN KEY ("accessId") REFERENCES public.client_accesses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_accesses client_accesses_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_accesses
    ADD CONSTRAINT "client_accesses_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_consents client_consents_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_consents
    ADD CONSTRAINT "client_consents_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: clients clients_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT "clients_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT "conversation_participants_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deadlines deadlines_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT "deadlines_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deadlines deadlines_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT "deadlines_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: deadlines deadlines_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT "deadlines_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_requests document_requests_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_requests document_requests_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_requests document_requests_responseDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_responseDocumentId_fkey" FOREIGN KEY ("responseDocumentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_requests document_requests_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_requests
    ADD CONSTRAINT "document_requests_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_tracking document_tracking_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.document_tracking
    ADD CONSTRAINT "document_tracking_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: documents documents_folderCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_folderCategoryId_fkey" FOREIGN KEY ("folderCategoryId") REFERENCES public.folder_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_categories folder_categories_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_categories
    ADD CONSTRAINT "folder_categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.folder_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_categories folder_categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_categories
    ADD CONSTRAINT "folder_categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_persons folder_persons_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT "folder_persons_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_persons folder_persons_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_persons
    ADD CONSTRAINT "folder_persons_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_templates folder_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_templates
    ADD CONSTRAINT "folder_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folders folders_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: folders folders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: folders folders_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: folders folders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT "notification_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_accessId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_accessId_fkey" FOREIGN KEY ("accessId") REFERENCES public.client_accesses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: registered_mails registered_mails_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.registered_mails
    ADD CONSTRAINT "registered_mails_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reminder_logs reminder_logs_trackingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.reminder_logs
    ADD CONSTRAINT "reminder_logs_trackingId_fkey" FOREIGN KEY ("trackingId") REFERENCES public.document_tracking(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: signature_reminders signature_reminders_signatureId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_reminders
    ADD CONSTRAINT "signature_reminders_signatureId_fkey" FOREIGN KEY ("signatureId") REFERENCES public.signatures(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: signatures signatures_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT "signatures_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: template_categories template_categories_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.template_categories
    ADD CONSTRAINT "template_categories_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT "tenant_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 0ZkkluHnRZ08mr0heKc3fp7L1Nh0AUUfVb46GNl8KvMs92IiIDZ9o5h6J06bUt9

