--
-- PostgreSQL database dump
--

\restrict eNGUW01yP0q9pGchrQiqrQlBE4pUBb8uciKsgVtOa3Nr8cIdjsOHcHackH6xNlo

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ClientType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ClientType" AS ENUM (
    'INDIVIDUAL',
    'COMPANY',
    'ASSOCIATION'
);


ALTER TYPE public."ClientType" OWNER TO lexdoc_user;

--
-- Name: ConsentType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."ConsentType" AS ENUM (
    'DATA_PROCESSING',
    'EMAIL_NOTIFICATIONS',
    'SMS_NOTIFICATIONS',
    'DOCUMENT_STORAGE',
    'DATA_RETENTION'
);


ALTER TYPE public."ConsentType" OWNER TO lexdoc_user;

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'DRAFT',
    'PENDING_REVIEW',
    'PENDING_SIGNATURE',
    'SIGNED',
    'SENT',
    'ARCHIVED',
    'CANCELLED'
);


ALTER TYPE public."DocumentStatus" OWNER TO lexdoc_user;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."DocumentType" AS ENUM (
    'CONTRACT',
    'DEED',
    'LETTER',
    'INVOICE',
    'RECEIPT',
    'CERTIFICATE',
    'REPORT',
    'MINUTES',
    'AMENDMENT',
    'MEMORANDUM',
    'POWER_OF_ATTORNEY',
    'OTHER'
);


ALTER TYPE public."DocumentType" OWNER TO lexdoc_user;

--
-- Name: FolderStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."FolderStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'PENDING',
    'CLOSED',
    'ARCHIVED'
);


ALTER TYPE public."FolderStatus" OWNER TO lexdoc_user;

--
-- Name: FolderType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."FolderType" AS ENUM (
    'LITIGATION',
    'CONTRACT',
    'BUSINESS',
    'FAMILY',
    'REAL_ESTATE',
    'LABOR',
    'INTELLECTUAL',
    'ADMINISTRATIVE',
    'CRIMINAL',
    'OTHER'
);


ALTER TYPE public."FolderType" OWNER TO lexdoc_user;

--
-- Name: RegisteredMailStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."RegisteredMailStatus" AS ENUM (
    'PREPARING',
    'SENT',
    'IN_TRANSIT',
    'DELIVERED',
    'RETURNED',
    'ERROR'
);


ALTER TYPE public."RegisteredMailStatus" OWNER TO lexdoc_user;

--
-- Name: SignatureStatus; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."SignatureStatus" AS ENUM (
    'PENDING',
    'SIGNED',
    'REFUSED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."SignatureStatus" OWNER TO lexdoc_user;

--
-- Name: SignerType; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."SignerType" AS ENUM (
    'CLIENT',
    'LAWYER',
    'THIRD_PARTY'
);


ALTER TYPE public."SignerType" OWNER TO lexdoc_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: lexdoc_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'LAWYER',
    'ASSISTANT',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO lexdoc_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO lexdoc_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text,
    changes jsonb,
    metadata jsonb,
    "userId" text,
    "ipAddress" text,
    "userAgent" text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO lexdoc_user;

--
-- Name: client_consents; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.client_consents (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "clientId" text NOT NULL,
    type public."ConsentType" NOT NULL,
    granted boolean NOT NULL,
    "grantedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "userAgent" text
);


ALTER TABLE public.client_consents OWNER TO lexdoc_user;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.clients (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    type public."ClientType" DEFAULT 'INDIVIDUAL'::public."ClientType" NOT NULL,
    "firstName" text,
    "lastName" text,
    "birthDate" timestamp(3) without time zone,
    "companyName" text,
    siret text,
    "vatNumber" text,
    email text NOT NULL,
    phone text,
    mobile text,
    address text,
    "addressLine2" text,
    "postalCode" text,
    city text,
    country text DEFAULT 'FR'::text NOT NULL,
    "hasExternet" boolean DEFAULT false NOT NULL,
    "extranetPassword" text,
    "extranetActivatedAt" timestamp(3) without time zone,
    "extranetLastLoginAt" timestamp(3) without time zone,
    "invitationToken" text,
    "invitationSentAt" timestamp(3) without time zone,
    "invitationExpiresAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    notes text,
    "tenantId" text NOT NULL
);


ALTER TABLE public.clients OWNER TO lexdoc_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    type public."DocumentType" NOT NULL,
    category text,
    tags text[] DEFAULT ARRAY[]::text[],
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    size bigint NOT NULL,
    checksum text NOT NULL,
    "bucketName" text NOT NULL,
    "objectKey" text NOT NULL,
    "isEncrypted" boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "parentId" text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    "requiresSignature" boolean DEFAULT false NOT NULL,
    "signatureDeadline" timestamp(3) without time zone,
    "validFrom" timestamp(3) without time zone,
    "validUntil" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "deletedAt" timestamp(3) without time zone,
    "folderId" text NOT NULL,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.documents OWNER TO lexdoc_user;

--
-- Name: folder_templates; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folder_templates (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    description text,
    "folderType" public."FolderType" NOT NULL,
    structure jsonb NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.folder_templates OWNER TO lexdoc_user;

--
-- Name: folders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.folders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    reference text NOT NULL,
    title text NOT NULL,
    description text,
    type public."FolderType" NOT NULL,
    status public."FolderStatus" DEFAULT 'OPEN'::public."FolderStatus" NOT NULL,
    "openedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "archivedAt" timestamp(3) without time zone,
    "clientId" text NOT NULL,
    "createdById" text NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.folders OWNER TO lexdoc_user;

--
-- Name: registered_mails; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.registered_mails (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    "recipientName" text NOT NULL,
    "recipientAddress" text NOT NULL,
    "recipientCity" text NOT NULL,
    "recipientPostalCode" text NOT NULL,
    "recipientCountry" text DEFAULT 'FR'::text NOT NULL,
    "sendingBoxId" text,
    "trackingNumber" text,
    status public."RegisteredMailStatus" DEFAULT 'PREPARING'::public."RegisteredMailStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "returnedAt" timestamp(3) without time zone,
    "proofUrl" text,
    cost numeric(10,2)
);


ALTER TABLE public.registered_mails OWNER TO lexdoc_user;

--
-- Name: signature_reminders; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signature_reminders (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "signatureId" text NOT NULL,
    "reminderNumber" integer NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "emailSent" boolean DEFAULT true NOT NULL,
    "smsSent" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.signature_reminders OWNER TO lexdoc_user;

--
-- Name: signatures; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.signatures (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentId" text NOT NULL,
    "signerEmail" text NOT NULL,
    "signerName" text NOT NULL,
    "signerType" public."SignerType" DEFAULT 'CLIENT'::public."SignerType" NOT NULL,
    "transactionId" text,
    "signatureUrl" text,
    status public."SignatureStatus" DEFAULT 'PENDING'::public."SignatureStatus" NOT NULL,
    "invitedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "signedAt" timestamp(3) without time zone,
    "refusedAt" timestamp(3) without time zone,
    "expiredAt" timestamp(3) without time zone,
    "certificateUrl" text
);


ALTER TABLE public.signatures OWNER TO lexdoc_user;

--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.tenant_settings (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "enableReminders" boolean DEFAULT true NOT NULL,
    "reminderSchedule" text DEFAULT '1,3,5'::text NOT NULL,
    "maxReminders" integer DEFAULT 3 NOT NULL,
    "defaultSignatureDeadlineDays" integer DEFAULT 7 NOT NULL,
    "emailFromName" text,
    "emailReplyTo" text,
    "emailSignature" text,
    "lrarSenderName" text,
    "lrarSenderAddress" text,
    "documentRetentionYears" integer DEFAULT 10 NOT NULL,
    "autoArchiveClosedFolders" boolean DEFAULT false NOT NULL,
    "autoArchiveAfterDays" integer DEFAULT 365 NOT NULL,
    "enforceStrongPasswords" boolean DEFAULT true NOT NULL,
    "sessionTimeoutMinutes" integer DEFAULT 480 NOT NULL,
    "require2FA" boolean DEFAULT false NOT NULL,
    "allowClientUpload" boolean DEFAULT false NOT NULL,
    "clientUploadMaxSizeMB" integer DEFAULT 10 NOT NULL,
    "tenantId" text NOT NULL
);


ALTER TABLE public.tenant_settings OWNER TO lexdoc_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    "legalName" text,
    siret text,
    address text,
    "postalCode" text,
    city text,
    country text DEFAULT 'FR'::text NOT NULL,
    phone text,
    email text NOT NULL,
    website text,
    logo text,
    "primaryColor" text DEFAULT '#0066ff'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "subscriptionTier" text DEFAULT 'TRIAL'::text NOT NULL,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    "maxClients" integer DEFAULT 100 NOT NULL,
    "maxStorage" bigint DEFAULT '5368709120'::bigint NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "subscribedAt" timestamp(3) without time zone
);


ALTER TABLE public.tenants OWNER TO lexdoc_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: lexdoc_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    avatar text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    permissions jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "resetToken" text,
    "resetTokenExpiresAt" timestamp(3) without time zone,
    "tenantId" text NOT NULL
);


ALTER TABLE public.users OWNER TO lexdoc_user;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
df614b84-63b5-4bb7-acb3-705677064d8c	c3975f490877fbbe544867ca743a67c9e6ee63f8c45786aab9149392fbc41cab	2026-02-03 17:36:28.361432+00	20260203173628_init	\N	\N	2026-02-03 17:36:28.169949+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.audit_logs (id, "createdAt", action, "entityType", "entityId", changes, metadata, "userId", "ipAddress", "userAgent", "tenantId") FROM stdin;
\.


--
-- Data for Name: client_consents; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.client_consents (id, "createdAt", "clientId", type, granted, "grantedAt", "ipAddress", "userAgent") FROM stdin;
cml6vyl0r0009jms2v73bxbzx	2026-02-03 17:41:57.868	cml6vykuw0006jms2difazkpa	DATA_PROCESSING	t	2026-02-03 17:41:57.868	192.168.1.100	\N
cml6vyl0r000ajms2e0pu8hwu	2026-02-03 17:41:57.868	cml6vykuw0006jms2difazkpa	EMAIL_NOTIFICATIONS	t	2026-02-03 17:41:57.868	192.168.1.100	\N
cml6vyl0r000bjms2rvuggnqr	2026-02-03 17:41:57.868	cml6vyl0p0008jms2dt1u0gp1	DATA_PROCESSING	t	2026-02-03 17:41:57.868	192.168.1.101	\N
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.clients (id, "createdAt", "updatedAt", type, "firstName", "lastName", "birthDate", "companyName", siret, "vatNumber", email, phone, mobile, address, "addressLine2", "postalCode", city, country, "hasExternet", "extranetPassword", "extranetActivatedAt", "extranetLastLoginAt", "invitationToken", "invitationSentAt", "invitationExpiresAt", "isActive", notes, "tenantId") FROM stdin;
cml6vykuw0006jms2difazkpa	2026-02-03 17:41:57.657	2026-02-03 17:41:57.657	COMPANY	\N	\N	\N	Tech Corp SAS	98765432100012	\N	jean.dupont@techcorp.fr	01 23 45 67 89	\N	456 Avenue de la Tech	\N	75001	Paris	FR	t	$2b$12$sR8AP6dslrQvCMFA60H5NePCJ7KenwISMAs9W58Y1LXRKyQcagv3q	2026-02-03 17:41:57.656	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27
cml6vyl0p0008jms2dt1u0gp1	2026-02-03 17:41:57.865	2026-02-03 17:41:57.865	INDIVIDUAL	Marie	Durand	\N	\N	\N	\N	marie.durand@email.fr	06 12 34 56 78	\N	789 Rue des Fleurs	\N	49100	Angers	FR	t	$2b$12$UTgWyiWCdi4/nw4xSO5cv.E.dhLPpMwNd5915A8JAh6vCzSdoCb0q	2026-02-03 17:41:57.864	\N	\N	\N	\N	t	\N	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.documents (id, "createdAt", "updatedAt", name, description, type, category, tags, filename, "originalName", "mimeType", size, checksum, "bucketName", "objectKey", "isEncrypted", version, "parentId", status, "requiresSignature", "signatureDeadline", "validFrom", "validUntil", "archivedAt", "deletedAt", "folderId", "createdById", "tenantId") FROM stdin;
cml6vyl13000jjms232792l1y	2026-02-03 17:41:57.879	2026-02-03 17:41:57.879	Protocole de cession - Tech Corp	\N	CONTRACT	\N	{}	protocole-cession-techcorp.pdf	Protocole de cession.pdf	application/pdf	2516582	abc123def456	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/protocole-cession-techcorp.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-08 17:41:57.878	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml6vyl17000ljms2xfzrqdbk	2026-02-03 17:41:57.883	2026-02-03 17:41:57.883	Acte de garantie d'actif et de passif	\N	DEED	\N	{}	acte-garantie-gap.pdf	GAP.pdf	application/pdf	1874329	def789ghi012	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/acte-garantie-gap.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-10 17:41:57.883	\N	\N	\N	\N	cml6vyl0v000djms25rbug5x8	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml6vyl19000njms2iu9iuwvv	2026-02-03 17:41:57.885	2026-02-03 17:41:57.885	Contrat de conseil juridique 2026	\N	CONTRACT	\N	{}	contrat-conseil-2026.pdf	Contrat conseil.pdf	application/pdf	987654	ghi345jkl678	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/contrat-conseil-2026.pdf	t	1	\N	SIGNED	t	\N	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml6vyl1b000pjms2707bomdj	2026-02-03 17:41:57.887	2026-02-03 17:41:57.887	Attestation de livraison - Matériel informatique	\N	CERTIFICATE	\N	{}	attestation-livraison.pdf	Attestation.pdf	application/pdf	654321	jkl901mno234	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/attestation-livraison.pdf	t	1	\N	SENT	f	\N	\N	\N	\N	\N	cml6vyl11000hjms2krxzvmzx	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml6vyl1d000rjms21ti62wqk	2026-02-03 17:41:57.889	2026-02-03 17:41:57.889	Avenant contrat commercial n°3	\N	AMENDMENT	\N	{}	avenant-3.pdf	Avenant 3.pdf	application/pdf	456789	mno567pqr890	lexdoc-dev	cml6vykdd0000jms2wwxl9s27/documents/avenant-3.pdf	t	1	\N	PENDING_SIGNATURE	t	2026-02-04 17:41:57.888	\N	\N	\N	\N	cml6vyl0z000fjms24ukfhi3k	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: folder_templates; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folder_templates (id, "createdAt", "updatedAt", name, description, "folderType", structure, "tenantId") FROM stdin;
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.folders (id, "createdAt", "updatedAt", reference, title, description, type, status, "openedAt", "closedAt", "archivedAt", "clientId", "createdById", "tenantId") FROM stdin;
cml6vyl0v000djms25rbug5x8	2026-02-03 17:41:57.872	2026-02-03 17:41:57.872	2026-001	Cession entreprise Tech Corp	Dossier de cession de parts sociales Tech Corp SAS	BUSINESS	IN_PROGRESS	2026-02-03 17:41:57.872	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml6vyl0z000fjms24ukfhi3k	2026-02-03 17:41:57.876	2026-02-03 17:41:57.876	2026-002	Contrats commerciaux	Rédaction contrats fournisseurs	CONTRACT	OPEN	2026-02-03 17:41:57.876	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
cml6vyl11000hjms2krxzvmzx	2026-02-03 17:41:57.877	2026-02-03 17:41:57.877	2026-003	Litige fournisseur	Contentieux livraison matériel informatique	LITIGATION	IN_PROGRESS	2026-02-03 17:41:57.877	\N	\N	cml6vykuw0006jms2difazkpa	cml6vykja0002jms2hhr4hfr3	cml6vykdd0000jms2wwxl9s27
\.


--
-- Data for Name: registered_mails; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.registered_mails (id, "createdAt", "updatedAt", "documentId", "recipientName", "recipientAddress", "recipientCity", "recipientPostalCode", "recipientCountry", "sendingBoxId", "trackingNumber", status, "sentAt", "deliveredAt", "returnedAt", "proofUrl", cost) FROM stdin;
cml6vyl1p0014jms2af8xdbue	2026-02-03 17:41:57.902	2026-02-03 17:41:57.902	cml6vyl1b000pjms2707bomdj	Fournisseur Tech SARL	123 Rue du Commerce	Lyon	69001	FR	\N	FR123456789	IN_TRANSIT	2026-02-01 17:41:57.901	\N	\N	\N	\N
\.


--
-- Data for Name: signature_reminders; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signature_reminders (id, "createdAt", "signatureId", "reminderNumber", "sentAt", "emailSent", "smsSent") FROM stdin;
cml6vyl1m0010jms2uk36e2zy	2026-02-03 17:41:57.898	cml6vyl1e000tjms2oi4th11h	1	2026-02-01 17:41:57.898	t	f
cml6vyl1m0011jms26zxu8vli	2026-02-03 17:41:57.898	cml6vyl1e000tjms2oi4th11h	2	2026-02-02 17:41:57.898	t	f
cml6vyl1m0012jms29qtoymzb	2026-02-03 17:41:57.898	cml6vyl1i000vjms2rmc6urqc	1	2026-02-02 17:41:57.898	t	f
\.


--
-- Data for Name: signatures; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.signatures (id, "createdAt", "updatedAt", "documentId", "signerEmail", "signerName", "signerType", "transactionId", "signatureUrl", status, "invitedAt", "signedAt", "refusedAt", "expiredAt", "certificateUrl") FROM stdin;
cml6vyl1e000tjms2oi4th11h	2026-02-03 17:41:57.891	2026-02-03 17:41:57.891	cml6vyl13000jjms232792l1y	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-01-29 17:41:57.89	\N	\N	\N	\N
cml6vyl1i000vjms2rmc6urqc	2026-02-03 17:41:57.894	2026-02-03 17:41:57.894	cml6vyl17000ljms2xfzrqdbk	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-01-31 17:41:57.893	\N	\N	\N	\N
cml6vyl1j000xjms2aikx8iv1	2026-02-03 17:41:57.896	2026-02-03 17:41:57.896	cml6vyl19000njms2iu9iuwvv	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	SIGNED	2026-01-16 17:41:57.895	2026-01-19 17:41:57.895	\N	\N	\N
cml6vyl1l000zjms2xq80j8mr	2026-02-03 17:41:57.897	2026-02-03 17:41:57.897	cml6vyl1d000rjms21ti62wqk	jean.dupont@techcorp.fr	Jean Dupont	CLIENT	\N	\N	PENDING	2026-02-03 11:41:57.896	\N	\N	\N	\N
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.tenant_settings (id, "createdAt", "updatedAt", "enableReminders", "reminderSchedule", "maxReminders", "defaultSignatureDeadlineDays", "emailFromName", "emailReplyTo", "emailSignature", "lrarSenderName", "lrarSenderAddress", "documentRetentionYears", "autoArchiveClosedFolders", "autoArchiveAfterDays", "enforceStrongPasswords", "sessionTimeoutMinutes", "require2FA", "allowClientUpload", "clientUploadMaxSizeMB", "tenantId") FROM stdin;
cml6vyl1t0016jms240uih3kh	2026-02-03 17:41:57.905	2026-02-03 17:41:57.905	t	1,3,5	3	7	Cabinet Pragmavox	contact@pragmavox.fr	\N	\N	\N	10	f	365	t	480	f	f	10	cml6vykdd0000jms2wwxl9s27
cml6vyl7s001bjms2x4pqt7mo	2026-02-03 17:41:58.12	2026-02-03 17:41:58.12	t	1,3,5	3	7	\N	\N	\N	\N	\N	10	f	365	t	480	f	f	10	cml6vyl1v0017jms2uzfefv85
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.tenants (id, "createdAt", "updatedAt", name, "legalName", siret, address, "postalCode", city, country, phone, email, website, logo, "primaryColor", "isActive", "subscriptionTier", "maxUsers", "maxClients", "maxStorage", "trialEndsAt", "subscribedAt") FROM stdin;
cml6vykdd0000jms2wwxl9s27	2026-02-03 17:41:57.026	2026-02-03 17:41:57.026	Cabinet Pragmavox	Cabinet Pragmavox Avocat	12345678900011	123 Rue de la Paix	49000	Angers	FR	02 41 00 00 00	contact@pragmavox.fr	https://pragmavox.fr	\N	#0066ff	t	PRO	5	100	5368709120	\N	\N
cml6vyl1v0017jms2uzfefv85	2026-02-03 17:41:57.908	2026-02-03 17:41:57.908	Cabinet Juridicom	Cabinet Juridicom & Associés	98765432100013	\N	\N	\N	FR	\N	contact@juridicom.fr	\N	\N	#0066ff	t	BASIC	5	100	5368709120	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lexdoc_user
--

COPY public.users (id, "createdAt", "updatedAt", email, password, "firstName", "lastName", phone, avatar, role, permissions, "isActive", "isEmailVerified", "emailVerifiedAt", "lastLoginAt", "resetToken", "resetTokenExpiresAt", "tenantId") FROM stdin;
cml6vykp40004jms2d2rnfrpm	2026-02-03 17:41:57.449	2026-02-03 17:41:57.449	assistant@pragmavox.fr	$2b$12$X04CXAF5kKlOVApw208cy.btG8k9PsUrTXUo1RUYdnytgEiAvLrf2	Sophie	Martin	\N	\N	ASSISTANT	\N	t	t	2026-02-03 17:41:57.448	\N	\N	\N	cml6vykdd0000jms2wwxl9s27
cml6vyl7q0019jms2mpbhvpm5	2026-02-03 17:41:58.118	2026-02-03 17:41:58.118	admin@juridicom.fr	$2b$12$oi3gWiJu07P.zzarhwQTX.V2Vu869ZzmqEeG2EyHXaGKaHtUXrfxy	Pierre	Legrand	\N	\N	ADMIN	\N	t	t	2026-02-03 17:41:58.117	\N	\N	\N	cml6vyl1v0017jms2uzfefv85
cml6vykja0002jms2hhr4hfr3	2026-02-03 17:41:57.238	2026-02-03 17:55:55.178	yves-marie.bienaime@pragmavox.fr	$2b$12$p1VevXVnTybDli3BCLSvGeslrpJw5/GqVeNZsog6jph447YHcDEou	Yves-Marie	Bienaimé	\N	\N	ADMIN	\N	t	t	2026-02-03 17:41:57.237	2026-02-03 17:55:55.177	\N	\N	cml6vykdd0000jms2wwxl9s27
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: client_consents client_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_consents
    ADD CONSTRAINT client_consents_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: folder_templates folder_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_templates
    ADD CONSTRAINT folder_templates_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: registered_mails registered_mails_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.registered_mails
    ADD CONSTRAINT registered_mails_pkey PRIMARY KEY (id);


--
-- Name: signature_reminders signature_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_reminders
    ADD CONSTRAINT signature_reminders_pkey PRIMARY KEY (id);


--
-- Name: signatures signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT signatures_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_tenantId_idx" ON public.audit_logs USING btree ("tenantId");


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: client_consents_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "client_consents_clientId_idx" ON public.client_consents USING btree ("clientId");


--
-- Name: clients_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX clients_email_idx ON public.clients USING btree (email);


--
-- Name: clients_invitationToken_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_invitationToken_idx" ON public.clients USING btree ("invitationToken");


--
-- Name: clients_invitationToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "clients_invitationToken_key" ON public.clients USING btree ("invitationToken");


--
-- Name: clients_tenantId_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_tenantId_email_idx" ON public.clients USING btree ("tenantId", email);


--
-- Name: clients_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "clients_tenantId_idx" ON public.clients USING btree ("tenantId");


--
-- Name: documents_checksum_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX documents_checksum_idx ON public.documents USING btree (checksum);


--
-- Name: documents_folderId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_folderId_idx" ON public.documents USING btree ("folderId");


--
-- Name: documents_requiresSignature_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_requiresSignature_idx" ON public.documents USING btree ("requiresSignature");


--
-- Name: documents_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX documents_status_idx ON public.documents USING btree (status);


--
-- Name: documents_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "documents_tenantId_idx" ON public.documents USING btree ("tenantId");


--
-- Name: folder_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folder_templates_tenantId_idx" ON public.folder_templates USING btree ("tenantId");


--
-- Name: folders_clientId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_clientId_idx" ON public.folders USING btree ("clientId");


--
-- Name: folders_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX folders_status_idx ON public.folders USING btree (status);


--
-- Name: folders_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "folders_tenantId_idx" ON public.folders USING btree ("tenantId");


--
-- Name: folders_tenantId_reference_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "folders_tenantId_reference_key" ON public.folders USING btree ("tenantId", reference);


--
-- Name: registered_mails_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "registered_mails_documentId_idx" ON public.registered_mails USING btree ("documentId");


--
-- Name: registered_mails_sendingBoxId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "registered_mails_sendingBoxId_key" ON public.registered_mails USING btree ("sendingBoxId");


--
-- Name: registered_mails_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX registered_mails_status_idx ON public.registered_mails USING btree (status);


--
-- Name: registered_mails_trackingNumber_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "registered_mails_trackingNumber_idx" ON public.registered_mails USING btree ("trackingNumber");


--
-- Name: registered_mails_trackingNumber_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "registered_mails_trackingNumber_key" ON public.registered_mails USING btree ("trackingNumber");


--
-- Name: signature_reminders_signatureId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signature_reminders_signatureId_idx" ON public.signature_reminders USING btree ("signatureId");


--
-- Name: signatures_documentId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_documentId_idx" ON public.signatures USING btree ("documentId");


--
-- Name: signatures_signerEmail_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_signerEmail_idx" ON public.signatures USING btree ("signerEmail");


--
-- Name: signatures_status_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX signatures_status_idx ON public.signatures USING btree (status);


--
-- Name: signatures_transactionId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "signatures_transactionId_idx" ON public.signatures USING btree ("transactionId");


--
-- Name: signatures_transactionId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "signatures_transactionId_key" ON public.signatures USING btree ("transactionId");


--
-- Name: tenant_settings_tenantId_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "tenant_settings_tenantId_key" ON public.tenant_settings USING btree ("tenantId");


--
-- Name: tenants_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX tenants_email_idx ON public.tenants USING btree (email);


--
-- Name: tenants_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX tenants_email_key ON public.tenants USING btree (email);


--
-- Name: tenants_siret_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX tenants_siret_idx ON public.tenants USING btree (siret);


--
-- Name: tenants_siret_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX tenants_siret_key ON public.tenants USING btree (siret);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_resetToken_key; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE UNIQUE INDEX "users_resetToken_key" ON public.users USING btree ("resetToken");


--
-- Name: users_tenantId_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "users_tenantId_idx" ON public.users USING btree ("tenantId");


--
-- Name: users_tenantId_role_idx; Type: INDEX; Schema: public; Owner: lexdoc_user
--

CREATE INDEX "users_tenantId_role_idx" ON public.users USING btree ("tenantId", role);


--
-- Name: audit_logs audit_logs_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: client_consents client_consents_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.client_consents
    ADD CONSTRAINT "client_consents_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: clients clients_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT "clients_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: documents documents_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder_templates folder_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folder_templates
    ADD CONSTRAINT "folder_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folders folders_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: folders folders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: folders folders_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT "folders_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: registered_mails registered_mails_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.registered_mails
    ADD CONSTRAINT "registered_mails_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: signature_reminders signature_reminders_signatureId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signature_reminders
    ADD CONSTRAINT "signature_reminders_signatureId_fkey" FOREIGN KEY ("signatureId") REFERENCES public.signatures(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: signatures signatures_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT "signatures_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT "tenant_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lexdoc_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict eNGUW01yP0q9pGchrQiqrQlBE4pUBb8uciKsgVtOa3Nr8cIdjsOHcHackH6xNlo

